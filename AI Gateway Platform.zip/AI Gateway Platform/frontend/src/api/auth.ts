import { get, post } from './request'

export interface UserVO {
  id: number
  username: string
  email: string
  phone?: string
  role: string
  companyId?: number
  status: string
  createdAt?: string
}

export interface LoginPayload {
  username: string
  password: string
}

export interface LoginResult {
  accessToken: string
  refreshToken: string
  user: UserVO
}

export interface RegisterPayload {
  username: string
  email: string
  password: string
  code: string
  companyName?: string
}

export interface SendCodePayload {
  email: string
  scene?: 'register' | 'reset'
}

export interface RefreshResult {
  accessToken: string
  refreshToken: string
}

export const authApi = {
  login: (data: LoginPayload) => post<LoginResult>('/api/auth/login', data),
  register: (data: RegisterPayload) =>
    post<LoginResult>('/api/auth/register', data),
  sendCode: (data: SendCodePayload) =>
    post<void>('/api/auth/send-code', data),
  refresh: (refreshToken: string) =>
    post<RefreshResult>('/api/auth/refresh', { refreshToken }),
  logout: () => post<void>('/api/auth/logout'),
  me: () => get<UserVO>('/api/auth/me'),
}
