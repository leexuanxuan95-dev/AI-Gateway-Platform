import axios, {
  type AxiosInstance,
  type AxiosRequestConfig,
  type AxiosResponse,
  type InternalAxiosRequestConfig,
} from 'axios'
import { ElMessage } from 'element-plus'
import type { ApiEnvelope } from './types'

/**
 * Axios instance.
 * baseURL is '/' — concrete paths ('/api/...') live in the api modules so the
 * same instance can also reach the '/v1' surface if ever needed for tooling.
 */
const service: AxiosInstance = axios.create({
  baseURL: '/',
  timeout: 30_000,
})

// Lazily import the auth store to avoid a circular dependency at module load.
async function readAuth(): Promise<{ token: string | null }> {
  const { useAuthStore } = await import('@/stores/auth')
  const store = useAuthStore()
  return { token: store.token }
}

// --- Request interceptor: attach Bearer token ------------------------------
service.interceptors.request.use(
  async (config: InternalAxiosRequestConfig) => {
    const { token } = await readAuth()
    if (token) {
      config.headers = config.headers ?? {}
      config.headers.Authorization = `Bearer ${token}`
    }
    return config
  },
  (error) => Promise.reject(error),
)

// --- Response interceptor: unwrap envelope, handle errors -------------------
service.interceptors.response.use(
  (response: AxiosResponse<ApiEnvelope>) => {
    const envelope = response.data
    // Some endpoints (e.g. blobs) may not use the envelope.
    if (envelope == null || typeof envelope !== 'object' || !('code' in envelope)) {
      return response
    }
    if (envelope.code === 0) {
      // Unwrap: callers receive `data` directly.
      return envelope.data as unknown as AxiosResponse
    }
    const message = envelope.msg || 'Request failed'
    ElMessage.error(message)
    return Promise.reject(new ApiError(envelope.code, message))
  },
  async (error) => {
    const status = error?.response?.status
    if (status === 401) {
      await handleUnauthorized()
      return Promise.reject(new ApiError(401, 'Unauthorized'))
    }
    const message =
      error?.response?.data?.msg || error?.message || 'Network error'
    ElMessage.error(message)
    return Promise.reject(error)
  },
)

let redirecting = false
async function handleUnauthorized(): Promise<void> {
  if (redirecting) return
  redirecting = true
  try {
    const { useAuthStore } = await import('@/stores/auth')
    useAuthStore().clear()
    ElMessage.error('Session expired, please sign in again')
    const next = encodeURIComponent(
      window.location.pathname + window.location.search,
    )
    // Hard redirect keeps it simple and breaks any in-flight component state.
    window.location.assign(`/login?redirect=${next}`)
  } finally {
    // Allow future 401s after navigation settles.
    setTimeout(() => (redirecting = false), 1000)
  }
}

export class ApiError extends Error {
  code: number
  constructor(code: number, message: string) {
    super(message)
    this.name = 'ApiError'
    this.code = code
  }
}

/**
 * Typed request helper. Returns the unwrapped `data` of the envelope.
 *
 * @example const user = await request<UserVO>({ url: '/api/auth/me' })
 */
export function request<T = unknown>(config: AxiosRequestConfig): Promise<T> {
  return service.request<unknown, T>(config)
}

// Sugar helpers ------------------------------------------------------------
export function get<T = unknown>(
  url: string,
  params?: object,
  config?: AxiosRequestConfig,
): Promise<T> {
  return request<T>({ ...config, method: 'GET', url, params })
}

export function post<T = unknown>(
  url: string,
  data?: unknown,
  config?: AxiosRequestConfig,
): Promise<T> {
  return request<T>({ ...config, method: 'POST', url, data })
}

export function put<T = unknown>(
  url: string,
  data?: unknown,
  config?: AxiosRequestConfig,
): Promise<T> {
  return request<T>({ ...config, method: 'PUT', url, data })
}

export function del<T = unknown>(
  url: string,
  config?: AxiosRequestConfig,
): Promise<T> {
  return request<T>({ ...config, method: 'DELETE', url })
}

export default service
