import { get, post, put, del } from './request'
import type { PageQuery, PageResult } from './types'

export interface Plan {
  id: number
  name: string
  description?: string
  // Monthly price.
  price: number
  currency: string
  // Quotas / limits.
  monthlyQuota?: number
  rateLimitRpm?: number
  // Pricing markup discount (%) applied for this plan.
  markupDiscount?: number
  enabled: boolean
  createdAt?: string
}

export const planApi = {
  list: (params?: PageQuery) => get<PageResult<Plan>>('/api/plan', params),
  get: (id: number) => get<Plan>(`/api/plan/${id}`),
  create: (data: Partial<Plan>) => post<Plan>('/api/plan', data),
  update: (id: number, data: Partial<Plan>) =>
    put<Plan>(`/api/plan/${id}`, data),
  remove: (id: number) => del<void>(`/api/plan/${id}`),
  toggle: (id: number, enabled: boolean) =>
    put<void>(`/api/plan/${id}/enabled`, { enabled }),
}
