import { get } from './request'

export interface DashboardStats {
  // Total API calls (e.g. last 24h).
  totalCalls: number
  callsTrend?: number // % vs previous period
  // Revenue (period).
  revenue: number
  revenueTrend?: number
  currency?: string
  // Active companies.
  activeCompanies: number
  // Channel health summary.
  channelsHealthy: number
  channelsTotal: number
}

export interface TimeSeriesPoint {
  ts: string
  value: number
}

export const dashboardApi = {
  stats: () => get<DashboardStats>('/api/dashboard/stats'),
  callsSeries: (params?: { range?: '24h' | '7d' | '30d' }) =>
    get<TimeSeriesPoint[]>('/api/dashboard/calls-series', params),
  revenueSeries: (params?: { range?: '24h' | '7d' | '30d' }) =>
    get<TimeSeriesPoint[]>('/api/dashboard/revenue-series', params),
}
