import { get, put } from './request'

/** Supported payment channel codes (design doc §10.2.x). */
export type PayChannelCode =
  | 'stripe'
  | 'alipay'
  | 'wechat'
  | 'usdt_trc20'
  | 'usdt_erc20'

export type ExchangeMode = 'fixed' | 'realtime'
export type ConfirmType = 'webhook' | 'blocks'
export type PayEnv = 'sandbox' | 'production'

/**
 * Payment channel config (pay_channel_config). Credentials are masked when
 * returned from the backend; only changed (non-masked) values are sent back.
 */
export interface PayChannelConfig {
  code: PayChannelCode
  name: string
  enabled: boolean
  // Masked credential preview, e.g. "sk_live_****abcd".
  credentialsMasked?: Record<string, string>
  feeRate?: number // percentage
  minAmount?: number
  maxAmount?: number
  currencies?: string[]
  exchangeMode?: ExchangeMode
  // For crypto: confirmation type and required block confirmations.
  confirmType?: ConfirmType
  confirmBlocks?: number
  env?: PayEnv
  updatedAt?: string
}

/** Payload to update a channel's config (only include fields being changed). */
export interface PayChannelConfigUpdate {
  enabled?: boolean
  // Raw (unmasked) credential values keyed by field name; omit unchanged ones.
  credentials?: Record<string, string>
  feeRate?: number
  minAmount?: number
  maxAmount?: number
  currencies?: string[]
  exchangeMode?: ExchangeMode
  confirmType?: ConfirmType
  confirmBlocks?: number
  env?: PayEnv
}

/** Slim view returned to consumers (e.g. recharge page) — enabled only. */
export interface EnabledPayChannel {
  code: PayChannelCode
  name: string
  currencies?: string[]
  minAmount?: number
  maxAmount?: number
  feeRate?: number
}

export const payApi = {
  // Admin config center: full list incl. masked credentials.
  configs: () => get<PayChannelConfig[]>('/api/pay/config'),
  updateConfig: (code: PayChannelCode, data: PayChannelConfigUpdate) =>
    put<PayChannelConfig>(`/api/pay/config/${code}`, data),
  // Consumer-facing: only ENABLED channels (used by Recharge.vue).
  enabledChannels: () => get<EnabledPayChannel[]>('/api/pay/channels'),
}
