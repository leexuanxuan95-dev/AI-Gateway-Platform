import { get, post, del } from './request'
import type { PageQuery, PageResult } from './types'

export interface ApiKey {
  id: number
  projectId: number
  name: string
  // Only a masked preview (e.g. "sk-...abcd") is ever returned by list/get.
  keyPreview: string
  status: 'active' | 'revoked'
  lastUsedAt?: string
  createdAt?: string
  expiresAt?: string
}

export interface CreateApiKeyPayload {
  projectId: number
  name: string
  expiresAt?: string
}

/** Returned ONCE on creation — contains the raw secret. Never stored. */
export interface CreateApiKeyResult {
  id: number
  name: string
  rawKey: string
  keyPreview: string
}

export const apikeyApi = {
  list: (params?: PageQuery & { projectId?: number }) =>
    get<PageResult<ApiKey>>('/api/apikey', params),
  create: (data: CreateApiKeyPayload) =>
    post<CreateApiKeyResult>('/api/apikey', data),
  revoke: (id: number) => post<void>(`/api/apikey/${id}/revoke`),
  remove: (id: number) => del<void>(`/api/apikey/${id}`),
}
