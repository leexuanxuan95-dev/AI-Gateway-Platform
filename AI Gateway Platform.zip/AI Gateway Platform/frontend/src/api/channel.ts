import { get, post, put, del } from './request'
import type { PageQuery, PageResult } from './types'

export type ChannelHealth = 'healthy' | 'degraded' | 'circuit_open' | 'down'

/** Upstream provider channel (account) in the routing pool. §8. */
export interface Channel {
  id: number
  name: string
  provider: string
  // Routing weight within its priority group.
  weight: number
  priority: number
  enabled: boolean
  health: ChannelHealth
  // Upstream account balance (USD).
  upstreamBalance?: number
  // §8.3 low-balance alert threshold.
  balanceThreshold?: number
  // Circuit-breaker tuning.
  allowedFails?: number
  cooldownTime?: number
  // §8.4 reserve / auto-recharge config.
  reserveEnabled?: boolean
  reserveBalance?: number
  autoRechargeEnabled?: boolean
  autoRechargeAmount?: number
  // Optional per-channel quota / rate limit.
  quota?: number
  createdAt?: string
}

export interface ChannelReserveConfig {
  reserveEnabled: boolean
  reserveBalance?: number
  autoRechargeEnabled: boolean
  autoRechargeAmount?: number
  balanceThreshold?: number
}

export const channelApi = {
  list: (params?: PageQuery & { provider?: string }) =>
    get<PageResult<Channel>>('/api/channel', params),
  get: (id: number) => get<Channel>(`/api/channel/${id}`),
  create: (data: Partial<Channel>) => post<Channel>('/api/channel', data),
  update: (id: number, data: Partial<Channel>) =>
    put<Channel>(`/api/channel/${id}`, data),
  remove: (id: number) => del<void>(`/api/channel/${id}`),
  toggle: (id: number, enabled: boolean) =>
    put<void>(`/api/channel/${id}/enabled`, { enabled }),
  updateReserve: (id: number, data: ChannelReserveConfig) =>
    put<void>(`/api/channel/${id}/reserve`, data),
  // Half-open probe / reset circuit.
  probe: (id: number) => post<void>(`/api/channel/${id}/probe`),
}
