import { get, post, put, del } from './request'
import type { PageQuery, PageResult } from './types'

export type NotifyChannel = 'email' | 'sms' | 'webhook' | 'inapp'

export interface NotifyTemplate {
  id: number
  code: string
  name: string
  channel: NotifyChannel
  subject?: string
  content: string
  enabled: boolean
  updatedAt?: string
}

export interface NotifyLog {
  id: number
  templateCode: string
  channel: NotifyChannel
  target: string
  status: 'sent' | 'failed' | 'pending'
  error?: string
  createdAt: string
}

export const notifyApi = {
  templates: (params?: PageQuery) =>
    get<PageResult<NotifyTemplate>>('/api/notify/templates', params),
  createTemplate: (data: Partial<NotifyTemplate>) =>
    post<NotifyTemplate>('/api/notify/templates', data),
  updateTemplate: (id: number, data: Partial<NotifyTemplate>) =>
    put<NotifyTemplate>(`/api/notify/templates/${id}`, data),
  removeTemplate: (id: number) => del<void>(`/api/notify/templates/${id}`),
  logs: (params?: PageQuery & { channel?: NotifyChannel }) =>
    get<PageResult<NotifyLog>>('/api/notify/logs', params),
}
