import { get, post, put } from './request'
import type { PageQuery, PageResult } from './types'

/** Per design doc §7.1 / §7.5: model_version.availability. */
export type ModelAvailability = 'available' | 'maintenance' | 'unavailable'
/** Listing status: enabled / disabled (delisted). */
export type ModelStatus = 'enabled' | 'disabled'

export interface ModelFamily {
  id: number
  name: string
  provider: string
  description?: string
}

export interface ModelVersion {
  id: number
  familyId: number
  familyName?: string
  name: string
  provider: string
  // available / maintenance / unavailable
  availability: ModelAvailability
  // enabled / disabled (listed for sale or not)
  status: ModelStatus
  // Pricing (per 1M tokens, client-facing price).
  inputPrice?: number
  outputPrice?: number
  currency?: string
  contextWindow?: number
  pendingPrice?: boolean
  createdAt?: string
}

export interface ModelPricingPayload {
  inputPrice: number
  outputPrice: number
  currency?: string
}

export const modelApi = {
  families: () => get<ModelFamily[]>('/api/model/families'),
  versions: (params?: PageQuery & { familyId?: number }) =>
    get<PageResult<ModelVersion>>('/api/model/versions', params),
  get: (id: number) => get<ModelVersion>(`/api/model/versions/${id}`),
  updatePricing: (id: number, data: ModelPricingPayload) =>
    put<ModelVersion>(`/api/model/versions/${id}/pricing`, data),
  // List (enable) / delist (disable) a version.
  list: (id: number) => post<void>(`/api/model/versions/${id}/list`),
  delist: (id: number) => post<void>(`/api/model/versions/${id}/delist`),
  // Set availability: available / maintenance / unavailable.
  setAvailability: (id: number, availability: ModelAvailability) =>
    put<void>(`/api/model/versions/${id}/availability`, { availability }),
  // Trigger upstream model sync (ModelSyncJob on demand).
  sync: () => post<void>('/api/model/sync'),
}
