import { get, post, put, del } from './request'
import type { PageQuery, PageResult } from './types'
import type { UserVO } from './auth'

export interface UpsertUserPayload {
  username: string
  email: string
  phone?: string
  role: string
  companyId?: number
  password?: string
  status?: string
}

export const userApi = {
  list: (params?: PageQuery & { companyId?: number; role?: string }) =>
    get<PageResult<UserVO>>('/api/user', params),
  get: (id: number) => get<UserVO>(`/api/user/${id}`),
  create: (data: UpsertUserPayload) => post<UserVO>('/api/user', data),
  update: (id: number, data: Partial<UpsertUserPayload>) =>
    put<UserVO>(`/api/user/${id}`, data),
  remove: (id: number) => del<void>(`/api/user/${id}`),
  setStatus: (id: number, status: string) =>
    put<void>(`/api/user/${id}/status`, { status }),
}
