import { get, post } from './request'
import type { PageQuery, PageResult } from './types'
import type { PayChannelCode } from './pay'

export type TxnType = 'recharge' | 'consume' | 'withdraw' | 'refund' | 'adjust'
export type TxnStatus = 'pending' | 'success' | 'failed'

export interface Transaction {
  id: number
  companyId: number
  type: TxnType
  amount: number
  currency: string
  balanceAfter?: number
  status: TxnStatus
  orderNo?: string
  remark?: string
  createdAt: string
}

export interface RechargeOrderPayload {
  companyId?: number
  channel: PayChannelCode
  amount: number
  currency?: string
}

export interface RechargeOrderResult {
  orderNo: string
  // Redirect URL (Stripe Checkout / Alipay page) or QR payload for scan-pay.
  payUrl?: string
  qrCode?: string
  // For crypto: deposit address + expected amount.
  address?: string
  expireAt?: string
}

export interface WithdrawPayload {
  companyId?: number
  amount: number
  currency?: string
  account: string
  remark?: string
}

export interface ProfitReport {
  date: string
  revenue: number
  cost: number
  profit: number
  margin: number // profit / revenue
}

export const financeApi = {
  transactions: (
    params?: PageQuery & {
      type?: TxnType
      status?: TxnStatus
      companyId?: number
    },
  ) => get<PageResult<Transaction>>('/api/finance/transactions', params),

  // Recharge: caller picks an ENABLED channel (from payApi.enabledChannels).
  createRecharge: (data: RechargeOrderPayload) =>
    post<RechargeOrderResult>('/api/finance/recharge', data),

  queryOrder: (orderNo: string) =>
    get<Transaction>(`/api/finance/order/${orderNo}`),

  // Withdraw request.
  withdraw: (data: WithdrawPayload) =>
    post<Transaction>('/api/finance/withdraw', data),
  withdrawals: (params?: PageQuery & { status?: TxnStatus }) =>
    get<PageResult<Transaction>>('/api/finance/withdrawals', params),

  // Profit dashboard (ProfitReportJob output).
  profit: (params?: { from?: string; to?: string }) =>
    get<ProfitReport[]>('/api/finance/profit', params),
}
