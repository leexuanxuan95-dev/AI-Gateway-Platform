import { get, post, put, del } from './request'
import type { PageQuery, PageResult } from './types'

export interface Project {
  id: number
  companyId: number
  name: string
  description?: string
  status: 'active' | 'disabled'
  apiKeyCount?: number
  createdAt?: string
}

export const projectApi = {
  list: (params?: PageQuery & { companyId?: number }) =>
    get<PageResult<Project>>('/api/project', params),
  get: (id: number) => get<Project>(`/api/project/${id}`),
  create: (data: Partial<Project>) => post<Project>('/api/project', data),
  update: (id: number, data: Partial<Project>) =>
    put<Project>(`/api/project/${id}`, data),
  remove: (id: number) => del<void>(`/api/project/${id}`),
}
