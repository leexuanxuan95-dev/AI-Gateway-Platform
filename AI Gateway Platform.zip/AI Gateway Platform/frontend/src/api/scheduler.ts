import { get, put, post } from './request'

/** A runtime-managed scheduled job (design doc §15.5). */
export interface ScheduledJob {
  jobKey: string
  jobName: string
  cron: string
  enabled: boolean
  description?: string
  lastRunAt?: string
  lastStatus?: 'running' | 'success' | 'fail'
  lastDurationMs?: number
  lastError?: string
  scheduled?: boolean
  nextRunAt?: string
}

export interface JobUpdate {
  cron?: string
  enabled?: boolean
}

/** List all managed jobs (super-admin). */
export function listJobs() {
  return get<ScheduledJob[]>('/api/admin/jobs')
}

/** Change a job's cron and/or enabled state (applied live). */
export function updateJob(jobKey: string, body: JobUpdate) {
  return put<ScheduledJob>(`/api/admin/jobs/${jobKey}`, body)
}

/** Trigger a job immediately. */
export function runJob(jobKey: string) {
  return post<void>(`/api/admin/jobs/${jobKey}/run`)
}
