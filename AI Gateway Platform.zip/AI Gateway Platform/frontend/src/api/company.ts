import { get, post, put, del } from './request'
import type { PageQuery, PageResult } from './types'

export type CompanyStatus = 'active' | 'pending' | 'suspended' | 'rejected'

export interface Company {
  id: number
  name: string
  contactName?: string
  contactEmail?: string
  contactPhone?: string
  status: CompanyStatus
  balance?: number
  createdAt?: string
}

export interface CompanyAuditPayload {
  id: number
  approved: boolean
  reason?: string
}

export const companyApi = {
  list: (params?: PageQuery & { status?: CompanyStatus }) =>
    get<PageResult<Company>>('/api/company', params),
  get: (id: number) => get<Company>(`/api/company/${id}`),
  create: (data: Partial<Company>) => post<Company>('/api/company', data),
  update: (id: number, data: Partial<Company>) =>
    put<Company>(`/api/company/${id}`, data),
  remove: (id: number) => del<void>(`/api/company/${id}`),
  // Audit queue (pending companies awaiting approval).
  pending: (params?: PageQuery) =>
    get<PageResult<Company>>('/api/company/pending', params),
  audit: (data: CompanyAuditPayload) =>
    post<void>(`/api/company/${data.id}/audit`, data),
}
