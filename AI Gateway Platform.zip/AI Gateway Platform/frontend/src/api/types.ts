// Shared API types.

/** Backend response envelope: code 0 = success. */
export interface ApiEnvelope<T = unknown> {
  code: number
  msg: string
  data: T
}

/** Generic paginated list result. */
export interface PageResult<T> {
  list: T[]
  total: number
  page: number
  pageSize: number
}

/** Common pagination query params. */
export interface PageQuery {
  page?: number
  pageSize?: number
  keyword?: string
}
