import { get } from './request'
import type { PageQuery, PageResult } from './types'

export interface CallLog {
  id: number
  companyId: number
  projectId?: number
  apiKeyId?: number
  model: string
  channel?: string
  status: number // HTTP-ish status (200 / 429 / 502 ...)
  promptTokens: number
  completionTokens: number
  totalTokens: number
  latencyMs?: number
  cost?: number
  price?: number
  createdAt: string
}

export interface TokenBillRow {
  period: string // e.g. '2026-06' or '2026-06-18'
  companyId: number
  companyName?: string
  model: string
  calls: number
  promptTokens: number
  completionTokens: number
  totalTokens: number
  cost: number
  revenue: number
}

export const billingApi = {
  callLogs: (
    params?: PageQuery & {
      companyId?: number
      model?: string
      status?: number
      from?: string
      to?: string
    },
  ) => get<PageResult<CallLog>>('/api/billing/call-logs', params),

  tokenBills: (
    params?: PageQuery & {
      companyId?: number
      from?: string
      to?: string
      groupBy?: 'day' | 'month'
    },
  ) => get<PageResult<TokenBillRow>>('/api/billing/token-bills', params),
}
