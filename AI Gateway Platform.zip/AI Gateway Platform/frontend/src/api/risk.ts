import { get, post, put, del } from './request'
import type { PageQuery, PageResult } from './types'

export type RiskRuleType =
  | 'rate_limit'
  | 'spend_limit'
  | 'geo_block'
  | 'keyword'
  | 'concurrency'

export interface RiskRule {
  id: number
  name: string
  type: RiskRuleType
  // Free-form config (threshold/window/etc.) — typed per rule on the backend.
  config: Record<string, unknown>
  action: 'block' | 'throttle' | 'alert'
  enabled: boolean
  createdAt?: string
}

export type BlacklistKind = 'ip' | 'apikey' | 'company' | 'email'

export interface BlacklistEntry {
  id: number
  kind: BlacklistKind
  value: string
  reason?: string
  expireAt?: string
  createdAt?: string
}

export const riskApi = {
  rules: (params?: PageQuery) =>
    get<PageResult<RiskRule>>('/api/risk/rules', params),
  createRule: (data: Partial<RiskRule>) =>
    post<RiskRule>('/api/risk/rules', data),
  updateRule: (id: number, data: Partial<RiskRule>) =>
    put<RiskRule>(`/api/risk/rules/${id}`, data),
  toggleRule: (id: number, enabled: boolean) =>
    put<void>(`/api/risk/rules/${id}/enabled`, { enabled }),
  removeRule: (id: number) => del<void>(`/api/risk/rules/${id}`),

  blacklist: (params?: PageQuery & { kind?: BlacklistKind }) =>
    get<PageResult<BlacklistEntry>>('/api/risk/blacklist', params),
  addBlacklist: (data: Partial<BlacklistEntry>) =>
    post<BlacklistEntry>('/api/risk/blacklist', data),
  removeBlacklist: (id: number) => del<void>(`/api/risk/blacklist/${id}`),
}
