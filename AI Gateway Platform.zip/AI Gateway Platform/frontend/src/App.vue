<script setup lang="ts">
// Root component — just hosts the router outlet.
</script>

<template>
  <router-view />
</template>
