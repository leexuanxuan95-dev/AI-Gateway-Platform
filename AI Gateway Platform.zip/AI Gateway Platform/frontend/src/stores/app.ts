import { defineStore } from 'pinia'
import type { Company } from '@/api/company'

const SIDEBAR_KEY = 'aigw_sidebar_collapsed'
const COMPANY_KEY = 'aigw_current_company'

function loadCompany(): Company | null {
  const raw = localStorage.getItem(COMPANY_KEY)
  if (!raw) return null
  try {
    return JSON.parse(raw) as Company
  } catch {
    return null
  }
}

interface AppState {
  sidebarCollapsed: boolean
  currentCompany: Company | null
}

export const useAppStore = defineStore('app', {
  state: (): AppState => ({
    sidebarCollapsed: localStorage.getItem(SIDEBAR_KEY) === '1',
    currentCompany: loadCompany(),
  }),

  getters: {
    currentCompanyId: (s): number | undefined => s.currentCompany?.id,
  },

  actions: {
    toggleSidebar() {
      this.sidebarCollapsed = !this.sidebarCollapsed
      localStorage.setItem(SIDEBAR_KEY, this.sidebarCollapsed ? '1' : '0')
    },
    setCurrentCompany(company: Company | null) {
      this.currentCompany = company
      if (company) localStorage.setItem(COMPANY_KEY, JSON.stringify(company))
      else localStorage.removeItem(COMPANY_KEY)
    },
  },
})
