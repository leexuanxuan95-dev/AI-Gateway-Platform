import { defineStore } from 'pinia'
import {
  authApi,
  type LoginPayload,
  type UserVO,
} from '@/api/auth'

const TOKEN_KEY = 'aigw_access_token'
const REFRESH_KEY = 'aigw_refresh_token'
const USER_KEY = 'aigw_user'

function loadUser(): UserVO | null {
  const raw = localStorage.getItem(USER_KEY)
  if (!raw) return null
  try {
    return JSON.parse(raw) as UserVO
  } catch {
    return null
  }
}

interface AuthState {
  token: string | null
  refreshToken: string | null
  user: UserVO | null
}

export const useAuthStore = defineStore('auth', {
  state: (): AuthState => ({
    token: localStorage.getItem(TOKEN_KEY),
    refreshToken: localStorage.getItem(REFRESH_KEY),
    user: loadUser(),
  }),

  getters: {
    isAuthenticated: (s): boolean => !!s.token,
    username: (s): string => s.user?.username ?? '',
    role: (s): string => s.user?.role ?? '',
  },

  actions: {
    persist() {
      if (this.token) localStorage.setItem(TOKEN_KEY, this.token)
      else localStorage.removeItem(TOKEN_KEY)

      if (this.refreshToken)
        localStorage.setItem(REFRESH_KEY, this.refreshToken)
      else localStorage.removeItem(REFRESH_KEY)

      if (this.user) localStorage.setItem(USER_KEY, JSON.stringify(this.user))
      else localStorage.removeItem(USER_KEY)
    },

    async login(payload: LoginPayload) {
      const res = await authApi.login(payload)
      this.token = res.accessToken
      this.refreshToken = res.refreshToken
      this.user = res.user
      this.persist()
      return res
    },

    async fetchMe() {
      this.user = await authApi.me()
      this.persist()
      return this.user
    },

    async refresh() {
      if (!this.refreshToken) throw new Error('No refresh token')
      const res = await authApi.refresh(this.refreshToken)
      this.token = res.accessToken
      this.refreshToken = res.refreshToken
      this.persist()
      return res
    },

    /** Clear local session state (no API call). Used by the 401 handler. */
    clear() {
      this.token = null
      this.refreshToken = null
      this.user = null
      this.persist()
    },

    async logout() {
      try {
        await authApi.logout()
      } catch {
        // Ignore — clear local state regardless.
      } finally {
        this.clear()
      }
    },
  },
})
