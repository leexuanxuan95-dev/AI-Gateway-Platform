<script setup lang="ts">
import { onMounted, reactive, ref } from 'vue'
import { ElMessage } from 'element-plus'
import {
  payApi,
  type PayChannelConfig,
  type PayChannelConfigUpdate,
} from '@/api/pay'

const loading = ref(false)
const configs = ref<PayChannelConfig[]>([])

const editDialog = ref(false)
const editingCode = ref<PayChannelConfig['code'] | null>(null)
const editingName = ref('')

// Form mirrors the editable fields. `credentials` holds RAW values typed by the
// admin; empty fields are omitted on save so masked existing secrets are kept.
const form = reactive<{
  enabled: boolean
  feeRate: number
  minAmount: number
  maxAmount: number
  currencies: string[]
  exchangeMode: PayChannelConfig['exchangeMode']
  confirmType: PayChannelConfig['confirmType']
  confirmBlocks: number
  env: PayChannelConfig['env']
  credentials: Record<string, string>
}>({
  enabled: false,
  feeRate: 0,
  minAmount: 0,
  maxAmount: 0,
  currencies: [],
  exchangeMode: 'fixed',
  confirmType: 'webhook',
  confirmBlocks: 1,
  env: 'sandbox',
  credentials: {},
})

// Credential field names per channel (so we render the right inputs).
const credentialFields: Record<string, string[]> = {
  stripe: ['secretKey', 'webhookSecret'],
  alipay: ['appId', 'privateKey', 'alipayPublicKey'],
  wechat: ['mchId', 'apiV3Key', 'serialNo', 'privateKey'],
  usdt_trc20: ['walletAddress', 'apiKey'],
  usdt_erc20: ['walletAddress', 'apiKey'],
}

function isCrypto(code: string) {
  return code.startsWith('usdt_')
}

async function load() {
  loading.value = true
  try {
    configs.value = await payApi.configs()
  } catch {
    configs.value = []
  } finally {
    loading.value = false
  }
}

function openEdit(c: PayChannelConfig) {
  editingCode.value = c.code
  editingName.value = c.name
  form.enabled = c.enabled
  form.feeRate = c.feeRate ?? 0
  form.minAmount = c.minAmount ?? 0
  form.maxAmount = c.maxAmount ?? 0
  form.currencies = c.currencies ?? []
  form.exchangeMode = c.exchangeMode ?? 'fixed'
  form.confirmType = c.confirmType ?? 'webhook'
  form.confirmBlocks = c.confirmBlocks ?? 1
  form.env = c.env ?? 'sandbox'
  // Pre-fill credential keys but NOT values — admin only enters new secrets.
  form.credentials = {}
  for (const f of credentialFields[c.code] ?? []) form.credentials[f] = ''
  editDialog.value = true
}

async function toggle(c: PayChannelConfig, enabled: boolean) {
  await payApi.updateConfig(c.code, { enabled })
  ElMessage.success(enabled ? 'Enabled' : 'Disabled')
  load()
}

async function save() {
  if (!editingCode.value) return
  // Only send non-empty (changed) credentials; masked ones stay untouched.
  const credentials: Record<string, string> = {}
  for (const [k, v] of Object.entries(form.credentials)) {
    if (v && v.trim()) credentials[k] = v.trim()
  }
  const payload: PayChannelConfigUpdate = {
    enabled: form.enabled,
    feeRate: form.feeRate,
    minAmount: form.minAmount,
    maxAmount: form.maxAmount,
    currencies: form.currencies,
    exchangeMode: form.exchangeMode,
    env: form.env,
    ...(Object.keys(credentials).length ? { credentials } : {}),
  }
  if (isCrypto(editingCode.value)) {
    payload.confirmType = form.confirmType
    payload.confirmBlocks = form.confirmBlocks
  }
  await payApi.updateConfig(editingCode.value, payload)
  ElMessage.success('Saved')
  editDialog.value = false
  load()
}

onMounted(load)
</script>

<template>
  <div class="page">
    <div class="page-header">
      <h2>Payment Channel Config</h2>
      <el-button :icon="'Refresh'" @click="load">Refresh</el-button>
    </div>

    <el-table :data="configs" v-loading="loading" border stripe>
      <el-table-column prop="name" label="Channel" width="160" />
      <el-table-column prop="code" label="Code" width="130">
        <template #default="{ row }"><code>{{ row.code }}</code></template>
      </el-table-column>
      <el-table-column label="Enabled" width="100">
        <template #default="{ row }">
          <el-switch
            :model-value="row.enabled"
            @change="(v: boolean) => toggle(row, v)"
          />
        </template>
      </el-table-column>
      <el-table-column label="Credentials" min-width="200">
        <template #default="{ row }">
          <span class="muted">
            <template v-if="row.credentialsMasked">
              {{
                Object.entries(row.credentialsMasked)
                  .map(([k, v]) => `${k}: ${v}`)
                  .join('  ')
              }}
            </template>
            <template v-else>not configured</template>
          </span>
        </template>
      </el-table-column>
      <el-table-column label="Fee %" width="90">
        <template #default="{ row }">{{ row.feeRate ?? '-' }}</template>
      </el-table-column>
      <el-table-column label="Env" width="120">
        <template #default="{ row }">
          <el-tag :type="row.env === 'production' ? 'danger' : 'info'" size="small">
            {{ row.env ?? 'sandbox' }}
          </el-tag>
        </template>
      </el-table-column>
      <el-table-column label="Actions" width="100" fixed="right">
        <template #default="{ row }">
          <el-button link type="primary" @click="openEdit(row)">Edit</el-button>
        </template>
      </el-table-column>
    </el-table>

    <el-dialog
      v-model="editDialog"
      :title="`Configure ${editingName}`"
      width="560px"
    >
      <el-form :model="form" label-width="150px">
        <el-form-item label="Enabled">
          <el-switch v-model="form.enabled" />
        </el-form-item>

        <el-divider content-position="left">Credentials</el-divider>
        <el-alert
          type="info"
          show-icon
          :closable="false"
          title="Leave a field blank to keep the existing (masked) secret."
          style="margin-bottom: 12px"
        />
        <el-form-item
          v-for="(_, field) in form.credentials"
          :key="field"
          :label="field"
        >
          <el-input
            v-model="form.credentials[field]"
            type="password"
            show-password
            placeholder="enter to replace"
          />
        </el-form-item>

        <el-divider content-position="left">Limits & fees</el-divider>
        <el-form-item label="Fee rate (%)">
          <el-input-number v-model="form.feeRate" :min="0" :step="0.1" />
        </el-form-item>
        <el-form-item label="Min amount">
          <el-input-number v-model="form.minAmount" :min="0" />
        </el-form-item>
        <el-form-item label="Max amount">
          <el-input-number v-model="form.maxAmount" :min="0" />
        </el-form-item>
        <el-form-item label="Currencies">
          <el-select
            v-model="form.currencies"
            multiple
            allow-create
            filterable
            default-first-option
            style="width: 100%"
          >
            <el-option label="USD" value="USD" />
            <el-option label="CNY" value="CNY" />
            <el-option label="EUR" value="EUR" />
            <el-option label="USDT" value="USDT" />
          </el-select>
        </el-form-item>
        <el-form-item label="Exchange mode">
          <el-radio-group v-model="form.exchangeMode">
            <el-radio value="fixed">Fixed</el-radio>
            <el-radio value="realtime">Realtime</el-radio>
          </el-radio-group>
        </el-form-item>

        <template v-if="editingCode && editingCode.startsWith('usdt_')">
          <el-divider content-position="left">Confirmation</el-divider>
          <el-form-item label="Confirm type">
            <el-radio-group v-model="form.confirmType">
              <el-radio value="webhook">Webhook</el-radio>
              <el-radio value="blocks">Block confirmations</el-radio>
            </el-radio-group>
          </el-form-item>
          <el-form-item label="Confirm blocks">
            <el-input-number v-model="form.confirmBlocks" :min="1" />
          </el-form-item>
        </template>

        <el-divider content-position="left">Environment</el-divider>
        <el-form-item label="Mode">
          <el-radio-group v-model="form.env">
            <el-radio value="sandbox">Sandbox</el-radio>
            <el-radio value="production">Production</el-radio>
          </el-radio-group>
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="editDialog = false">Cancel</el-button>
        <el-button type="primary" @click="save">Save</el-button>
      </template>
    </el-dialog>
  </div>
</template>
