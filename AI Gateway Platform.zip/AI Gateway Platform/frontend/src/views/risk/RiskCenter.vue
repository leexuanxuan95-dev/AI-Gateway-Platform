<script setup lang="ts">
import { onMounted, reactive, ref } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import {
  riskApi,
  type RiskRule,
  type RiskRuleType,
  type BlacklistEntry,
  type BlacklistKind,
} from '@/api/risk'

const activeTab = ref('rules')

/* ---------------- Rules ---------------- */
const rulesLoading = ref(false)
const rulesRows = ref<RiskRule[]>([])
const rulesTotal = ref(0)
const rulesQuery = reactive({ page: 1, pageSize: 10 })

const ruleDialogVisible = ref(false)
const ruleEditingId = ref<number | null>(null)
const ruleConfigText = ref('{}')
const ruleForm = reactive<{
  name: string
  type: RiskRuleType
  action: RiskRule['action']
  enabled: boolean
}>({
  name: '',
  type: 'rate_limit',
  action: 'block',
  enabled: true,
})

async function loadRules() {
  rulesLoading.value = true
  try {
    const res = await riskApi.rules(rulesQuery)
    rulesRows.value = res.list
    rulesTotal.value = res.total
  } catch {
    rulesRows.value = []
    rulesTotal.value = 0
  } finally {
    rulesLoading.value = false
  }
}

function openCreateRule() {
  ruleEditingId.value = null
  Object.assign(ruleForm, {
    name: '',
    type: 'rate_limit',
    action: 'block',
    enabled: true,
  })
  ruleConfigText.value = '{}'
  ruleDialogVisible.value = true
}

function openEditRule(row: RiskRule) {
  ruleEditingId.value = row.id
  Object.assign(ruleForm, {
    name: row.name,
    type: row.type,
    action: row.action,
    enabled: row.enabled,
  })
  ruleConfigText.value = JSON.stringify(row.config ?? {}, null, 2)
  ruleDialogVisible.value = true
}

async function saveRule() {
  let config: Record<string, unknown>
  try {
    config = JSON.parse(ruleConfigText.value) as Record<string, unknown>
  } catch {
    ElMessage.error('Config must be valid JSON')
    return
  }
  const payload: Partial<RiskRule> = { ...ruleForm, config }
  if (ruleEditingId.value == null) {
    await riskApi.createRule(payload)
    ElMessage.success('Rule created')
  } else {
    await riskApi.updateRule(ruleEditingId.value, payload)
    ElMessage.success('Rule updated')
  }
  ruleDialogVisible.value = false
  loadRules()
}

async function toggleRule(row: RiskRule, value: boolean) {
  try {
    await riskApi.toggleRule(row.id, value)
    ElMessage.success('Updated')
  } finally {
    loadRules()
  }
}

async function removeRule(row: RiskRule) {
  await ElMessageBox.confirm(`Delete rule "${row.name}"?`, 'Confirm', {
    type: 'warning',
  })
  await riskApi.removeRule(row.id)
  ElMessage.success('Deleted')
  loadRules()
}

function configPreview(config: Record<string, unknown>): string {
  const s = JSON.stringify(config ?? {})
  return s.length > 40 ? `${s.slice(0, 40)}…` : s
}

/* ---------------- Blacklist ---------------- */
const blLoading = ref(false)
const blRows = ref<BlacklistEntry[]>([])
const blTotal = ref(0)
const blQuery = reactive<{
  page: number
  pageSize: number
  kind?: BlacklistKind
}>({ page: 1, pageSize: 10, kind: undefined })

const blDialogVisible = ref(false)
const blForm = reactive<{
  kind: BlacklistKind
  value: string
  reason: string
  expireAt: string
}>({
  kind: 'ip',
  value: '',
  reason: '',
  expireAt: '',
})

async function loadBlacklist() {
  blLoading.value = true
  try {
    const res = await riskApi.blacklist(blQuery)
    blRows.value = res.list
    blTotal.value = res.total
  } catch {
    blRows.value = []
    blTotal.value = 0
  } finally {
    blLoading.value = false
  }
}

function openCreateBlacklist() {
  Object.assign(blForm, {
    kind: 'ip',
    value: '',
    reason: '',
    expireAt: '',
  })
  blDialogVisible.value = true
}

async function saveBlacklist() {
  const payload: Partial<BlacklistEntry> = {
    kind: blForm.kind,
    value: blForm.value,
    reason: blForm.reason || undefined,
    expireAt: blForm.expireAt || undefined,
  }
  await riskApi.addBlacklist(payload)
  ElMessage.success('Added')
  blDialogVisible.value = false
  loadBlacklist()
}

async function removeBlacklist(row: BlacklistEntry) {
  await ElMessageBox.confirm(`Delete blacklist entry "${row.value}"?`, 'Confirm', {
    type: 'warning',
  })
  await riskApi.removeBlacklist(row.id)
  ElMessage.success('Deleted')
  loadBlacklist()
}

onMounted(() => {
  loadRules()
  loadBlacklist()
})
</script>

<template>
  <div class="page">
    <div class="page-header">
      <h2>Risk Center</h2>
      <el-button
        v-if="activeTab === 'rules'"
        type="primary"
        :icon="'Plus'"
        @click="openCreateRule"
      >
        New Rule
      </el-button>
      <el-button
        v-else
        type="primary"
        :icon="'Plus'"
        @click="openCreateBlacklist"
      >
        Add
      </el-button>
    </div>

    <el-tabs v-model="activeTab">
      <!-- Rules -->
      <el-tab-pane label="Rules" name="rules">
        <el-table :data="rulesRows" v-loading="rulesLoading" border stripe>
          <el-table-column prop="id" label="ID" width="80" />
          <el-table-column prop="name" label="Name" />
          <el-table-column prop="type" label="Type" width="140">
            <template #default="{ row }">
              <el-tag size="small">{{ row.type }}</el-tag>
            </template>
          </el-table-column>
          <el-table-column prop="action" label="Action" width="120">
            <template #default="{ row }">
              <el-tag size="small" type="warning">{{ row.action }}</el-tag>
            </template>
          </el-table-column>
          <el-table-column label="Config" min-width="180">
            <template #default="{ row }">
              <span>{{ configPreview(row.config) }}</span>
            </template>
          </el-table-column>
          <el-table-column prop="enabled" label="Enabled" width="100">
            <template #default="{ row }">
              <el-switch
                :model-value="row.enabled"
                @change="(val: boolean) => toggleRule(row, val)"
              />
            </template>
          </el-table-column>
          <el-table-column prop="createdAt" label="Created" width="180" />
          <el-table-column label="Actions" width="160" fixed="right">
            <template #default="{ row }">
              <el-button link type="primary" @click="openEditRule(row)">
                Edit
              </el-button>
              <el-button link type="danger" @click="removeRule(row)">
                Delete
              </el-button>
            </template>
          </el-table-column>
        </el-table>

        <div class="pager">
          <el-pagination
            layout="total, prev, pager, next"
            :total="rulesTotal"
            v-model:current-page="rulesQuery.page"
            v-model:page-size="rulesQuery.pageSize"
            @current-change="loadRules"
          />
        </div>
      </el-tab-pane>

      <!-- Blacklist -->
      <el-tab-pane label="Blacklist" name="blacklist">
        <div class="toolbar">
          <el-select
            v-model="blQuery.kind"
            placeholder="Kind"
            clearable
            style="width: 180px"
          >
            <el-option label="IP" value="ip" />
            <el-option label="API Key" value="apikey" />
            <el-option label="Company" value="company" />
            <el-option label="Email" value="email" />
          </el-select>
          <el-button
            :icon="'Search'"
            @click="((blQuery.page = 1), loadBlacklist())"
          >
            Search
          </el-button>
        </div>

        <el-table :data="blRows" v-loading="blLoading" border stripe>
          <el-table-column prop="id" label="ID" width="80" />
          <el-table-column prop="kind" label="Kind" width="120">
            <template #default="{ row }">
              <el-tag size="small">{{ row.kind }}</el-tag>
            </template>
          </el-table-column>
          <el-table-column prop="value" label="Value" />
          <el-table-column prop="reason" label="Reason" />
          <el-table-column prop="expireAt" label="Expire At" width="180" />
          <el-table-column prop="createdAt" label="Created" width="180" />
          <el-table-column label="Actions" width="120" fixed="right">
            <template #default="{ row }">
              <el-button link type="danger" @click="removeBlacklist(row)">
                Delete
              </el-button>
            </template>
          </el-table-column>
        </el-table>

        <div class="pager">
          <el-pagination
            layout="total, prev, pager, next"
            :total="blTotal"
            v-model:current-page="blQuery.page"
            v-model:page-size="blQuery.pageSize"
            @current-change="loadBlacklist"
          />
        </div>
      </el-tab-pane>
    </el-tabs>

    <!-- Rule dialog -->
    <el-dialog
      v-model="ruleDialogVisible"
      :title="ruleEditingId == null ? 'New Rule' : 'Edit Rule'"
      width="520px"
    >
      <el-form :model="ruleForm" label-width="100px">
        <el-form-item label="Name">
          <el-input v-model="ruleForm.name" />
        </el-form-item>
        <el-form-item label="Type">
          <el-select v-model="ruleForm.type">
            <el-option label="Rate Limit" value="rate_limit" />
            <el-option label="Spend Limit" value="spend_limit" />
            <el-option label="Geo Block" value="geo_block" />
            <el-option label="Keyword" value="keyword" />
            <el-option label="Concurrency" value="concurrency" />
          </el-select>
        </el-form-item>
        <el-form-item label="Action">
          <el-select v-model="ruleForm.action">
            <el-option label="Block" value="block" />
            <el-option label="Throttle" value="throttle" />
            <el-option label="Alert" value="alert" />
          </el-select>
        </el-form-item>
        <el-form-item label="Config">
          <el-input
            v-model="ruleConfigText"
            type="textarea"
            :rows="6"
            placeholder='{"threshold": 100, "window": 60}'
          />
        </el-form-item>
        <el-form-item label="Enabled">
          <el-switch v-model="ruleForm.enabled" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="ruleDialogVisible = false">Cancel</el-button>
        <el-button type="primary" @click="saveRule">Save</el-button>
      </template>
    </el-dialog>

    <!-- Blacklist dialog -->
    <el-dialog v-model="blDialogVisible" title="Add Blacklist Entry" width="480px">
      <el-form :model="blForm" label-width="100px">
        <el-form-item label="Kind">
          <el-select v-model="blForm.kind">
            <el-option label="IP" value="ip" />
            <el-option label="API Key" value="apikey" />
            <el-option label="Company" value="company" />
            <el-option label="Email" value="email" />
          </el-select>
        </el-form-item>
        <el-form-item label="Value">
          <el-input v-model="blForm.value" />
        </el-form-item>
        <el-form-item label="Reason">
          <el-input v-model="blForm.reason" />
        </el-form-item>
        <el-form-item label="Expire At">
          <el-date-picker
            v-model="blForm.expireAt"
            type="datetime"
            value-format="YYYY-MM-DDTHH:mm:ss"
            placeholder="Select datetime"
            style="width: 100%"
          />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="blDialogVisible = false">Cancel</el-button>
        <el-button type="primary" @click="saveBlacklist">Save</el-button>
      </template>
    </el-dialog>
  </div>
</template>
