<script setup lang="ts">
import { onMounted, reactive, ref } from 'vue'
import { ElMessage } from 'element-plus'
import { payApi, type EnabledPayChannel } from '@/api/pay'
import { financeApi, type RechargeOrderResult } from '@/api/finance'
import { useAppStore } from '@/stores/app'

const app = useAppStore()
const loading = ref(false)
const channels = ref<EnabledPayChannel[]>([])

const form = reactive({
  channel: '' as EnabledPayChannel['code'] | '',
  amount: 50,
  currency: 'USD',
})

const order = ref<RechargeOrderResult | null>(null)
const submitting = ref(false)

// Pick the selected channel object for min/max/currency hints.
function selectedChannel(): EnabledPayChannel | undefined {
  return channels.value.find((c) => c.code === form.channel)
}

async function loadChannels() {
  loading.value = true
  try {
    // Only ENABLED channels are returned here — admin config lives elsewhere.
    channels.value = await payApi.enabledChannels()
    if (channels.value.length && !form.channel) {
      form.channel = channels.value[0].code
      form.currency = channels.value[0].currencies?.[0] ?? 'USD'
    }
  } catch {
    channels.value = []
  } finally {
    loading.value = false
  }
}

function onChannelChange() {
  const c = selectedChannel()
  if (c?.currencies?.length) form.currency = c.currencies[0]
}

async function createOrder() {
  if (!form.channel) {
    ElMessage.warning('Select a payment channel')
    return
  }
  const c = selectedChannel()
  if (c?.minAmount != null && form.amount < c.minAmount) {
    ElMessage.warning(`Minimum amount is ${c.minAmount}`)
    return
  }
  if (c?.maxAmount != null && form.amount > c.maxAmount) {
    ElMessage.warning(`Maximum amount is ${c.maxAmount}`)
    return
  }
  submitting.value = true
  try {
    order.value = await financeApi.createRecharge({
      companyId: app.currentCompanyId,
      channel: form.channel,
      amount: form.amount,
      currency: form.currency,
    })
    // Redirect-based channels (Stripe / Alipay) return a payUrl.
    if (order.value.payUrl) {
      window.open(order.value.payUrl, '_blank')
    }
    ElMessage.success('Order created')
  } finally {
    submitting.value = false
  }
}
</script>

<template>
  <div class="page" v-loading="loading">
    <div class="page-header">
      <h2>Recharge</h2>
    </div>

    <el-card style="max-width: 560px">
      <el-form :model="form" label-width="120px">
        <el-form-item label="Channel">
          <el-select
            v-model="form.channel"
            placeholder="Select enabled channel"
            style="width: 100%"
            @change="onChannelChange"
          >
            <el-option
              v-for="c in channels"
              :key="c.code"
              :label="c.name"
              :value="c.code"
            />
          </el-select>
          <div v-if="!channels.length" class="muted" style="margin-top: 6px">
            No enabled payment channels. Configure one in Payment Config.
          </div>
        </el-form-item>

        <el-form-item label="Amount">
          <el-input-number v-model="form.amount" :min="1" :step="10" />
          <span class="muted" style="margin-left: 8px">
            <template v-if="selectedChannel()?.minAmount != null">
              min {{ selectedChannel()?.minAmount }}
            </template>
            <template v-if="selectedChannel()?.maxAmount != null">
              · max {{ selectedChannel()?.maxAmount }}
            </template>
          </span>
        </el-form-item>

        <el-form-item label="Currency">
          <el-select v-model="form.currency" style="width: 160px">
            <el-option
              v-for="cur in selectedChannel()?.currencies ?? ['USD']"
              :key="cur"
              :label="cur"
              :value="cur"
            />
          </el-select>
        </el-form-item>

        <el-form-item v-if="selectedChannel()?.feeRate != null" label="Fee">
          <span class="muted">{{ selectedChannel()?.feeRate }}%</span>
        </el-form-item>

        <el-form-item>
          <el-button
            type="primary"
            :loading="submitting"
            :disabled="!channels.length"
            @click="createOrder"
          >
            Create order
          </el-button>
        </el-form-item>
      </el-form>
    </el-card>

    <el-card v-if="order" style="max-width: 560px; margin-top: 16px">
      <template #header>Order created</template>
      <p>Order No: <code>{{ order.orderNo }}</code></p>
      <p v-if="order.payUrl">
        <el-link type="primary" :href="order.payUrl" target="_blank">
          Open payment page
        </el-link>
      </p>
      <div v-if="order.qrCode">
        <p class="muted">Scan to pay:</p>
        <el-image :src="order.qrCode" style="width: 180px" />
      </div>
      <div v-if="order.address">
        <p>Deposit address: <code>{{ order.address }}</code></p>
        <p v-if="order.expireAt" class="muted">Expires: {{ order.expireAt }}</p>
      </div>
    </el-card>
  </div>
</template>
