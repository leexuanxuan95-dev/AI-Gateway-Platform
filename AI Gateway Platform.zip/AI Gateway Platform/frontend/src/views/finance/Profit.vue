<script setup lang="ts">
import { computed, onMounted, reactive, ref } from 'vue'
import { financeApi, type ProfitReport } from '@/api/finance'

const loading = ref(false)
const rows = ref<ProfitReport[]>([])
const range = reactive<{ from?: string; to?: string }>({
  from: undefined,
  to: undefined,
})

const dateRange = computed<[string, string] | null>({
  get() {
    return range.from && range.to ? [range.from, range.to] : null
  },
  set(val) {
    range.from = val?.[0]
    range.to = val?.[1]
  },
})

const totalRevenue = computed(() =>
  rows.value.reduce((sum, r) => sum + r.revenue, 0),
)
const totalCost = computed(() =>
  rows.value.reduce((sum, r) => sum + r.cost, 0),
)
const totalProfit = computed(() =>
  rows.value.reduce((sum, r) => sum + r.profit, 0),
)

async function load() {
  loading.value = true
  try {
    rows.value = await financeApi.profit({ from: range.from, to: range.to })
  } catch {
    rows.value = []
  } finally {
    loading.value = false
  }
}

onMounted(load)
</script>

<template>
  <div class="page" v-loading="loading">
    <div class="page-header">
      <h2>Profit</h2>
    </div>

    <div class="toolbar">
      <el-date-picker
        v-model="dateRange"
        type="daterange"
        value-format="YYYY-MM-DD"
        start-placeholder="From"
        end-placeholder="To"
      />
      <el-button :icon="'Search'" @click="load">Query</el-button>
    </div>

    <el-row :gutter="16" style="margin-bottom: 16px">
      <el-col :span="8">
        <el-card>
          <div>Revenue</div>
          <h2>{{ totalRevenue }}</h2>
        </el-card>
      </el-col>
      <el-col :span="8">
        <el-card>
          <div>Cost</div>
          <h2>{{ totalCost }}</h2>
        </el-card>
      </el-col>
      <el-col :span="8">
        <el-card>
          <div>Profit</div>
          <h2>{{ totalProfit }}</h2>
        </el-card>
      </el-col>
    </el-row>

    <el-table :data="rows" v-loading="loading" border stripe>
      <el-table-column prop="date" label="Date" width="160" />
      <el-table-column prop="revenue" label="Revenue" />
      <el-table-column prop="cost" label="Cost" />
      <el-table-column prop="profit" label="Profit" />
      <el-table-column label="Margin" width="120">
        <template #default="{ row }">
          {{ (row.margin * 100).toFixed(1) + '%' }}
        </template>
      </el-table-column>
    </el-table>
  </div>
</template>
