<script setup lang="ts">
import { onMounted, reactive, ref } from 'vue'
import { financeApi, type Transaction, type TxnType, type TxnStatus } from '@/api/finance'
import { useAppStore } from '@/stores/app'

const app = useAppStore()

const loading = ref(false)
const rows = ref<Transaction[]>([])
const total = ref(0)
const query = reactive<{
  page: number
  pageSize: number
  type?: TxnType
  status?: TxnStatus
  companyId?: number
}>({
  page: 1,
  pageSize: 10,
  type: undefined,
  status: undefined,
  companyId: app.currentCompanyId,
})

const typeTagMap: Record<TxnType, '' | 'success' | 'warning' | 'danger' | 'info'> = {
  recharge: 'success',
  consume: 'info',
  withdraw: 'warning',
  refund: 'danger',
  adjust: '',
}

function statusTag(status: TxnStatus): 'success' | 'warning' | 'danger' {
  if (status === 'success') return 'success'
  if (status === 'pending') return 'warning'
  return 'danger'
}

async function load() {
  loading.value = true
  try {
    const res = await financeApi.transactions(query)
    rows.value = res.list
    total.value = res.total
  } catch {
    rows.value = []
    total.value = 0
  } finally {
    loading.value = false
  }
}

onMounted(load)
</script>

<template>
  <div class="page">
    <div class="page-header">
      <h2>Transactions</h2>
    </div>

    <div class="toolbar">
      <el-select
        v-model="query.type"
        placeholder="Type"
        clearable
        style="width: 160px"
      >
        <el-option label="Recharge" value="recharge" />
        <el-option label="Consume" value="consume" />
        <el-option label="Withdraw" value="withdraw" />
        <el-option label="Refund" value="refund" />
        <el-option label="Adjust" value="adjust" />
      </el-select>
      <el-select
        v-model="query.status"
        placeholder="Status"
        clearable
        style="width: 160px"
      >
        <el-option label="Pending" value="pending" />
        <el-option label="Success" value="success" />
        <el-option label="Failed" value="failed" />
      </el-select>
      <el-button :icon="'Search'" @click="((query.page = 1), load())">
        Search
      </el-button>
    </div>

    <el-table :data="rows" v-loading="loading" border stripe>
      <el-table-column prop="id" label="ID" width="80" />
      <el-table-column prop="orderNo" label="Order No" />
      <el-table-column prop="type" label="Type" width="120">
        <template #default="{ row }">
          <el-tag :type="typeTagMap[row.type as TxnType]" size="small">
            {{ row.type }}
          </el-tag>
        </template>
      </el-table-column>
      <el-table-column label="Amount" width="140">
        <template #default="{ row }">
          {{ row.amount }} {{ row.currency }}
        </template>
      </el-table-column>
      <el-table-column prop="balanceAfter" label="Balance After" width="140" />
      <el-table-column prop="status" label="Status" width="110">
        <template #default="{ row }">
          <el-tag :type="statusTag(row.status as TxnStatus)" size="small">
            {{ row.status }}
          </el-tag>
        </template>
      </el-table-column>
      <el-table-column prop="remark" label="Remark" />
      <el-table-column prop="createdAt" label="Created At" width="180" />
    </el-table>

    <div class="pager">
      <el-pagination
        layout="total, prev, pager, next"
        :total="total"
        v-model:current-page="query.page"
        v-model:page-size="query.pageSize"
        @current-change="load"
      />
    </div>
  </div>
</template>
