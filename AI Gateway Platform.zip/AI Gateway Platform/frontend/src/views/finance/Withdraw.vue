<script setup lang="ts">
import { onMounted, reactive, ref } from 'vue'
import { ElMessage } from 'element-plus'
import { financeApi, type Transaction, type TxnStatus } from '@/api/finance'
import { useAppStore } from '@/stores/app'

const app = useAppStore()

const form = reactive<{
  amount: number
  currency: string
  account: string
  remark: string
}>({
  amount: 0,
  currency: 'USD',
  account: '',
  remark: '',
})
const submitting = ref(false)

const loading = ref(false)
const rows = ref<Transaction[]>([])
const total = ref(0)
const query = reactive<{ page: number; pageSize: number; status?: TxnStatus }>({
  page: 1,
  pageSize: 10,
  status: undefined,
})

function statusTag(status: TxnStatus): 'success' | 'warning' | 'danger' {
  if (status === 'success') return 'success'
  if (status === 'pending') return 'warning'
  return 'danger'
}

async function submit() {
  submitting.value = true
  try {
    await financeApi.withdraw({
      companyId: app.currentCompanyId,
      amount: form.amount,
      currency: form.currency,
      account: form.account,
      remark: form.remark,
    })
    ElMessage.success('Withdraw request submitted')
    Object.assign(form, { amount: 0, currency: 'USD', account: '', remark: '' })
    load()
  } finally {
    submitting.value = false
  }
}

async function load() {
  loading.value = true
  try {
    const res = await financeApi.withdrawals(query)
    rows.value = res.list
    total.value = res.total
  } catch {
    rows.value = []
    total.value = 0
  } finally {
    loading.value = false
  }
}

onMounted(load)
</script>

<template>
  <div class="page">
    <div class="page-header">
      <h2>Withdraw</h2>
    </div>

    <el-card>
      <el-form :model="form" label-width="100px">
        <el-form-item label="Amount">
          <el-input-number v-model="form.amount" :min="0" />
        </el-form-item>
        <el-form-item label="Currency">
          <el-select v-model="form.currency" style="width: 160px">
            <el-option label="USD" value="USD" />
            <el-option label="CNY" value="CNY" />
          </el-select>
        </el-form-item>
        <el-form-item label="Account">
          <el-input v-model="form.account" style="width: 320px" />
        </el-form-item>
        <el-form-item label="Remark">
          <el-input v-model="form.remark" style="width: 320px" />
        </el-form-item>
        <el-form-item>
          <el-button type="primary" :loading="submitting" @click="submit">
            Submit
          </el-button>
        </el-form-item>
      </el-form>
    </el-card>

    <el-table :data="rows" v-loading="loading" border stripe style="margin-top: 16px">
      <el-table-column prop="id" label="ID" width="80" />
      <el-table-column prop="orderNo" label="Order No" />
      <el-table-column label="Amount" width="140">
        <template #default="{ row }">
          {{ row.amount }} {{ row.currency }}
        </template>
      </el-table-column>
      <el-table-column prop="currency" label="Currency" width="100" />
      <el-table-column prop="status" label="Status" width="110">
        <template #default="{ row }">
          <el-tag :type="statusTag(row.status as TxnStatus)" size="small">
            {{ row.status }}
          </el-tag>
        </template>
      </el-table-column>
      <el-table-column prop="remark" label="Remark" />
      <el-table-column prop="createdAt" label="Created At" width="180" />
    </el-table>

    <div class="pager">
      <el-pagination
        layout="total, prev, pager, next"
        :total="total"
        v-model:current-page="query.page"
        v-model:page-size="query.pageSize"
        @current-change="load"
      />
    </div>
  </div>
</template>
