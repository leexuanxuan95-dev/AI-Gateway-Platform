<script setup lang="ts">
import { onMounted, reactive, ref } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { companyApi, type Company } from '@/api/company'

const loading = ref(false)
const rows = ref<Company[]>([])
const total = ref(0)
const query = reactive({ page: 1, pageSize: 10, keyword: '' })

async function load() {
  loading.value = true
  try {
    const res = await companyApi.pending(query)
    rows.value = res.list
    total.value = res.total
  } catch {
    rows.value = []
    total.value = 0
  } finally {
    loading.value = false
  }
}

async function approve(row: Company) {
  await companyApi.audit({ id: row.id, approved: true })
  ElMessage.success('Approved')
  load()
}

async function reject(row: Company) {
  const { value: reason } = await ElMessageBox.prompt(
    `Reject company "${row.name}"?`,
    'Reject',
    {
      type: 'warning',
      inputPlaceholder: 'Reason',
    },
  )
  await companyApi.audit({ id: row.id, approved: false, reason })
  ElMessage.success('Rejected')
  load()
}

onMounted(load)
</script>

<template>
  <div class="page">
    <div class="page-header">
      <h2>Company Audit</h2>
    </div>

    <div class="toolbar">
      <el-input
        v-model="query.keyword"
        placeholder="Search name / contact"
        clearable
        style="width: 260px"
        @keyup.enter="((query.page = 1), load())"
      />
      <el-button :icon="'Search'" @click="((query.page = 1), load())">
        Search
      </el-button>
    </div>

    <el-table :data="rows" v-loading="loading" border stripe>
      <el-table-column prop="id" label="ID" width="80" />
      <el-table-column prop="name" label="Name" />
      <el-table-column prop="contactName" label="Contact" width="140" />
      <el-table-column prop="contactEmail" label="Email" />
      <el-table-column prop="createdAt" label="Created" width="180" />
      <el-table-column label="Actions" width="180" fixed="right">
        <template #default="{ row }">
          <el-button link type="success" @click="approve(row)">Approve</el-button>
          <el-button link type="danger" @click="reject(row)">Reject</el-button>
        </template>
      </el-table-column>
    </el-table>

    <div class="pager">
      <el-pagination
        layout="total, prev, pager, next"
        :total="total"
        v-model:current-page="query.page"
        v-model:page-size="query.pageSize"
        @current-change="load"
      />
    </div>
  </div>
</template>
