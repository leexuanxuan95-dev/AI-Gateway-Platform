<script setup lang="ts">
import { onMounted, reactive, ref } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { companyApi, type Company, type CompanyStatus } from '@/api/company'

const loading = ref(false)
const rows = ref<Company[]>([])
const total = ref(0)
const query = reactive<{
  page: number
  pageSize: number
  keyword: string
  status: CompanyStatus | ''
}>({ page: 1, pageSize: 10, keyword: '', status: '' })

const dialogVisible = ref(false)
const editingId = ref<number | null>(null)
const form = reactive<{
  name: string
  contactName: string
  contactEmail: string
  contactPhone: string
  status: CompanyStatus
}>({
  name: '',
  contactName: '',
  contactEmail: '',
  contactPhone: '',
  status: 'active',
})

function statusTagType(status: CompanyStatus): 'success' | 'warning' | 'info' | 'danger' {
  switch (status) {
    case 'active':
      return 'success'
    case 'pending':
      return 'warning'
    case 'suspended':
      return 'info'
    case 'rejected':
      return 'danger'
  }
}

async function load() {
  loading.value = true
  try {
    const res = await companyApi.list({
      page: query.page,
      pageSize: query.pageSize,
      keyword: query.keyword,
      status: query.status || undefined,
    })
    rows.value = res.list
    total.value = res.total
  } catch {
    rows.value = []
    total.value = 0
  } finally {
    loading.value = false
  }
}

function openCreate() {
  editingId.value = null
  Object.assign(form, {
    name: '',
    contactName: '',
    contactEmail: '',
    contactPhone: '',
    status: 'active',
  })
  dialogVisible.value = true
}

function openEdit(row: Company) {
  editingId.value = row.id
  Object.assign(form, {
    name: row.name,
    contactName: row.contactName ?? '',
    contactEmail: row.contactEmail ?? '',
    contactPhone: row.contactPhone ?? '',
    status: row.status,
  })
  dialogVisible.value = true
}

async function save() {
  if (editingId.value == null) {
    await companyApi.create(form)
    ElMessage.success('Company created')
  } else {
    await companyApi.update(editingId.value, form)
    ElMessage.success('Company updated')
  }
  dialogVisible.value = false
  load()
}

async function remove(row: Company) {
  await ElMessageBox.confirm(`Delete company "${row.name}"?`, 'Confirm', {
    type: 'warning',
  })
  await companyApi.remove(row.id)
  ElMessage.success('Deleted')
  load()
}

onMounted(load)
</script>

<template>
  <div class="page">
    <div class="page-header">
      <h2>Companies</h2>
      <el-button type="primary" :icon="'Plus'" @click="openCreate">
        New Company
      </el-button>
    </div>

    <div class="toolbar">
      <el-input
        v-model="query.keyword"
        placeholder="Search name / contact"
        clearable
        style="width: 260px"
        @keyup.enter="((query.page = 1), load())"
      />
      <el-select
        v-model="query.status"
        placeholder="Status"
        clearable
        style="width: 160px"
        @change="((query.page = 1), load())"
      >
        <el-option label="Active" value="active" />
        <el-option label="Pending" value="pending" />
        <el-option label="Suspended" value="suspended" />
        <el-option label="Rejected" value="rejected" />
      </el-select>
      <el-button :icon="'Search'" @click="((query.page = 1), load())">
        Search
      </el-button>
    </div>

    <el-table :data="rows" v-loading="loading" border stripe>
      <el-table-column prop="id" label="ID" width="80" />
      <el-table-column prop="name" label="Name" />
      <el-table-column prop="contactName" label="Contact" width="140" />
      <el-table-column prop="contactEmail" label="Email" />
      <el-table-column prop="contactPhone" label="Phone" width="140" />
      <el-table-column prop="balance" label="Balance" width="120" />
      <el-table-column prop="status" label="Status" width="120">
        <template #default="{ row }">
          <el-tag :type="statusTagType(row.status)" size="small">
            {{ row.status }}
          </el-tag>
        </template>
      </el-table-column>
      <el-table-column prop="createdAt" label="Created" width="180" />
      <el-table-column label="Actions" width="160" fixed="right">
        <template #default="{ row }">
          <el-button link type="primary" @click="openEdit(row)">Edit</el-button>
          <el-button link type="danger" @click="remove(row)">Delete</el-button>
        </template>
      </el-table-column>
    </el-table>

    <div class="pager">
      <el-pagination
        layout="total, prev, pager, next"
        :total="total"
        v-model:current-page="query.page"
        v-model:page-size="query.pageSize"
        @current-change="load"
      />
    </div>

    <el-dialog
      v-model="dialogVisible"
      :title="editingId == null ? 'New Company' : 'Edit Company'"
      width="480px"
    >
      <el-form :model="form" label-width="100px">
        <el-form-item label="Name">
          <el-input v-model="form.name" />
        </el-form-item>
        <el-form-item label="Contact">
          <el-input v-model="form.contactName" />
        </el-form-item>
        <el-form-item label="Email">
          <el-input v-model="form.contactEmail" />
        </el-form-item>
        <el-form-item label="Phone">
          <el-input v-model="form.contactPhone" />
        </el-form-item>
        <el-form-item label="Status">
          <el-select v-model="form.status">
            <el-option label="Active" value="active" />
            <el-option label="Pending" value="pending" />
            <el-option label="Suspended" value="suspended" />
            <el-option label="Rejected" value="rejected" />
          </el-select>
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="dialogVisible = false">Cancel</el-button>
        <el-button type="primary" @click="save">Save</el-button>
      </template>
    </el-dialog>
  </div>
</template>
