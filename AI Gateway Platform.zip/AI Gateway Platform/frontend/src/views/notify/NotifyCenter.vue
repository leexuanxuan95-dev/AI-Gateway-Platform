<script setup lang="ts">
import { onMounted, reactive, ref } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import {
  notifyApi,
  type NotifyTemplate,
  type NotifyChannel,
  type NotifyLog,
} from '@/api/notify'

const activeTab = ref('templates')

/* ---------------- Templates ---------------- */
const tplLoading = ref(false)
const tplRows = ref<NotifyTemplate[]>([])
const tplTotal = ref(0)
const tplQuery = reactive({ page: 1, pageSize: 10 })

const tplDialogVisible = ref(false)
const tplEditingId = ref<number | null>(null)
const tplForm = reactive<{
  code: string
  name: string
  channel: NotifyChannel
  subject: string
  content: string
  enabled: boolean
}>({
  code: '',
  name: '',
  channel: 'email',
  subject: '',
  content: '',
  enabled: true,
})

async function loadTemplates() {
  tplLoading.value = true
  try {
    const res = await notifyApi.templates(tplQuery)
    tplRows.value = res.list
    tplTotal.value = res.total
  } catch {
    tplRows.value = []
    tplTotal.value = 0
  } finally {
    tplLoading.value = false
  }
}

function openCreateTemplate() {
  tplEditingId.value = null
  Object.assign(tplForm, {
    code: '',
    name: '',
    channel: 'email',
    subject: '',
    content: '',
    enabled: true,
  })
  tplDialogVisible.value = true
}

function openEditTemplate(row: NotifyTemplate) {
  tplEditingId.value = row.id
  Object.assign(tplForm, {
    code: row.code,
    name: row.name,
    channel: row.channel,
    subject: row.subject ?? '',
    content: row.content,
    enabled: row.enabled,
  })
  tplDialogVisible.value = true
}

async function saveTemplate() {
  const payload: Partial<NotifyTemplate> = {
    code: tplForm.code,
    name: tplForm.name,
    channel: tplForm.channel,
    subject: tplForm.subject || undefined,
    content: tplForm.content,
    enabled: tplForm.enabled,
  }
  if (tplEditingId.value == null) {
    await notifyApi.createTemplate(payload)
    ElMessage.success('Template created')
  } else {
    await notifyApi.updateTemplate(tplEditingId.value, payload)
    ElMessage.success('Template updated')
  }
  tplDialogVisible.value = false
  loadTemplates()
}

async function toggleTemplate(row: NotifyTemplate, value: boolean) {
  try {
    await notifyApi.updateTemplate(row.id, { enabled: value })
    ElMessage.success('Updated')
  } finally {
    loadTemplates()
  }
}

async function removeTemplate(row: NotifyTemplate) {
  await ElMessageBox.confirm(`Delete template "${row.code}"?`, 'Confirm', {
    type: 'warning',
  })
  await notifyApi.removeTemplate(row.id)
  ElMessage.success('Deleted')
  loadTemplates()
}

/* ---------------- Logs ---------------- */
const logsLoading = ref(false)
const logsRows = ref<NotifyLog[]>([])
const logsTotal = ref(0)
const logsQuery = reactive<{
  page: number
  pageSize: number
  channel?: NotifyChannel
}>({ page: 1, pageSize: 10, channel: undefined })

async function loadLogs() {
  logsLoading.value = true
  try {
    const res = await notifyApi.logs(logsQuery)
    logsRows.value = res.list
    logsTotal.value = res.total
  } catch {
    logsRows.value = []
    logsTotal.value = 0
  } finally {
    logsLoading.value = false
  }
}

function logStatusType(
  status: NotifyLog['status'],
): 'success' | 'danger' | 'warning' {
  if (status === 'sent') return 'success'
  if (status === 'failed') return 'danger'
  return 'warning'
}

onMounted(() => {
  loadTemplates()
  loadLogs()
})
</script>

<template>
  <div class="page">
    <div class="page-header">
      <h2>Notify Center</h2>
      <el-button
        v-if="activeTab === 'templates'"
        type="primary"
        :icon="'Plus'"
        @click="openCreateTemplate"
      >
        New Template
      </el-button>
    </div>

    <el-tabs v-model="activeTab">
      <!-- Templates -->
      <el-tab-pane label="Templates" name="templates">
        <el-table :data="tplRows" v-loading="tplLoading" border stripe>
          <el-table-column prop="id" label="ID" width="80" />
          <el-table-column prop="code" label="Code" width="160" />
          <el-table-column prop="name" label="Name" />
          <el-table-column prop="channel" label="Channel" width="120">
            <template #default="{ row }">
              <el-tag size="small">{{ row.channel }}</el-tag>
            </template>
          </el-table-column>
          <el-table-column prop="subject" label="Subject" />
          <el-table-column prop="enabled" label="Enabled" width="100">
            <template #default="{ row }">
              <el-switch
                :model-value="row.enabled"
                @change="(val: boolean) => toggleTemplate(row, val)"
              />
            </template>
          </el-table-column>
          <el-table-column prop="updatedAt" label="Updated" width="180" />
          <el-table-column label="Actions" width="160" fixed="right">
            <template #default="{ row }">
              <el-button link type="primary" @click="openEditTemplate(row)">
                Edit
              </el-button>
              <el-button link type="danger" @click="removeTemplate(row)">
                Delete
              </el-button>
            </template>
          </el-table-column>
        </el-table>

        <div class="pager">
          <el-pagination
            layout="total, prev, pager, next"
            :total="tplTotal"
            v-model:current-page="tplQuery.page"
            v-model:page-size="tplQuery.pageSize"
            @current-change="loadTemplates"
          />
        </div>
      </el-tab-pane>

      <!-- Logs -->
      <el-tab-pane label="Logs" name="logs">
        <div class="toolbar">
          <el-select
            v-model="logsQuery.channel"
            placeholder="Channel"
            clearable
            style="width: 180px"
          >
            <el-option label="Email" value="email" />
            <el-option label="SMS" value="sms" />
            <el-option label="Webhook" value="webhook" />
            <el-option label="In-App" value="inapp" />
          </el-select>
          <el-button
            :icon="'Search'"
            @click="((logsQuery.page = 1), loadLogs())"
          >
            Search
          </el-button>
        </div>

        <el-table :data="logsRows" v-loading="logsLoading" border stripe>
          <el-table-column prop="id" label="ID" width="80" />
          <el-table-column prop="templateCode" label="Template" width="160" />
          <el-table-column prop="channel" label="Channel" width="120">
            <template #default="{ row }">
              <el-tag size="small">{{ row.channel }}</el-tag>
            </template>
          </el-table-column>
          <el-table-column prop="target" label="Target" />
          <el-table-column prop="status" label="Status" width="120">
            <template #default="{ row }">
              <el-tag size="small" :type="logStatusType(row.status)">
                {{ row.status }}
              </el-tag>
            </template>
          </el-table-column>
          <el-table-column prop="error" label="Error" />
          <el-table-column prop="createdAt" label="Created" width="180" />
        </el-table>

        <div class="pager">
          <el-pagination
            layout="total, prev, pager, next"
            :total="logsTotal"
            v-model:current-page="logsQuery.page"
            v-model:page-size="logsQuery.pageSize"
            @current-change="loadLogs"
          />
        </div>
      </el-tab-pane>
    </el-tabs>

    <!-- Template dialog -->
    <el-dialog
      v-model="tplDialogVisible"
      :title="tplEditingId == null ? 'New Template' : 'Edit Template'"
      width="520px"
    >
      <el-form :model="tplForm" label-width="100px">
        <el-form-item label="Code">
          <el-input v-model="tplForm.code" />
        </el-form-item>
        <el-form-item label="Name">
          <el-input v-model="tplForm.name" />
        </el-form-item>
        <el-form-item label="Channel">
          <el-select v-model="tplForm.channel">
            <el-option label="Email" value="email" />
            <el-option label="SMS" value="sms" />
            <el-option label="Webhook" value="webhook" />
            <el-option label="In-App" value="inapp" />
          </el-select>
        </el-form-item>
        <el-form-item label="Subject">
          <el-input v-model="tplForm.subject" />
        </el-form-item>
        <el-form-item label="Content">
          <el-input v-model="tplForm.content" type="textarea" :rows="6" />
        </el-form-item>
        <el-form-item label="Enabled">
          <el-switch v-model="tplForm.enabled" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="tplDialogVisible = false">Cancel</el-button>
        <el-button type="primary" @click="saveTemplate">Save</el-button>
      </template>
    </el-dialog>
  </div>
</template>
