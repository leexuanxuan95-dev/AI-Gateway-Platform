<script setup lang="ts">
import { onMounted, reactive, ref } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import {
  apikeyApi,
  type ApiKey,
  type CreateApiKeyResult,
} from '@/api/apikey'
import { projectApi, type Project } from '@/api/project'

const loading = ref(false)
const rows = ref<ApiKey[]>([])
const total = ref(0)
const query = reactive({
  page: 1,
  pageSize: 10,
  projectId: undefined as number | undefined,
})
const projects = ref<Project[]>([])

// Create dialog
const createDialog = ref(false)
const createForm = reactive({
  projectId: undefined as number | undefined,
  name: '',
  expiresAt: '',
})

// One-time reveal dialog — holds the raw secret ONLY in component state, never
// persisted anywhere. Cleared when dialog closes.
const revealDialog = ref(false)
const created = ref<CreateApiKeyResult | null>(null)

async function loadProjects() {
  try {
    const res = await projectApi.list({ page: 1, pageSize: 200 })
    projects.value = res.list
  } catch {
    projects.value = []
  }
}

async function load() {
  loading.value = true
  try {
    const res = await apikeyApi.list(query)
    rows.value = res.list
    total.value = res.total
  } catch {
    rows.value = []
    total.value = 0
  } finally {
    loading.value = false
  }
}

function openCreate() {
  createForm.projectId = query.projectId
  createForm.name = ''
  createForm.expiresAt = ''
  createDialog.value = true
}

async function doCreate() {
  if (!createForm.projectId || !createForm.name) {
    ElMessage.warning('Project and name are required')
    return
  }
  const res = await apikeyApi.create({
    projectId: createForm.projectId,
    name: createForm.name,
    expiresAt: createForm.expiresAt || undefined,
  })
  createDialog.value = false
  created.value = res
  revealDialog.value = true
  load()
}

async function copyKey() {
  if (!created.value) return
  try {
    await navigator.clipboard.writeText(created.value.rawKey)
    ElMessage.success('Copied to clipboard')
  } catch {
    ElMessage.warning('Copy failed — select and copy manually')
  }
}

function closeReveal() {
  revealDialog.value = false
  // Security: drop the raw key from memory immediately.
  created.value = null
}

async function revoke(row: ApiKey) {
  await ElMessageBox.confirm(
    `Revoke key "${row.name}"? Applications using it will stop working.`,
    'Confirm',
    { type: 'warning' },
  )
  await apikeyApi.revoke(row.id)
  ElMessage.success('Revoked')
  load()
}

onMounted(() => {
  loadProjects()
  load()
})
</script>

<template>
  <div class="page">
    <div class="page-header">
      <h2>API Keys</h2>
      <el-button type="primary" :icon="'Plus'" @click="openCreate">
        Create Key
      </el-button>
    </div>

    <div class="toolbar">
      <el-select
        v-model="query.projectId"
        placeholder="All projects"
        clearable
        style="width: 240px"
        @change="((query.page = 1), load())"
      >
        <el-option
          v-for="p in projects"
          :key="p.id"
          :label="p.name"
          :value="p.id"
        />
      </el-select>
    </div>

    <el-table :data="rows" v-loading="loading" border stripe>
      <el-table-column prop="name" label="Name" />
      <el-table-column prop="keyPreview" label="Key" width="200">
        <template #default="{ row }">
          <code>{{ row.keyPreview }}</code>
        </template>
      </el-table-column>
      <el-table-column prop="status" label="Status" width="110">
        <template #default="{ row }">
          <el-tag :type="row.status === 'active' ? 'success' : 'danger'" size="small">
            {{ row.status }}
          </el-tag>
        </template>
      </el-table-column>
      <el-table-column prop="lastUsedAt" label="Last used" width="180" />
      <el-table-column prop="createdAt" label="Created" width="180" />
      <el-table-column label="Actions" width="120" fixed="right">
        <template #default="{ row }">
          <el-button
            link
            type="danger"
            :disabled="row.status !== 'active'"
            @click="revoke(row)"
          >
            Revoke
          </el-button>
        </template>
      </el-table-column>
    </el-table>

    <div class="pager">
      <el-pagination
        layout="total, prev, pager, next"
        :total="total"
        v-model:current-page="query.page"
        v-model:page-size="query.pageSize"
        @current-change="load"
      />
    </div>

    <!-- Create -->
    <el-dialog v-model="createDialog" title="Create API Key" width="460px">
      <el-form :model="createForm" label-width="100px">
        <el-form-item label="Project" required>
          <el-select v-model="createForm.projectId" style="width: 100%">
            <el-option
              v-for="p in projects"
              :key="p.id"
              :label="p.name"
              :value="p.id"
            />
          </el-select>
        </el-form-item>
        <el-form-item label="Name" required>
          <el-input v-model="createForm.name" placeholder="e.g. prod-server" />
        </el-form-item>
        <el-form-item label="Expires">
          <el-date-picker
            v-model="createForm.expiresAt"
            type="datetime"
            placeholder="optional"
            value-format="YYYY-MM-DDTHH:mm:ss"
            style="width: 100%"
          />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="createDialog = false">Cancel</el-button>
        <el-button type="primary" @click="doCreate">Create</el-button>
      </template>
    </el-dialog>

    <!-- One-time reveal -->
    <el-dialog
      v-model="revealDialog"
      title="Your new API key"
      width="560px"
      :close-on-click-modal="false"
      :show-close="false"
      @close="closeReveal"
    >
      <el-alert
        type="warning"
        show-icon
        :closable="false"
        title="Copy this key now — it will not be shown again."
        description="For security the raw secret is displayed only once. Store it somewhere safe."
        style="margin-bottom: 12px"
      />
      <el-input :model-value="created?.rawKey" readonly>
        <template #append>
          <el-button :icon="'CopyDocument'" @click="copyKey">Copy</el-button>
        </template>
      </el-input>
      <template #footer>
        <el-button type="primary" @click="closeReveal">
          I've copied it
        </el-button>
      </template>
    </el-dialog>
  </div>
</template>
