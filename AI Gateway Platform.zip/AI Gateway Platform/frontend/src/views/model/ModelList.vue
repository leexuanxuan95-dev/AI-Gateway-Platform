<script setup lang="ts">
import { computed, onMounted, reactive, ref } from 'vue'
import { ElMessage } from 'element-plus'
import {
  modelApi,
  type ModelAvailability,
  type ModelFamily,
  type ModelVersion,
} from '@/api/model'

const loading = ref(false)
const families = ref<ModelFamily[]>([])
const rows = ref<ModelVersion[]>([])
const total = ref(0)
const query = reactive({
  page: 1,
  pageSize: 10,
  keyword: '',
  familyId: undefined as number | undefined,
})

const pricingDialog = ref(false)
const editing = ref<ModelVersion | null>(null)
const pricingForm = reactive({ inputPrice: 0, outputPrice: 0, currency: 'USD' })

function availabilityTag(a: ModelAvailability) {
  switch (a) {
    case 'available':
      return { type: 'success' as const, label: 'Available' }
    case 'maintenance':
      return { type: 'warning' as const, label: 'Maintenance' }
    default:
      return { type: 'info' as const, label: 'Unavailable' }
  }
}

// §7.1 / §7.5: unavailable rows are greyed & their controls disabled.
function isUnavailable(row: ModelVersion) {
  return row.availability === 'unavailable'
}

async function loadFamilies() {
  try {
    families.value = await modelApi.families()
  } catch {
    families.value = []
  }
}

async function load() {
  loading.value = true
  try {
    const res = await modelApi.versions(query)
    rows.value = res.list
    total.value = res.total
  } catch {
    rows.value = []
    total.value = 0
  } finally {
    loading.value = false
  }
}

function openPricing(row: ModelVersion) {
  editing.value = row
  pricingForm.inputPrice = row.inputPrice ?? 0
  pricingForm.outputPrice = row.outputPrice ?? 0
  pricingForm.currency = row.currency ?? 'USD'
  pricingDialog.value = true
}

async function savePricing() {
  if (!editing.value) return
  await modelApi.updatePricing(editing.value.id, { ...pricingForm })
  ElMessage.success('Pricing updated')
  pricingDialog.value = false
  load()
}

async function toggleListing(row: ModelVersion) {
  if (row.status === 'enabled') {
    await modelApi.delist(row.id)
    ElMessage.success('Delisted')
  } else {
    await modelApi.list(row.id)
    ElMessage.success('Listed')
  }
  load()
}

async function changeAvailability(row: ModelVersion, a: ModelAvailability) {
  await modelApi.setAvailability(row.id, a)
  ElMessage.success('Availability updated')
  load()
}

async function sync() {
  await modelApi.sync()
  ElMessage.success('Sync triggered')
  load()
}

const rowClass = computed(
  () =>
    ({ row }: { row: ModelVersion }) =>
      isUnavailable(row) ? 'row-unavailable' : '',
)

onMounted(() => {
  loadFamilies()
  load()
})
</script>

<template>
  <div class="page">
    <div class="page-header">
      <h2>Models</h2>
      <el-button :icon="'Refresh'" @click="sync">Sync upstream</el-button>
    </div>

    <div class="toolbar">
      <el-select
        v-model="query.familyId"
        placeholder="All families"
        clearable
        style="width: 220px"
        @change="((query.page = 1), load())"
      >
        <el-option
          v-for="f in families"
          :key="f.id"
          :label="`${f.name} (${f.provider})`"
          :value="f.id"
        />
      </el-select>
      <el-input
        v-model="query.keyword"
        placeholder="Search model"
        clearable
        style="width: 240px"
        @keyup.enter="((query.page = 1), load())"
      />
      <el-button :icon="'Search'" @click="((query.page = 1), load())">
        Search
      </el-button>
    </div>

    <el-table
      :data="rows"
      v-loading="loading"
      border
      stripe
      :row-class-name="rowClass"
    >
      <el-table-column prop="name" label="Model" min-width="200">
        <template #default="{ row }">
          <span :class="{ muted: isUnavailable(row) }">{{ row.name }}</span>
        </template>
      </el-table-column>
      <el-table-column prop="provider" label="Provider" width="120" />
      <el-table-column prop="familyName" label="Family" width="160" />
      <el-table-column label="Input $/1M" width="120">
        <template #default="{ row }">
          <span v-if="row.inputPrice != null">{{ row.inputPrice }}</span>
          <el-tag v-else type="warning" size="small">pending</el-tag>
        </template>
      </el-table-column>
      <el-table-column label="Output $/1M" width="120">
        <template #default="{ row }">
          <span v-if="row.outputPrice != null">{{ row.outputPrice }}</span>
          <el-tag v-else type="warning" size="small">pending</el-tag>
        </template>
      </el-table-column>
      <el-table-column label="Availability" width="150">
        <template #default="{ row }">
          <el-tag :type="availabilityTag(row.availability).type" size="small">
            {{ availabilityTag(row.availability).label }}
          </el-tag>
        </template>
      </el-table-column>
      <el-table-column label="Listed" width="100">
        <template #default="{ row }">
          <el-tag :type="row.status === 'enabled' ? 'success' : 'info'" size="small">
            {{ row.status === 'enabled' ? 'Listed' : 'Delisted' }}
          </el-tag>
        </template>
      </el-table-column>
      <el-table-column label="Actions" width="300" fixed="right">
        <template #default="{ row }">
          <!-- Controls disabled when the version is unavailable (§7.5). -->
          <el-button
            link
            type="primary"
            :disabled="isUnavailable(row)"
            @click="openPricing(row)"
          >
            Pricing
          </el-button>
          <el-button
            link
            :type="row.status === 'enabled' ? 'warning' : 'success'"
            :disabled="isUnavailable(row)"
            @click="toggleListing(row)"
          >
            {{ row.status === 'enabled' ? 'Delist' : 'List' }}
          </el-button>
          <el-dropdown
            trigger="click"
            @command="(cmd: ModelAvailability) => changeAvailability(row, cmd)"
          >
            <el-button link type="info">Availability</el-button>
            <template #dropdown>
              <el-dropdown-menu>
                <el-dropdown-item command="available">Available</el-dropdown-item>
                <el-dropdown-item command="maintenance">
                  Maintenance
                </el-dropdown-item>
                <el-dropdown-item command="unavailable">
                  Unavailable
                </el-dropdown-item>
              </el-dropdown-menu>
            </template>
          </el-dropdown>
        </template>
      </el-table-column>
    </el-table>

    <div class="pager">
      <el-pagination
        layout="total, prev, pager, next"
        :total="total"
        v-model:current-page="query.page"
        v-model:page-size="query.pageSize"
        @current-change="load"
      />
    </div>

    <el-dialog v-model="pricingDialog" title="Edit Pricing" width="420px">
      <el-form :model="pricingForm" label-width="140px">
        <el-form-item label="Input $/1M tokens">
          <el-input-number v-model="pricingForm.inputPrice" :min="0" :step="0.01" />
        </el-form-item>
        <el-form-item label="Output $/1M tokens">
          <el-input-number v-model="pricingForm.outputPrice" :min="0" :step="0.01" />
        </el-form-item>
        <el-form-item label="Currency">
          <el-select v-model="pricingForm.currency">
            <el-option label="USD" value="USD" />
            <el-option label="CNY" value="CNY" />
          </el-select>
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="pricingDialog = false">Cancel</el-button>
        <el-button type="primary" @click="savePricing">Save</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<style scoped>
:deep(.row-unavailable) {
  opacity: 0.55;
  background: #fafafa;
}
</style>
