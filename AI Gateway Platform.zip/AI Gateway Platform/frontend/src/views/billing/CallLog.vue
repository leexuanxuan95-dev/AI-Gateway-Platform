<script setup lang="ts">
import { onMounted, reactive, ref } from 'vue'
import { billingApi, type CallLog } from '@/api/billing'
import { useAppStore } from '@/stores/app'

const app = useAppStore()

const loading = ref(false)
const rows = ref<CallLog[]>([])
const total = ref(0)

const query = reactive<{
  page: number
  pageSize: number
  companyId?: number
  model?: string
  status?: number
  from?: string
  to?: string
}>({
  page: 1,
  pageSize: 10,
  companyId: app.currentCompanyId,
  model: '',
  status: undefined,
  from: undefined,
  to: undefined,
})

const dateRange = ref<[string, string] | null>(null)

function onDateChange(val: [string, string] | null) {
  query.from = val?.[0]
  query.to = val?.[1]
}

async function load() {
  loading.value = true
  try {
    const res = await billingApi.callLogs(query)
    rows.value = res.list
    total.value = res.total
  } catch {
    rows.value = []
    total.value = 0
  } finally {
    loading.value = false
  }
}

function search() {
  query.page = 1
  load()
}

function statusType(status: number) {
  if (status < 400) return 'success'
  if (status < 500) return 'warning'
  return 'danger'
}

onMounted(load)
</script>

<template>
  <div class="page">
    <div class="page-header">
      <h2>Call Logs</h2>
    </div>

    <div class="toolbar">
      <el-input
        v-model="query.model"
        placeholder="Model"
        clearable
        style="width: 200px"
        @keyup.enter="search"
      />
      <el-input-number
        v-model="query.status"
        placeholder="Status"
        :min="0"
        :controls="false"
        style="width: 120px"
      />
      <el-date-picker
        v-model="dateRange"
        type="daterange"
        value-format="YYYY-MM-DD"
        start-placeholder="From"
        end-placeholder="To"
        range-separator="-"
        @change="onDateChange"
      />
      <el-button :icon="'Search'" @click="search">Search</el-button>
    </div>

    <el-table :data="rows" v-loading="loading" border stripe>
      <el-table-column prop="id" label="ID" width="80" />
      <el-table-column prop="createdAt" label="Created At" width="180" />
      <el-table-column prop="model" label="Model" />
      <el-table-column prop="channel" label="Channel" />
      <el-table-column prop="status" label="Status" width="100">
        <template #default="{ row }">
          <el-tag :type="statusType(row.status)" size="small">
            {{ row.status }}
          </el-tag>
        </template>
      </el-table-column>
      <el-table-column prop="promptTokens" label="Prompt" width="100" />
      <el-table-column prop="completionTokens" label="Completion" width="110" />
      <el-table-column prop="totalTokens" label="Total" width="100" />
      <el-table-column prop="latencyMs" label="Latency (ms)" width="120" />
      <el-table-column prop="cost" label="Cost" width="100" />
      <el-table-column prop="price" label="Price" width="100" />
    </el-table>

    <div class="pager">
      <el-pagination
        layout="total, prev, pager, next"
        :total="total"
        v-model:current-page="query.page"
        v-model:page-size="query.pageSize"
        @current-change="load"
      />
    </div>
  </div>
</template>
