<script setup lang="ts">
import { onMounted, reactive, ref } from 'vue'
import { billingApi, type TokenBillRow } from '@/api/billing'
import { useAppStore } from '@/stores/app'

const app = useAppStore()

const loading = ref(false)
const rows = ref<TokenBillRow[]>([])
const total = ref(0)

const query = reactive<{
  page: number
  pageSize: number
  companyId?: number
  from?: string
  to?: string
  groupBy: 'day' | 'month'
}>({
  page: 1,
  pageSize: 10,
  companyId: app.currentCompanyId,
  from: undefined,
  to: undefined,
  groupBy: 'day',
})

const dateRange = ref<[string, string] | null>(null)

function onDateChange(val: [string, string] | null) {
  query.from = val?.[0]
  query.to = val?.[1]
}

async function load() {
  loading.value = true
  try {
    const res = await billingApi.tokenBills(query)
    rows.value = res.list
    total.value = res.total
  } catch {
    rows.value = []
    total.value = 0
  } finally {
    loading.value = false
  }
}

function search() {
  query.page = 1
  load()
}

onMounted(load)
</script>

<template>
  <div class="page">
    <div class="page-header">
      <h2>Token Bills</h2>
    </div>

    <div class="toolbar">
      <el-radio-group v-model="query.groupBy">
        <el-radio-button label="day">Day</el-radio-button>
        <el-radio-button label="month">Month</el-radio-button>
      </el-radio-group>
      <el-date-picker
        v-model="dateRange"
        type="daterange"
        value-format="YYYY-MM-DD"
        start-placeholder="From"
        end-placeholder="To"
        range-separator="-"
        @change="onDateChange"
      />
      <el-button :icon="'Search'" @click="search">Search</el-button>
    </div>

    <el-table :data="rows" v-loading="loading" border stripe>
      <el-table-column prop="period" label="Period" width="140" />
      <el-table-column label="Company">
        <template #default="{ row }">
          {{ row.companyName ?? row.companyId }}
        </template>
      </el-table-column>
      <el-table-column prop="model" label="Model" />
      <el-table-column prop="calls" label="Calls" width="100" />
      <el-table-column prop="promptTokens" label="Prompt" width="100" />
      <el-table-column prop="completionTokens" label="Completion" width="110" />
      <el-table-column prop="totalTokens" label="Total" width="100" />
      <el-table-column prop="cost" label="Cost" width="100" />
      <el-table-column prop="revenue" label="Revenue" width="100" />
    </el-table>

    <div class="pager">
      <el-pagination
        layout="total, prev, pager, next"
        :total="total"
        v-model:current-page="query.page"
        v-model:page-size="query.pageSize"
        @current-change="load"
      />
    </div>
  </div>
</template>
