<script setup lang="ts">
import { onMounted, reactive, ref } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { planApi, type Plan } from '@/api/plan'

const loading = ref(false)
const rows = ref<Plan[]>([])
const total = ref(0)
const query = reactive({ page: 1, pageSize: 10 })

const dialogVisible = ref(false)
const editingId = ref<number | null>(null)
const form = reactive<Partial<Plan>>({
  name: '',
  description: '',
  price: 0,
  currency: 'USD',
  monthlyQuota: 0,
  rateLimitRpm: 0,
  markupDiscount: 0,
  enabled: true,
})

async function load() {
  loading.value = true
  try {
    const res = await planApi.list(query)
    rows.value = res.list
    total.value = res.total
  } catch {
    rows.value = []
    total.value = 0
  } finally {
    loading.value = false
  }
}

function openCreate() {
  editingId.value = null
  Object.assign(form, {
    name: '',
    description: '',
    price: 0,
    currency: 'USD',
    monthlyQuota: 0,
    rateLimitRpm: 0,
    markupDiscount: 0,
    enabled: true,
  })
  dialogVisible.value = true
}

function openEdit(row: Plan) {
  editingId.value = row.id
  Object.assign(form, {
    name: row.name,
    description: row.description ?? '',
    price: row.price,
    currency: row.currency,
    monthlyQuota: row.monthlyQuota ?? 0,
    rateLimitRpm: row.rateLimitRpm ?? 0,
    markupDiscount: row.markupDiscount ?? 0,
    enabled: row.enabled,
  })
  dialogVisible.value = true
}

async function save() {
  if (editingId.value == null) {
    await planApi.create(form)
    ElMessage.success('Plan created')
  } else {
    await planApi.update(editingId.value, form)
    ElMessage.success('Plan updated')
  }
  dialogVisible.value = false
  load()
}

async function toggleEnabled(row: Plan, val: boolean) {
  await planApi.toggle(row.id, val)
  ElMessage.success('Updated')
  load()
}

async function remove(row: Plan) {
  await ElMessageBox.confirm(`Delete plan "${row.name}"?`, 'Confirm', {
    type: 'warning',
  })
  await planApi.remove(row.id)
  ElMessage.success('Deleted')
  load()
}

onMounted(load)
</script>

<template>
  <div class="page">
    <div class="page-header">
      <h2>Plans</h2>
      <el-button type="primary" :icon="'Plus'" @click="openCreate">
        New Plan
      </el-button>
    </div>

    <el-table :data="rows" v-loading="loading" border stripe>
      <el-table-column prop="id" label="ID" width="80" />
      <el-table-column prop="name" label="Name" />
      <el-table-column prop="description" label="Description" />
      <el-table-column label="Price" width="120">
        <template #default="{ row }">
          {{ row.currency }} {{ row.price }}
        </template>
      </el-table-column>
      <el-table-column prop="monthlyQuota" label="Monthly Quota" width="140" />
      <el-table-column prop="rateLimitRpm" label="Rate Limit (RPM)" width="150" />
      <el-table-column label="Markup Discount" width="150">
        <template #default="{ row }">
          {{ row.markupDiscount ?? 0 }}%
        </template>
      </el-table-column>
      <el-table-column label="Enabled" width="110">
        <template #default="{ row }">
          <el-switch
            :model-value="row.enabled"
            @change="(val: boolean) => toggleEnabled(row, val)"
          />
        </template>
      </el-table-column>
      <el-table-column prop="createdAt" label="Created At" width="180" />
      <el-table-column label="Actions" width="160" fixed="right">
        <template #default="{ row }">
          <el-button link type="primary" @click="openEdit(row)">Edit</el-button>
          <el-button link type="danger" @click="remove(row)">Delete</el-button>
        </template>
      </el-table-column>
    </el-table>

    <div class="pager">
      <el-pagination
        layout="total, prev, pager, next"
        :total="total"
        v-model:current-page="query.page"
        v-model:page-size="query.pageSize"
        @current-change="load"
      />
    </div>

    <el-dialog
      v-model="dialogVisible"
      :title="editingId == null ? 'New Plan' : 'Edit Plan'"
      width="480px"
    >
      <el-form :model="form" label-width="140px">
        <el-form-item label="Name">
          <el-input v-model="form.name" />
        </el-form-item>
        <el-form-item label="Description">
          <el-input v-model="form.description" type="textarea" :rows="3" />
        </el-form-item>
        <el-form-item label="Price">
          <el-input-number v-model="form.price" :min="0" :precision="2" />
        </el-form-item>
        <el-form-item label="Currency">
          <el-select v-model="form.currency">
            <el-option label="USD" value="USD" />
            <el-option label="CNY" value="CNY" />
          </el-select>
        </el-form-item>
        <el-form-item label="Monthly Quota">
          <el-input-number v-model="form.monthlyQuota" :min="0" />
        </el-form-item>
        <el-form-item label="Rate Limit (RPM)">
          <el-input-number v-model="form.rateLimitRpm" :min="0" />
        </el-form-item>
        <el-form-item label="Markup Discount (%)">
          <el-input-number v-model="form.markupDiscount" :min="0" />
        </el-form-item>
        <el-form-item label="Enabled">
          <el-switch v-model="form.enabled" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="dialogVisible = false">Cancel</el-button>
        <el-button type="primary" @click="save">Save</el-button>
      </template>
    </el-dialog>
  </div>
</template>
