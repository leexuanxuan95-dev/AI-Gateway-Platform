<script setup lang="ts">
import { onMounted, reactive, ref } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { userApi, type UpsertUserPayload } from '@/api/user'
import type { UserVO } from '@/api/auth'

const loading = ref(false)
const rows = ref<UserVO[]>([])
const total = ref(0)
const query = reactive({ page: 1, pageSize: 10, keyword: '' })

const dialogVisible = ref(false)
const editingId = ref<number | null>(null)
const form = reactive<UpsertUserPayload>({
  username: '',
  email: '',
  phone: '',
  role: 'member',
  password: '',
  status: 'active',
})

async function load() {
  loading.value = true
  try {
    const res = await userApi.list(query)
    rows.value = res.list
    total.value = res.total
  } catch {
    rows.value = []
    total.value = 0
  } finally {
    loading.value = false
  }
}

function openCreate() {
  editingId.value = null
  Object.assign(form, {
    username: '',
    email: '',
    phone: '',
    role: 'member',
    password: '',
    status: 'active',
  })
  dialogVisible.value = true
}

function openEdit(row: UserVO) {
  editingId.value = row.id
  Object.assign(form, {
    username: row.username,
    email: row.email,
    phone: row.phone ?? '',
    role: row.role,
    password: '',
    status: row.status,
  })
  dialogVisible.value = true
}

async function save() {
  if (editingId.value == null) {
    await userApi.create(form)
    ElMessage.success('User created')
  } else {
    await userApi.update(editingId.value, form)
    ElMessage.success('User updated')
  }
  dialogVisible.value = false
  load()
}

async function remove(row: UserVO) {
  await ElMessageBox.confirm(`Delete user "${row.username}"?`, 'Confirm', {
    type: 'warning',
  })
  await userApi.remove(row.id)
  ElMessage.success('Deleted')
  load()
}

onMounted(load)
</script>

<template>
  <div class="page">
    <div class="page-header">
      <h2>Users</h2>
      <el-button type="primary" :icon="'Plus'" @click="openCreate">
        New User
      </el-button>
    </div>

    <div class="toolbar">
      <el-input
        v-model="query.keyword"
        placeholder="Search username / email"
        clearable
        style="width: 260px"
        @keyup.enter="((query.page = 1), load())"
      />
      <el-button :icon="'Search'" @click="((query.page = 1), load())">
        Search
      </el-button>
    </div>

    <el-table :data="rows" v-loading="loading" border stripe>
      <el-table-column prop="id" label="ID" width="80" />
      <el-table-column prop="username" label="Username" />
      <el-table-column prop="email" label="Email" />
      <el-table-column prop="phone" label="Phone" width="140" />
      <el-table-column prop="role" label="Role" width="120">
        <template #default="{ row }">
          <el-tag size="small">{{ row.role }}</el-tag>
        </template>
      </el-table-column>
      <el-table-column prop="status" label="Status" width="110">
        <template #default="{ row }">
          <el-tag :type="row.status === 'active' ? 'success' : 'info'" size="small">
            {{ row.status }}
          </el-tag>
        </template>
      </el-table-column>
      <el-table-column label="Actions" width="160" fixed="right">
        <template #default="{ row }">
          <el-button link type="primary" @click="openEdit(row)">Edit</el-button>
          <el-button link type="danger" @click="remove(row)">Delete</el-button>
        </template>
      </el-table-column>
    </el-table>

    <div class="pager">
      <el-pagination
        layout="total, prev, pager, next, sizes"
        :total="total"
        v-model:current-page="query.page"
        v-model:page-size="query.pageSize"
        :page-sizes="[10, 20, 50]"
        @current-change="load"
        @size-change="load"
      />
    </div>

    <el-dialog
      v-model="dialogVisible"
      :title="editingId == null ? 'New User' : 'Edit User'"
      width="480px"
    >
      <el-form :model="form" label-width="100px">
        <el-form-item label="Username">
          <el-input v-model="form.username" />
        </el-form-item>
        <el-form-item label="Email">
          <el-input v-model="form.email" />
        </el-form-item>
        <el-form-item label="Phone">
          <el-input v-model="form.phone" />
        </el-form-item>
        <el-form-item label="Role">
          <el-select v-model="form.role">
            <el-option label="Admin" value="admin" />
            <el-option label="Operator" value="operator" />
            <el-option label="Member" value="member" />
          </el-select>
        </el-form-item>
        <el-form-item label="Password">
          <el-input
            v-model="form.password"
            type="password"
            show-password
            :placeholder="editingId == null ? '' : 'leave blank to keep'"
          />
        </el-form-item>
        <el-form-item label="Status">
          <el-select v-model="form.status">
            <el-option label="Active" value="active" />
            <el-option label="Disabled" value="disabled" />
          </el-select>
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="dialogVisible = false">Cancel</el-button>
        <el-button type="primary" @click="save">Save</el-button>
      </template>
    </el-dialog>
  </div>
</template>
