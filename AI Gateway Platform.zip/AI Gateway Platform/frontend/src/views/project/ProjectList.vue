<script setup lang="ts">
import { onMounted, reactive, ref } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { projectApi, type Project } from '@/api/project'

const loading = ref(false)
const rows = ref<Project[]>([])
const total = ref(0)
const query = reactive({ page: 1, pageSize: 10, keyword: '' })

const dialogVisible = ref(false)
const editingId = ref<number | null>(null)
const form = reactive<Partial<Project>>({
  name: '',
  companyId: 0,
  description: '',
  status: 'active',
})

async function load() {
  loading.value = true
  try {
    const res = await projectApi.list(query)
    rows.value = res.list
    total.value = res.total
  } catch {
    rows.value = []
    total.value = 0
  } finally {
    loading.value = false
  }
}

function openCreate() {
  editingId.value = null
  Object.assign(form, {
    name: '',
    companyId: 0,
    description: '',
    status: 'active',
  })
  dialogVisible.value = true
}

function openEdit(row: Project) {
  editingId.value = row.id
  Object.assign(form, {
    name: row.name,
    companyId: row.companyId,
    description: row.description ?? '',
    status: row.status,
  })
  dialogVisible.value = true
}

async function save() {
  if (editingId.value == null) {
    await projectApi.create(form)
    ElMessage.success('Project created')
  } else {
    await projectApi.update(editingId.value, form)
    ElMessage.success('Project updated')
  }
  dialogVisible.value = false
  load()
}

async function remove(row: Project) {
  await ElMessageBox.confirm(`Delete project "${row.name}"?`, 'Confirm', {
    type: 'warning',
  })
  await projectApi.remove(row.id)
  ElMessage.success('Deleted')
  load()
}

onMounted(load)
</script>

<template>
  <div class="page">
    <div class="page-header">
      <h2>Projects</h2>
      <el-button type="primary" :icon="'Plus'" @click="openCreate">
        New Project
      </el-button>
    </div>

    <div class="toolbar">
      <el-input
        v-model="query.keyword"
        placeholder="Search name"
        clearable
        style="width: 260px"
        @keyup.enter="((query.page = 1), load())"
      />
      <el-button :icon="'Search'" @click="((query.page = 1), load())">
        Search
      </el-button>
    </div>

    <el-table :data="rows" v-loading="loading" border stripe>
      <el-table-column prop="id" label="ID" width="80" />
      <el-table-column prop="name" label="Name" />
      <el-table-column prop="companyId" label="Company ID" width="120" />
      <el-table-column prop="description" label="Description" />
      <el-table-column prop="status" label="Status" width="110">
        <template #default="{ row }">
          <el-tag :type="row.status === 'active' ? 'success' : 'info'" size="small">
            {{ row.status }}
          </el-tag>
        </template>
      </el-table-column>
      <el-table-column prop="apiKeyCount" label="API Keys" width="110" />
      <el-table-column prop="createdAt" label="Created At" width="180" />
      <el-table-column label="Actions" width="160" fixed="right">
        <template #default="{ row }">
          <el-button link type="primary" @click="openEdit(row)">Edit</el-button>
          <el-button link type="danger" @click="remove(row)">Delete</el-button>
        </template>
      </el-table-column>
    </el-table>

    <div class="pager">
      <el-pagination
        layout="total, prev, pager, next"
        :total="total"
        v-model:current-page="query.page"
        v-model:page-size="query.pageSize"
        @current-change="load"
      />
    </div>

    <el-dialog
      v-model="dialogVisible"
      :title="editingId == null ? 'New Project' : 'Edit Project'"
      width="480px"
    >
      <el-form :model="form" label-width="100px">
        <el-form-item label="Name">
          <el-input v-model="form.name" />
        </el-form-item>
        <el-form-item label="Company ID">
          <el-input-number v-model="form.companyId" :min="0" />
        </el-form-item>
        <el-form-item label="Description">
          <el-input v-model="form.description" type="textarea" :rows="3" />
        </el-form-item>
        <el-form-item label="Status">
          <el-select v-model="form.status">
            <el-option label="Active" value="active" />
            <el-option label="Disabled" value="disabled" />
          </el-select>
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="dialogVisible = false">Cancel</el-button>
        <el-button type="primary" @click="save">Save</el-button>
      </template>
    </el-dialog>
  </div>
</template>
