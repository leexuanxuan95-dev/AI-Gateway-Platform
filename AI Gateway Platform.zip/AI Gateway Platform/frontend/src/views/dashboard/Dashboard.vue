<script setup lang="ts">
import { onMounted, ref } from 'vue'
import { dashboardApi, type DashboardStats } from '@/api/dashboard'

const stats = ref<DashboardStats>({
  totalCalls: 0,
  revenue: 0,
  activeCompanies: 0,
  channelsHealthy: 0,
  channelsTotal: 0,
  currency: 'USD',
})
const loading = ref(false)

async function load() {
  loading.value = true
  try {
    stats.value = await dashboardApi.stats()
  } catch {
    // Scaffold: fall back to mock numbers when backend is offline.
    stats.value = {
      totalCalls: 128_430,
      callsTrend: 12.4,
      revenue: 8_642.5,
      revenueTrend: 5.1,
      currency: 'USD',
      activeCompanies: 37,
      channelsHealthy: 8,
      channelsTotal: 9,
    }
  } finally {
    loading.value = false
  }
}

onMounted(load)
</script>

<template>
  <div class="page" v-loading="loading">
    <div class="page-header">
      <h2>Dashboard</h2>
      <el-button :icon="'Refresh'" @click="load">Refresh</el-button>
    </div>

    <el-row :gutter="16">
      <el-col :span="6">
        <el-card shadow="hover">
          <div class="stat">
            <div class="stat-label">API Calls (24h)</div>
            <div class="stat-value">{{ stats.totalCalls.toLocaleString() }}</div>
            <el-tag
              v-if="stats.callsTrend != null"
              :type="stats.callsTrend >= 0 ? 'success' : 'danger'"
              size="small"
            >
              {{ stats.callsTrend >= 0 ? '+' : '' }}{{ stats.callsTrend }}%
            </el-tag>
          </div>
        </el-card>
      </el-col>
      <el-col :span="6">
        <el-card shadow="hover">
          <div class="stat">
            <div class="stat-label">Revenue</div>
            <div class="stat-value">
              {{ stats.currency }} {{ stats.revenue.toLocaleString() }}
            </div>
            <el-tag
              v-if="stats.revenueTrend != null"
              :type="stats.revenueTrend >= 0 ? 'success' : 'danger'"
              size="small"
            >
              {{ stats.revenueTrend >= 0 ? '+' : '' }}{{ stats.revenueTrend }}%
            </el-tag>
          </div>
        </el-card>
      </el-col>
      <el-col :span="6">
        <el-card shadow="hover">
          <div class="stat">
            <div class="stat-label">Active Companies</div>
            <div class="stat-value">{{ stats.activeCompanies }}</div>
          </div>
        </el-card>
      </el-col>
      <el-col :span="6">
        <el-card shadow="hover">
          <div class="stat">
            <div class="stat-label">Channel Health</div>
            <div class="stat-value">
              {{ stats.channelsHealthy }}/{{ stats.channelsTotal }}
            </div>
            <el-tag
              :type="
                stats.channelsHealthy === stats.channelsTotal
                  ? 'success'
                  : 'warning'
              "
              size="small"
            >
              {{
                stats.channelsHealthy === stats.channelsTotal
                  ? 'All healthy'
                  : 'Degraded'
              }}
            </el-tag>
          </div>
        </el-card>
      </el-col>
    </el-row>

    <el-card class="chart-card" shadow="never">
      <template #header>Traffic & Revenue</template>
      <!-- TODO: wire dashboardApi.callsSeries / revenueSeries to a chart lib
           (e.g. ECharts) — out of scope for the scaffold. -->
      <el-empty description="Charts placeholder — integrate ECharts here" />
    </el-card>
  </div>
</template>

<style scoped>
.stat {
  display: flex;
  flex-direction: column;
  gap: 8px;
}
.stat-label {
  color: #909399;
  font-size: 13px;
}
.stat-value {
  font-size: 26px;
  font-weight: 700;
}
.chart-card {
  margin-top: 16px;
}
</style>
