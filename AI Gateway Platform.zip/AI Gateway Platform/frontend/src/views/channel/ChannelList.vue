<script setup lang="ts">
import { onMounted, reactive, ref } from 'vue'
import { ElMessage } from 'element-plus'
import {
  channelApi,
  type Channel,
  type ChannelHealth,
  type ChannelReserveConfig,
} from '@/api/channel'

const loading = ref(false)
const rows = ref<Channel[]>([])
const total = ref(0)
const query = reactive({ page: 1, pageSize: 10, provider: '' })

const reserveDialog = ref(false)
const editing = ref<Channel | null>(null)
const reserveForm = reactive<ChannelReserveConfig>({
  reserveEnabled: false,
  reserveBalance: 0,
  autoRechargeEnabled: false,
  autoRechargeAmount: 0,
  balanceThreshold: 0,
})

function healthTag(h: ChannelHealth) {
  switch (h) {
    case 'healthy':
      return { type: 'success' as const, label: 'Healthy' }
    case 'degraded':
      return { type: 'warning' as const, label: 'Degraded' }
    case 'circuit_open':
      return { type: 'danger' as const, label: 'Circuit open' }
    default:
      return { type: 'info' as const, label: 'Down' }
  }
}

async function load() {
  loading.value = true
  try {
    const res = await channelApi.list({
      page: query.page,
      pageSize: query.pageSize,
      provider: query.provider || undefined,
    })
    rows.value = res.list
    total.value = res.total
  } catch {
    rows.value = []
    total.value = 0
  } finally {
    loading.value = false
  }
}

async function toggle(row: Channel, enabled: boolean) {
  await channelApi.toggle(row.id, enabled)
  ElMessage.success(enabled ? 'Enabled' : 'Disabled')
  load()
}

async function probe(row: Channel) {
  await channelApi.probe(row.id)
  ElMessage.success('Probe triggered')
  load()
}

function openReserve(row: Channel) {
  editing.value = row
  reserveForm.reserveEnabled = row.reserveEnabled ?? false
  reserveForm.reserveBalance = row.reserveBalance ?? 0
  reserveForm.autoRechargeEnabled = row.autoRechargeEnabled ?? false
  reserveForm.autoRechargeAmount = row.autoRechargeAmount ?? 0
  reserveForm.balanceThreshold = row.balanceThreshold ?? 0
  reserveDialog.value = true
}

async function saveReserve() {
  if (!editing.value) return
  await channelApi.updateReserve(editing.value.id, { ...reserveForm })
  ElMessage.success('Reserve config saved')
  reserveDialog.value = false
  load()
}

onMounted(load)
</script>

<template>
  <div class="page">
    <div class="page-header">
      <h2>Channels (routing pool)</h2>
    </div>

    <div class="toolbar">
      <el-input
        v-model="query.provider"
        placeholder="Filter by provider"
        clearable
        style="width: 220px"
        @keyup.enter="((query.page = 1), load())"
      />
      <el-button :icon="'Search'" @click="((query.page = 1), load())">
        Search
      </el-button>
    </div>

    <el-table :data="rows" v-loading="loading" border stripe>
      <el-table-column prop="name" label="Channel" min-width="160" />
      <el-table-column prop="provider" label="Provider" width="120" />
      <el-table-column prop="priority" label="Priority" width="90" />
      <el-table-column prop="weight" label="Weight" width="90" />
      <el-table-column label="Health" width="130">
        <template #default="{ row }">
          <el-tag :type="healthTag(row.health).type" size="small">
            {{ healthTag(row.health).label }}
          </el-tag>
        </template>
      </el-table-column>
      <el-table-column label="Upstream balance" width="150">
        <template #default="{ row }">
          <span
            :class="{
              muted:
                row.balanceThreshold != null &&
                row.upstreamBalance != null &&
                row.upstreamBalance < row.balanceThreshold,
            }"
          >
            {{ row.upstreamBalance != null ? `$${row.upstreamBalance}` : '-' }}
          </span>
        </template>
      </el-table-column>
      <el-table-column prop="quota" label="Quota" width="100">
        <template #default="{ row }">{{ row.quota ?? '∞' }}</template>
      </el-table-column>
      <el-table-column label="Enabled" width="90">
        <template #default="{ row }">
          <el-switch
            :model-value="row.enabled"
            @change="(v: boolean) => toggle(row, v)"
          />
        </template>
      </el-table-column>
      <el-table-column label="Actions" width="220" fixed="right">
        <template #default="{ row }">
          <el-button link type="primary" @click="openReserve(row)">
            Reserve
          </el-button>
          <el-button link type="info" @click="probe(row)">Probe</el-button>
        </template>
      </el-table-column>
    </el-table>

    <div class="pager">
      <el-pagination
        layout="total, prev, pager, next"
        :total="total"
        v-model:current-page="query.page"
        v-model:page-size="query.pageSize"
        @current-change="load"
      />
    </div>

    <el-dialog
      v-model="reserveDialog"
      title="Reserve & auto-recharge"
      width="480px"
    >
      <el-form :model="reserveForm" label-width="180px">
        <el-form-item label="Low-balance threshold ($)">
          <el-input-number v-model="reserveForm.balanceThreshold" :min="0" />
        </el-form-item>
        <el-form-item label="Reserve enabled">
          <el-switch v-model="reserveForm.reserveEnabled" />
        </el-form-item>
        <el-form-item label="Reserve balance ($)">
          <el-input-number
            v-model="reserveForm.reserveBalance"
            :min="0"
            :disabled="!reserveForm.reserveEnabled"
          />
        </el-form-item>
        <el-form-item label="Auto-recharge enabled">
          <el-switch v-model="reserveForm.autoRechargeEnabled" />
        </el-form-item>
        <el-form-item label="Auto-recharge amount ($)">
          <el-input-number
            v-model="reserveForm.autoRechargeAmount"
            :min="0"
            :disabled="!reserveForm.autoRechargeEnabled"
          />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="reserveDialog = false">Cancel</el-button>
        <el-button type="primary" @click="saveReserve">Save</el-button>
      </template>
    </el-dialog>
  </div>
</template>
