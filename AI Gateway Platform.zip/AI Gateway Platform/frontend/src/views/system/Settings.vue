<script setup lang="ts">
import { onMounted, reactive, ref } from 'vue'
import { ElMessage } from 'element-plus'
import { get, put } from '@/api/request'

interface SystemSettings {
  exchangeRateSafetyFactor: number
  upstreamBalanceAlertThreshold: number
  modelAutoSyncEnabled: boolean
  modelSyncIntervalHours: number
  priceAutoSyncEnabled: boolean
  defaultCurrency: string
  maintenanceMode: boolean
}

const defaults: SystemSettings = {
  exchangeRateSafetyFactor: 1.05,
  upstreamBalanceAlertThreshold: 100,
  modelAutoSyncEnabled: true,
  modelSyncIntervalHours: 24,
  priceAutoSyncEnabled: true,
  defaultCurrency: 'USD',
  maintenanceMode: false,
}

const loading = ref(false)
const saving = ref(false)
const form = reactive<SystemSettings>({ ...defaults })

async function load() {
  loading.value = true
  try {
    const res = await get<SystemSettings>('/api/system/settings')
    Object.assign(form, defaults, res)
  } catch {
    Object.assign(form, defaults)
  } finally {
    loading.value = false
  }
}

async function save() {
  saving.value = true
  try {
    await put('/api/system/settings', { ...form })
    ElMessage.success('Saved')
  } finally {
    saving.value = false
  }
}

onMounted(load)
</script>

<template>
  <div class="page">
    <div class="page-header">
      <h2>Settings</h2>
    </div>

    <el-card shadow="never">
      <el-form
        v-loading="loading"
        :model="form"
        label-width="240px"
        style="max-width: 640px"
      >
        <el-form-item label="Exchange Rate Safety Factor">
          <el-input-number
            v-model="form.exchangeRateSafetyFactor"
            :step="0.01"
            :min="1"
          />
        </el-form-item>

        <el-form-item label="Upstream Balance Alert Threshold">
          <el-input-number
            v-model="form.upstreamBalanceAlertThreshold"
            :min="0"
          />
        </el-form-item>

        <el-form-item label="Default Currency">
          <el-select v-model="form.defaultCurrency" style="width: 180px">
            <el-option label="USD" value="USD" />
            <el-option label="CNY" value="CNY" />
            <el-option label="EUR" value="EUR" />
          </el-select>
        </el-form-item>

        <el-form-item label="Model Auto Sync">
          <el-switch v-model="form.modelAutoSyncEnabled" />
        </el-form-item>

        <el-form-item label="Model Sync Interval (hours)">
          <el-input-number
            v-model="form.modelSyncIntervalHours"
            :min="1"
            :disabled="!form.modelAutoSyncEnabled"
          />
        </el-form-item>

        <el-form-item label="Price Auto Sync">
          <el-switch v-model="form.priceAutoSyncEnabled" />
        </el-form-item>

        <el-form-item label="Maintenance Mode">
          <el-switch v-model="form.maintenanceMode" />
        </el-form-item>

        <el-form-item>
          <el-button type="primary" :loading="saving" @click="save">
            Save
          </el-button>
          <el-button :disabled="loading" @click="load">Reset</el-button>
        </el-form-item>
      </el-form>
    </el-card>
  </div>
</template>
