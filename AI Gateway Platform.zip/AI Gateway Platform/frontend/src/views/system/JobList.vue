<script setup lang="ts">
import { onMounted, ref } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { listJobs, updateJob, runJob, type ScheduledJob } from '@/api/scheduler'

const loading = ref(false)
const jobs = ref<ScheduledJob[]>([])

async function load() {
  loading.value = true
  try {
    jobs.value = await listJobs()
  } catch (e) {
    /* request interceptor surfaces the error */
  } finally {
    loading.value = false
  }
}

async function toggle(job: ScheduledJob) {
  await updateJob(job.jobKey, { enabled: job.enabled })
  ElMessage.success(`${job.jobKey} ${job.enabled ? 'enabled' : 'disabled'}`)
  await load()
}

async function editCron(job: ScheduledJob) {
  const { value } = await ElMessageBox.prompt('Cron (Spring 6-field: sec min hour day month weekday)', `Edit schedule: ${job.jobKey}`, {
    inputValue: job.cron,
    inputPattern: /\S+/,
    inputErrorMessage: 'cron required',
  })
  await updateJob(job.jobKey, { cron: value })
  ElMessage.success('schedule updated')
  await load()
}

async function run(job: ScheduledJob) {
  await runJob(job.jobKey)
  ElMessage.success(`${job.jobKey} triggered`)
  setTimeout(load, 1500)
}

function statusType(s?: string) {
  return s === 'success' ? 'success' : s === 'fail' ? 'danger' : s === 'running' ? 'warning' : 'info'
}

onMounted(load)
</script>

<template>
  <el-card shadow="never">
    <template #header>
      <div style="display:flex;justify-content:space-between;align-items:center">
        <span>定时任务 / Scheduled Jobs</span>
        <el-button size="small" @click="load" :loading="loading">刷新</el-button>
      </div>
    </template>

    <el-table :data="jobs" v-loading="loading" stripe>
      <el-table-column prop="jobKey" label="Key" width="180" />
      <el-table-column prop="description" label="说明" min-width="200" show-overflow-tooltip />
      <el-table-column prop="cron" label="Cron" width="160" />
      <el-table-column label="启用" width="90">
        <template #default="{ row }">
          <el-switch v-model="row.enabled" @change="toggle(row)" />
        </template>
      </el-table-column>
      <el-table-column label="上次状态" width="110">
        <template #default="{ row }">
          <el-tag :type="statusType(row.lastStatus)" size="small">{{ row.lastStatus || '—' }}</el-tag>
        </template>
      </el-table-column>
      <el-table-column prop="lastRunAt" label="上次运行" width="180" />
      <el-table-column prop="nextRunAt" label="下次运行" width="180" />
      <el-table-column label="操作" width="170" fixed="right">
        <template #default="{ row }">
          <el-button link type="primary" size="small" @click="editCron(row)">改时间</el-button>
          <el-button link type="primary" size="small" @click="run(row)">立即运行</el-button>
        </template>
      </el-table-column>
    </el-table>
    <p style="color:#999;font-size:12px;margin-top:8px">仅超级管理员可见。改 cron / 启停 / 立即运行均实时生效,无需重启。</p>
  </el-card>
</template>
