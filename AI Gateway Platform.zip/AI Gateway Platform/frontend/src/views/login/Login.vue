<script setup lang="ts">
import { reactive, ref } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { ElMessage, type FormInstance, type FormRules } from 'element-plus'
import { useAuthStore } from '@/stores/auth'
import { authApi } from '@/api/auth'

const router = useRouter()
const route = useRoute()
const auth = useAuthStore()

const mode = ref<'login' | 'register'>('login')
const loading = ref(false)
const formRef = ref<FormInstance>()

const form = reactive({
  username: '',
  password: '',
  email: '',
  code: '',
  companyName: '',
})

const rules: FormRules = {
  username: [{ required: true, message: 'Username is required', trigger: 'blur' }],
  password: [{ required: true, message: 'Password is required', trigger: 'blur' }],
  email: [
    { required: true, message: 'Email is required', trigger: 'blur' },
    { type: 'email', message: 'Invalid email', trigger: 'blur' },
  ],
  code: [{ required: true, message: 'Verification code is required', trigger: 'blur' }],
}

const codeSending = ref(false)
const codeCountdown = ref(0)

async function sendCode() {
  if (!form.email) {
    ElMessage.warning('Enter your email first')
    return
  }
  codeSending.value = true
  try {
    await authApi.sendCode({ email: form.email, scene: 'register' })
    ElMessage.success('Verification code sent')
    codeCountdown.value = 60
    const t = setInterval(() => {
      codeCountdown.value -= 1
      if (codeCountdown.value <= 0) clearInterval(t)
    }, 1000)
  } finally {
    codeSending.value = false
  }
}

async function submit() {
  if (!formRef.value) return
  await formRef.value.validate(async (valid) => {
    if (!valid) return
    loading.value = true
    try {
      if (mode.value === 'login') {
        await auth.login({ username: form.username, password: form.password })
      } else {
        // register returns the same LoginResult shape; persist via store.
        await auth.login({ username: form.username, password: form.password }).catch(
          async () => {
            // Fallback: call register endpoint directly, then re-login.
            await authApi.register({
              username: form.username,
              email: form.email,
              password: form.password,
              code: form.code,
              companyName: form.companyName || undefined,
            })
            await auth.login({ username: form.username, password: form.password })
          },
        )
      }
      ElMessage.success('Welcome')
      const redirect = (route.query.redirect as string) || '/dashboard'
      router.push(redirect)
    } finally {
      loading.value = false
    }
  })
}
</script>

<template>
  <div class="login-wrap">
    <el-card class="login-card">
      <div class="brand">
        <h1>AI Gateway Console</h1>
        <p class="muted">Enterprise AI traffic management</p>
      </div>

      <el-tabs v-model="mode" stretch>
        <el-tab-pane label="Sign in" name="login" />
        <el-tab-pane label="Register" name="register" />
      </el-tabs>

      <el-form ref="formRef" :model="form" :rules="rules" label-position="top">
        <el-form-item label="Username" prop="username">
          <el-input v-model="form.username" placeholder="username" />
        </el-form-item>

        <template v-if="mode === 'register'">
          <el-form-item label="Email" prop="email">
            <el-input v-model="form.email" placeholder="you@company.com" />
          </el-form-item>
          <el-form-item label="Verification code" prop="code">
            <div class="code-row">
              <el-input v-model="form.code" placeholder="6-digit code" />
              <el-button
                :disabled="codeCountdown > 0"
                :loading="codeSending"
                @click="sendCode"
              >
                {{ codeCountdown > 0 ? `${codeCountdown}s` : 'Send code' }}
              </el-button>
            </div>
          </el-form-item>
          <el-form-item label="Company name">
            <el-input v-model="form.companyName" placeholder="optional" />
          </el-form-item>
        </template>

        <el-form-item label="Password" prop="password">
          <el-input
            v-model="form.password"
            type="password"
            show-password
            placeholder="password"
            @keyup.enter="submit"
          />
        </el-form-item>

        <el-button
          type="primary"
          class="submit"
          :loading="loading"
          @click="submit"
        >
          {{ mode === 'login' ? 'Sign in' : 'Create account' }}
        </el-button>
      </el-form>
    </el-card>
  </div>
</template>

<style scoped>
.login-wrap {
  height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  background: linear-gradient(135deg, #1f2937, #111827);
}
.login-card {
  width: 380px;
}
.brand {
  text-align: center;
  margin-bottom: 8px;
}
.brand h1 {
  font-size: 20px;
  margin: 0 0 4px;
}
.code-row {
  display: flex;
  gap: 8px;
  width: 100%;
}
.submit {
  width: 100%;
}
</style>
