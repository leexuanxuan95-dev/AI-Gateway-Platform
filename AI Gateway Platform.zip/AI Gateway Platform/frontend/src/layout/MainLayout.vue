<script setup lang="ts">
import { computed, onMounted, ref } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { ElMessageBox } from 'element-plus'
import { useAuthStore } from '@/stores/auth'
import { useAppStore } from '@/stores/app'
import { companyApi, type Company } from '@/api/company'

const route = useRoute()
const router = useRouter()
const auth = useAuthStore()
const app = useAppStore()

const activeMenu = computed(() => route.path)

// Sidebar menu groups (mirrors design doc §14 admin modules).
interface MenuItem {
  path: string
  title: string
  icon: string
}
interface MenuGroup {
  title: string
  icon: string
  items: MenuItem[]
}

const menuGroups: MenuGroup[] = [
  {
    title: 'Overview',
    icon: 'Odometer',
    items: [{ path: '/dashboard', title: 'Dashboard', icon: 'Odometer' }],
  },
  {
    title: 'Tenants',
    icon: 'OfficeBuilding',
    items: [
      { path: '/companies', title: 'Companies', icon: 'OfficeBuilding' },
      { path: '/companies/audit', title: 'Company Audit', icon: 'CircleCheck' },
      { path: '/users', title: 'Users', icon: 'User' },
      { path: '/projects', title: 'Projects', icon: 'Folder' },
      { path: '/apikeys', title: 'API Keys', icon: 'Key' },
    ],
  },
  {
    title: 'Models & Routing',
    icon: 'MagicStick',
    items: [
      { path: '/models', title: 'Models', icon: 'MagicStick' },
      { path: '/channels', title: 'Channels', icon: 'Connection' },
    ],
  },
  {
    title: 'Commercial',
    icon: 'Goods',
    items: [
      { path: '/plans', title: 'Plans', icon: 'Goods' },
      { path: '/pay-config', title: 'Payment Config', icon: 'CreditCard' },
    ],
  },
  {
    title: 'Finance',
    icon: 'Wallet',
    items: [
      { path: '/finance/recharge', title: 'Recharge', icon: 'Wallet' },
      { path: '/finance/transactions', title: 'Transactions', icon: 'List' },
      { path: '/finance/withdraw', title: 'Withdraw', icon: 'Money' },
      { path: '/finance/profit', title: 'Profit', icon: 'TrendCharts' },
    ],
  },
  {
    title: 'Billing',
    icon: 'Document',
    items: [
      { path: '/billing/call-log', title: 'Call Log', icon: 'Document' },
      { path: '/billing/token-bill', title: 'Token Bill', icon: 'Tickets' },
    ],
  },
  {
    title: 'Operations',
    icon: 'Setting',
    items: [
      { path: '/risk', title: 'Risk Center', icon: 'Warning' },
      { path: '/notify', title: 'Notifications', icon: 'Bell' },
      { path: '/jobs', title: 'Scheduled Jobs', icon: 'Timer' },
      { path: '/settings', title: 'Settings', icon: 'Setting' },
    ],
  },
]

function go(path: string) {
  router.push(path)
}

// --- Company switcher ---
const companies = ref<Company[]>([])
const currentCompanyId = computed({
  get: () => app.currentCompanyId,
  set: (id?: number) => {
    const c = companies.value.find((x) => x.id === id) ?? null
    app.setCurrentCompany(c)
  },
})

async function loadCompanies() {
  try {
    const res = await companyApi.list({ page: 1, pageSize: 100 })
    companies.value = res.list
    if (!app.currentCompany && res.list.length) {
      app.setCurrentCompany(res.list[0])
    }
  } catch {
    // Backend may be unavailable in scaffold mode; switcher stays empty.
  }
}

async function handleLogout() {
  await ElMessageBox.confirm('Sign out of the console?', 'Confirm', {
    type: 'warning',
  }).catch(() => 'cancel')
  await auth.logout()
  router.push('/login')
}

onMounted(() => {
  loadCompanies()
  // Refresh current user profile if we have a token but no user.
  if (auth.isAuthenticated && !auth.user) {
    auth.fetchMe().catch(() => undefined)
  }
})
</script>

<template>
  <el-container class="layout">
    <el-aside :width="app.sidebarCollapsed ? '64px' : '220px'" class="aside">
      <div class="logo">
        <span v-if="!app.sidebarCollapsed">AI Gateway</span>
        <span v-else>AG</span>
      </div>
      <el-menu
        :default-active="activeMenu"
        :collapse="app.sidebarCollapsed"
        :collapse-transition="false"
        background-color="#1f2937"
        text-color="#cbd5e1"
        active-text-color="#409eff"
        router
      >
        <el-sub-menu
          v-for="group in menuGroups"
          :key="group.title"
          :index="group.title"
        >
          <template #title>
            <el-icon><component :is="group.icon" /></el-icon>
            <span>{{ group.title }}</span>
          </template>
          <el-menu-item
            v-for="item in group.items"
            :key="item.path"
            :index="item.path"
            @click="go(item.path)"
          >
            <el-icon><component :is="item.icon" /></el-icon>
            <span>{{ item.title }}</span>
          </el-menu-item>
        </el-sub-menu>
      </el-menu>
    </el-aside>

    <el-container>
      <el-header class="header">
        <div class="header-left">
          <el-button
            link
            :icon="app.sidebarCollapsed ? 'Expand' : 'Fold'"
            @click="app.toggleSidebar()"
          />
          <span class="title">{{ route.meta.title ?? 'Console' }}</span>
        </div>
        <div class="header-right">
          <el-select
            v-model="currentCompanyId"
            placeholder="Company"
            size="default"
            filterable
            class="company-select"
          >
            <el-option
              v-for="c in companies"
              :key="c.id"
              :label="c.name"
              :value="c.id"
            />
          </el-select>

          <el-dropdown trigger="click">
            <span class="user-trigger">
              <el-icon><Avatar /></el-icon>
              <span class="username">{{ auth.username || 'admin' }}</span>
              <el-icon><ArrowDown /></el-icon>
            </span>
            <template #dropdown>
              <el-dropdown-menu>
                <el-dropdown-item disabled>
                  {{ auth.user?.email || auth.role || 'Signed in' }}
                </el-dropdown-item>
                <el-dropdown-item divided @click="handleLogout">
                  <el-icon><SwitchButton /></el-icon> Sign out
                </el-dropdown-item>
              </el-dropdown-menu>
            </template>
          </el-dropdown>
        </div>
      </el-header>

      <el-main class="main">
        <router-view v-slot="{ Component }">
          <component :is="Component" />
        </router-view>
      </el-main>
    </el-container>
  </el-container>
</template>

<style scoped>
.layout {
  height: 100vh;
}
.aside {
  background: #1f2937;
  transition: width 0.2s;
  overflow-x: hidden;
}
.aside :deep(.el-menu) {
  border-right: none;
}
.logo {
  height: 56px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #fff;
  font-weight: 700;
  letter-spacing: 1px;
  background: #111827;
}
.header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  background: #fff;
  border-bottom: 1px solid #ebeef5;
}
.header-left {
  display: flex;
  align-items: center;
  gap: 12px;
}
.header-left .title {
  font-weight: 600;
}
.header-right {
  display: flex;
  align-items: center;
  gap: 16px;
}
.company-select {
  width: 200px;
}
.user-trigger {
  display: flex;
  align-items: center;
  gap: 6px;
  cursor: pointer;
}
.main {
  background: var(--aigw-bg);
  padding: 0;
}
</style>
