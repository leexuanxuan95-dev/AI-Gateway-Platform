import {
  createRouter,
  createWebHistory,
  type RouteRecordRaw,
} from 'vue-router'
import { useAuthStore } from '@/stores/auth'

const routes: RouteRecordRaw[] = [
  {
    path: '/login',
    name: 'login',
    component: () => import('@/views/login/Login.vue'),
    meta: { public: true, title: 'Sign in' },
  },
  {
    path: '/',
    component: () => import('@/layout/MainLayout.vue'),
    redirect: '/dashboard',
    children: [
      {
        path: 'dashboard',
        name: 'dashboard',
        component: () => import('@/views/dashboard/Dashboard.vue'),
        meta: { title: 'Dashboard', icon: 'Odometer' },
      },
      // --- Tenants ---
      {
        path: 'companies',
        name: 'companies',
        component: () => import('@/views/company/CompanyList.vue'),
        meta: { title: 'Companies', icon: 'OfficeBuilding' },
      },
      {
        path: 'companies/audit',
        name: 'company-audit',
        component: () => import('@/views/company/CompanyAudit.vue'),
        meta: { title: 'Company Audit', icon: 'CircleCheck' },
      },
      {
        path: 'users',
        name: 'users',
        component: () => import('@/views/user/UserList.vue'),
        meta: { title: 'Users', icon: 'User' },
      },
      {
        path: 'projects',
        name: 'projects',
        component: () => import('@/views/project/ProjectList.vue'),
        meta: { title: 'Projects', icon: 'Folder' },
      },
      {
        path: 'apikeys',
        name: 'apikeys',
        component: () => import('@/views/apikey/ApiKeyList.vue'),
        meta: { title: 'API Keys', icon: 'Key' },
      },
      // --- Models & routing ---
      {
        path: 'models',
        name: 'models',
        component: () => import('@/views/model/ModelList.vue'),
        meta: { title: 'Models', icon: 'MagicStick' },
      },
      {
        path: 'channels',
        name: 'channels',
        component: () => import('@/views/channel/ChannelList.vue'),
        meta: { title: 'Channels', icon: 'Connection' },
      },
      // --- Commercial ---
      {
        path: 'plans',
        name: 'plans',
        component: () => import('@/views/plan/PlanList.vue'),
        meta: { title: 'Plans', icon: 'Goods' },
      },
      {
        path: 'pay-config',
        name: 'pay-config',
        component: () => import('@/views/pay/PayConfig.vue'),
        meta: { title: 'Payment Config', icon: 'CreditCard' },
      },
      // --- Finance ---
      {
        path: 'finance/recharge',
        name: 'recharge',
        component: () => import('@/views/finance/Recharge.vue'),
        meta: { title: 'Recharge', icon: 'Wallet' },
      },
      {
        path: 'finance/transactions',
        name: 'transactions',
        component: () => import('@/views/finance/Transactions.vue'),
        meta: { title: 'Transactions', icon: 'List' },
      },
      {
        path: 'finance/withdraw',
        name: 'withdraw',
        component: () => import('@/views/finance/Withdraw.vue'),
        meta: { title: 'Withdraw', icon: 'Money' },
      },
      {
        path: 'finance/profit',
        name: 'profit',
        component: () => import('@/views/finance/Profit.vue'),
        meta: { title: 'Profit', icon: 'TrendCharts' },
      },
      // --- Billing / usage ---
      {
        path: 'billing/call-log',
        name: 'call-log',
        component: () => import('@/views/billing/CallLog.vue'),
        meta: { title: 'Call Log', icon: 'Document' },
      },
      {
        path: 'billing/token-bill',
        name: 'token-bill',
        component: () => import('@/views/billing/TokenBill.vue'),
        meta: { title: 'Token Bill', icon: 'Tickets' },
      },
      // --- Ops ---
      {
        path: 'risk',
        name: 'risk',
        component: () => import('@/views/risk/RiskCenter.vue'),
        meta: { title: 'Risk Center', icon: 'Warning' },
      },
      {
        path: 'notify',
        name: 'notify',
        component: () => import('@/views/notify/NotifyCenter.vue'),
        meta: { title: 'Notifications', icon: 'Bell' },
      },
      {
        path: 'settings',
        name: 'settings',
        component: () => import('@/views/system/Settings.vue'),
        meta: { title: 'Settings', icon: 'Setting' },
      },
      {
        path: 'jobs',
        name: 'jobs',
        component: () => import('@/views/system/JobList.vue'),
        meta: { title: 'Scheduled Jobs', icon: 'Timer' },
      },
    ],
  },
  {
    path: '/:pathMatch(.*)*',
    redirect: '/dashboard',
  },
]

const router = createRouter({
  history: createWebHistory(),
  routes,
})

// Navigation guard: require auth for non-public routes.
router.beforeEach((to) => {
  const auth = useAuthStore()
  if (to.meta.public) {
    // Already signed in -> skip login page.
    if (to.name === 'login' && auth.isAuthenticated) {
      return { path: '/dashboard' }
    }
    return true
  }
  if (!auth.isAuthenticated) {
    return { path: '/login', query: { redirect: to.fullPath } }
  }
  return true
})

export default router
