# AI Gateway — Admin Console (frontend)

Vue 3 + TypeScript admin/console for the AI Gateway SaaS platform.

Stack: **Vue 3** · **TypeScript** · **Pinia** · **Vue Router 4** · **Element Plus** · **Vite** · **Axios**.

> This console targets the **management REST API** (`/api/...`). The
> OpenAI-compatible model traffic surface (`/v1/...`) is a separate system and is
> **not** part of this UI.

## Quick start

```bash
cd frontend
npm install
npm run dev
```

Dev server runs at <http://localhost:5173>.

### Backend proxy

`vite.config.ts` proxies API calls to the Spring Boot backend so there are no
CORS issues in development:

| Path     | Proxied to                         |
|----------|------------------------------------|
| `/api/*` | `http://localhost:8080` (mgmt API) |
| `/v1/*`  | `http://localhost:8080` (kept for tooling only) |

Override the backend origin without editing the config:

```bash
VITE_BACKEND_ORIGIN=http://my-backend:8080 npm run dev
```

The app renders even when the backend is offline — list pages fall back to empty
tables and the dashboard shows mock stats, so you can develop the UI standalone.

## Scripts

| Command             | Description                            |
|---------------------|----------------------------------------|
| `npm run dev`       | Start Vite dev server                  |
| `npm run build`     | Type-check (`vue-tsc`) + production build to `dist/` |
| `npm run preview`   | Preview the production build           |
| `npm run type-check`| Run `vue-tsc --noEmit` only            |

## Auth flow

- `POST /api/auth/login` → `{ accessToken, refreshToken, user }`.
- The token is stored in the Pinia `auth` store and persisted to `localStorage`.
- The Axios request interceptor adds `Authorization: Bearer <accessToken>`.
- The response interceptor unwraps the `{ code, msg, data }` envelope
  (`code === 0` = success) and returns `data` directly to callers.
- A `401` clears the session and redirects to `/login` (auto-logout).
- The router guard redirects unauthenticated users to `/login`.

## Project structure

```
src/
  api/        Typed API modules (auth, company, project, apikey, model,
              channel, finance, pay, plan, risk, notify, dashboard, billing,
              user) + request.ts (axios + envelope unwrap) + types.ts
  stores/     Pinia stores: auth (token/user), app (sidebar/current company)
  router/     Routes + nav guard (public /login + authenticated layout)
  layout/     MainLayout.vue (el-container: grouped sidebar + top bar)
  views/      One folder per module (login, dashboard, user, company, model,
              channel, plan, pay, finance, apikey, project, billing, risk,
              notify, system)
  assets/     Global CSS
  main.ts     App bootstrap (Element Plus, router, pinia, icons)
```

## Security notes

- **Raw API keys** are shown exactly once in a create dialog (with copy button +
  warning) and are dropped from memory when the dialog closes. List endpoints
  only ever return a masked preview.
- **Payment credentials** in the Payment Config center are displayed masked;
  blank fields keep the existing secret — only entered values are sent back.
- **Auto-logout** on `401`.

## Docker

Multi-stage build → static assets served by nginx, which also reverse-proxies
`/api` and `/v1` to the backend (service name `backend:8080`).

```bash
docker build -t ai-gateway-console ./frontend
```

Intended to be wired into the platform `docker-compose` as the `frontend`
service. Adjust the `upstream backend` block in `nginx.conf` if your backend
service name/port differs.

## Notes for extenders

- Endpoints are typed and follow `/api/<module>` REST conventions; some are
  best-guess and marked where deeper logic is out of scope (`TODO` comments).
- Dashboard charts are a placeholder — wire `dashboardApi.callsSeries` /
  `revenueSeries` to a chart library (e.g. ECharts).
- Model versions marked `unavailable` are greyed out and their controls disabled
  per design doc §7.1 / §7.5.
```
