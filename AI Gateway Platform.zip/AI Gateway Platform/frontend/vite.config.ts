import { fileURLToPath, URL } from 'node:url'
import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'

// Backend (Spring Boot) management API + OpenAI-compatible traffic surface.
const BACKEND = process.env.VITE_BACKEND_ORIGIN || 'http://localhost:8080'

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [vue()],
  resolve: {
    alias: {
      '@': fileURLToPath(new URL('./src', import.meta.url)),
    },
  },
  server: {
    port: 5173,
    proxy: {
      // Management REST API
      '/api': {
        target: BACKEND,
        changeOrigin: true,
      },
      // OpenAI-compatible model traffic (kept here for convenience/testing only;
      // it is NOT part of the console surface).
      '/v1': {
        target: BACKEND,
        changeOrigin: true,
      },
    },
  },
})
