-- LiteLLM manages its own schema via Prisma and will take over the `public` schema of
-- whatever database it connects to. It MUST therefore use a separate database from the
-- application, or it will wipe the app tables. Create that database here (runs before the
-- app schema script, ordered by filename).
CREATE DATABASE litellm;
