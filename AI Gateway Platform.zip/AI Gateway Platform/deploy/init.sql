-- ============================================================================
-- AI Gateway SaaS - PostgreSQL 16 initial schema (init.sql)
-- Consolidated DDL for all modules per the design doc. Idempotent-ish:
-- uses CREATE TABLE IF NOT EXISTS so it can be re-run on a fresh DB.
-- ============================================================================

-- ===================== §3 User system =====================
CREATE TABLE IF NOT EXISTS sys_user (
    id              BIGSERIAL PRIMARY KEY,
    uid             VARCHAR(32) UNIQUE NOT NULL,
    email           VARCHAR(128) UNIQUE,
    mobile          VARCHAR(20) UNIQUE,
    nickname        VARCHAR(64),
    avatar          VARCHAR(512),
    password        VARCHAR(128),
    google_id       VARCHAR(64) UNIQUE,
    totp_secret     VARCHAR(64),
    totp_enabled    BOOLEAN DEFAULT FALSE,
    super_admin     BOOLEAN DEFAULT FALSE,
    status          SMALLINT DEFAULT 0,          -- 0 pending review 1 normal 2 logged-off 3 disabled 4 cancelled
    register_ip     VARCHAR(45),
    register_time   TIMESTAMPTZ DEFAULT now(),
    last_login_time TIMESTAMPTZ,
    last_login_ip   VARCHAR(45),
    deleted         SMALLINT DEFAULT 0,
    created_at      TIMESTAMPTZ DEFAULT now(),
    updated_at      TIMESTAMPTZ DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_user_email ON sys_user(email);
CREATE INDEX IF NOT EXISTS idx_user_mobile ON sys_user(mobile);

CREATE TABLE IF NOT EXISTS sys_login_log (
    id           BIGSERIAL PRIMARY KEY,
    user_id      BIGINT NOT NULL,
    login_type   VARCHAR(20),
    ip           VARCHAR(45),
    location     VARCHAR(128),
    user_agent   VARCHAR(512),
    device_id    VARCHAR(64),
    status       SMALLINT,                        -- 1 success 0 fail
    created_at   TIMESTAMPTZ DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_login_log_user ON sys_login_log(user_id);

-- ===================== §4 Company (multi-tenant) =====================
CREATE TABLE IF NOT EXISTS biz_company (
    id               BIGSERIAL PRIMARY KEY,
    company_code     VARCHAR(32) UNIQUE NOT NULL,
    company_name     VARCHAR(128) NOT NULL,
    contact_name     VARCHAR(64),
    contact_mobile   VARCHAR(20),
    contact_email    VARCHAR(128),
    business_license VARCHAR(512),
    legal_id_front   VARCHAR(512),
    owner_user_id    BIGINT NOT NULL,
    plan_id          BIGINT,
    plan_expire_at   TIMESTAMPTZ,
    auth_status      SMALLINT DEFAULT 0,          -- 0 pending 1 passed 2 rejected
    status           SMALLINT DEFAULT 1,          -- 1 normal 2 logged-off 3 disabled
    deleted          SMALLINT DEFAULT 0,
    created_at       TIMESTAMPTZ DEFAULT now(),
    updated_at       TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS biz_company_member (
    id          BIGSERIAL PRIMARY KEY,
    company_id  BIGINT NOT NULL,
    user_id     BIGINT NOT NULL,
    role        VARCHAR(20) NOT NULL,             -- OWNER/ADMIN/DEVELOPER/VIEWER
    status      SMALLINT DEFAULT 1,
    invited_by  BIGINT,
    joined_at   TIMESTAMPTZ DEFAULT now(),
    UNIQUE(company_id, user_id)
);
CREATE INDEX IF NOT EXISTS idx_member_user ON biz_company_member(user_id);

CREATE TABLE IF NOT EXISTS biz_company_invite (
    id           BIGSERIAL PRIMARY KEY,
    company_id   BIGINT NOT NULL,
    invite_token VARCHAR(64) UNIQUE NOT NULL,
    role         VARCHAR(20) NOT NULL,
    email        VARCHAR(128),
    invited_by   BIGINT,
    expire_at    TIMESTAMPTZ,
    used         BOOLEAN DEFAULT FALSE,
    created_at   TIMESTAMPTZ DEFAULT now()
);

-- ===================== §5 Project =====================
CREATE TABLE IF NOT EXISTS biz_project (
    id            BIGSERIAL PRIMARY KEY,
    company_id    BIGINT NOT NULL,
    name          VARCHAR(64) NOT NULL,
    description   VARCHAR(255),
    monthly_quota NUMERIC(18,6) DEFAULT 0,        -- 0 = unlimited
    allowed_models JSONB,
    status        SMALLINT DEFAULT 1,
    deleted       SMALLINT DEFAULT 0,
    created_at    TIMESTAMPTZ DEFAULT now(),
    updated_at    TIMESTAMPTZ DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_project_company ON biz_project(company_id);

-- ===================== §6 API Key =====================
CREATE TABLE IF NOT EXISTS biz_api_key (
    id            BIGSERIAL PRIMARY KEY,
    company_id    BIGINT NOT NULL,
    project_id    BIGINT,
    key_name      VARCHAR(64),
    key_prefix    VARCHAR(12),
    key_hash      VARCHAR(64) UNIQUE NOT NULL,     -- SHA-256
    allowed_models JSONB,
    rpm_limit     INT DEFAULT 60,
    tpm_limit     INT DEFAULT 100000,
    daily_quota   NUMERIC(18,6) DEFAULT 0,
    ip_whitelist  JSONB,
    status        SMALLINT DEFAULT 1,              -- 1 active 2 disabled 3 deleted
    expire_at     TIMESTAMPTZ,
    last_used_at  TIMESTAMPTZ,
    created_by    BIGINT,
    created_at    TIMESTAMPTZ DEFAULT now(),
    updated_at    TIMESTAMPTZ DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_apikey_hash ON biz_api_key(key_hash);
CREATE INDEX IF NOT EXISTS idx_apikey_company ON biz_api_key(company_id);

-- ===================== §7 Model system =====================
CREATE TABLE IF NOT EXISTS model_family (
    id          BIGSERIAL PRIMARY KEY,
    family_code VARCHAR(32) UNIQUE NOT NULL,       -- claude / gpt / gemini
    family_name VARCHAR(64),
    icon        VARCHAR(512),
    sort        INT DEFAULT 0,
    status      SMALLINT DEFAULT 1
);

CREATE TABLE IF NOT EXISTS model_version (
    id              BIGSERIAL PRIMARY KEY,
    family_id       BIGINT NOT NULL,
    model_code      VARCHAR(64) UNIQUE NOT NULL,
    display_name    VARCHAR(64),
    tagline         VARCHAR(128),
    capabilities    JSONB,
    context_window  INT,
    max_output      INT,
    price_input     NUMERIC(12,6),                 -- customer price / 1M tokens
    price_output    NUMERIC(12,6),
    price_cached    NUMERIC(12,6),
    cost_input      NUMERIC(12,6),                 -- upstream cost / 1M tokens
    cost_output     NUMERIC(12,6),
    cost_cached     NUMERIC(12,6),
    currency        VARCHAR(8) DEFAULT 'USD',
    status          SMALLINT DEFAULT 1,            -- 1 active 2 maintenance 3 disabled
    availability    VARCHAR(20) DEFAULT 'available', -- available/maintenance/unavailable
    sort            INT DEFAULT 0,
    created_at      TIMESTAMPTZ DEFAULT now(),
    updated_at      TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS model_channel_route (
    id            BIGSERIAL PRIMARY KEY,
    model_id      BIGINT NOT NULL,
    channel_id    BIGINT NOT NULL,
    upstream_model VARCHAR(128),
    weight        INT DEFAULT 1,
    priority      INT DEFAULT 0,
    status        SMALLINT DEFAULT 1
);
CREATE INDEX IF NOT EXISTS idx_route_model ON model_channel_route(model_id);

-- Tracks each (channel key, model) registered as a LiteLLM deployment, so a banned/deleted
-- key's deployment can be removed via the admin API (design doc §7.6 dynamic routing).
CREATE TABLE IF NOT EXISTS litellm_deployment (
    id               BIGSERIAL PRIMARY KEY,
    channel_id       BIGINT,
    key_id           BIGINT,
    model_code       VARCHAR(64),
    upstream_model   VARCHAR(128),
    litellm_model_id VARCHAR(64),
    status           SMALLINT DEFAULT 1,
    created_at       TIMESTAMPTZ DEFAULT now(),
    updated_at       TIMESTAMPTZ DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_lldep_key ON litellm_deployment(key_id);
CREATE INDEX IF NOT EXISTS idx_lldep_channel ON litellm_deployment(channel_id);

CREATE TABLE IF NOT EXISTS model_sync_log (
    id            BIGSERIAL PRIMARY KEY,
    channel_id    BIGINT,
    provider_name VARCHAR(32),
    new_count     INT DEFAULT 0,
    updated_count INT DEFAULT 0,
    stale_count   INT DEFAULT 0,
    detail        JSONB,
    created_at    TIMESTAMPTZ DEFAULT now()
);

-- ===================== §8 Channel (upstream pool) =====================
CREATE TABLE IF NOT EXISTS channel (
    id            BIGSERIAL PRIMARY KEY,
    provider_name VARCHAR(32) NOT NULL,
    channel_name  VARCHAR(64),
    family_id     BIGINT,
    api_key       VARCHAR(1024),                   -- AES-256 encrypted
    base_url      VARCHAR(255),
    org_id        VARCHAR(128),
    quota         NUMERIC(18,6) DEFAULT 0,         -- total recharged
    used_quota    NUMERIC(18,6) DEFAULT 0,         -- accumulated cost
    weight        INT DEFAULT 1,
    priority      INT DEFAULT 0,
    health        SMALLINT DEFAULT 1,              -- 1 healthy 0 broken
    low_threshold NUMERIC(18,6) DEFAULT 0,         -- low balance alert threshold
    status        SMALLINT DEFAULT 1,
    created_at    TIMESTAMPTZ DEFAULT now(),
    updated_at    TIMESTAMPTZ DEFAULT now()
);

-- Upstream key pool: a channel can hold MANY provider keys; banned keys are tracked and
-- admins replenish from the console without redeploy (design doc §8 key management).
CREATE TABLE IF NOT EXISTS channel_api_key (
    id           BIGSERIAL PRIMARY KEY,
    channel_id   BIGINT NOT NULL,
    key_alias    VARCHAR(64),
    api_key      VARCHAR(1024) NOT NULL,           -- AES-256 encrypted
    status       SMALLINT DEFAULT 1,               -- 1 active 2 banned 3 disabled
    ban_reason   VARCHAR(255),
    weight       INT DEFAULT 1,
    fail_count   INT DEFAULT 0,
    used_count   BIGINT DEFAULT 0,
    last_used_at TIMESTAMPTZ,
    banned_at    TIMESTAMPTZ,
    created_at   TIMESTAMPTZ DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_chkey_channel ON channel_api_key(channel_id, status);

CREATE TABLE IF NOT EXISTS upstream_recharge_log (
    id           BIGSERIAL PRIMARY KEY,
    channel_id   BIGINT NOT NULL,
    amount       NUMERIC(18,6),
    currency     VARCHAR(8),
    auto         BOOLEAN DEFAULT FALSE,
    operator     BIGINT,
    remark       VARCHAR(255),
    created_at   TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS upstream_reserve (
    id            BIGSERIAL PRIMARY KEY,
    channel_id    BIGINT UNIQUE NOT NULL,
    provider_name VARCHAR(32),
    reserve_amount NUMERIC(18,6) DEFAULT 0,
    auto_recharge  BOOLEAN DEFAULT FALSE,
    threshold      NUMERIC(18,6) DEFAULT 0,
    recharge_amount NUMERIC(18,6) DEFAULT 0,
    updated_at     TIMESTAMPTZ DEFAULT now()
);

-- ===================== §9 Plan =====================
CREATE TABLE IF NOT EXISTS plan (
    id           BIGSERIAL PRIMARY KEY,
    name         VARCHAR(64),
    price        NUMERIC(12,2),
    currency     VARCHAR(8) DEFAULT 'USD',
    duration     INT,
    token_limit  BIGINT,
    rpm_limit    INT,
    max_api_keys INT,
    max_projects INT,
    allowed_models JSONB,
    sort         INT DEFAULT 0,
    status       SMALLINT DEFAULT 1
);

-- ===================== §10 Finance =====================
CREATE TABLE IF NOT EXISTS fin_account (
    id                BIGSERIAL PRIMARY KEY,
    company_id        BIGINT UNIQUE NOT NULL,
    available_balance NUMERIC(18,6) DEFAULT 0,
    freeze_balance    NUMERIC(18,6) DEFAULT 0,
    total_recharge    NUMERIC(18,6) DEFAULT 0,
    total_consume     NUMERIC(18,6) DEFAULT 0,
    currency          VARCHAR(8) DEFAULT 'USD',
    version           BIGINT DEFAULT 0,
    updated_at        TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS fin_transaction (
    id           BIGSERIAL PRIMARY KEY,
    company_id   BIGINT NOT NULL,
    biz_type     VARCHAR(20),                      -- recharge/consume/refund/withdraw/freeze
    amount       NUMERIC(18,6),
    balance_after NUMERIC(18,6),
    ref_id       VARCHAR(64),
    remark       VARCHAR(255),
    created_at   TIMESTAMPTZ DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_txn_company ON fin_transaction(company_id);

CREATE TABLE IF NOT EXISTS fin_model_binding (
    id          BIGSERIAL PRIMARY KEY,
    company_id  BIGINT NOT NULL,
    model_code  VARCHAR(64),
    allocated   NUMERIC(18,6) DEFAULT 0,
    used        NUMERIC(18,6) DEFAULT 0,
    status      SMALLINT DEFAULT 1,
    UNIQUE(company_id, model_code)
);

CREATE TABLE IF NOT EXISTS fin_recharge_order (
    id            BIGSERIAL PRIMARY KEY,
    order_no      VARCHAR(40) UNIQUE NOT NULL,
    company_id    BIGINT NOT NULL,
    user_id       BIGINT NOT NULL,
    amount        NUMERIC(18,2),
    currency      VARCHAR(8),
    pay_channel   VARCHAR(20),                      -- stripe/alipay/wechat/usdt_trc20/usdt_erc20/wise
    pay_method    VARCHAR(20),                      -- card/wallet/crypto/bank
    status        SMALLINT DEFAULT 0,               -- 0 pending 1 paid 2 cancelled 3 expired 4 refunded
    third_txn_id  VARCHAR(128),
    paid_at       TIMESTAMPTZ,
    expire_at     TIMESTAMPTZ,
    raw_callback  JSONB,
    created_at    TIMESTAMPTZ DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_recharge_company ON fin_recharge_order(company_id);

CREATE TABLE IF NOT EXISTS fin_withdraw_order (
    id          BIGSERIAL PRIMARY KEY,
    order_no    VARCHAR(40) UNIQUE,
    company_id  BIGINT NOT NULL,
    amount      NUMERIC(18,2),
    fee         NUMERIC(18,2),
    channel     VARCHAR(20),                        -- wise/bank/usdt
    account_info JSONB,                             -- encrypted
    status      SMALLINT DEFAULT 0,                 -- 0 pending 1 approved 2 rejected 3 paid 4 failed
    audit_by    BIGINT,
    audit_at    TIMESTAMPTZ,
    paid_at     TIMESTAMPTZ,
    created_at  TIMESTAMPTZ DEFAULT now()
);

-- ===================== §10.2.1 Payment channel config =====================
CREATE TABLE IF NOT EXISTS pay_channel_config (
    id            BIGSERIAL PRIMARY KEY,
    channel_code  VARCHAR(20) UNIQUE NOT NULL,
    display_name  VARCHAR(64),
    icon          VARCHAR(512),
    enabled       BOOLEAN DEFAULT FALSE,
    env_mode      VARCHAR(12) DEFAULT 'production',
    credentials   JSONB,                            -- AES-encrypted secret values
    currencies    JSONB,
    fee_rate      NUMERIC(6,4) DEFAULT 0,
    fee_fixed     NUMERIC(12,2) DEFAULT 0,
    min_amount    NUMERIC(12,2) DEFAULT 0,
    max_amount    NUMERIC(12,2) DEFAULT 0,
    exchange_mode VARCHAR(12) DEFAULT 'auto',
    fixed_rate    NUMERIC(12,6),
    confirm_type  VARCHAR(12) DEFAULT 'webhook',
    confirm_blocks INT DEFAULT 0,
    callback_url  VARCHAR(255),
    sort          INT DEFAULT 0,
    remark        VARCHAR(255),
    updated_by    BIGINT,
    updated_at    TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS pay_reconcile (
    id           BIGSERIAL PRIMARY KEY,
    channel_code VARCHAR(20),
    recon_date   DATE,
    platform_cnt INT,        platform_amount NUMERIC(18,2),
    channel_cnt  INT,        channel_amount  NUMERIC(18,2),
    diff_cnt     INT,        diff_amount     NUMERIC(18,2),
    status       SMALLINT DEFAULT 0,
    created_at   TIMESTAMPTZ DEFAULT now()
);

-- ===================== §10.4 Pricing / profit =====================
CREATE TABLE IF NOT EXISTS pricing_markup (
    id            BIGSERIAL PRIMARY KEY,
    scope         VARCHAR(20),                      -- global/family/model/channel/plan/company
    scope_ref     VARCHAR(64),
    markup_rate   NUMERIC(6,4) DEFAULT 0.30,
    markup_fixed  NUMERIC(12,6) DEFAULT 0,
    min_margin    NUMERIC(6,4) DEFAULT 0.10,
    enabled       BOOLEAN DEFAULT TRUE,
    updated_at    TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS recharge_fee_config (
    id          BIGSERIAL PRIMARY KEY,
    scope       VARCHAR(20),                        -- global/plan/company
    scope_ref   VARCHAR(64),
    fee_rate    NUMERIC(6,4) DEFAULT 0,
    enabled     BOOLEAN DEFAULT FALSE
);

CREATE TABLE IF NOT EXISTS platform_profit_account (
    id            INT PRIMARY KEY DEFAULT 1,
    total_revenue NUMERIC(20,6) DEFAULT 0,
    total_cost    NUMERIC(20,6) DEFAULT 0,
    total_profit  NUMERIC(20,6) DEFAULT 0,
    updated_at    TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS profit_ledger (
    id           BIGSERIAL PRIMARY KEY,
    source       VARCHAR(20),                       -- consume/recharge_fee
    ref_id       VARCHAR(64),
    company_id   BIGINT,
    model_code   VARCHAR(64),
    revenue      NUMERIC(18,6),
    cost         NUMERIC(18,6),
    profit       NUMERIC(18,6),
    created_at   TIMESTAMPTZ DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_profit_company ON profit_ledger(company_id);

-- ===================== §11 Billing (partitioned) =====================
CREATE TABLE IF NOT EXISTS bill_token (
    id              BIGSERIAL,
    request_id      VARCHAR(40),
    company_id      BIGINT NOT NULL,
    user_id         BIGINT,
    project_id      BIGINT,
    api_key_id      BIGINT,
    model_code      VARCHAR(64),
    channel_id      BIGINT,
    prompt_tokens   INT,
    completion_tokens INT,
    cached_tokens   INT,
    total_tokens    INT,
    cost            NUMERIC(18,6),                   -- customer charge
    upstream_cost   NUMERIC(18,6),                   -- cost (before margin)
    created_at      TIMESTAMPTZ DEFAULT now(),
    PRIMARY KEY (id, created_at)
) PARTITION BY RANGE (created_at);

CREATE TABLE IF NOT EXISTS call_log (
    id            BIGSERIAL,
    request_id    VARCHAR(40),
    api_key_id    BIGINT,
    company_id    BIGINT,
    model_code    VARCHAR(64),
    channel_id    BIGINT,
    ip            VARCHAR(45),
    user_agent    VARCHAR(512),
    http_status   INT,
    biz_status    VARCHAR(40),
    response_time INT,
    is_stream     BOOLEAN,
    created_at    TIMESTAMPTZ DEFAULT now(),
    PRIMARY KEY (id, created_at)
) PARTITION BY RANGE (created_at);

-- default partitions for the current month and next two months (PartitionCreateJob extends these)
DO $$
DECLARE
    m INT;
    start_d DATE;
    end_d DATE;
    p_name TEXT;
BEGIN
    FOR m IN 0..2 LOOP
        start_d := date_trunc('month', now())::date + (m || ' month')::interval;
        end_d := start_d + interval '1 month';
        p_name := to_char(start_d, 'YYYYMM');
        EXECUTE format('CREATE TABLE IF NOT EXISTS bill_token_%s PARTITION OF bill_token FOR VALUES FROM (%L) TO (%L)', p_name, start_d, end_d);
        EXECUTE format('CREATE TABLE IF NOT EXISTS call_log_%s PARTITION OF call_log FOR VALUES FROM (%L) TO (%L)', p_name, start_d, end_d);
    END LOOP;
END $$;

-- ===================== §12 Risk =====================
CREATE TABLE IF NOT EXISTS risk_rule (
    id          BIGSERIAL PRIMARY KEY,
    rule_type   VARCHAR(40),                        -- token_spike/high_freq/proxy_ip
    threshold   JSONB,
    action      VARCHAR(20),                        -- alert/throttle/ban
    status      SMALLINT DEFAULT 1
);

CREATE TABLE IF NOT EXISTS risk_blacklist (
    id        BIGSERIAL PRIMARY KEY,
    type      VARCHAR(20),                          -- ip/country/user
    value     VARCHAR(64),
    reason    VARCHAR(255),
    expire_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_blacklist_value ON risk_blacklist(type, value);

-- ===================== §13 Notify =====================
CREATE TABLE IF NOT EXISTS notify_log (
    id        BIGSERIAL PRIMARY KEY,
    company_id BIGINT,
    channel   VARCHAR(20),                          -- email/sms/inmail/webhook
    scene     VARCHAR(40),
    target    VARCHAR(255),
    content   TEXT,
    status    SMALLINT,                             -- 0 pending 1 success 2 fail
    retry     INT DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS notify_template (
    id        BIGSERIAL PRIMARY KEY,
    scene     VARCHAR(40) UNIQUE,
    channel   VARCHAR(20),
    title     VARCHAR(128),
    content   TEXT,
    enabled   BOOLEAN DEFAULT TRUE
);

-- ===================== §15.4 System config center =====================
CREATE TABLE IF NOT EXISTS sys_config (
    config_key   VARCHAR(64) PRIMARY KEY,
    config_value JSONB,
    group_name   VARCHAR(40),                       -- pay/model/risk/markup/notify/system
    remark       VARCHAR(255),
    updated_by   BIGINT,
    updated_at   TIMESTAMPTZ DEFAULT now()
);

-- ===================== §18 Operation audit log =====================
CREATE TABLE IF NOT EXISTS sys_audit_log (
    id          BIGSERIAL PRIMARY KEY,
    user_id     BIGINT,
    company_id  BIGINT,
    module      VARCHAR(40),
    action      VARCHAR(64),
    method      VARCHAR(64),
    uri         VARCHAR(255),
    ip          VARCHAR(45),
    request_id  VARCHAR(64),
    status      SMALLINT,                            -- 1 success 0 failure
    error_msg   VARCHAR(512),
    cost_ms     BIGINT,
    created_at  TIMESTAMPTZ DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_audit_user ON sys_audit_log(user_id);
CREATE INDEX IF NOT EXISTS idx_audit_created ON sys_audit_log(created_at);

-- ===================== OmniRoute landing CMS (官网 doc §4.2) =====================
-- Site-level config (brand/SEO/theme/footer) — one row per language.
CREATE TABLE IF NOT EXISTS site_setting (
    id          INT PRIMARY KEY DEFAULT 1,
    lang        VARCHAR(8) DEFAULT 'zh',
    brand       JSONB,        -- {name,logo,favicon,domain,copyright,icp}
    seo         JSONB,        -- {title,description,keywords,ogImage}
    theme       JSONB,        -- {bg,amber,mint,text,font,radius...}
    footer      JSONB,        -- link groups
    updated_by  BIGINT,
    updated_at  TIMESTAMPTZ DEFAULT now()
);

-- Sections (hero/features/how/code/models/pricing/security/cta...).
CREATE TABLE IF NOT EXISTS site_section (
    id          BIGSERIAL PRIMARY KEY,
    section_key VARCHAR(32),
    lang        VARCHAR(8) DEFAULT 'zh',
    enabled     BOOLEAN DEFAULT TRUE,
    sort        INT DEFAULT 0,
    title       VARCHAR(255),
    subtitle    VARCHAR(512),
    payload     JSONB,
    bind_source VARCHAR(20),                  -- optional: model_version / plan (auto-sync)
    updated_at  TIMESTAMPTZ DEFAULT now(),
    UNIQUE(section_key, lang)
);

-- FAQ (own table for easy add/sort).
CREATE TABLE IF NOT EXISTS site_faq (
    id        BIGSERIAL PRIMARY KEY,
    lang      VARCHAR(8) DEFAULT 'zh',
    question  VARCHAR(255),
    answer    TEXT,
    sort      INT DEFAULT 0,
    enabled   BOOLEAN DEFAULT TRUE
);

-- Publish snapshots (draft / published, supports rollback).
CREATE TABLE IF NOT EXISTS site_publish (
    id           BIGSERIAL PRIMARY KEY,
    lang         VARCHAR(8),
    status       SMALLINT,                     -- 0 draft 1 published
    snapshot     JSONB,                         -- full-site content snapshot
    published_by BIGINT,
    published_at TIMESTAMPTZ DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_site_publish_lang ON site_publish(lang, status);

-- ===================== §15.5 Scheduled job control (admin-managed) =====================
CREATE TABLE IF NOT EXISTS sys_scheduled_job (
    id               BIGSERIAL PRIMARY KEY,
    job_key          VARCHAR(64) UNIQUE NOT NULL,
    job_name         VARCHAR(128),
    cron             VARCHAR(64),                       -- Spring 6-field cron
    enabled          BOOLEAN DEFAULT TRUE,
    description      VARCHAR(255),
    last_run_at      TIMESTAMPTZ,
    last_status      VARCHAR(16),                       -- running/success/fail
    last_duration_ms BIGINT,
    last_error       VARCHAR(512),
    updated_by       BIGINT,
    created_at       TIMESTAMPTZ DEFAULT now(),
    updated_at       TIMESTAMPTZ DEFAULT now()
);

-- ===================== seed data =====================
INSERT INTO platform_profit_account (id) VALUES (1) ON CONFLICT DO NOTHING;

INSERT INTO pricing_markup (scope, scope_ref, markup_rate, min_margin, enabled)
VALUES ('global', NULL, 0.30, 0.10, TRUE) ON CONFLICT DO NOTHING;

INSERT INTO model_family (family_code, family_name, sort) VALUES
    ('claude', 'Claude', 1),
    ('gpt', 'GPT', 2),
    ('gemini', 'Gemini', 3),
    ('grok', 'Grok', 4),
    ('deepseek', 'DeepSeek', 5)
ON CONFLICT (family_code) DO NOTHING;

INSERT INTO plan (name, price, duration, token_limit, rpm_limit, max_api_keys, max_projects, sort) VALUES
    ('Basic', 0, 30, 1000000, 20, 2, 1, 1),
    ('Pro', 49, 30, 20000000, 60, 10, 5, 2),
    ('Enterprise', 299, 30, 200000000, 300, 50, 20, 3)
ON CONFLICT DO NOTHING;
