# Kubernetes deployment — AI Gateway SaaS

Manifests for the AI Gateway platform (design doc §15.2 architecture, §17
performance, §19 go-live). Everything runs in the `ai-gateway` namespace.

## Topology

```
                    Internet (TLS)
                         │
                 ┌───────▼────────┐   ingress.yaml (nginx/ALB, HTTPS only)
                 │    Ingress     │   /  -> frontend   /api,/v1 -> backend
                 └───┬────────┬───┘
                     │        │
            ┌────────▼──┐  ┌──▼──────────┐
            │ frontend  │  │  backend    │  HPA 3..20, PDB minAvailable=2
            │  :80      │  │  :8080      │  probes: /actuator/health/{readiness,liveness}
            └───────────┘  └──┬───┬───┬──┘
                              │   │   │  └──────────────┐
                  ┌───────────┘   │   └────┐           │
            ┌─────▼────┐   ┌──────▼──┐ ┌───▼────┐  ┌───▼────┐  ┌─────────┐
            │ litellm  │   │ postgres│ │ redis  │  │ kafka  │  │ minio   │
            │ :4000    │   │ :5432   │ │ :6379  │  │ :9092  │  │ :9000   │
            │ INTERNAL │   └─────────┘ └────────┘  └────────┘  └─────────┘
            └──────────┘   (all ClusterIP-only; NetworkPolicy: backend-only ingress)
```

LiteLLM and all datastores are **ClusterIP-only** and reachable **only from the
backend** (networkpolicy.yaml). They are never routed through the Ingress.

## Prerequisites

- A CNI that enforces `NetworkPolicy` (Calico / Cilium) — otherwise the
  zero-trust rules are silently ignored.
- An ingress controller. Manifests default to **ingress-nginx**; ALB annotations
  are included (commented) in `ingress.yaml`.
- `cert-manager` with a `letsencrypt-prod` ClusterIssuer (or supply your own TLS
  Secret named `ai-gateway-tls`).
- A `StorageClass` for the PVCs (Postgres/Redis/Kafka/MinIO).
- For the optional QPS-based HPA metric: `prometheus-adapter`.
- Label your ingress namespace `kubernetes.io/metadata.name=ingress-nginx` and the
  Prometheus namespace `kubernetes.io/metadata.name=monitoring` so the
  NetworkPolicies match (they reference those names).

## Apply order

```bash
kubectl apply -f namespace.yaml

# 1. config + secrets (EDIT secret.example.yaml first, or use External Secrets)
cp secret.example.yaml secret.yaml   # then replace every CHANGE_ME
kubectl apply -f configmap.yaml
kubectl apply -f secret.yaml         # do NOT commit secret.yaml

# 2. network policies (apply BEFORE workloads so deny-by-default is in effect)
kubectl apply -f networkpolicy.yaml

# 3. stateful backing services (or skip if using managed PG/Redis/Kafka/S3)
kubectl apply -f postgres-statefulset.yaml
kubectl apply -f redis-statefulset.yaml
kubectl apply -f kafka-statefulset.yaml
kubectl apply -f minio-deployment.yaml
#    wait until postgres is Ready, then load schema:
#    kubectl -n ai-gateway exec -i postgres-0 -- psql -U gw -d ai_gateway < ../init.sql

# 4. internal model gateway
kubectl apply -f litellm-deployment.yaml
kubectl apply -f litellm-service.yaml

# 5. application
kubectl apply -f backend-deployment.yaml
kubectl apply -f backend-service.yaml
kubectl apply -f frontend-deployment.yaml
kubectl apply -f frontend-service.yaml

# 6. scaling + availability + edge
kubectl apply -f hpa.yaml
kubectl apply -f poddisruptionbudget.yaml
kubectl apply -f ingress.yaml
```

Or apply the whole directory once secrets are templated:
`kubectl apply -f .` (kubectl orders by kind, but applying networkpolicy first
is still recommended).

## Secrets

`secret.example.yaml` is a **template with placeholders only**. For production use
**External Secrets Operator**, **Sealed Secrets**, or the **Vault CSI driver** —
do not store plaintext Secrets in git (SECURITY.md). The example splits secrets by
least privilege: `backend-secrets`, `litellm-secrets`, `datastore-secrets`.

## Production notes

- Prefer **managed** Postgres / Redis / Kafka / object store (RDS, ElastiCache,
  MSK, S3). If you do, delete the corresponding StatefulSet/Deployment and update
  `configmap.yaml` (`DB_URL`, `REDIS_HOST`, `KAFKA_BROKERS`, `MINIO_ENDPOINT`) and
  the matching Secret entries. Managed services give you HA + PITR backups
  (design doc §19) for free.
- `backend-deployment.yaml` sets `replicas: 3` but the **HPA owns** the replica
  count at runtime (3..20). Keep the two minimums consistent.
- Bind `/actuator/prometheus` to the internal monitoring path only — the
  NetworkPolicy already restricts the scrape to the `monitoring` namespace
  (SECURITY.md hardening item).
- Add a WAF / DDoS layer in front of the Ingress before go-live.

See `../monitoring/` for Prometheus/Grafana/Alertmanager and `../logging/` for the
ELK pipeline.
