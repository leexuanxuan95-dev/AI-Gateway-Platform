# Logging (ELK) — AI Gateway

Pipeline (design doc §15.1):

```
backend (JSON logs, requestId MDC) --stdout--> Filebeat --> Logstash --> Elasticsearch --> Kibana
```

- `filebeat.yml` — DaemonSet tailing container logs; decodes JSON, keeps
  `request_id` (from the `requestId` MDC field SECURITY.md propagates as
  `X-Request-Id`), strips secret-ish fields, ships to Logstash:5044.
- `logstash.conf` — parses JSON, normalizes level/timestamp, tags gateway access
  logs, writes daily indices `ai-gateway-<app>-YYYY.MM.dd` to Elasticsearch.

## Kibana index pattern

1. Kibana → Stack Management → **Data Views** → Create data view.
2. Index pattern: `ai-gateway-*`
3. Timestamp field: `@timestamp`
4. Save. You can now search by `request_id:"<id>"` to trace a single call across
   the chain, or filter `tags:gateway AND status:>=500` for failed `/v1` requests.

## Retention

Configure an ILM policy on the `ai-gateway-*` indices (e.g. hot 7d → warm 30d →
delete 90d). PII must not be logged; the gateway already disables message logging
at the LiteLLM layer (litellm-config.yaml `turn_off_message_logging: true`).
