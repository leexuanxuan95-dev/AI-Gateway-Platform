# 免费服务器部署指南 / Deploy on a Free Server (with domain + HTTPS)

把整套平台部署到一台**永久免费**的服务器上,带域名和自动 HTTPS。一次性,约 15 分钟。

> 这套要 ~4GB+ 内存(PG/Redis/Kafka/LiteLLM/后端 JVM/两前端)。免费层里只有
> **Oracle Cloud Always Free 的 ARM 机器(最高 4 核/24GB)**能舒服跑全栈。
> 1GB 的 AWS/GCP micro 跑不动整套。

---

## 1. 领一台免费服务器(Oracle Cloud Always Free)
1. 注册 https://www.oracle.com/cloud/free/ (需绑卡验证,**不会扣费**;选离你近的区域)。
2. 创建实例:**Ampere A1 (ARM)**,Shape `VM.Standard.A1.Flex`,**4 OCPU / 24GB**(免费额度内),系统选 **Ubuntu 22.04**。
   - ARM 配额偶尔满,换个可用域/区域多试几次,或先用 2 OCPU/12GB。
3. 安全列表/网络:放行入站 **TCP 22 / 80 / 443**。
4. SSH 登录后装 Docker:
   ```bash
   curl -fsSL https://get.docker.com | sudo sh
   sudo usermod -aG docker $USER && newgrp docker
   ```

> 也可用任何 ≥4GB 的 VPS(同样步骤)。1GB 小鸡不行。

---

## 2. 弄个域名(三选一,都免费)
- **最快(免注册):nip.io** —— 直接用 `<服务器公网IP>.nip.io` 当根域名,例如 `132.226.10.5.nip.io`。自动解析到你的 IP,Let's Encrypt 也能签证书。
- **DuckDNS**:https://duckdns.org 注册一个 `xxx.duckdns.org`,把它和 `console.xxx`/`api.xxx` 指向你的 IP。
- **真实域名**:在 DNS 处加三条 A 记录指向服务器 IP:
  - `你的域名` 、 `console.你的域名` 、 `api.你的域名`

> 用 nip.io 时,三个主机名天然是 `IP.nip.io` / `console.IP.nip.io` / `api.IP.nip.io`,全部解析到同一 IP,无需手动加记录。

---

## 3. 拉代码 + 一键配置 + 启动
```bash
git clone <你的仓库地址> ai-gateway && cd ai-gateway/deploy

# 用你的根域名(或 <IP>.nip.io)生成所有密钥与地址
./setup.sh 132.226.10.5.nip.io          # 例:nip.io
# 或 ./setup.sh your-domain.com

# 构建并启动(只有 Caddy 对外暴露 80/443,自动签 HTTPS)
docker compose -f docker-compose.free.yml up -d --build
```
首次构建几分钟。完成后:
- 官网:`https://<根域名>`
- 控制台:`https://console.<根域名>` (登录见 setup.sh 打印的 `admin@<域名>` + 密码)
- API:`https://api.<根域名>`(OpenAI 兼容 `/v1`)

健康检查:
```bash
docker compose -f docker-compose.free.yml ps
curl -s https://api.<根域名>/actuator/health      # {"status":"UP"}
curl -s "https://api.<根域名>/api/site/landing?lang=zh" | head
```

---

## 4. 上线后
1. 控制台登录 → 改掉初始管理员密码。
2. 「渠道管理」加上游 key(或在 .env 填 `OPENAI_KEY` 等后 `up -d`),「模型管理」上架定价。
3. 想跑真实补全:`OPENAI_KEY=sk-... ./real-provider-smoke.sh`(见脚本说明)。
4. 「定时任务」按需启停/改时间;「支付渠道配置中心」按需开通。

---

## 5. 常见问题
- **证书没签下来**:确认 80/443 已放行且域名 A 记录指向本机;`docker compose -f docker-compose.free.yml logs caddy`。
- **内存吃紧(<4GB)**:把 `JAVA_OPTS` 调小、或停掉 `kafka`(账单走同步,Kafka 仅异步日志/通知)。真要省内存建议换 24GB 的 Oracle 免费机。
- **ARM 上构建**:本 compose 在 ARM 上正常(基础镜像都是多架构);后端 Maven 构建在容器内完成,无需本机装 JDK。
- **更新**:`git pull && docker compose -f docker-compose.free.yml up -d --build`(数据卷保留)。
- **换域名**:`./setup.sh <新域名> --force` 然后 `up -d`(会换新密钥)。

> 我无法替你注册服务器/域名(需要你的账号与实名/绑卡)。以上是能真正免费跑起这套的现成路径,文件都已备好。
