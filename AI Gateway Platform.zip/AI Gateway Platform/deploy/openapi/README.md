# Customer API spec (`/v1/*`)

`gateway-v1.yaml` is the OpenAPI 3 spec for the OpenAI-compatible customer surface
(design doc §20). It covers chat/completions (stream + non-stream), embeddings,
images/generations, audio/speech, audio/transcriptions, rerank, and models, plus
the Bearer auth, the custom response headers (`X-Request-Id`, `X-Tokens-Used`,
`X-Cost`, `X-Balance`, `X-RateLimit-*`) and the §20.8 error-code table.

## View it

```bash
# Swagger UI in a container
docker run --rm -p 8088:8080 \
  -e SWAGGER_JSON=/spec/gateway-v1.yaml \
  -v "$PWD:/spec" swaggerapi/swagger-ui
# open http://localhost:8088
```

Or paste it into https://editor.swagger.io.

## curl quickstart

```bash
BASE=https://api.your-gateway.com/v1
KEY=sk-your-key

# chat (non-stream) — note the billing headers in the response
curl -i "$BASE/chat/completions" \
  -H "Authorization: Bearer $KEY" \
  -H "Content-Type: application/json" \
  -d '{"model":"claude-opus-4-8","messages":[{"role":"user","content":"hi"}]}'

# chat (stream) — SSE
curl -N "$BASE/chat/completions" \
  -H "Authorization: Bearer $KEY" \
  -H "Content-Type: application/json" \
  -d '{"model":"claude-opus-4-8","stream":true,"messages":[{"role":"user","content":"haiku"}]}'

# embeddings
curl "$BASE/embeddings" -H "Authorization: Bearer $KEY" -H "Content-Type: application/json" \
  -d '{"model":"text-embedding-3-small","input":"hello"}'

# audio transcription (multipart upload)
curl "$BASE/audio/transcriptions" -H "Authorization: Bearer $KEY" \
  -F file=@sample.mp3 -F model=whisper-1

# list models available to this key
curl "$BASE/models" -H "Authorization: Bearer $KEY"
```

Read the `X-Request-Id` from responses and keep it — it's needed to trace or
report any issue (it flows through MDC -> logs -> Kibana, see `../logging/`).
On 429/5xx, retry with exponential backoff and honor `Retry-After` (§20.9).
