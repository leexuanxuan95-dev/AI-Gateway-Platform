#!/usr/bin/env bash
# ============================================================================
# Real upstream-provider smoke test (live integration with a REAL provider key).
#
# Prereqs:
#   1) stack running:  docker compose up -d
#   2) a REAL provider key exported, e.g.:  export OPENAI_KEY=sk-...
#
# It drives the WHOLE platform via its public APIs, exactly like an operator:
#   admin login -> create channel -> add the real upstream key to the key pool
#   -> register a model version + route -> call /v1/chat/completions for real
#   -> assert a real completion + token usage + balance deducted.
#
# This is the one step that genuinely needs your provider key — everything else
# is already verified with a mock upstream. Usage:  ./real-provider-smoke.sh
# Optional env: BASE (default http://localhost:8080), MODEL (default gpt-4o-mini),
#   PROVIDER (default openai), UPSTREAM_MODEL (default gpt-4o-mini),
#   BASE_URL (default https://api.openai.com), ADMIN_EMAIL/ADMIN_PASSWORD.
# ============================================================================
set -euo pipefail

B="${BASE:-http://localhost:8080}"
PROVIDER="${PROVIDER:-openai}"
MODEL="${MODEL:-gpt-4o-mini}"
UPSTREAM_MODEL="${UPSTREAM_MODEL:-gpt-4o-mini}"
BASE_URL="${BASE_URL:-https://api.openai.com}"
ADMIN_EMAIL="${ADMIN_EMAIL:-admin@aigateway.local}"
ADMIN_PASSWORD="${ADMIN_PASSWORD:-admin123456}"
UPKEY="${OPENAI_KEY:-${PROVIDER_KEY:-}}"

if [[ -z "${UPKEY}" ]]; then
  echo "ERROR: set a real provider key first, e.g.  export OPENAI_KEY=sk-..." >&2
  exit 1
fi

jqget() { python3 -c "import sys,json;d=json.load(sys.stdin);print(eval('d'+sys.argv[1]))" "$1"; }

echo "==> admin login ($ADMIN_EMAIL)"
TOK=$(curl -fsS -X POST "$B/api/auth/login" -H 'Content-Type: application/json' \
  -d "{\"email\":\"$ADMIN_EMAIL\",\"password\":\"$ADMIN_PASSWORD\"}" | jqget "['data']['accessToken']")

echo "==> create channel ($PROVIDER @ $BASE_URL)"
CH=$(curl -fsS -X POST "$B/api/channel" -H "Authorization: Bearer $TOK" -H 'Content-Type: application/json' \
  -d "{\"providerName\":\"$PROVIDER\",\"channelName\":\"real-$PROVIDER\",\"apiKey\":\"$UPKEY\",\"baseUrl\":\"$BASE_URL\",\"weight\":1,\"priority\":0,\"status\":1,\"lowThreshold\":0}")
CHID=$(echo "$CH" | jqget "['data']['id']")
echo "   channel id=$CHID"

echo "==> recharge channel quota (so it has upstream balance headroom)"
curl -fsS -X POST "$B/api/channel/$CHID/recharge" -H "Authorization: Bearer $TOK" -H 'Content-Type: application/json' \
  -d '{"amount":100,"currency":"USD","remark":"smoke"}' >/dev/null

echo "==> add the REAL key to the channel key-pool (also registers a LiteLLM deployment)"
curl -fsS -X POST "$B/api/channel/$CHID/keys" -H "Authorization: Bearer $TOK" -H 'Content-Type: application/json' \
  -d "{\"keyAlias\":\"real-1\",\"apiKey\":\"$UPKEY\",\"weight\":1}" >/dev/null

echo "==> register model version $MODEL (priced + active) and route it to the channel"
FAMILY_ID=$(curl -fsS "$B/api/model/families" -H "Authorization: Bearer $TOK" | python3 -c "import sys,json;d=json.load(sys.stdin)['data'];print(d[0]['id'] if d else 1)")
MV=$(curl -fsS -X POST "$B/api/model/versions" -H "Authorization: Bearer $TOK" -H 'Content-Type: application/json' \
  -d "{\"familyId\":$FAMILY_ID,\"modelCode\":\"$MODEL\",\"displayName\":\"$MODEL\",\"costInput\":0.15,\"costOutput\":0.60,\"priceInput\":0.20,\"priceOutput\":0.80,\"currency\":\"USD\",\"status\":1,\"availability\":\"available\",\"capabilities\":[\"chat\"]}")
MVID=$(echo "$MV" | jqget "['data']['id']")
curl -fsS -X POST "$B/api/model/routes" -H "Authorization: Bearer $TOK" -H 'Content-Type: application/json' \
  -d "{\"modelId\":$MVID,\"channelId\":$CHID,\"upstreamModel\":\"$UPSTREAM_MODEL\",\"weight\":1,\"priority\":0,\"status\":1}" >/dev/null
echo "   model version id=$MVID routed to channel $CHID -> upstream $UPSTREAM_MODEL"

echo "==> create a customer API key + give the tenant balance"
SK=$(curl -fsS -X POST "$B/api/apikey" -H "Authorization: Bearer $TOK" -H 'Content-Type: application/json' \
  -d '{"keyName":"smoke","rpmLimit":600,"tpmLimit":1000000}' | jqget "['data']['rawKey']")
echo "   NOTE: ensure the calling company has balance (recharge via the console) — else expect 402."

echo "==> REAL completion via the gateway"
RESP=$(curl -fsS "$B/v1/chat/completions" -H "Authorization: Bearer $SK" -H 'Content-Type: application/json' \
  -d "{\"model\":\"$MODEL\",\"messages\":[{\"role\":\"user\",\"content\":\"Say hello in 5 words.\"}],\"max_tokens\":50}")
echo "$RESP" | python3 -c "import sys,json;d=json.load(sys.stdin);print('content =',d['choices'][0]['message']['content']);print('usage   =',d['usage'])"
echo "==> SUCCESS — real provider call billed through the gateway."
