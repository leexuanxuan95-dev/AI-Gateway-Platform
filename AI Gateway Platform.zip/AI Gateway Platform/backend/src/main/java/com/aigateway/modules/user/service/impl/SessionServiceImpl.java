package com.aigateway.modules.user.service.impl;

import com.aigateway.common.constant.RedisKeys;
import com.aigateway.modules.user.dto.SessionView;
import com.aigateway.modules.user.service.SessionService;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * Default {@link SessionService}. Sessions live in a per-user Redis hash so listing and
 * revocation are O(1)/O(n) without scanning. The hash carries a TTL matching the refresh
 * token lifetime; every register call refreshes it. All Redis access is defensive: a cache
 * fault must never break login/logout.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class SessionServiceImpl implements SessionService {

    /** Mirrors the refresh-token TTL in AuthServiceImpl. */
    private static final Duration SESSION_TTL = Duration.ofDays(30);

    private final StringRedisTemplate redis;
    private final ObjectMapper objectMapper;

    /** Per-user session hash. Kept module-local since {@code common.RedisKeys} is read-only here. */
    private static String sessionsKey(Long userId) {
        return "gw:sessions:" + userId;
    }

    @Override
    public void register(Long userId, String tokenId, String ip, String userAgent) {
        if (userId == null || !StringUtils.hasText(tokenId)) {
            return;
        }
        try {
            Meta meta = new Meta();
            meta.ip = ip;
            meta.userAgent = userAgent;
            meta.createdAt = System.currentTimeMillis();
            String key = sessionsKey(userId);
            redis.opsForHash().put(key, tokenId, objectMapper.writeValueAsString(meta));
            redis.expire(key, SESSION_TTL);
        } catch (Exception e) {
            log.warn("session register failed for user {}: {}", userId, e.getMessage());
        }
    }

    @Override
    public void deregister(Long userId, String tokenId) {
        if (userId == null || !StringUtils.hasText(tokenId)) {
            return;
        }
        try {
            redis.opsForHash().delete(sessionsKey(userId), tokenId);
        } catch (Exception e) {
            log.warn("session deregister failed for user {}: {}", userId, e.getMessage());
        }
    }

    @Override
    public List<SessionView> list(Long userId, String currentTokenId) {
        List<SessionView> out = new ArrayList<>();
        try {
            Map<Object, Object> entries = redis.opsForHash().entries(sessionsKey(userId));
            for (Map.Entry<Object, Object> e : entries.entrySet()) {
                String tokenId = String.valueOf(e.getKey());
                Meta meta = parse(String.valueOf(e.getValue()));
                out.add(new SessionView(tokenId, meta.ip, meta.userAgent, meta.createdAt,
                        Objects.equals(tokenId, currentTokenId)));
            }
            out.sort((a, b) -> Long.compare(
                    b.getCreatedAt() == null ? 0 : b.getCreatedAt(),
                    a.getCreatedAt() == null ? 0 : a.getCreatedAt()));
        } catch (Exception e) {
            log.warn("session list failed for user {}: {}", userId, e.getMessage());
        }
        return out;
    }

    @Override
    public void revoke(Long userId, String tokenId) {
        if (userId == null || !StringUtils.hasText(tokenId)) {
            return;
        }
        try {
            redis.opsForHash().delete(sessionsKey(userId), tokenId);
            redis.delete(RedisKeys.refreshToken(tokenId));
        } catch (Exception e) {
            log.warn("session revoke failed for user {}: {}", userId, e.getMessage());
        }
    }

    @Override
    public void revokeAllExcept(Long userId, String keepTokenId) {
        try {
            Map<Object, Object> entries = redis.opsForHash().entries(sessionsKey(userId));
            for (Object field : entries.keySet()) {
                String tokenId = String.valueOf(field);
                if (Objects.equals(tokenId, keepTokenId)) {
                    continue;
                }
                redis.delete(RedisKeys.refreshToken(tokenId));
                redis.opsForHash().delete(sessionsKey(userId), tokenId);
            }
        } catch (Exception e) {
            log.warn("session revoke-all failed for user {}: {}", userId, e.getMessage());
        }
    }

    @Override
    public boolean isNewDevice(Long userId, String ip, String userAgent) {
        try {
            Map<Object, Object> entries = redis.opsForHash().entries(sessionsKey(userId));
            if (entries.isEmpty()) {
                return false; // first-ever session is not an "abnormal" device
            }
            for (Object v : entries.values()) {
                Meta meta = parse(String.valueOf(v));
                if (Objects.equals(meta.ip, ip) && Objects.equals(meta.userAgent, userAgent)) {
                    return false;
                }
            }
            return true;
        } catch (Exception e) {
            log.warn("session isNewDevice check failed for user {}: {}", userId, e.getMessage());
            return false; // fail-safe: do not spam alerts on a cache hiccup
        }
    }

    private Meta parse(String json) {
        try {
            return objectMapper.readValue(json, Meta.class);
        } catch (Exception e) {
            return new Meta();
        }
    }

    /** Serialized session metadata. */
    public static class Meta {
        public String ip;
        public String userAgent;
        public Long createdAt;
    }
}
