package com.aigateway.modules.payment.dto;

import lombok.Data;

import java.math.BigDecimal;

/** Public channel option returned by {@code GET /api/pay/channels} (design doc §10.2.1-C). */
@Data
public class ChannelOption {

    private String code;
    private String name;
    private String icon;
    private BigDecimal fee;
    private BigDecimal min;
    private BigDecimal max;
    private Integer confirmBlocks;
}
