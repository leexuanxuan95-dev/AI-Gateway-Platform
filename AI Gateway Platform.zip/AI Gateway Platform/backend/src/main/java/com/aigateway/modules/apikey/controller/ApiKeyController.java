package com.aigateway.modules.apikey.controller;

import com.aigateway.common.api.PageResult;
import com.aigateway.common.api.R;
import com.aigateway.common.security.RequirePerm;
import com.aigateway.common.security.RolePermissions;
import com.aigateway.modules.apikey.dto.ApiKeyCreateRequest;
import com.aigateway.modules.apikey.dto.ApiKeyCreateResponse;
import com.aigateway.modules.apikey.dto.ApiKeyUpdateRequest;
import com.aigateway.modules.apikey.dto.ApiKeyView;
import com.aigateway.modules.apikey.service.ApiKeyService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/** Company-scoped API key management endpoints. */
@RestController
@RequestMapping("/api/apikey")
@RequiredArgsConstructor
public class ApiKeyController {

    private final ApiKeyService apiKeyService;

    /** Create a key; returns the raw secret exactly once. */
    @PostMapping
    @RequirePerm(RolePermissions.APIKEY_MANAGE)
    public R<ApiKeyCreateResponse> create(@RequestBody @Valid ApiKeyCreateRequest req) {
        return R.ok(apiKeyService.create(req));
    }

    @GetMapping
    @RequirePerm(RolePermissions.APIKEY_READ)
    public R<PageResult<ApiKeyView>> page(@RequestParam(defaultValue = "1") long current,
                                          @RequestParam(defaultValue = "20") long size) {
        return R.ok(apiKeyService.page(current, size));
    }

    @PutMapping("/{id}")
    @RequirePerm(RolePermissions.APIKEY_MANAGE)
    public R<ApiKeyView> update(@PathVariable Long id, @RequestBody @Valid ApiKeyUpdateRequest req) {
        return R.ok(apiKeyService.update(id, req));
    }

    @PostMapping("/{id}/disable")
    @RequirePerm(RolePermissions.APIKEY_MANAGE)
    public R<Void> disable(@PathVariable Long id) {
        apiKeyService.disable(id);
        return R.ok();
    }

    @PostMapping("/{id}/enable")
    @RequirePerm(RolePermissions.APIKEY_MANAGE)
    public R<Void> enable(@PathVariable Long id) {
        apiKeyService.enable(id);
        return R.ok();
    }

    @DeleteMapping("/{id}")
    @RequirePerm(RolePermissions.APIKEY_MANAGE)
    public R<Void> delete(@PathVariable Long id) {
        apiKeyService.delete(id);
        return R.ok();
    }
}
