package com.aigateway.modules.company.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

/** Update a member's role. */
@Data
public class RoleUpdateRequest {

    @NotBlank
    private String role;
}
