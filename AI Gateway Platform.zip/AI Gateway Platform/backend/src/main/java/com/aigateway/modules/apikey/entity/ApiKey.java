package com.aigateway.modules.apikey.entity;

import com.aigateway.common.enums.ApiKeyStatus;
import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.handlers.JacksonTypeHandler;
import lombok.Data;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.List;

/**
 * API key entity (table {@code biz_api_key}). The raw key is never stored; only
 * the SHA-256 {@code keyHash} and a short {@code keyPrefix} for display.
 */
@Data
@TableName(value = "biz_api_key", autoResultMap = true)
public class ApiKey {

    @TableId(type = IdType.AUTO)
    private Long id;

    private Long companyId;

    private Long projectId;

    private String keyName;

    private String keyPrefix;

    /** SHA-256 hex of the raw key. Unique. */
    private String keyHash;

    @TableField(typeHandler = JacksonTypeHandler.class)
    private List<String> allowedModels;

    private Integer rpmLimit;

    private Integer tpmLimit;

    private BigDecimal dailyQuota;

    @TableField(typeHandler = JacksonTypeHandler.class)
    private List<String> ipWhitelist;

    /** 1 active, 2 disabled, 3 deleted. */
    private ApiKeyStatus status;

    private OffsetDateTime expireAt;

    private OffsetDateTime lastUsedAt;

    private Long createdBy;

    @TableField(fill = FieldFill.INSERT)
    private OffsetDateTime createdAt;

    @TableField(fill = FieldFill.INSERT_UPDATE)
    private OffsetDateTime updatedAt;
}
