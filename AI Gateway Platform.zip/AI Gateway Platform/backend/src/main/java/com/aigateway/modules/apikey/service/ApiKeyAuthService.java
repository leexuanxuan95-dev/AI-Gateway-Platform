package com.aigateway.modules.apikey.service;

import com.aigateway.modules.apikey.dto.ApiKeyAuthContext;

/**
 * Gateway-facing API-key authentication service. This is the integration point
 * for the OpenAI-compatible {@code /v1/*} surface: it resolves a raw {@code sk-...}
 * key into a validated {@link ApiKeyAuthContext} (with Redis caching), and records
 * usage timestamps.
 */
public interface ApiKeyAuthService {

    /**
     * Resolve and validate a raw API key.
     *
     * @param rawKey   the raw {@code sk-...} secret presented by the caller
     * @param clientIp the caller IP (for IP-whitelist enforcement); may be null
     * @return a populated {@link ApiKeyAuthContext}
     * @throws com.aigateway.common.exception.BizException with
     *         {@code INVALID_API_KEY} (not found / wrong status),
     *         {@code KEY_EXPIRED} (past {@code expireAt}), or
     *         {@code IP_NOT_ALLOWED} (whitelist set and IP not listed).
     */
    ApiKeyAuthContext authenticate(String rawKey, String clientIp);

    /**
     * Update {@code last_used_at} for the given key. Best-effort; failures are
     * swallowed so request handling is never blocked by bookkeeping.
     *
     * @param apiKeyId the API key id
     */
    void touchLastUsed(Long apiKeyId);
}
