package com.aigateway.modules.notify.sender;

import com.aigateway.modules.notify.dto.NotifyMessage;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * In-app (inbox) sender (design doc §13). Unlike email/sms/webhook there is no external
 * delivery: the {@code notify_log} row that the dispatcher persists for every dispatch IS
 * the in-app inbox entry (company_id + content), so this sender simply accepts the message
 * (no throw = the dispatcher records status=success). We avoid writing a second row here to
 * honour the {@link NotifySender} contract that the dispatcher owns {@code notify_log}.
 */
@Slf4j
@Component
public class InmailSender implements NotifySender {

    @Override
    public String channel() {
        return "inmail";
    }

    @Override
    public void send(NotifyMessage msg) {
        if (msg.getCompanyId() == null && (msg.getTarget() == null || msg.getTarget().isBlank())) {
            throw new IllegalArgumentException("inmail needs a companyId or target");
        }
        log.info("[notify:inmail] delivered to inbox company={} target={} scene={}",
                msg.getCompanyId(), msg.getTarget(), msg.getScene());
    }
}
