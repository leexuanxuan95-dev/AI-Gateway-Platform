package com.aigateway.common.enums;

import com.baomidou.mybatisplus.annotation.EnumValue;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;

/** Company verification auth_status (design doc §4.1). */
@Getter
public enum AuthStatus implements CodedEnum<Integer> {

    PENDING(0),
    PASSED(1),
    REJECTED(2);

    @EnumValue
    @JsonValue
    private final Integer code;

    AuthStatus(Integer code) {
        this.code = code;
    }

    @JsonCreator
    public static AuthStatus of(Integer code) {
        if (code == null) {
            return null;
        }
        for (AuthStatus v : values()) {
            if (v.code.equals(code)) {
                return v;
            }
        }
        return null;
    }
}
