package com.aigateway.modules.user.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.Size;
import lombok.Data;

/**
 * Registration request. Either ({@code email}+{@code password}) or
 * ({@code mobile}+{@code code}) must be provided. {@code captcha} is validated
 * against the code stored in Redis for the chosen target.
 */
@Data
public class RegisterRequest {

    @Email
    private String email;

    /** When provided (email registration) must be at least 8 chars. */
    @Size(min = 8, max = 100)
    private String password;

    private String mobile;

    /** Verification code for mobile registration (scene = register). */
    private String code;

    private String nickname;
}
