package com.aigateway.modules.gateway.service;

import com.aigateway.common.exception.BizException;
import com.aigateway.common.exception.ErrorCode;
import com.aigateway.modules.apikey.dto.ApiKeyAuthContext;
import com.aigateway.modules.gateway.context.GatewayContext;
import com.aigateway.modules.model.service.ModelRouteService;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

/**
 * Shared request resolution for the {@code /v1/*} proxy controllers: reads the model from the
 * body, enforces the key's allow-list and {@code assertCallable}, and resolves the effective
 * project id honoring the {@code X-Project-Id} header override.
 */
@Component
@RequiredArgsConstructor
public class GatewayRequestSupport {

    /** A sane model token: alphanumerics plus {@code . _ : -}, 1..64 chars (input safety §20). */
    private static final Pattern MODEL_PATTERN = Pattern.compile("[A-Za-z0-9._:-]{1,64}");
    /** Hard caps to reject abusive payloads before routing (never log the body). */
    private static final int MAX_MESSAGES = 2000;
    private static final long MAX_TOTAL_CHARS = 4_000_000L;

    private final ModelRouteService modelRouteService;

    /** Resolve + validate the model code, throwing OpenAI-mapped errors on violation. */
    public String resolveModel(Object modelField) {
        if (!(modelField instanceof String) || ((String) modelField).isBlank()) {
            throw new BizException(ErrorCode.PARAM_ERROR, "missing 'model'");
        }
        String model = ((String) modelField).trim();
        // Input safety: reject anything that is not a plausible model token before routing.
        if (!MODEL_PATTERN.matcher(model).matches()) {
            throw new BizException(ErrorCode.PARAM_ERROR, "invalid 'model'");
        }
        ApiKeyAuthContext ctx = GatewayContext.auth();
        List<String> allowed = ctx == null ? null : ctx.getAllowedModels();
        if (allowed != null && !allowed.isEmpty() && !allowed.contains(model)) {
            throw new BizException(ErrorCode.MODEL_NOT_ALLOWED);
        }
        modelRouteService.assertCallable(model);
        return model;
    }

    /**
     * Bound the number and total size of chat messages to reject abusive payloads early
     * (design doc §20 input safety). Never logs the body. No-op when no {@code messages} array.
     */
    @SuppressWarnings("unchecked")
    public void assertWithinLimits(Map<String, Object> body) {
        if (body == null) {
            return;
        }
        Object messages = body.get("messages");
        if (!(messages instanceof List<?> list)) {
            return;
        }
        if (list.size() > MAX_MESSAGES) {
            throw new BizException(ErrorCode.PARAM_ERROR, "too many messages");
        }
        long chars = 0;
        for (Object m : list) {
            if (m instanceof Map<?, ?> msg) {
                Object c = msg.get("content");
                if (c instanceof String s) {
                    chars += s.length();
                } else if (c != null) {
                    chars += String.valueOf(c).length();
                }
                if (chars > MAX_TOTAL_CHARS) {
                    throw new BizException(ErrorCode.PARAM_ERROR, "request payload too large");
                }
            }
        }
    }

    /** Effective project id: {@code X-Project-Id} header override, else the key's project. */
    public Long resolveProjectId(HttpServletRequest req) {
        String header = req.getHeader("X-Project-Id");
        if (header != null && !header.isBlank()) {
            try {
                return Long.parseLong(header.trim());
            } catch (NumberFormatException ignore) {
                // fall through to key default
            }
        }
        ApiKeyAuthContext ctx = GatewayContext.auth();
        return ctx == null ? null : ctx.getProjectId();
    }
}
