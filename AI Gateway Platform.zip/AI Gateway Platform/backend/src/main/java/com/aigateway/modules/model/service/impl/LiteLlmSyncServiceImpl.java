package com.aigateway.modules.model.service.impl;

import com.aigateway.common.crypto.AesUtil;
import com.aigateway.common.enums.ChannelKeyStatus;
import com.aigateway.common.enums.CommonStatus;
import com.aigateway.modules.channel.entity.Channel;
import com.aigateway.modules.channel.entity.ChannelApiKey;
import com.aigateway.modules.channel.mapper.ChannelApiKeyMapper;
import com.aigateway.modules.channel.mapper.ChannelMapper;
import com.aigateway.modules.model.entity.LitellmDeployment;
import com.aigateway.modules.model.entity.ModelChannelRoute;
import com.aigateway.modules.model.entity.ModelVersion;
import com.aigateway.modules.model.mapper.LitellmDeploymentMapper;
import com.aigateway.modules.model.mapper.ModelChannelRouteMapper;
import com.aigateway.modules.model.mapper.ModelVersionMapper;
import com.aigateway.modules.model.service.LiteLlmAdminClient;
import com.aigateway.modules.model.service.LiteLlmSyncService;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Default {@link LiteLlmSyncService}. Depends ONLY on mappers + {@link LiteLlmAdminClient} +
 * {@link AesUtil} (never on {@code ChannelApiKeyService}) so the channel module can depend on it
 * without creating a circular bean dependency. Every method is fully defensive: failures are logged
 * (warn) and swallowed, and decrypted upstream keys are never logged.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class LiteLlmSyncServiceImpl implements LiteLlmSyncService {

    /** Provider/upstream-model separator, e.g. {@code openai/gpt-4o}. */
    private static final String MODEL_SEPARATOR = "/";

    private final ChannelApiKeyMapper channelApiKeyMapper;
    private final ChannelMapper channelMapper;
    private final ModelChannelRouteMapper routeMapper;
    private final ModelVersionMapper versionMapper;
    private final LitellmDeploymentMapper deploymentMapper;
    private final LiteLlmAdminClient liteLlmAdminClient;
    private final AesUtil aesUtil;

    @Override
    public void syncKey(Long keyId) {
        if (keyId == null) {
            return;
        }
        try {
            ChannelApiKey key = channelApiKeyMapper.selectById(keyId);
            if (key == null || ChannelKeyStatus.ACTIVE != key.getStatus()) {
                removeKeyDeployments(keyId);
                return;
            }
            Channel channel = channelMapper.selectById(key.getChannelId());
            if (channel == null) {
                log.warn("syncKey {}: channel {} not found", keyId, key.getChannelId());
                return;
            }
            List<ModelChannelRoute> routes = routeMapper.selectList(
                    Wrappers.<ModelChannelRoute>lambdaQuery()
                            .eq(ModelChannelRoute::getChannelId, channel.getId())
                            .eq(ModelChannelRoute::getStatus, CommonStatus.ENABLED));
            for (ModelChannelRoute route : routes) {
                syncRouteForKey(channel, key, route);
            }
        } catch (Exception e) {
            log.warn("syncKey {} failed: {}", keyId, e.getMessage());
        }
    }

    /** Register a deployment for one (key, enabled route) pair if not already present. Idempotent. */
    private void syncRouteForKey(Channel channel, ChannelApiKey key, ModelChannelRoute route) {
        try {
            ModelVersion version = versionMapper.selectById(route.getModelId());
            if (version == null || version.getModelCode() == null) {
                return;
            }
            String modelCode = version.getModelCode();
            Long existing = deploymentMapper.selectCount(
                    Wrappers.<LitellmDeployment>lambdaQuery()
                            .eq(LitellmDeployment::getKeyId, key.getId())
                            .eq(LitellmDeployment::getModelCode, modelCode));
            if (existing != null && existing > 0) {
                return;
            }
            String litellmModel = channel.getProviderName() + MODEL_SEPARATOR + route.getUpstreamModel();
            String modelId = liteLlmAdminClient.registerDeployment(
                    modelCode, litellmModel, aesUtil.decrypt(key.getApiKey()), channel.getBaseUrl());
            if (modelId == null) {
                return;
            }
            LitellmDeployment row = new LitellmDeployment();
            row.setChannelId(channel.getId());
            row.setKeyId(key.getId());
            row.setModelCode(modelCode);
            row.setUpstreamModel(route.getUpstreamModel());
            row.setLitellmModelId(modelId);
            row.setStatus(CommonStatus.ENABLED);
            deploymentMapper.insert(row);
        } catch (Exception e) {
            log.warn("syncRouteForKey key={} route={} failed: {}",
                    key.getId(), route.getId(), e.getMessage());
        }
    }

    @Override
    public void removeKeyDeployments(Long keyId) {
        if (keyId == null) {
            return;
        }
        try {
            List<LitellmDeployment> rows = deploymentMapper.selectList(
                    Wrappers.<LitellmDeployment>lambdaQuery().eq(LitellmDeployment::getKeyId, keyId));
            for (LitellmDeployment row : rows) {
                deleteDeployment(row);
            }
        } catch (Exception e) {
            log.warn("removeKeyDeployments {} failed: {}", keyId, e.getMessage());
        }
    }

    /** Delete one deployment from LiteLLM then drop its row. Best-effort per row. */
    private void deleteDeployment(LitellmDeployment row) {
        try {
            if (row.getLitellmModelId() != null) {
                liteLlmAdminClient.deleteModel(row.getLitellmModelId());
            }
            deploymentMapper.deleteById(row.getId());
        } catch (Exception e) {
            log.warn("delete deployment {} (key {}) failed: {}",
                    row.getId(), row.getKeyId(), e.getMessage());
        }
    }

    @Override
    public void syncChannel(Long channelId) {
        if (channelId == null) {
            return;
        }
        try {
            List<ChannelApiKey> keys = channelApiKeyMapper.selectList(
                    Wrappers.<ChannelApiKey>lambdaQuery().eq(ChannelApiKey::getChannelId, channelId));
            for (ChannelApiKey key : keys) {
                if (ChannelKeyStatus.ACTIVE == key.getStatus()) {
                    syncKey(key.getId());
                } else {
                    removeKeyDeployments(key.getId());
                }
            }
        } catch (Exception e) {
            log.warn("syncChannel {} failed: {}", channelId, e.getMessage());
        }
    }

    @Override
    public void reconcileAll() {
        try {
            List<Channel> channels = channelMapper.selectList(
                    Wrappers.<Channel>lambdaQuery().eq(Channel::getStatus, CommonStatus.ENABLED));
            for (Channel ch : channels) {
                syncChannel(ch.getId());
            }
            pruneOrphanDeployments();
        } catch (Exception e) {
            log.warn("reconcileAll failed: {}", e.getMessage());
        }
    }

    /** Delete deployments whose key no longer exists or is no longer active. Self-healing. */
    private void pruneOrphanDeployments() {
        try {
            List<LitellmDeployment> rows = deploymentMapper.selectList(
                    Wrappers.<LitellmDeployment>lambdaQuery());
            Set<Long> activeKeyIds = new HashSet<>();
            Set<Long> knownKeyIds = new HashSet<>();
            for (LitellmDeployment row : rows) {
                Long keyId = row.getKeyId();
                if (keyId == null) {
                    deleteDeployment(row);
                    continue;
                }
                if (!knownKeyIds.contains(keyId) && !activeKeyIds.contains(keyId)) {
                    ChannelApiKey key = channelApiKeyMapper.selectById(keyId);
                    if (key != null && ChannelKeyStatus.ACTIVE == key.getStatus()) {
                        activeKeyIds.add(keyId);
                    } else {
                        knownKeyIds.add(keyId);
                    }
                }
                if (!activeKeyIds.contains(keyId)) {
                    deleteDeployment(row);
                }
            }
        } catch (Exception e) {
            log.warn("pruneOrphanDeployments failed: {}", e.getMessage());
        }
    }
}
