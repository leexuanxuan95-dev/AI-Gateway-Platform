package com.aigateway.modules.payment.adapter;

import com.aigateway.common.exception.BizException;
import com.aigateway.common.exception.ErrorCode;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

/** Resolves a {@link PaymentAdapter} by channel code. */
@Component
public class PaymentAdapterRegistry {

    private final Map<String, PaymentAdapter> byCode;

    public PaymentAdapterRegistry(List<PaymentAdapter> adapters) {
        this.byCode = adapters.stream()
                .collect(Collectors.toMap(PaymentAdapter::code, Function.identity()));
    }

    /** Find the adapter for a channel code or throw if none registered. */
    public PaymentAdapter require(String code) {
        PaymentAdapter a = byCode.get(code);
        if (a == null) {
            throw new BizException(ErrorCode.PAY_CHANNEL_DISABLED, "no adapter for channel " + code);
        }
        return a;
    }
}
