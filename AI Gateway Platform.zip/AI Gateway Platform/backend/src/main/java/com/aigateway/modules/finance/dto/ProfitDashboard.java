package com.aigateway.modules.finance.dto;

import lombok.Data;

import java.math.BigDecimal;
import java.util.List;

/** Super-admin profit dashboard (design doc §10.4). */
@Data
public class ProfitDashboard {

    private BigDecimal totalRevenue;
    private BigDecimal totalCost;
    private BigDecimal totalProfit;
    /** Overall margin = profit / revenue. */
    private BigDecimal margin;
    private List<ModelMargin> byModel;

    /** Per-model margin breakdown. */
    @Data
    public static class ModelMargin {
        private String modelCode;
        private BigDecimal revenue;
        private BigDecimal cost;
        private BigDecimal profit;
        private BigDecimal margin;
    }
}
