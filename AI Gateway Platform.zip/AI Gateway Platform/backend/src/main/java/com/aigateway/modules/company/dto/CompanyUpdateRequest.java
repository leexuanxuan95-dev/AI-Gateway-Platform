package com.aigateway.modules.company.dto;

import lombok.Data;

/** Editable company settings. */
@Data
public class CompanyUpdateRequest {

    private String companyName;

    private String contactName;

    private String contactMobile;

    private String contactEmail;
}
