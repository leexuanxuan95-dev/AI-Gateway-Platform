package com.aigateway.modules.billing.consumer;

import com.aigateway.common.constant.KafkaTopics;
import com.aigateway.modules.billing.entity.CallLog;
import com.aigateway.modules.billing.mapper.CallLogMapper;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

/**
 * Consumes call-log messages off {@code KafkaTopics.CALL_LOG} (design doc §11) and inserts
 * them into the partitioned {@code call_log} table. The gateway publishes these asynchronously
 * so request latency is never gated on the log write. Poison messages are logged and skipped.
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class CallLogConsumer {

    private final CallLogMapper callLogMapper;
    private final ObjectMapper objectMapper;

    /**
     * Deserializes a call-log payload and inserts it into the partitioned {@code call_log} table.
     * Any failure is logged and the message is skipped (no retry / no rethrow).
     *
     * @param payload JSON-serialized {@link CallLog} from the {@code CALL_LOG} topic
     */
    @KafkaListener(topics = KafkaTopics.CALL_LOG, groupId = "ai-gateway-calllog")
    public void onMessage(String payload) {
        try {
            CallLog c = objectMapper.readValue(payload, CallLog.class);
            callLogMapper.insertLog(c.getRequestId(), c.getApiKeyId(), c.getCompanyId(),
                    c.getModelCode(), c.getChannelId(), c.getIp(), c.getUserAgent(),
                    c.getHttpStatus(), c.getBizStatus(), c.getResponseTime(), c.getIsStream());
        } catch (Exception e) {
            log.warn("call-log consume failed, skipping: {}", e.getMessage());
        }
    }
}
