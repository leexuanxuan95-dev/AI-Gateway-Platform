package com.aigateway.modules.model.dto;

import com.aigateway.common.enums.ModelAvailability;
import com.aigateway.common.enums.ModelStatus;
import lombok.Data;

/** Filter for the paged model-version list endpoint. */
@Data
public class ModelVersionQuery {

    private Long familyId;
    private ModelAvailability availability;
    private ModelStatus status;
    /** Free-text match against modelCode / displayName. */
    private String keyword;
}
