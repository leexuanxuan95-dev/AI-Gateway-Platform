package com.aigateway.modules.finance.mapper;

import com.aigateway.modules.finance.entity.FinWithdrawOrder;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/** MyBatis-Plus mapper for {@link FinWithdrawOrder}. */
public interface FinWithdrawOrderMapper extends BaseMapper<FinWithdrawOrder> {
}
