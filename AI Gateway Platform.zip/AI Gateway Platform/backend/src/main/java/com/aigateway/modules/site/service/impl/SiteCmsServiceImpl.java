package com.aigateway.modules.site.service.impl;

import com.aigateway.common.enums.CommonStatus;
import com.aigateway.common.enums.SitePublishStatus;
import com.aigateway.common.exception.BizException;
import com.aigateway.common.exception.ErrorCode;
import com.aigateway.modules.model.entity.ModelFamily;
import com.aigateway.modules.model.entity.ModelVersion;
import com.aigateway.modules.model.mapper.ModelFamilyMapper;
import com.aigateway.modules.model.service.ModelRouteService;
import com.aigateway.modules.plan.entity.Plan;
import com.aigateway.modules.plan.mapper.PlanMapper;
import com.aigateway.modules.site.dto.PreviewResp;
import com.aigateway.modules.site.dto.SiteFaqReq;
import com.aigateway.modules.site.dto.SiteSectionReq;
import com.aigateway.modules.site.dto.SiteSettingReq;
import com.aigateway.modules.site.entity.SiteFaq;
import com.aigateway.modules.site.entity.SitePublish;
import com.aigateway.modules.site.entity.SiteSection;
import com.aigateway.modules.site.entity.SiteSetting;
import com.aigateway.modules.site.mapper.SiteFaqMapper;
import com.aigateway.modules.site.mapper.SitePublishMapper;
import com.aigateway.modules.site.mapper.SiteSectionMapper;
import com.aigateway.modules.site.mapper.SiteSettingMapper;
import com.aigateway.modules.site.service.SiteCmsService;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Duration;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * Default {@link SiteCmsService} (OmniRoute doc §4.3 / §4.4).
 *
 * <p>Editing writes to draft tables ({@code site_setting} / {@code site_section} /
 * {@code site_faq}); publishing assembles a fully-resolved snapshot (bind_source data
 * embedded at publish time, OmniRoute §4.5) into {@code site_publish}. The public landing
 * read serves the latest published snapshot, Redis-cached for a short TTL, and falls back
 * to assembling from the draft so a fresh install still renders.</p>
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class SiteCmsServiceImpl implements SiteCmsService {

    /** Default / fallback content language. */
    private static final String DEFAULT_LANG = "zh";
    /** Section bind_source: auto-sync from the {@code plan} table. */
    private static final String BIND_PLAN = "plan";
    /** Section bind_source: auto-sync from {@code model_version}. */
    private static final String BIND_MODEL = "model_version";

    /** Landing snapshot cache TTL (OmniRoute §4.4: ~5min strong cache). */
    private static final Duration LANDING_TTL = Duration.ofMinutes(5);
    /** Preview snapshot TTL. */
    private static final Duration PREVIEW_TTL = Duration.ofMinutes(30);
    /** Landing cache key prefix. */
    private static final String LANDING_KEY_PREFIX = "gw:site:landing:";
    /** Preview snapshot key prefix. */
    private static final String PREVIEW_KEY_PREFIX = "gw:site:preview:";

    private final SiteSettingMapper siteSettingMapper;
    private final SiteSectionMapper siteSectionMapper;
    private final SiteFaqMapper siteFaqMapper;
    private final SitePublishMapper sitePublishMapper;
    private final PlanMapper planMapper;
    private final ModelFamilyMapper modelFamilyMapper;
    private final ModelRouteService modelRouteService;
    private final RedisTemplate<String, Object> redisTemplate;

    // ----------------------------------------------------------------- draft

    @Override
    public Map<String, Object> getDraft(String lang) {
        // admin draft view: keep disabled sections/faq visible for editing, don't resolve binds
        return assembleContent(normalizeLang(lang), false, false);
    }

    @Override
    public SiteSetting upsertSetting(String lang, SiteSettingReq req, Long operatorUserId) {
        String useLang = normalizeLang(lang);
        SiteSetting existing = findSetting(useLang);
        SiteSetting row = existing == null ? new SiteSetting() : existing;
        row.setLang(useLang);
        if (req.getBrand() != null) {
            row.setBrand(req.getBrand());
        }
        if (req.getSeo() != null) {
            row.setSeo(req.getSeo());
        }
        if (req.getTheme() != null) {
            row.setTheme(req.getTheme());
        }
        if (req.getFooter() != null) {
            row.setFooter(req.getFooter());
        }
        row.setUpdatedBy(operatorUserId);
        if (existing == null) {
            siteSettingMapper.insert(row);
        } else {
            siteSettingMapper.updateById(row);
        }
        return row;
    }

    @Override
    public SiteSection upsertSection(String sectionKey, String lang, SiteSectionReq req) {
        if (sectionKey == null || sectionKey.isBlank()) {
            throw new BizException(ErrorCode.PARAM_ERROR, "sectionKey is required");
        }
        String useLang = normalizeLang(lang);
        SiteSection existing = siteSectionMapper.selectOne(Wrappers.<SiteSection>lambdaQuery()
                .eq(SiteSection::getSectionKey, sectionKey)
                .eq(SiteSection::getLang, useLang));
        SiteSection row = existing == null ? new SiteSection() : existing;
        row.setSectionKey(sectionKey);
        row.setLang(useLang);
        if (req.getEnabled() != null) {
            row.setEnabled(req.getEnabled());
        }
        if (req.getSort() != null) {
            row.setSort(req.getSort());
        }
        if (req.getTitle() != null) {
            row.setTitle(req.getTitle());
        }
        if (req.getSubtitle() != null) {
            row.setSubtitle(req.getSubtitle());
        }
        if (req.getPayload() != null) {
            row.setPayload(req.getPayload());
        }
        if (req.getBindSource() != null) {
            row.setBindSource(req.getBindSource().isBlank() ? null : req.getBindSource());
        }
        if (existing == null) {
            if (row.getEnabled() == null) {
                row.setEnabled(Boolean.TRUE);
            }
            if (row.getSort() == null) {
                row.setSort(0);
            }
            siteSectionMapper.insert(row);
        } else {
            siteSectionMapper.updateById(row);
        }
        return row;
    }

    @Override
    public SiteFaq createFaq(SiteFaqReq req) {
        SiteFaq row = new SiteFaq();
        row.setLang(normalizeLang(req.getLang()));
        row.setQuestion(req.getQuestion());
        row.setAnswer(req.getAnswer());
        row.setSort(req.getSort() == null ? 0 : req.getSort());
        row.setEnabled(req.getEnabled() == null ? Boolean.TRUE : req.getEnabled());
        siteFaqMapper.insert(row);
        return row;
    }

    @Override
    public SiteFaq updateFaq(Long id, SiteFaqReq req) {
        SiteFaq existing = siteFaqMapper.selectById(id);
        if (existing == null) {
            throw new BizException(ErrorCode.NOT_FOUND, "faq not found");
        }
        if (req.getLang() != null) {
            existing.setLang(normalizeLang(req.getLang()));
        }
        if (req.getQuestion() != null) {
            existing.setQuestion(req.getQuestion());
        }
        if (req.getAnswer() != null) {
            existing.setAnswer(req.getAnswer());
        }
        if (req.getSort() != null) {
            existing.setSort(req.getSort());
        }
        if (req.getEnabled() != null) {
            existing.setEnabled(req.getEnabled());
        }
        siteFaqMapper.updateById(existing);
        return existing;
    }

    @Override
    public void deleteFaq(Long id) {
        siteFaqMapper.deleteById(id);
    }

    // --------------------------------------------------------------- preview

    @Override
    public PreviewResp createPreview(String lang) {
        String useLang = normalizeLang(lang);
        Map<String, Object> snapshot = assembleContent(useLang, true, true);
        String token = UUID.randomUUID().toString().replace("-", "");
        try {
            redisTemplate.opsForValue().set(PREVIEW_KEY_PREFIX + token, snapshot, PREVIEW_TTL);
        } catch (Exception e) {
            log.warn("site preview cache write failed: {}", e.getMessage());
            throw new BizException(ErrorCode.SYSTEM_ERROR, "preview store unavailable");
        }
        return new PreviewResp(token, "/api/site/preview/" + token);
    }

    @Override
    @SuppressWarnings("unchecked")
    public Map<String, Object> getPreview(String token) {
        if (token == null || token.isBlank()) {
            return null;
        }
        try {
            Object cached = redisTemplate.opsForValue().get(PREVIEW_KEY_PREFIX + token);
            if (cached instanceof Map) {
                return (Map<String, Object>) cached;
            }
        } catch (Exception e) {
            log.warn("site preview cache read failed: {}", e.getMessage());
        }
        return null;
    }

    // --------------------------------------------------------------- publish

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Map<String, Object> publish(String lang, Long operatorUserId) {
        String useLang = normalizeLang(lang);
        Map<String, Object> snapshot = assembleContent(useLang, true, true);
        supersedePrevious(useLang);
        insertPublished(useLang, snapshot, operatorUserId);
        evictLanding(useLang);
        return snapshot;
    }

    @Override
    public List<SitePublish> publishHistory(String lang) {
        return sitePublishMapper.selectList(Wrappers.<SitePublish>lambdaQuery()
                .eq(SitePublish::getLang, normalizeLang(lang))
                .orderByDesc(SitePublish::getId));
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Map<String, Object> rollback(Long publishId, Long operatorUserId) {
        SitePublish old = sitePublishMapper.selectById(publishId);
        if (old == null) {
            throw new BizException(ErrorCode.NOT_FOUND, "publish version not found");
        }
        String useLang = normalizeLang(old.getLang());
        Map<String, Object> snapshot = old.getSnapshot();
        supersedePrevious(useLang);
        insertPublished(useLang, snapshot, operatorUserId);
        evictLanding(useLang);
        return snapshot;
    }

    /** Mark all currently-published rows for a language as superseded (preserves the §4 status=2 marker). */
    private void supersedePrevious(String lang) {
        SitePublish update = new SitePublish();
        update.setStatus(SitePublishStatus.SUPERSEDED);
        sitePublishMapper.update(update, Wrappers.<SitePublish>lambdaUpdate()
                .eq(SitePublish::getLang, lang)
                .eq(SitePublish::getStatus, SitePublishStatus.PUBLISHED));
    }

    /** Insert a freshly-published snapshot row. */
    private void insertPublished(String lang, Map<String, Object> snapshot, Long operatorUserId) {
        SitePublish row = new SitePublish();
        row.setLang(lang);
        row.setStatus(SitePublishStatus.PUBLISHED);
        row.setSnapshot(snapshot);
        row.setPublishedBy(operatorUserId);
        row.setPublishedAt(OffsetDateTime.now());
        sitePublishMapper.insert(row);
    }

    // --------------------------------------------------------------- landing

    @Override
    @SuppressWarnings("unchecked")
    public Map<String, Object> getLanding(String lang) {
        String useLang = normalizeLang(lang);
        String cacheKey = LANDING_KEY_PREFIX + useLang;
        try {
            Object cached = redisTemplate.opsForValue().get(cacheKey);
            if (cached instanceof Map) {
                return (Map<String, Object>) cached;
            }
        } catch (Exception e) {
            log.debug("site landing cache read failed for {}: {}", useLang, e.getMessage());
        }

        Map<String, Object> content = latestPublishedSnapshot(useLang);
        if (content == null && !DEFAULT_LANG.equals(useLang)) {
            // fall back to the default language's published snapshot
            content = latestPublishedSnapshot(DEFAULT_LANG);
        }
        if (content == null) {
            // fresh install: nothing published yet -> assemble live from draft so it renders
            content = assembleContent(useLang, true, true);
        }
        try {
            redisTemplate.opsForValue().set(cacheKey, content, LANDING_TTL);
        } catch (Exception e) {
            log.debug("site landing cache write failed for {}: {}", useLang, e.getMessage());
        }
        return content;
    }

    /** Latest published snapshot for a language, or null. */
    private Map<String, Object> latestPublishedSnapshot(String lang) {
        SitePublish latest = sitePublishMapper.selectOne(Wrappers.<SitePublish>lambdaQuery()
                .eq(SitePublish::getLang, lang)
                .eq(SitePublish::getStatus, SitePublishStatus.PUBLISHED)
                .orderByDesc(SitePublish::getId)
                .last("LIMIT 1"));
        return latest == null ? null : latest.getSnapshot();
    }

    private void evictLanding(String lang) {
        try {
            redisTemplate.delete(LANDING_KEY_PREFIX + lang);
        } catch (Exception e) {
            log.debug("site landing cache evict failed for {}: {}", lang, e.getMessage());
        }
    }

    // -------------------------------------------------------------- assembly

    /**
     * Assemble the structured content object (OmniRoute §4.3 shape).
     *
     * @param lang            content language
     * @param resolveBind     when true, resolve bind_source live (plan / model_version) and
     *                        embed the data into each section's payload (used at publish/preview)
     * @param excludeDisabled when true, omit disabled sections and disabled FAQ (rendered
     *                        output); when false, include them (admin draft view for editing)
     */
    private Map<String, Object> assembleContent(String lang, boolean resolveBind, boolean excludeDisabled) {
        SiteSetting setting = findSetting(lang);
        if (setting == null && !DEFAULT_LANG.equals(lang)) {
            setting = findSetting(DEFAULT_LANG);
        }

        List<SiteSection> sections = siteSectionMapper.selectList(Wrappers.<SiteSection>lambdaQuery()
                .eq(SiteSection::getLang, lang)
                .orderByAsc(SiteSection::getSort));
        if (sections.isEmpty() && !DEFAULT_LANG.equals(lang)) {
            sections = siteSectionMapper.selectList(Wrappers.<SiteSection>lambdaQuery()
                    .eq(SiteSection::getLang, DEFAULT_LANG)
                    .orderByAsc(SiteSection::getSort));
        }

        List<SiteFaq> faqs = siteFaqMapper.selectList(Wrappers.<SiteFaq>lambdaQuery()
                .eq(SiteFaq::getLang, lang)
                .eq(excludeDisabled, SiteFaq::getEnabled, Boolean.TRUE)
                .orderByAsc(SiteFaq::getSort));
        if (faqs.isEmpty() && !DEFAULT_LANG.equals(lang)) {
            faqs = siteFaqMapper.selectList(Wrappers.<SiteFaq>lambdaQuery()
                    .eq(SiteFaq::getLang, DEFAULT_LANG)
                    .eq(excludeDisabled, SiteFaq::getEnabled, Boolean.TRUE)
                    .orderByAsc(SiteFaq::getSort));
        }

        Map<String, Object> out = new LinkedHashMap<>();
        out.put("lang", lang);
        out.put("brand", setting == null ? null : setting.getBrand());
        out.put("seo", setting == null ? null : setting.getSeo());
        out.put("theme", setting == null ? null : setting.getTheme());
        out.put("footer", setting == null ? null : setting.getFooter());

        List<Map<String, Object>> sectionList = new ArrayList<>();
        for (SiteSection s : sections) {
            // exclude disabled sections from rendered output; keep them in the admin draft view
            if (excludeDisabled && Boolean.FALSE.equals(s.getEnabled())) {
                continue;
            }
            sectionList.add(toSectionMap(s, resolveBind));
        }
        out.put("sections", sectionList);

        List<Map<String, Object>> faqList = new ArrayList<>();
        for (SiteFaq f : faqs) {
            Map<String, Object> fm = new LinkedHashMap<>();
            fm.put("q", f.getQuestion());
            fm.put("a", f.getAnswer());
            faqList.add(fm);
        }
        out.put("faq", faqList);
        return out;
    }

    /** Convert a section to its output map, optionally embedding resolved bind_source data. */
    private Map<String, Object> toSectionMap(SiteSection s, boolean resolveBind) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("key", s.getSectionKey());
        m.put("enabled", s.getEnabled() == null ? Boolean.TRUE : s.getEnabled());
        m.put("sort", s.getSort());
        m.put("title", s.getTitle());
        m.put("subtitle", s.getSubtitle());

        Map<String, Object> payload = s.getPayload() == null
                ? new LinkedHashMap<>() : new LinkedHashMap<>(s.getPayload());
        String bind = s.getBindSource();
        if (resolveBind && bind != null) {
            if (BIND_PLAN.equals(bind)) {
                payload.put("plans", resolvePlans());
            } else if (BIND_MODEL.equals(bind)) {
                payload.put("models", resolveModels());
            }
        }
        m.put("payload", payload);
        m.put("bind_source", bind);
        return m;
    }

    /** Resolve active plans for a pricing section bound to {@code plan}. */
    private List<Map<String, Object>> resolvePlans() {
        List<Plan> plans = planMapper.selectList(Wrappers.<Plan>lambdaQuery()
                .eq(Plan::getStatus, CommonStatus.ENABLED)
                .orderByAsc(Plan::getSort));
        List<Map<String, Object>> out = new ArrayList<>();
        for (Plan p : plans) {
            Map<String, Object> m = new LinkedHashMap<>();
            m.put("id", p.getId());
            m.put("name", p.getName());
            m.put("price", p.getPrice());
            m.put("currency", p.getCurrency());
            m.put("duration", p.getDuration());
            m.put("tokenLimit", p.getTokenLimit());
            m.put("rpmLimit", p.getRpmLimit());
            m.put("maxApiKeys", p.getMaxApiKeys());
            m.put("maxProjects", p.getMaxProjects());
            m.put("allowedModels", p.getAllowedModels());
            m.put("sort", p.getSort());
            out.add(m);
        }
        return out;
    }

    /** Resolve available model versions (grouped with their family) for a {@code model_version} section. */
    private List<Map<String, Object>> resolveModels() {
        List<ModelVersion> versions = modelRouteService.listAvailable(Collections.emptyList());
        Map<Long, ModelFamily> familyById = modelFamilyMapper
                .selectList(Wrappers.<ModelFamily>lambdaQuery())
                .stream()
                .collect(Collectors.toMap(ModelFamily::getId, Function.identity(), (a, b) -> a));
        List<Map<String, Object>> out = new ArrayList<>();
        for (ModelVersion v : versions) {
            Map<String, Object> m = new LinkedHashMap<>();
            m.put("modelCode", v.getModelCode());
            m.put("displayName", v.getDisplayName());
            m.put("tagline", v.getTagline());
            m.put("availability", v.getAvailability());
            m.put("contextWindow", v.getContextWindow());
            m.put("capabilities", v.getCapabilities());
            ModelFamily fam = v.getFamilyId() == null ? null : familyById.get(v.getFamilyId());
            if (fam != null) {
                m.put("familyCode", fam.getFamilyCode());
                m.put("familyName", fam.getFamilyName());
            }
            out.add(m);
        }
        return out;
    }

    // --------------------------------------------------------------- helpers

    private SiteSetting findSetting(String lang) {
        return siteSettingMapper.selectOne(Wrappers.<SiteSetting>lambdaQuery()
                .eq(SiteSetting::getLang, lang)
                .last("LIMIT 1"));
    }

    /** Normalize a requested language to a supported one ({@code zh} / {@code en}); default {@code zh}. */
    private String normalizeLang(String lang) {
        if (lang == null || lang.isBlank()) {
            return DEFAULT_LANG;
        }
        String l = lang.trim().toLowerCase();
        if ("en".equals(l)) {
            return "en";
        }
        return DEFAULT_LANG;
    }
}
