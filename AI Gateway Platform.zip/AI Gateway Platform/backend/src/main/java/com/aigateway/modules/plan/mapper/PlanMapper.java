package com.aigateway.modules.plan.mapper;

import com.aigateway.modules.plan.entity.Plan;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/** MyBatis-Plus mapper for {@link Plan}. */
public interface PlanMapper extends BaseMapper<Plan> {
}
