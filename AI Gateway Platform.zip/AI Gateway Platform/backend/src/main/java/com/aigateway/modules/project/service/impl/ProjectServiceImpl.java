package com.aigateway.modules.project.service.impl;

import com.aigateway.common.api.PageResult;
import com.aigateway.common.enums.CommonStatus;
import com.aigateway.common.exception.BizException;
import com.aigateway.common.exception.ErrorCode;
import com.aigateway.common.security.UserContext;
import com.aigateway.modules.project.dto.ProjectRequest;
import com.aigateway.modules.project.entity.Project;
import com.aigateway.modules.project.mapper.ProjectMapper;
import com.aigateway.modules.project.service.ProjectService;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;

/** Default {@link ProjectService}. All operations filter by the active company. */
@Service
@RequiredArgsConstructor
public class ProjectServiceImpl implements ProjectService {

    private final ProjectMapper projectMapper;

    @Override
    public Project create(ProjectRequest req) {
        Project p = new Project();
        p.setCompanyId(UserContext.companyId());
        p.setName(req.getName());
        p.setDescription(req.getDescription());
        p.setMonthlyQuota(req.getMonthlyQuota() != null ? req.getMonthlyQuota() : BigDecimal.ZERO);
        p.setAllowedModels(req.getAllowedModels());
        p.setStatus(req.getStatus() != null ? req.getStatus() : CommonStatus.ENABLED);
        projectMapper.insert(p);
        return p;
    }

    @Override
    public PageResult<Project> page(long current, long size) {
        LambdaQueryWrapper<Project> qw = Wrappers.<Project>lambdaQuery()
                .eq(Project::getCompanyId, UserContext.companyId())
                .orderByDesc(Project::getId);
        IPage<Project> p = projectMapper.selectPage(new Page<>(current, size), qw);
        return PageResult.of(p);
    }

    @Override
    public Project get(Long id) {
        return requireOwned(id);
    }

    @Override
    public Project update(Long id, ProjectRequest req) {
        Project p = requireOwned(id);
        if (req.getName() != null) {
            p.setName(req.getName());
        }
        if (req.getDescription() != null) {
            p.setDescription(req.getDescription());
        }
        if (req.getMonthlyQuota() != null) {
            p.setMonthlyQuota(req.getMonthlyQuota());
        }
        if (req.getAllowedModels() != null) {
            p.setAllowedModels(req.getAllowedModels());
        }
        if (req.getStatus() != null) {
            p.setStatus(req.getStatus());
        }
        projectMapper.updateById(p);
        return p;
    }

    @Override
    public void delete(Long id) {
        Project p = requireOwned(id);
        projectMapper.deleteById(p.getId());
    }

    /** Load a project and verify it belongs to the active company. */
    private Project requireOwned(Long id) {
        Project p = projectMapper.selectById(id);
        if (p == null || !UserContext.companyId().equals(p.getCompanyId())) {
            throw new BizException(ErrorCode.NOT_FOUND);
        }
        return p;
    }
}
