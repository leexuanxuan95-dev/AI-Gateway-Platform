package com.aigateway.modules.user.mapper;

import com.aigateway.modules.user.entity.SysUser;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/** MyBatis-Plus mapper for {@link SysUser}. */
public interface SysUserMapper extends BaseMapper<SysUser> {
}
