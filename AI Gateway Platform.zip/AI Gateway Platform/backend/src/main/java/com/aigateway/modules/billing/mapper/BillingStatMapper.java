package com.aigateway.modules.billing.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.Map;

/**
 * Aggregation + maintenance SQL over the partitioned billing tables (design doc §11).
 * Sums are computed directly in PostgreSQL; partition creation runs the same DDL as
 * {@code init.sql} for upcoming months.
 */
@Mapper
public interface BillingStatMapper {

    /**
     * Sum charge/cost/tokens/requests over {@code bill_token} for a company (null = all)
     * within an inclusive-from / exclusive-to time window.
     */
    @Select("<script>" +
            "SELECT COALESCE(SUM(cost),0) AS charge, COALESCE(SUM(upstream_cost),0) AS cost, " +
            "COALESCE(SUM(total_tokens),0) AS tokens, COUNT(*) AS requests " +
            "FROM bill_token WHERE created_at &gt;= #{from} AND created_at &lt; #{to} " +
            "<if test='companyId != null'> AND company_id = #{companyId} </if>" +
            "</script>")
    Map<String, Object> sumWindow(@Param("companyId") Long companyId,
                                  @Param("from") String from,
                                  @Param("to") String to);

    /** Create a monthly partition for {@code bill_token} if absent. */
    @Update("CREATE TABLE IF NOT EXISTS bill_token_${suffix} PARTITION OF bill_token " +
            "FOR VALUES FROM ('${startDate}') TO ('${endDate}')")
    void createBillTokenPartition(@Param("suffix") String suffix,
                                  @Param("startDate") String startDate,
                                  @Param("endDate") String endDate);

    /** Create a monthly partition for {@code call_log} if absent. */
    @Update("CREATE TABLE IF NOT EXISTS call_log_${suffix} PARTITION OF call_log " +
            "FOR VALUES FROM ('${startDate}') TO ('${endDate}')")
    void createCallLogPartition(@Param("suffix") String suffix,
                                @Param("startDate") String startDate,
                                @Param("endDate") String endDate);
}
