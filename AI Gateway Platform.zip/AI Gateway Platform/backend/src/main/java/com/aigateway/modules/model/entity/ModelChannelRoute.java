package com.aigateway.modules.model.entity;

import com.aigateway.common.enums.CommonStatus;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

/**
 * Binds one {@link ModelVersion} to one {@link com.aigateway.modules.channel.entity.Channel}
 * (table {@code model_channel_route}). A version may be served by many channels; routes are
 * load-balanced by {@code weight} within the same {@code priority}, with lower priority used
 * first and higher priorities acting as failover.
 */
@Data
@TableName(value = "model_channel_route", autoResultMap = true)
public class ModelChannelRoute {

    @TableId(type = IdType.AUTO)
    private Long id;

    /** {@link ModelVersion#getId()}. */
    private Long modelId;

    private Long channelId;

    /** Upstream model id to call on this channel (provider-specific). */
    private String upstreamModel;

    private Integer weight;

    private Integer priority;

    /** 1 enabled. */
    private CommonStatus status;
}
