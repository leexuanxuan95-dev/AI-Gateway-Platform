package com.aigateway.modules.scheduler.dto;

import lombok.Data;

/** Update a job's schedule. Either field may be supplied. */
@Data
public class JobUpdateRequest {

    /** New Spring 6-field cron; ignored if null/blank. */
    private String cron;
    /** Enable/disable; ignored if null. */
    private Boolean enabled;
}
