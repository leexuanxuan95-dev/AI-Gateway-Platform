package com.aigateway.modules.finance.mapper;

import com.aigateway.modules.finance.entity.FinModelBinding;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/** MyBatis-Plus mapper for {@link FinModelBinding}. */
public interface FinModelBindingMapper extends BaseMapper<FinModelBinding> {
}
