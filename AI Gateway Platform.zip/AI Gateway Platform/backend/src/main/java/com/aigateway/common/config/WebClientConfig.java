package com.aigateway.common.config;

import io.netty.channel.ChannelOption;
import io.netty.handler.timeout.ReadTimeoutHandler;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.netty.http.client.HttpClient;
import reactor.netty.resources.ConnectionProvider;

import java.util.concurrent.TimeUnit;

/**
 * WebClient used to proxy to LiteLLM and to call upstream provider management APIs
 * (model list / balance). Large request bodies and streaming are supported.
 */
@Configuration
public class WebClientConfig {

    /** TCP connect timeout in milliseconds. */
    private static final int CONNECT_TIMEOUT_MS = 10000;
    /** Max buffered in-memory body size for codecs (16 MiB). */
    private static final int MAX_IN_MEMORY_SIZE = 16 * 1024 * 1024;

    @Value("${aigateway.gateway.request-timeout-ms:120000}")
    private int timeoutMs;
    /** Max pooled upstream connections (LiteLLM + provider mgmt APIs). */
    @Value("${HTTP_POOL_MAX_CONNECTIONS:500}")
    private int poolMaxConnections;
    /** Max requests queued waiting for a connection before failing fast. */
    @Value("${HTTP_POOL_PENDING_MAX:2000}")
    private int poolPendingAcquireMax;

    @Bean
    public WebClient.Builder webClientBuilder() {
        // bounded, self-evicting connection pool for the upstream hot path (design doc §17)
        ConnectionProvider provider = ConnectionProvider.builder("gw-upstream")
                .maxConnections(poolMaxConnections)
                .pendingAcquireMaxCount(poolPendingAcquireMax)
                .pendingAcquireTimeout(java.time.Duration.ofSeconds(10))
                .maxIdleTime(java.time.Duration.ofSeconds(60))
                .maxLifeTime(java.time.Duration.ofMinutes(10))
                .evictInBackground(java.time.Duration.ofSeconds(120))
                .build();
        HttpClient httpClient = HttpClient.create(provider)
                .option(ChannelOption.CONNECT_TIMEOUT_MILLIS, CONNECT_TIMEOUT_MS)
                .responseTimeout(java.time.Duration.ofMillis(timeoutMs))
                .doOnConnected(conn -> conn.addHandlerLast(
                        new ReadTimeoutHandler(timeoutMs, TimeUnit.MILLISECONDS)));
        return WebClient.builder()
                .clientConnector(new ReactorClientHttpConnector(httpClient))
                .codecs(c -> c.defaultCodecs().maxInMemorySize(MAX_IN_MEMORY_SIZE));
    }

    @Bean
    public WebClient litellmWebClient(WebClient.Builder builder,
                                      @Value("${aigateway.litellm.base-url}") String baseUrl) {
        return builder.baseUrl(baseUrl).build();
    }
}
