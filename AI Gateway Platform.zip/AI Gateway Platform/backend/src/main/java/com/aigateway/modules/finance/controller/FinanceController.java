package com.aigateway.modules.finance.controller;

import com.aigateway.common.api.PageResult;
import com.aigateway.common.api.R;
import com.aigateway.common.exception.BizException;
import com.aigateway.common.exception.ErrorCode;
import com.aigateway.common.security.RequirePerm;
import com.aigateway.common.security.RolePermissions;
import com.aigateway.common.security.UserContext;
import com.aigateway.modules.finance.dto.ModelBindingRequest;
import com.aigateway.modules.finance.dto.ProfitDashboard;
import com.aigateway.modules.finance.entity.FinAccount;
import com.aigateway.modules.finance.entity.FinModelBinding;
import com.aigateway.modules.finance.entity.FinTransaction;
import com.aigateway.modules.finance.entity.PricingMarkup;
import com.aigateway.modules.finance.entity.RechargeFeeConfig;
import com.aigateway.modules.finance.mapper.PricingMarkupMapper;
import com.aigateway.modules.finance.mapper.RechargeFeeConfigMapper;
import com.aigateway.modules.finance.service.FinanceService;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/** Finance console endpoints (design doc §10). */
@RestController
@RequestMapping("/api/finance")
@RequiredArgsConstructor
public class FinanceController {

    private final FinanceService financeService;
    private final PricingMarkupMapper pricingMarkupMapper;
    private final RechargeFeeConfigMapper rechargeFeeConfigMapper;

    // ---- balance / transactions (company-scoped) ----

    @GetMapping("/account")
    @RequirePerm({RolePermissions.BILLING_READ, RolePermissions.BILLING_READ_SELF})
    public R<FinAccount> account() {
        return R.ok(financeService.getOrCreateAccount(UserContext.companyId()));
    }

    @GetMapping("/transactions")
    @RequirePerm({RolePermissions.BILLING_READ, RolePermissions.BILLING_READ_SELF})
    public R<PageResult<FinTransaction>> transactions(@RequestParam(defaultValue = "1") long current,
                                                      @RequestParam(defaultValue = "20") long size) {
        return R.ok(financeService.transactions(UserContext.companyId(), current, size));
    }

    // ---- model bindings (company-scoped) ----

    @PostMapping("/bindings")
    @RequirePerm(RolePermissions.RECHARGE)
    public R<FinModelBinding> allocate(@RequestBody @Valid ModelBindingRequest req) {
        return R.ok(financeService.allocate(UserContext.companyId(), req));
    }

    @GetMapping("/bindings")
    @RequirePerm({RolePermissions.BILLING_READ, RolePermissions.BILLING_READ_SELF})
    public R<List<FinModelBinding>> bindings() {
        return R.ok(financeService.bindings(UserContext.companyId()));
    }

    // ---- profit dashboard (super-admin) ----

    @GetMapping("/profit/dashboard")
    public R<ProfitDashboard> profitDashboard() {
        requireSuperAdmin();
        return R.ok(financeService.profitDashboard());
    }

    // ---- markup config CRUD (super-admin) ----

    @GetMapping("/markup")
    public R<List<PricingMarkup>> listMarkup() {
        requireSuperAdmin();
        return R.ok(pricingMarkupMapper.selectList(
                Wrappers.<PricingMarkup>lambdaQuery().orderByAsc(PricingMarkup::getId)));
    }

    @PostMapping("/markup")
    public R<PricingMarkup> createMarkup(@RequestBody PricingMarkup m) {
        requireSuperAdmin();
        m.setId(null);
        pricingMarkupMapper.insert(m);
        return R.ok(m);
    }

    @PutMapping("/markup/{id}")
    public R<PricingMarkup> updateMarkup(@PathVariable Long id, @RequestBody PricingMarkup m) {
        requireSuperAdmin();
        m.setId(id);
        pricingMarkupMapper.updateById(m);
        return R.ok(pricingMarkupMapper.selectById(id));
    }

    @DeleteMapping("/markup/{id}")
    public R<Void> deleteMarkup(@PathVariable Long id) {
        requireSuperAdmin();
        pricingMarkupMapper.deleteById(id);
        return R.ok();
    }

    // ---- recharge-fee config CRUD (super-admin) ----

    @GetMapping("/recharge-fee")
    public R<List<RechargeFeeConfig>> listFee() {
        requireSuperAdmin();
        return R.ok(rechargeFeeConfigMapper.selectList(
                Wrappers.<RechargeFeeConfig>lambdaQuery().orderByAsc(RechargeFeeConfig::getId)));
    }

    @PostMapping("/recharge-fee")
    public R<RechargeFeeConfig> createFee(@RequestBody RechargeFeeConfig c) {
        requireSuperAdmin();
        c.setId(null);
        rechargeFeeConfigMapper.insert(c);
        return R.ok(c);
    }

    @PutMapping("/recharge-fee/{id}")
    public R<RechargeFeeConfig> updateFee(@PathVariable Long id, @RequestBody RechargeFeeConfig c) {
        requireSuperAdmin();
        c.setId(id);
        rechargeFeeConfigMapper.updateById(c);
        return R.ok(rechargeFeeConfigMapper.selectById(id));
    }

    @DeleteMapping("/recharge-fee/{id}")
    public R<Void> deleteFee(@PathVariable Long id) {
        requireSuperAdmin();
        rechargeFeeConfigMapper.deleteById(id);
        return R.ok();
    }

    private void requireSuperAdmin() {
        if (!UserContext.require().isSuperAdmin()) {
            throw new BizException(ErrorCode.PERMISSION_DENIED);
        }
    }
}
