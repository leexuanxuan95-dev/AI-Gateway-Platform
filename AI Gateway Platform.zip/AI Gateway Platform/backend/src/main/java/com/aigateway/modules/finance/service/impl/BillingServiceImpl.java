package com.aigateway.modules.finance.service.impl;

import com.aigateway.common.constant.KafkaTopics;
import com.aigateway.common.enums.TransactionType;
import com.aigateway.common.exception.BizException;
import com.aigateway.common.exception.ErrorCode;
import com.aigateway.modules.finance.dto.SettleCmd;
import com.aigateway.modules.finance.entity.FinAccount;
import com.aigateway.modules.finance.entity.FinModelBinding;
import com.aigateway.modules.finance.entity.FinTransaction;
import com.aigateway.modules.finance.entity.PlatformProfitAccount;
import com.aigateway.modules.finance.entity.ProfitLedger;
import com.aigateway.modules.finance.mapper.FinAccountMapper;
import com.aigateway.modules.finance.mapper.FinModelBindingMapper;
import com.aigateway.modules.finance.mapper.FinTransactionMapper;
import com.aigateway.modules.finance.mapper.PlatformProfitAccountMapper;
import com.aigateway.modules.finance.mapper.ProfitLedgerMapper;
import com.aigateway.modules.finance.mapper.SettlementMapper;
import com.aigateway.modules.finance.service.BillingService;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.HashMap;
import java.util.Map;

/**
 * Default {@link BillingService} (design doc §10.4-E / §11.1).
 *
 * <p>Balance model: at freeze, the estimate moves available -&gt; freeze. At settle, the
 * frozen estimate moves freeze -&gt; available, then the actual charge is deducted from
 * available. This keeps the two phases symmetric and avoids double-deduction.</p>
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class BillingServiceImpl implements BillingService {

    private static final int SCALE = 6;
    private static final int FREEZE_RETRIES = 5;
    /** Low-margin alert threshold (§10.4): emit profit-ledger Kafka msg when margin < 5%. */
    private static final BigDecimal LOW_MARGIN = new BigDecimal("0.05");

    private final FinAccountMapper finAccountMapper;
    private final FinTransactionMapper finTransactionMapper;
    private final FinModelBindingMapper finModelBindingMapper;
    private final PlatformProfitAccountMapper platformProfitAccountMapper;
    private final ProfitLedgerMapper profitLedgerMapper;
    private final SettlementMapper settlementMapper;
    private final KafkaTemplate<String, String> kafkaTemplate;
    private final ObjectMapper objectMapper;

    @Override
    @Transactional
    public BigDecimal freeze(Long companyId, BigDecimal estimate) {
        BigDecimal amt = scale(estimate);
        if (amt.signum() <= 0) {
            return BigDecimal.ZERO;
        }
        // Optimistic-lock retry loop: re-read and CAS via @Version on updateById.
        for (int i = 0; i < FREEZE_RETRIES; i++) {
            FinAccount acc = loadAccount(companyId);
            if (nz(acc.getAvailableBalance()).compareTo(amt) < 0) {
                throw new BizException(ErrorCode.INSUFFICIENT_BALANCE);
            }
            acc.setAvailableBalance(scale(nz(acc.getAvailableBalance()).subtract(amt)));
            acc.setFreezeBalance(scale(nz(acc.getFreezeBalance()).add(amt)));
            int updated = finAccountMapper.updateById(acc);
            if (updated > 0) {
                return amt;
            }
            // version conflict -> retry
        }
        throw new BizException(ErrorCode.SYSTEM_ERROR, "freeze failed: balance contention");
    }

    @Override
    @Transactional
    public void release(Long companyId, BigDecimal frozen) {
        BigDecimal amt = scale(frozen);
        if (amt.signum() <= 0) {
            return;
        }
        for (int i = 0; i < FREEZE_RETRIES; i++) {
            FinAccount acc = finAccountMapper.selectOne(
                    Wrappers.<FinAccount>lambdaQuery().eq(FinAccount::getCompanyId, companyId));
            if (acc == null) {
                log.warn("release: no account for company {}", companyId);
                return;
            }
            // cap at the current freeze balance to avoid going negative on partial states
            BigDecimal move = nz(acc.getFreezeBalance()).min(amt);
            acc.setFreezeBalance(scale(nz(acc.getFreezeBalance()).subtract(move)));
            acc.setAvailableBalance(scale(nz(acc.getAvailableBalance()).add(move)));
            if (finAccountMapper.updateById(acc) > 0) {
                return;
            }
        }
        log.warn("release failed after retries for company {} amount {}", companyId, amt);
    }

    @Override
    @Transactional
    public void settle(SettleCmd cmd) {
        BigDecimal charge = scale(cmd.getCharge());
        BigDecimal cost = scale(cmd.getCost());
        BigDecimal frozen = scale(cmd.getFrozen());

        // 1) Adjust the company account under optimistic lock.
        FinAccount acc = settleAccount(cmd.getCompanyId(), charge, frozen);

        // 2) Ledger row for the consumption.
        FinTransaction txn = new FinTransaction();
        txn.setCompanyId(cmd.getCompanyId());
        txn.setBizType(TransactionType.CONSUME);
        txn.setAmount(charge.negate());
        txn.setBalanceAfter(acc.getAvailableBalance());
        txn.setRefId(cmd.getRequestId());
        txn.setRemark("settle " + cmd.getModelCode());
        finTransactionMapper.insert(txn);

        // 3) Model binding (if allocated): deduct allocated/used.
        FinModelBinding binding = finModelBindingMapper.selectOne(
                Wrappers.<FinModelBinding>lambdaQuery()
                        .eq(FinModelBinding::getCompanyId, cmd.getCompanyId())
                        .eq(FinModelBinding::getModelCode, cmd.getModelCode())
                        .last("limit 1"));
        if (binding != null) {
            binding.setUsed(scale(nz(binding.getUsed()).add(charge)));
            binding.setAllocated(scale(nz(binding.getAllocated()).subtract(charge)));
            finModelBindingMapper.updateById(binding);
        }

        // 4) Upstream accounting: channel.used_quota += cost, upstream_reserve += cost.
        if (cmd.getChannelId() != null && cost.signum() > 0) {
            settlementMapper.addChannelUsedQuota(cmd.getChannelId(), cost);
            settlementMapper.addUpstreamReserve(cmd.getChannelId(), cost);
        }

        // 5) Platform profit account + profit ledger.
        BigDecimal profit = scale(charge.subtract(cost));
        bumpProfitAccount(charge, cost, profit);

        ProfitLedger ledger = new ProfitLedger();
        ledger.setSource("consume");
        ledger.setRefId(cmd.getRequestId());
        ledger.setCompanyId(cmd.getCompanyId());
        ledger.setModelCode(cmd.getModelCode());
        ledger.setRevenue(charge);
        ledger.setCost(cost);
        ledger.setProfit(profit);
        profitLedgerMapper.insert(ledger);

        // 6) Bill-token record (cost column = customer charge, upstream_cost = cost).
        long total = cmd.getPromptTokens() + cmd.getCompletionTokens() + cmd.getCachedTokens();
        settlementMapper.insertBillToken(cmd.getRequestId(), cmd.getCompanyId(), cmd.getProjectId(),
                cmd.getApiKeyId(), cmd.getModelCode(), cmd.getChannelId(),
                cmd.getPromptTokens(), cmd.getCompletionTokens(), cmd.getCachedTokens(), total,
                charge, cost);

        // 7) Emit a profit-ledger Kafka message when the margin is low (best-effort).
        if (isLowMargin(charge, profit)) {
            emitLowMargin(cmd, charge, cost, profit);
        }
    }

    /** Apply the settlement deltas to the account with version retry. */
    private FinAccount settleAccount(Long companyId, BigDecimal charge, BigDecimal frozen) {
        for (int i = 0; i < FREEZE_RETRIES; i++) {
            FinAccount acc = loadAccount(companyId);
            // release frozen estimate: freeze -> available
            acc.setFreezeBalance(scale(nz(acc.getFreezeBalance()).subtract(frozen)));
            acc.setAvailableBalance(scale(nz(acc.getAvailableBalance()).add(frozen)));
            // deduct actual charge from available
            acc.setAvailableBalance(scale(acc.getAvailableBalance().subtract(charge)));
            acc.setTotalConsume(scale(nz(acc.getTotalConsume()).add(charge)));
            int updated = finAccountMapper.updateById(acc);
            if (updated > 0) {
                return acc;
            }
        }
        throw new BizException(ErrorCode.SYSTEM_ERROR, "settle failed: balance contention");
    }

    private void bumpProfitAccount(BigDecimal charge, BigDecimal cost, BigDecimal profit) {
        PlatformProfitAccount p = platformProfitAccountMapper.selectById(1);
        if (p == null) {
            p = new PlatformProfitAccount();
            p.setId(1);
            p.setTotalRevenue(BigDecimal.ZERO);
            p.setTotalCost(BigDecimal.ZERO);
            p.setTotalProfit(BigDecimal.ZERO);
            platformProfitAccountMapper.insert(p);
        }
        p.setTotalRevenue(scale(nz(p.getTotalRevenue()).add(charge)));
        p.setTotalCost(scale(nz(p.getTotalCost()).add(cost)));
        p.setTotalProfit(scale(nz(p.getTotalProfit()).add(profit)));
        platformProfitAccountMapper.updateById(p);
    }

    private boolean isLowMargin(BigDecimal charge, BigDecimal profit) {
        if (charge == null || charge.signum() <= 0) {
            return false;
        }
        BigDecimal margin = profit.divide(charge, SCALE, RoundingMode.HALF_UP);
        return margin.compareTo(LOW_MARGIN) < 0;
    }

    private void emitLowMargin(SettleCmd cmd, BigDecimal charge, BigDecimal cost, BigDecimal profit) {
        try {
            Map<String, Object> msg = new HashMap<>();
            msg.put("source", "consume");
            msg.put("refId", cmd.getRequestId());
            msg.put("companyId", cmd.getCompanyId());
            msg.put("modelCode", cmd.getModelCode());
            msg.put("revenue", charge);
            msg.put("cost", cost);
            msg.put("profit", profit);
            msg.put("lowMargin", true);
            kafkaTemplate.send(KafkaTopics.PROFIT_LEDGER, cmd.getRequestId(),
                    objectMapper.writeValueAsString(msg));
        } catch (Exception e) {
            log.warn("emit low-margin profit-ledger failed: {}", e.getMessage());
        }
    }

    private FinAccount loadAccount(Long companyId) {
        FinAccount acc = finAccountMapper.selectOne(
                Wrappers.<FinAccount>lambdaQuery().eq(FinAccount::getCompanyId, companyId).last("limit 1"));
        if (acc == null) {
            throw new BizException(ErrorCode.INSUFFICIENT_BALANCE, "no finance account");
        }
        return acc;
    }

    private static BigDecimal nz(BigDecimal v) {
        return v == null ? BigDecimal.ZERO : v;
    }

    private static BigDecimal scale(BigDecimal v) {
        return nz(v).setScale(SCALE, RoundingMode.HALF_UP);
    }
}
