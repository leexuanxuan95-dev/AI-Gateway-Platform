package com.aigateway.modules.company.dto;

import com.aigateway.common.enums.AuthStatus;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

/** Super-admin audit decision on company verification. */
@Data
public class AuditRequest {

    /** Target auth_status: 1 = passed, 2 = rejected. */
    @NotNull
    private AuthStatus authStatus;

    private String remark;
}
