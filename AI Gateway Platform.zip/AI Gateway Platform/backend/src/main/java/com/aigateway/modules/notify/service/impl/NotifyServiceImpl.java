package com.aigateway.modules.notify.service.impl;

import com.aigateway.common.api.PageResult;
import com.aigateway.common.enums.NotifyStatus;
import com.aigateway.modules.notify.dto.NotifyMessage;
import com.aigateway.modules.notify.entity.NotifyLog;
import com.aigateway.modules.notify.entity.NotifyTemplate;
import com.aigateway.modules.notify.mapper.NotifyLogMapper;
import com.aigateway.modules.notify.mapper.NotifyTemplateMapper;
import com.aigateway.modules.notify.sender.NotifyPendingException;
import com.aigateway.modules.notify.sender.NotifySender;
import com.aigateway.modules.notify.service.NotifyService;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Default {@link NotifyService}. Resolves a sender per channel from the Spring context,
 * renders the {@code notify_template} body (substituting {@code {placeholder}} tokens with
 * the message params), delivers with a bounded retry (max 3), then records a {@code notify_log}
 * row with status 1 (success) / 2 (fail) / 0 (pending = channel not configured). Delivery
 * failures are swallowed (logged + recorded) so the consumer never crashes.
 */
@Slf4j
@Service
public class NotifyServiceImpl implements NotifyService {

    /** Max delivery attempts before the row is recorded as failed. */
    private static final int MAX_RETRY = 3;

    private final NotifyLogMapper notifyLogMapper;
    private final NotifyTemplateMapper notifyTemplateMapper;
    private final Map<String, NotifySender> senders;

    public NotifyServiceImpl(NotifyLogMapper notifyLogMapper,
                             NotifyTemplateMapper notifyTemplateMapper,
                             List<NotifySender> senderList) {
        this.notifyLogMapper = notifyLogMapper;
        this.notifyTemplateMapper = notifyTemplateMapper;
        this.senders = senderList.stream()
                .collect(Collectors.toMap(NotifySender::channel, s -> s));
    }

    @Override
    public void dispatch(NotifyMessage msg) {
        // Render the body from the scene template + params before sending, so the sent content
        // and the recorded notify_log content match.
        renderContent(msg);

        NotifyLog row = new NotifyLog();
        row.setCompanyId(msg.getCompanyId());
        row.setChannel(msg.getChannel());
        row.setScene(msg.getScene());
        row.setTarget(msg.getTarget());
        row.setContent(msg.getContent());
        row.setRetry(0);

        NotifySender sender = msg.getChannel() == null ? null : senders.get(msg.getChannel());
        if (sender == null) {
            log.warn("no notify sender for channel {}", msg.getChannel());
            row.setStatus(NotifyStatus.FAIL);
            notifyLogMapper.insert(row);
            return;
        }

        int attempts = 0;
        Exception lastError = null;
        for (int i = 1; i <= MAX_RETRY; i++) {
            attempts = i;
            try {
                sender.send(msg);
                row.setStatus(NotifyStatus.SUCCESS);
                row.setRetry(i - 1);
                notifyLogMapper.insert(row);
                return;
            } catch (NotifyPendingException pe) {
                // Channel not configured: retrying will never help -> record pending, no retry.
                log.warn("notify pending channel={} scene={}: {}",
                        msg.getChannel(), msg.getScene(), pe.getMessage());
                row.setStatus(NotifyStatus.PENDING);
                row.setRetry(i - 1);
                notifyLogMapper.insert(row);
                return;
            } catch (Exception e) {
                lastError = e;
                log.warn("notify dispatch attempt {}/{} failed channel={} scene={}: {}",
                        i, MAX_RETRY, msg.getChannel(), msg.getScene(), e.getMessage());
            }
        }
        // Exhausted retries.
        row.setStatus(NotifyStatus.FAIL);
        row.setRetry(attempts);
        notifyLogMapper.insert(row);
        log.warn("notify dispatch gave up after {} attempts channel={} scene={}: {}",
                attempts, msg.getChannel(), msg.getScene(),
                lastError != null ? lastError.getMessage() : "unknown");
    }

    /**
     * Resolve the message body: if blank, load the enabled {@code notify_template} for the
     * scene (+channel) and use its content/title. Then substitute {@code {placeholder}} tokens
     * with {@code msg.params}. Defensive: any failure leaves the original content untouched.
     */
    private void renderContent(NotifyMessage msg) {
        try {
            String content = msg.getContent();
            if ((content == null || content.isBlank()) && msg.getScene() != null) {
                NotifyTemplate tpl = notifyTemplateMapper.selectOne(
                        Wrappers.<NotifyTemplate>lambdaQuery()
                                .eq(NotifyTemplate::getScene, msg.getScene())
                                .eq(NotifyTemplate::getEnabled, true)
                                .last("limit 1"));
                if (tpl != null) {
                    content = tpl.getContent();
                    if (msg.getTitle() == null) {
                        msg.setTitle(substitute(tpl.getTitle(), msg.getParams()));
                    }
                }
            }
            msg.setContent(substitute(content, msg.getParams()));
        } catch (Exception e) {
            log.warn("notify template render failed scene={}: {}", msg.getScene(), e.getMessage());
        }
    }

    /** Replace {@code {token}} markers in the text with the matching param value. */
    private String substitute(String text, Map<String, Object> params) {
        if (text == null || params == null || params.isEmpty() || text.indexOf('{') < 0) {
            return text;
        }
        String out = text;
        for (Map.Entry<String, Object> e : params.entrySet()) {
            if (e.getKey() == null) {
                continue;
            }
            String value = e.getValue() == null ? "" : String.valueOf(e.getValue());
            out = out.replace("{" + e.getKey() + "}", value);
        }
        return out;
    }

    @Override
    public PageResult<NotifyLog> pageLogs(Long companyId, long current, long size) {
        IPage<NotifyLog> page = notifyLogMapper.selectPage(new Page<>(current, size),
                Wrappers.<NotifyLog>lambdaQuery()
                        .eq(companyId != null, NotifyLog::getCompanyId, companyId)
                        .orderByDesc(NotifyLog::getId));
        return PageResult.of(page);
    }

    @Override
    public List<NotifyTemplate> listTemplates() {
        return notifyTemplateMapper.selectList(
                Wrappers.<NotifyTemplate>lambdaQuery().orderByAsc(NotifyTemplate::getScene));
    }

    @Override
    public NotifyTemplate saveTemplate(NotifyTemplate template) {
        if (template.getId() == null) {
            notifyTemplateMapper.insert(template);
        } else {
            notifyTemplateMapper.updateById(template);
        }
        return notifyTemplateMapper.selectById(template.getId());
    }

    @Override
    public void deleteTemplate(Long id) {
        notifyTemplateMapper.deleteById(id);
    }
}
