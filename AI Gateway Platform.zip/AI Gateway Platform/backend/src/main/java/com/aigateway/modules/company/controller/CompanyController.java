package com.aigateway.modules.company.controller;

import com.aigateway.common.api.PageResult;
import com.aigateway.common.api.R;
import com.aigateway.common.security.RequirePerm;
import com.aigateway.common.security.RolePermissions;
import com.aigateway.modules.company.dto.AcceptInviteRequest;
import com.aigateway.modules.company.dto.AuthSubmitRequest;
import com.aigateway.modules.company.dto.CompanyCreateRequest;
import com.aigateway.modules.company.dto.CompanyUpdateRequest;
import com.aigateway.modules.company.dto.InviteRequest;
import com.aigateway.modules.company.dto.MemberView;
import com.aigateway.modules.company.dto.RoleUpdateRequest;
import com.aigateway.modules.company.entity.Company;
import com.aigateway.modules.company.entity.CompanyInvite;
import com.aigateway.modules.company.service.CompanyService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/** Company self-service: settings, verification, members. */
@RestController
@RequestMapping("/api/company")
@RequiredArgsConstructor
public class CompanyController {

    private final CompanyService companyService;

    /** Create a company (caller becomes OWNER). Any authenticated user may do this. */
    @PostMapping
    public R<Company> create(@RequestBody @Valid CompanyCreateRequest req) {
        return R.ok(companyService.create(req));
    }

    @GetMapping("/current")
    public R<Company> current() {
        return R.ok(companyService.current());
    }

    @PutMapping
    @RequirePerm(RolePermissions.COMPANY_SETTINGS)
    public R<Company> update(@RequestBody CompanyUpdateRequest req) {
        return R.ok(companyService.update(req));
    }

    @PostMapping("/auth-submit")
    @RequirePerm(RolePermissions.COMPANY_SETTINGS)
    public R<Void> submitAuth(@RequestBody @Valid AuthSubmitRequest req) {
        companyService.submitAuth(req);
        return R.ok();
    }

    @GetMapping("/members")
    public R<PageResult<MemberView>> members(@RequestParam(defaultValue = "1") long current,
                                             @RequestParam(defaultValue = "20") long size) {
        return R.ok(companyService.members(current, size));
    }

    @PostMapping("/members/invite")
    @RequirePerm(RolePermissions.COMPANY_MEMBER_MANAGE)
    public R<CompanyInvite> invite(@RequestBody @Valid InviteRequest req) {
        return R.ok(companyService.invite(req));
    }

    /** Accept an invite — performed by the invitee, so no member-manage permission required. */
    @PostMapping("/members/accept")
    public R<Void> acceptInvite(@RequestBody @Valid AcceptInviteRequest req) {
        companyService.acceptInvite(req);
        return R.ok();
    }

    @PutMapping("/members/{userId}/role")
    @RequirePerm(RolePermissions.COMPANY_MEMBER_MANAGE)
    public R<Void> updateRole(@PathVariable Long userId, @RequestBody @Valid RoleUpdateRequest req) {
        companyService.updateMemberRole(userId, req);
        return R.ok();
    }

    @DeleteMapping("/members/{userId}")
    @RequirePerm(RolePermissions.COMPANY_MEMBER_MANAGE)
    public R<Void> removeMember(@PathVariable Long userId) {
        companyService.removeMember(userId);
        return R.ok();
    }
}
