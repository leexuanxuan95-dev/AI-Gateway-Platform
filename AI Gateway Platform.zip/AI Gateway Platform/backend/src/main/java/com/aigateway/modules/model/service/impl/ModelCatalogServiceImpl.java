package com.aigateway.modules.model.service.impl;

import com.aigateway.common.api.PageResult;
import com.aigateway.common.enums.CommonStatus;
import com.aigateway.common.enums.ModelAvailability;
import com.aigateway.common.enums.ModelStatus;
import com.aigateway.common.exception.BizException;
import com.aigateway.common.exception.ErrorCode;
import com.aigateway.modules.model.dto.ModelFamilyRequest;
import com.aigateway.modules.model.dto.ModelRouteRequest;
import com.aigateway.modules.model.dto.ModelVersionQuery;
import com.aigateway.modules.model.dto.ModelVersionRequest;
import com.aigateway.modules.model.entity.ModelChannelRoute;
import com.aigateway.modules.model.entity.ModelFamily;
import com.aigateway.modules.model.entity.ModelVersion;
import com.aigateway.modules.model.mapper.ModelChannelRouteMapper;
import com.aigateway.modules.model.mapper.ModelFamilyMapper;
import com.aigateway.modules.model.mapper.ModelVersionMapper;
import com.aigateway.modules.model.service.ModelCatalogService;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

/** Default {@link ModelCatalogService}. */
@Service
@RequiredArgsConstructor
public class ModelCatalogServiceImpl implements ModelCatalogService {

    private final ModelFamilyMapper familyMapper;
    private final ModelVersionMapper versionMapper;
    private final ModelChannelRouteMapper routeMapper;

    // ---- families ----

    @Override
    public List<ModelFamily> listFamilies() {
        return familyMapper.selectList(
                Wrappers.<ModelFamily>lambdaQuery().orderByAsc(ModelFamily::getSort));
    }

    @Override
    public ModelFamily createFamily(ModelFamilyRequest req) {
        ModelFamily f = new ModelFamily();
        f.setFamilyCode(req.getFamilyCode());
        f.setFamilyName(req.getFamilyName());
        f.setIcon(req.getIcon());
        f.setSort(req.getSort() != null ? req.getSort() : 0);
        f.setStatus(req.getStatus() != null ? req.getStatus() : CommonStatus.ENABLED);
        familyMapper.insert(f);
        return f;
    }

    @Override
    public ModelFamily updateFamily(Long id, ModelFamilyRequest req) {
        ModelFamily f = requireFamily(id);
        if (req.getFamilyCode() != null) {
            f.setFamilyCode(req.getFamilyCode());
        }
        if (req.getFamilyName() != null) {
            f.setFamilyName(req.getFamilyName());
        }
        if (req.getIcon() != null) {
            f.setIcon(req.getIcon());
        }
        if (req.getSort() != null) {
            f.setSort(req.getSort());
        }
        if (req.getStatus() != null) {
            f.setStatus(req.getStatus());
        }
        familyMapper.updateById(f);
        return f;
    }

    @Override
    public void deleteFamily(Long id) {
        requireFamily(id);
        familyMapper.deleteById(id);
    }

    // ---- versions ----

    @Override
    public PageResult<ModelVersion> pageVersions(ModelVersionQuery query, long current, long size) {
        LambdaQueryWrapper<ModelVersion> qw = Wrappers.<ModelVersion>lambdaQuery();
        if (query != null) {
            if (query.getFamilyId() != null) {
                qw.eq(ModelVersion::getFamilyId, query.getFamilyId());
            }
            if (query.getAvailability() != null) {
                qw.eq(ModelVersion::getAvailability, query.getAvailability());
            }
            if (query.getStatus() != null) {
                qw.eq(ModelVersion::getStatus, query.getStatus());
            }
            if (query.getKeyword() != null && !query.getKeyword().isBlank()) {
                String kw = query.getKeyword();
                qw.and(w -> w.like(ModelVersion::getModelCode, kw)
                        .or().like(ModelVersion::getDisplayName, kw));
            }
        }
        qw.orderByAsc(ModelVersion::getSort).orderByDesc(ModelVersion::getId);
        IPage<ModelVersion> p = versionMapper.selectPage(new Page<>(current, size), qw);
        return PageResult.of(p);
    }

    @Override
    public ModelVersion createVersion(ModelVersionRequest req) {
        ModelVersion v = new ModelVersion();
        apply(v, req);
        v.setStatus(req.getStatus() != null ? req.getStatus() : ModelStatus.ACTIVE);
        v.setAvailability(req.getAvailability() != null ? req.getAvailability() : ModelAvailability.AVAILABLE);
        v.setCurrency(req.getCurrency() != null ? req.getCurrency() : "USD");
        v.setSort(req.getSort() != null ? req.getSort() : 0);
        versionMapper.insert(v);
        return v;
    }

    @Override
    public ModelVersion updateVersion(Long id, ModelVersionRequest req) {
        ModelVersion v = requireVersion(id);
        apply(v, req);
        if (req.getStatus() != null) {
            v.setStatus(req.getStatus());
        }
        if (req.getAvailability() != null) {
            v.setAvailability(req.getAvailability());
        }
        if (req.getCurrency() != null) {
            v.setCurrency(req.getCurrency());
        }
        if (req.getSort() != null) {
            v.setSort(req.getSort());
        }
        versionMapper.updateById(v);
        return v;
    }

    @Override
    public ModelVersion listVersion(Long id) {
        ModelVersion v = requireVersion(id);
        v.setAvailability(ModelAvailability.AVAILABLE);
        v.setStatus(ModelStatus.ACTIVE);
        versionMapper.updateById(v);
        return v;
    }

    @Override
    public ModelVersion delistVersion(Long id) {
        ModelVersion v = requireVersion(id);
        v.setAvailability(ModelAvailability.UNAVAILABLE);
        v.setStatus(ModelStatus.DISABLED);
        versionMapper.updateById(v);
        return v;
    }

    @Override
    public void deleteVersion(Long id) {
        requireVersion(id);
        versionMapper.deleteById(id);
    }

    // ---- routes ----

    @Override
    public List<ModelChannelRoute> routesForVersion(Long versionId) {
        requireVersion(versionId);
        return routeMapper.selectList(Wrappers.<ModelChannelRoute>lambdaQuery()
                .eq(ModelChannelRoute::getModelId, versionId)
                .orderByAsc(ModelChannelRoute::getPriority)
                .orderByDesc(ModelChannelRoute::getWeight));
    }

    @Override
    public ModelChannelRoute createRoute(ModelRouteRequest req) {
        ModelChannelRoute r = new ModelChannelRoute();
        r.setModelId(req.getModelId());
        r.setChannelId(req.getChannelId());
        r.setUpstreamModel(req.getUpstreamModel());
        r.setWeight(req.getWeight() != null ? req.getWeight() : 1);
        r.setPriority(req.getPriority() != null ? req.getPriority() : 0);
        r.setStatus(req.getStatus() != null ? req.getStatus() : CommonStatus.ENABLED);
        routeMapper.insert(r);
        return r;
    }

    @Override
    public ModelChannelRoute updateRoute(Long id, ModelRouteRequest req) {
        ModelChannelRoute r = routeMapper.selectById(id);
        if (r == null) {
            throw new BizException(ErrorCode.NOT_FOUND);
        }
        if (req.getModelId() != null) {
            r.setModelId(req.getModelId());
        }
        if (req.getChannelId() != null) {
            r.setChannelId(req.getChannelId());
        }
        if (req.getUpstreamModel() != null) {
            r.setUpstreamModel(req.getUpstreamModel());
        }
        if (req.getWeight() != null) {
            r.setWeight(req.getWeight());
        }
        if (req.getPriority() != null) {
            r.setPriority(req.getPriority());
        }
        if (req.getStatus() != null) {
            r.setStatus(req.getStatus());
        }
        routeMapper.updateById(r);
        return r;
    }

    @Override
    public void deleteRoute(Long id) {
        if (routeMapper.selectById(id) == null) {
            throw new BizException(ErrorCode.NOT_FOUND);
        }
        routeMapper.deleteById(id);
    }

    // ---- helpers ----

    /** Copy non-null mutable info fields from the request onto the entity. */
    private void apply(ModelVersion v, ModelVersionRequest req) {
        if (req.getFamilyId() != null) {
            v.setFamilyId(req.getFamilyId());
        }
        if (req.getModelCode() != null) {
            v.setModelCode(req.getModelCode());
        }
        if (req.getDisplayName() != null) {
            v.setDisplayName(req.getDisplayName());
        }
        if (req.getTagline() != null) {
            v.setTagline(req.getTagline());
        }
        if (req.getCapabilities() != null) {
            v.setCapabilities(req.getCapabilities());
        }
        if (req.getContextWindow() != null) {
            v.setContextWindow(req.getContextWindow());
        }
        if (req.getMaxOutput() != null) {
            v.setMaxOutput(req.getMaxOutput());
        }
        if (req.getPriceInput() != null) {
            v.setPriceInput(req.getPriceInput());
        }
        if (req.getPriceOutput() != null) {
            v.setPriceOutput(req.getPriceOutput());
        }
        if (req.getPriceCached() != null) {
            v.setPriceCached(req.getPriceCached());
        }
        if (req.getCostInput() != null) {
            v.setCostInput(req.getCostInput());
        }
        if (req.getCostOutput() != null) {
            v.setCostOutput(req.getCostOutput());
        }
        if (req.getCostCached() != null) {
            v.setCostCached(req.getCostCached());
        }
    }

    private ModelFamily requireFamily(Long id) {
        ModelFamily f = familyMapper.selectById(id);
        if (f == null) {
            throw new BizException(ErrorCode.NOT_FOUND);
        }
        return f;
    }

    private ModelVersion requireVersion(Long id) {
        ModelVersion v = versionMapper.selectById(id);
        if (v == null) {
            throw new BizException(ErrorCode.MODEL_NOT_FOUND);
        }
        return v;
    }
}
