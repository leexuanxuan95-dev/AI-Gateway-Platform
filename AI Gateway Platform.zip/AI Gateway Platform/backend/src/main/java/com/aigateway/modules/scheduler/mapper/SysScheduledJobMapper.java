package com.aigateway.modules.scheduler.mapper;

import com.aigateway.modules.scheduler.entity.SysScheduledJob;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/** MyBatis-Plus mapper for {@link SysScheduledJob}. */
@Mapper
public interface SysScheduledJobMapper extends BaseMapper<SysScheduledJob> {
}
