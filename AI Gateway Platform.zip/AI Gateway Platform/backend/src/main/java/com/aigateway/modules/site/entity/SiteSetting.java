package com.aigateway.modules.site.entity;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.handlers.JacksonTypeHandler;
import lombok.Data;

import java.time.OffsetDateTime;
import java.util.Map;

/**
 * Site-level configuration for the OmniRoute marketing landing (table {@code site_setting},
 * OmniRoute doc §4.2). One row per language; holds brand / SEO / theme / footer JSON.
 */
@Data
@TableName(value = "site_setting", autoResultMap = true)
public class SiteSetting {

    @TableId(type = IdType.AUTO)
    private Integer id;

    /** Content language: {@code zh} / {@code en}. */
    private String lang;

    /** Brand info: {@code {name,logo,favicon,domain,copyright,icp}}. */
    @TableField(typeHandler = JacksonTypeHandler.class)
    private Map<String, Object> brand;

    /** SEO config: {@code {title,description,keywords,ogImage}}. */
    @TableField(typeHandler = JacksonTypeHandler.class)
    private Map<String, Object> seo;

    /** Theme tokens: {@code {bg,amber,mint,text,border,font,radius...}}. */
    @TableField(typeHandler = JacksonTypeHandler.class)
    private Map<String, Object> theme;

    /** Footer link groups + copyright. */
    @TableField(typeHandler = JacksonTypeHandler.class)
    private Map<String, Object> footer;

    private Long updatedBy;

    @TableField(fill = FieldFill.INSERT_UPDATE)
    private OffsetDateTime updatedAt;
}
