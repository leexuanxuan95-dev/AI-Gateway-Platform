package com.aigateway.modules.user.entity;

import com.aigateway.common.enums.UserStatus;
import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableLogic;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.time.OffsetDateTime;

/** Platform user entity (table {@code sys_user}). */
@Data
@TableName("sys_user")
public class SysUser {

    @TableId(type = IdType.AUTO)
    private Long id;

    private String uid;

    private String email;

    private String mobile;

    private String nickname;

    private String avatar;

    /** bcrypt hash. */
    private String password;

    private String googleId;

    /** AES-encrypted TOTP secret. */
    private String totpSecret;

    private Boolean totpEnabled;

    private Boolean superAdmin;

    /** 0 pending, 1 normal, 2 logged-off, 3 disabled, 4 cancelled. */
    private UserStatus status;

    private String registerIp;

    private OffsetDateTime registerTime;

    private OffsetDateTime lastLoginTime;

    private String lastLoginIp;

    @TableLogic
    private Integer deleted;

    @TableField(fill = FieldFill.INSERT)
    private OffsetDateTime createdAt;

    @TableField(fill = FieldFill.INSERT_UPDATE)
    private OffsetDateTime updatedAt;
}
