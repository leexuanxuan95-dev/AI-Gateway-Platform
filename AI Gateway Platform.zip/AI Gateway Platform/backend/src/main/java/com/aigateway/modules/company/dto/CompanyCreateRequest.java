package com.aigateway.modules.company.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

/** Request to create a new company; the caller becomes its OWNER. */
@Data
public class CompanyCreateRequest {

    @NotBlank
    private String companyName;

    private String contactName;

    private String contactMobile;

    private String contactEmail;
}
