package com.aigateway.modules.billing.service.impl;

import com.aigateway.common.api.PageResult;
import com.aigateway.modules.billing.dto.BillQuery;
import com.aigateway.modules.billing.entity.BillToken;
import com.aigateway.modules.billing.entity.CallLog;
import com.aigateway.modules.billing.mapper.BillTokenMapper;
import com.aigateway.modules.billing.mapper.BillingStatMapper;
import com.aigateway.modules.billing.mapper.CallLogMapper;
import com.aigateway.modules.billing.service.BillingQueryService;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.io.Writer;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Default {@link BillingQueryService}. Reads/aggregates the partitioned {@code bill_token} and
 * {@code call_log} tables. Time windows always bound the partition scan; the CSV export streams
 * the latest matching rows in a single bounded page to avoid unbounded memory use.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class BillingQueryServiceImpl implements BillingQueryService {

    /** Hard cap on CSV export rows (a single bounded page). */
    private static final int EXPORT_LIMIT = 50_000;

    private final BillTokenMapper billTokenMapper;
    private final CallLogMapper callLogMapper;
    private final BillingStatMapper billingStatMapper;

    @Override
    public PageResult<BillToken> pageBills(Long companyId, BillQuery q) {
        LambdaQueryWrapper<BillToken> w = Wrappers.<BillToken>lambdaQuery()
                .eq(companyId != null, BillToken::getCompanyId, companyId)
                .eq(q.getProjectId() != null, BillToken::getProjectId, q.getProjectId())
                .eq(q.getModelCode() != null, BillToken::getModelCode, q.getModelCode())
                .ge(q.getFrom() != null, BillToken::getCreatedAt, q.getFrom())
                .lt(q.getTo() != null, BillToken::getCreatedAt, q.getTo())
                .orderByDesc(BillToken::getCreatedAt);
        IPage<BillToken> page = billTokenMapper.selectPage(new Page<>(q.getCurrent(), q.getSize()), w);
        return PageResult.of(page);
    }

    @Override
    public PageResult<CallLog> pageCallLogs(Long companyId, BillQuery q) {
        LambdaQueryWrapper<CallLog> w = Wrappers.<CallLog>lambdaQuery()
                .eq(companyId != null, CallLog::getCompanyId, companyId)
                .eq(q.getModelCode() != null, CallLog::getModelCode, q.getModelCode())
                .ge(q.getFrom() != null, CallLog::getCreatedAt, q.getFrom())
                .lt(q.getTo() != null, CallLog::getCreatedAt, q.getTo())
                .orderByDesc(CallLog::getCreatedAt);
        IPage<CallLog> page = callLogMapper.selectPage(new Page<>(q.getCurrent(), q.getSize()), w);
        return PageResult.of(page);
    }

    @Override
    public void exportBillsCsv(Long companyId, BillQuery q, Writer out) {
        LambdaQueryWrapper<BillToken> w = Wrappers.<BillToken>lambdaQuery()
                .eq(companyId != null, BillToken::getCompanyId, companyId)
                .eq(q.getProjectId() != null, BillToken::getProjectId, q.getProjectId())
                .eq(q.getModelCode() != null, BillToken::getModelCode, q.getModelCode())
                .ge(q.getFrom() != null, BillToken::getCreatedAt, q.getFrom())
                .lt(q.getTo() != null, BillToken::getCreatedAt, q.getTo())
                .orderByDesc(BillToken::getCreatedAt)
                .last("limit " + EXPORT_LIMIT);
        List<BillToken> rows = billTokenMapper.selectList(w);
        try {
            out.write("request_id,created_at,company_id,project_id,api_key_id,model_code,channel_id,"
                    + "prompt_tokens,completion_tokens,cached_tokens,total_tokens,charge,upstream_cost\n");
            for (BillToken r : rows) {
                out.write(csv(r.getRequestId()) + "," + csv(r.getCreatedAt()) + ","
                        + nz(r.getCompanyId()) + "," + nz(r.getProjectId()) + "," + nz(r.getApiKeyId()) + ","
                        + csv(r.getModelCode()) + "," + nz(r.getChannelId()) + ","
                        + nz(r.getPromptTokens()) + "," + nz(r.getCompletionTokens()) + ","
                        + nz(r.getCachedTokens()) + "," + nz(r.getTotalTokens()) + ","
                        + nz(r.getCost()) + "," + nz(r.getUpstreamCost()) + "\n");
            }
            out.flush();
        } catch (IOException e) {
            throw new UncheckedIOException(e);
        }
    }

    @Override
    public Map<String, Object> summary(Long companyId) {
        LocalDate today = LocalDate.now(ZoneOffset.UTC);
        OffsetDateTime startToday = today.atStartOfDay().atOffset(ZoneOffset.UTC);
        OffsetDateTime startYesterday = startToday.minusDays(1);
        OffsetDateTime startMonth = today.withDayOfMonth(1).atStartOfDay().atOffset(ZoneOffset.UTC);
        OffsetDateTime now = OffsetDateTime.now(ZoneOffset.UTC);
        OffsetDateTime epoch = OffsetDateTime.of(2000, 1, 1, 0, 0, 0, 0, ZoneOffset.UTC);

        Map<String, Object> result = new LinkedHashMap<>();
        result.put("today", billingStatMapper.sumWindow(companyId, iso(startToday), iso(now)));
        result.put("yesterday", billingStatMapper.sumWindow(companyId, iso(startYesterday), iso(startToday)));
        result.put("month", billingStatMapper.sumWindow(companyId, iso(startMonth), iso(now)));
        result.put("total", billingStatMapper.sumWindow(companyId, iso(epoch), iso(now)));
        return result;
    }

    private static String iso(OffsetDateTime t) {
        return t.toString();
    }

    private static String csv(Object v) {
        if (v == null) {
            return "";
        }
        String s = String.valueOf(v);
        if (s.contains(",") || s.contains("\"") || s.contains("\n")) {
            return "\"" + s.replace("\"", "\"\"") + "\"";
        }
        return s;
    }

    private static Object nz(Object v) {
        return v == null ? "" : v;
    }
}
