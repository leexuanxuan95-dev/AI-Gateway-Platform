package com.aigateway.common.enums;

import com.baomidou.mybatisplus.annotation.EnumValue;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;

/** notify_log.status. */
@Getter
public enum NotifyStatus implements CodedEnum<Integer> {

    PENDING(0),
    SUCCESS(1),
    FAIL(2);

    @EnumValue
    @JsonValue
    private final Integer code;

    NotifyStatus(Integer code) {
        this.code = code;
    }

    @JsonCreator
    public static NotifyStatus of(Integer code) {
        if (code == null) {
            return null;
        }
        for (NotifyStatus v : values()) {
            if (v.code.equals(code)) {
                return v;
            }
        }
        return null;
    }
}
