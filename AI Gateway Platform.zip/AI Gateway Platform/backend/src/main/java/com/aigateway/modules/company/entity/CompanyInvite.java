package com.aigateway.modules.company.entity;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.time.OffsetDateTime;

/** Company invitation entity (table {@code biz_company_invite}). */
@Data
@TableName("biz_company_invite")
public class CompanyInvite {

    @TableId(type = IdType.AUTO)
    private Long id;

    private Long companyId;

    private String inviteToken;

    /** Role granted on acceptance. */
    private String role;

    private String email;

    private Long invitedBy;

    private OffsetDateTime expireAt;

    private Boolean used;

    @TableField(fill = FieldFill.INSERT)
    private OffsetDateTime createdAt;
}
