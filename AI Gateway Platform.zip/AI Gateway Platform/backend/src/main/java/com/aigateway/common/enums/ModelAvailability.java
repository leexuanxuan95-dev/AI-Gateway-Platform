package com.aigateway.common.enums;

import com.baomidou.mybatisplus.annotation.EnumValue;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;

/** model_version.availability (design doc §7.5). */
@Getter
public enum ModelAvailability implements CodedEnum<String> {

    AVAILABLE("available"),
    MAINTENANCE("maintenance"),
    UNAVAILABLE("unavailable");

    @EnumValue
    @JsonValue
    private final String code;

    ModelAvailability(String code) {
        this.code = code;
    }

    @JsonCreator
    public static ModelAvailability of(String code) {
        if (code == null) {
            return null;
        }
        for (ModelAvailability v : values()) {
            if (v.code.equals(code)) {
                return v;
            }
        }
        return null;
    }
}
