package com.aigateway.modules.scheduler.controller;

import com.aigateway.common.api.R;
import com.aigateway.common.security.RequirePerm;
import com.aigateway.common.security.RolePermissions;
import com.aigateway.modules.scheduler.dto.JobUpdateRequest;
import com.aigateway.modules.scheduler.dto.JobView;
import com.aigateway.modules.scheduler.service.JobAdminService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * Admin scheduled-job management (design doc §15.5). Guarded by
 * {@link RolePermissions#SCHED_MANAGE}, which is granted to no company role — so only the
 * platform super-admin (who bypasses permission checks) can reach it.
 */
@RestController
@RequestMapping("/api/admin/jobs")
@RequirePerm(RolePermissions.SCHED_MANAGE)
@RequiredArgsConstructor
public class JobAdminController {

    private final JobAdminService jobAdminService;

    /** List all managed jobs with cron, enabled state, last-run status and next fire time. */
    @GetMapping
    public R<List<JobView>> list() {
        return R.ok(jobAdminService.list());
    }

    /** Change a job's cron and/or enabled state (applied live). */
    @PutMapping("/{jobKey}")
    public R<JobView> update(@PathVariable String jobKey, @RequestBody JobUpdateRequest req) {
        return R.ok(jobAdminService.update(jobKey, req));
    }

    /** Trigger a job immediately. */
    @PostMapping("/{jobKey}/run")
    public R<Void> run(@PathVariable String jobKey) {
        jobAdminService.runNow(jobKey);
        return R.ok();
    }
}
