package com.aigateway.modules.model.dto;

import com.aigateway.common.enums.ModelAvailability;
import com.aigateway.common.enums.ModelStatus;
import lombok.Data;

import java.math.BigDecimal;
import java.util.List;

/** Create/update payload for a model version. */
@Data
public class ModelVersionRequest {

    private Long familyId;
    private String modelCode;
    private String displayName;
    private String tagline;
    private List<String> capabilities;
    private Integer contextWindow;
    private Integer maxOutput;
    private BigDecimal priceInput;
    private BigDecimal priceOutput;
    private BigDecimal priceCached;
    private BigDecimal costInput;
    private BigDecimal costOutput;
    private BigDecimal costCached;
    private String currency;
    private ModelStatus status;
    private ModelAvailability availability;
    private Integer sort;
}
