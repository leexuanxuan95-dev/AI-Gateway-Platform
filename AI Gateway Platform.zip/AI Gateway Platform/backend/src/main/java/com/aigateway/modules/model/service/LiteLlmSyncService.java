package com.aigateway.modules.model.service;

/**
 * Keeps LiteLLM deployments in sync with the channel key pools: every ACTIVE upstream key in a
 * channel becomes its own LiteLLM deployment of each enabled model on that channel, so LiteLLM can
 * load-balance and fail over across the channel's keys. Banning/disabling/deleting a key removes
 * its deployments.
 *
 * <p>All methods are best-effort: they swallow failures (log warn), never throw to callers, and
 * never log decrypted upstream keys.</p>
 */
public interface LiteLlmSyncService {

    /**
     * Reconcile a single key. If the key is missing or not active (status != 1) its deployments are
     * removed; otherwise a deployment is registered for each enabled model route of its channel
     * (idempotent: existing deployment rows are left untouched).
     */
    void syncKey(Long keyId);

    /** Remove all LiteLLM deployments of a key (delete the LiteLLM model + the row). Best-effort. */
    void removeKeyDeployments(Long keyId);

    /** Reconcile every key of a channel: active keys are synced, non-active ones are removed. */
    void syncChannel(Long channelId);

    /**
     * Reconcile all enabled channels and prune deployment rows whose key no longer exists or is
     * non-active. Self-healing; intended to be called on a schedule.
     */
    void reconcileAll();
}
