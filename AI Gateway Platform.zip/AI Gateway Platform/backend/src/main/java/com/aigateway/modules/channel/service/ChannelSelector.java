package com.aigateway.modules.channel.service;

import com.aigateway.modules.channel.dto.ChannelPick;

import java.math.BigDecimal;

/**
 * Selects a healthy upstream channel for a model and tracks per-channel health for the
 * circuit breaker. Consumed by the gateway module; signatures are part of the contract.
 */
public interface ChannelSelector {

    /**
     * Pick a healthy channel for the given model code: priority first, then weighted-random
     * within the lowest priority that has candidates. Throws {@code ALL_CHANNELS_UNAVAILABLE}
     * if no channel is healthy, enabled, off-cooldown and has positive balance.
     */
    ChannelPick pick(String modelCode);

    /** Report a successful upstream call (clears the failure counter). */
    void reportSuccess(Long channelId, BigDecimal upstreamCost);

    /** Report a failed upstream call; trips the breaker (health=0 + cooldown) at >=3 fails. */
    void reportFailure(Long channelId);
}
