package com.aigateway.modules.company.dto;

import com.aigateway.common.enums.CommonStatus;
import lombok.Data;

import java.time.OffsetDateTime;

/** Member listing row enriched with basic user identity. */
@Data
public class MemberView {

    private Long userId;
    private String role;
    private CommonStatus status;
    private OffsetDateTime joinedAt;

    private String uid;
    private String email;
    private String nickname;
}
