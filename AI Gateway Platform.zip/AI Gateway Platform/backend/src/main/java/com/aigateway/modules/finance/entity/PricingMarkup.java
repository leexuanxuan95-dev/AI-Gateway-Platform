package com.aigateway.modules.finance.entity;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.math.BigDecimal;
import java.time.OffsetDateTime;

/** Pricing markup rule (table {@code pricing_markup}, design doc §10.4). */
@Data
@TableName(value = "pricing_markup", autoResultMap = true)
public class PricingMarkup {

    @TableId(type = IdType.AUTO)
    private Long id;

    /** global / family / model / channel / plan / company. */
    private String scope;

    /** Reference id matching the scope (e.g. company id, model code), null for global. */
    private String scopeRef;

    private BigDecimal markupRate;

    private BigDecimal markupFixed;

    private BigDecimal minMargin;

    private Boolean enabled;

    @TableField(fill = FieldFill.INSERT_UPDATE)
    private OffsetDateTime updatedAt;
}
