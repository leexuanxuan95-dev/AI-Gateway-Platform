package com.aigateway.modules.channel.dto;

import com.aigateway.common.enums.ChannelHealth;
import com.aigateway.common.enums.CommonStatus;
import com.aigateway.modules.channel.entity.Channel;
import lombok.Data;

import java.math.BigDecimal;
import java.time.OffsetDateTime;

/** Channel projection for responses. The api key is masked and never returned in full. */
@Data
public class ChannelView {

    private Long id;
    private String providerName;
    private String channelName;
    private Long familyId;
    /** Masked api key, e.g. {@code sk-...abcd}. */
    private String apiKeyMasked;
    private String baseUrl;
    private String orgId;
    private BigDecimal quota;
    private BigDecimal usedQuota;
    private BigDecimal balance;
    private Integer weight;
    private Integer priority;
    private ChannelHealth health;
    private BigDecimal lowThreshold;
    private CommonStatus status;
    private OffsetDateTime createdAt;
    private OffsetDateTime updatedAt;

    /** Build a view from an entity, masking the key. {@code balance} = quota - usedQuota. */
    public static ChannelView of(Channel ch, String maskedKey, BigDecimal balance) {
        ChannelView v = new ChannelView();
        v.setId(ch.getId());
        v.setProviderName(ch.getProviderName());
        v.setChannelName(ch.getChannelName());
        v.setFamilyId(ch.getFamilyId());
        v.setApiKeyMasked(maskedKey);
        v.setBaseUrl(ch.getBaseUrl());
        v.setOrgId(ch.getOrgId());
        v.setQuota(ch.getQuota());
        v.setUsedQuota(ch.getUsedQuota());
        v.setBalance(balance);
        v.setWeight(ch.getWeight());
        v.setPriority(ch.getPriority());
        v.setHealth(ch.getHealth());
        v.setLowThreshold(ch.getLowThreshold());
        v.setStatus(ch.getStatus());
        v.setCreatedAt(ch.getCreatedAt());
        v.setUpdatedAt(ch.getUpdatedAt());
        return v;
    }
}
