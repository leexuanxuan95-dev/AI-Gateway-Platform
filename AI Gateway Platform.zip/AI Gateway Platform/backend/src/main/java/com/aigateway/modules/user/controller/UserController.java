package com.aigateway.modules.user.controller;

import com.aigateway.common.api.R;
import com.aigateway.modules.user.dto.ChangeContactRequest;
import com.aigateway.modules.user.dto.ChangePasswordRequest;
import com.aigateway.modules.user.dto.ProfileUpdateRequest;
import com.aigateway.modules.user.dto.SessionActionRequest;
import com.aigateway.modules.user.dto.SessionView;
import com.aigateway.modules.user.dto.SwitchCompanyRequest;
import com.aigateway.modules.user.dto.TotpCodeRequest;
import com.aigateway.modules.user.dto.TotpSetupResponse;
import com.aigateway.modules.user.dto.UserInfo;
import com.aigateway.modules.user.service.AuthService;
import com.aigateway.modules.user.service.UserService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

/** Authenticated current-user endpoints (profile, password, 2FA, company switch). */
@RestController
@RequestMapping("/api/user")
@RequiredArgsConstructor
public class UserController {

    private final UserService userService;
    private final AuthService authService;

    @GetMapping("/me")
    public R<UserInfo> me() {
        return R.ok(userService.me());
    }

    @PutMapping("/profile")
    public R<Void> updateProfile(@RequestBody ProfileUpdateRequest req) {
        userService.updateProfile(req);
        return R.ok();
    }

    @PostMapping("/change-password")
    public R<Void> changePassword(@RequestBody @Valid ChangePasswordRequest req) {
        userService.changePassword(req);
        return R.ok();
    }

    /** Change bound email/mobile; requires step-up re-verification (password or fresh code). */
    @PostMapping("/change-contact")
    public R<Void> changeContact(@RequestBody @Valid ChangeContactRequest req) {
        userService.changeContact(req);
        return R.ok();
    }

    @PostMapping("/totp/setup")
    public R<TotpSetupResponse> totpSetup() {
        return R.ok(userService.totpSetup());
    }

    @PostMapping("/totp/enable")
    public R<Void> totpEnable(@RequestBody @Valid TotpCodeRequest req) {
        userService.totpEnable(req.getCode());
        return R.ok();
    }

    @PostMapping("/totp/disable")
    public R<Void> totpDisable(@RequestBody @Valid TotpCodeRequest req) {
        userService.totpDisable(req.getCode(), req.getPassword());
        return R.ok();
    }

    /** List active sessions/devices for the current user (design doc §3.3). */
    @GetMapping("/sessions")
    public R<List<SessionView>> sessions(@RequestParam(name = "refreshToken", required = false)
                                         String refreshToken) {
        return R.ok(userService.listSessions(refreshToken));
    }

    /** Revoke a single session/device by its refresh-token id. */
    @DeleteMapping("/sessions/{tokenId}")
    public R<Void> revokeSession(@PathVariable String tokenId) {
        userService.revokeSession(tokenId);
        return R.ok();
    }

    /** Kick all other devices, keeping the caller's current session (if provided). */
    @PostMapping("/sessions/revoke-all")
    public R<Void> revokeAllSessions(@RequestBody(required = false) SessionActionRequest req) {
        userService.revokeOtherSessions(req != null ? req.getRefreshToken() : null);
        return R.ok();
    }

    /** Switch the active company; returns a freshly-issued access token. */
    @PostMapping("/switch-company")
    public R<Map<String, Object>> switchCompany(@RequestBody @Valid SwitchCompanyRequest req) {
        return R.ok(Map.of("accessToken", authService.switchCompany(req.getCompanyId())));
    }
}
