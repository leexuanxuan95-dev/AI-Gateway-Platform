package com.aigateway.modules.finance.service.impl;

import com.aigateway.common.exception.BizException;
import com.aigateway.common.exception.ErrorCode;
import com.aigateway.modules.finance.dto.ChargeResult;
import com.aigateway.modules.finance.entity.PricingMarkup;
import com.aigateway.modules.finance.mapper.PricingMarkupMapper;
import com.aigateway.modules.finance.service.PricingService;
import com.aigateway.modules.model.entity.ModelVersion;
import com.aigateway.modules.model.service.ModelRouteService;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;

/**
 * Default {@link PricingService} (design doc §10.4).
 *
 * <p>cost = prompt/1e6*costInput + completion/1e6*costOutput + cached/1e6*costCached.</p>
 * <p>HARD RULE (§10.4-D): charge = max(cost*(1+markupRate), cost*(1+minMargin)) + markupFixed.
 * The charge is never below cost. If the model price/cost is not configured the model is
 * considered delisted and {@link ErrorCode#PRICE_NOT_SET} is thrown.</p>
 */
@Service
@RequiredArgsConstructor
public class PricingServiceImpl implements PricingService {

    private static final BigDecimal MILLION = new BigDecimal("1000000");
    private static final int SCALE = 6;
    /** Intermediate division scale for tokens/1e6 before multiplying by the per-million price. */
    private static final int DIVISION_SCALE = 12;

    private final PricingMarkupMapper pricingMarkupMapper;
    private final ModelRouteService modelRouteService;

    @Value("${aigateway.pricing.default-markup-rate:0.30}")
    private BigDecimal defaultMarkupRate;

    @Value("${aigateway.pricing.default-min-margin:0.10}")
    private BigDecimal defaultMinMargin;

    @Override
    public ChargeResult calc(String modelCode, long promptTokens, long completionTokens,
                             long cachedTokens, Long companyId) {
        ModelVersion mv = modelRouteService.getByCode(modelCode);
        if (mv == null) {
            throw new BizException(ErrorCode.MODEL_NOT_FOUND);
        }
        BigDecimal costInput = mv.getCostInput();
        BigDecimal costOutput = mv.getCostOutput();
        BigDecimal costCached = mv.getCostCached();
        // If cost is not configured the model is delisted -> never sell at unknown cost.
        if (isUnset(costInput) && isUnset(costOutput) && isUnset(costCached)) {
            throw new BizException(ErrorCode.PRICE_NOT_SET);
        }
        BigDecimal cost = part(promptTokens, costInput)
                .add(part(completionTokens, costOutput))
                .add(part(cachedTokens, costCached))
                .setScale(SCALE, RoundingMode.HALF_UP);

        if (cost.signum() <= 0) {
            // Tokens billed but cost resolved to zero -> price not set correctly.
            throw new BizException(ErrorCode.PRICE_NOT_SET);
        }

        PricingMarkup rule = resolveMarkup(modelCode, mv.getFamilyId(), companyId);
        return applyMarkup(cost, rule);
    }

    @Override
    public ChargeResult calcByCost(BigDecimal upstreamCost, Long companyId) {
        if (upstreamCost == null || upstreamCost.signum() <= 0) {
            // Unit cost not derivable -> price not set; never sell at unknown cost.
            throw new BizException(ErrorCode.PRICE_NOT_SET);
        }
        BigDecimal cost = upstreamCost.setScale(SCALE, RoundingMode.HALF_UP);
        // No model code / family available for unit endpoints: resolve company/global scope only.
        PricingMarkup rule = resolveMarkup(null, null, companyId);
        return applyMarkup(cost, rule);
    }

    /** Apply the hard min-margin markup rule to a resolved cost. */
    private ChargeResult applyMarkup(BigDecimal cost, PricingMarkup rule) {
        BigDecimal markupRate = rule != null && rule.getMarkupRate() != null
                ? rule.getMarkupRate() : defaultMarkupRate;
        BigDecimal minMargin = rule != null && rule.getMinMargin() != null
                ? rule.getMinMargin() : defaultMinMargin;
        BigDecimal markupFixed = rule != null && rule.getMarkupFixed() != null
                ? rule.getMarkupFixed() : BigDecimal.ZERO;

        BigDecimal byRate = cost.multiply(BigDecimal.ONE.add(markupRate));
        BigDecimal byMargin = cost.multiply(BigDecimal.ONE.add(minMargin));
        BigDecimal charge = byRate.max(byMargin).add(markupFixed)
                .setScale(SCALE, RoundingMode.HALF_UP);
        // Safety net: never charge below cost.
        if (charge.compareTo(cost) < 0) {
            charge = cost;
        }

        ChargeResult res = new ChargeResult();
        res.setCharge(charge);
        res.setCost(cost);
        res.setMarkupRate(markupRate);
        res.setMinMargin(minMargin);
        return res;
    }

    /** tokens/1e6 * pricePerMillion. */
    private BigDecimal part(long tokens, BigDecimal pricePerMillion) {
        if (pricePerMillion == null || tokens <= 0) {
            return BigDecimal.ZERO;
        }
        return BigDecimal.valueOf(tokens).divide(MILLION, DIVISION_SCALE, RoundingMode.HALF_UP)
                .multiply(pricePerMillion);
    }

    private boolean isUnset(BigDecimal v) {
        return v == null || v.signum() == 0;
    }

    /**
     * Resolve the markup rule by priority company &gt; plan &gt; model &gt; family &gt; global.
     * For now company + model + family + global are queried; plan resolution is left to a
     * future enhancement. Falls back to global, then to app defaults (handled by caller).
     */
    private PricingMarkup resolveMarkup(String modelCode, Long familyId, Long companyId) {
        List<PricingMarkup> rules = pricingMarkupMapper.selectList(
                Wrappers.<PricingMarkup>lambdaQuery().eq(PricingMarkup::getEnabled, true));
        if (rules.isEmpty()) {
            return null;
        }
        PricingMarkup company = null, model = null, family = null, global = null;
        for (PricingMarkup r : rules) {
            String scope = r.getScope();
            if (scope == null) {
                continue;
            }
            switch (scope) {
                case "company":
                    if (companyId != null && companyId.toString().equals(r.getScopeRef())) {
                        company = r;
                    }
                    break;
                case "model":
                    if (modelCode != null && modelCode.equals(r.getScopeRef())) {
                        model = r;
                    }
                    break;
                case "family":
                    if (familyId != null && familyId.toString().equals(r.getScopeRef())) {
                        family = r;
                    }
                    break;
                case "global":
                    global = r;
                    break;
                default:
                    break;
            }
        }
        if (company != null) {
            return company;
        }
        if (model != null) {
            return model;
        }
        if (family != null) {
            return family;
        }
        return global;
    }
}
