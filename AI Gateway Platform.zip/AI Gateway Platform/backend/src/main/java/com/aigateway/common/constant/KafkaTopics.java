package com.aigateway.common.constant;

/** Kafka topic names for async pipelines (billing, notify, risk) per design doc §13/§11. */
public final class KafkaTopics {

    private KafkaTopics() {
    }

    /** Token billing records flushed asynchronously to PostgreSQL. */
    public static final String BILL_TOKEN = "ai-gw.bill.token";
    /** Call logs. */
    public static final String CALL_LOG = "ai-gw.call.log";
    /** Notifications (email/sms/inmail/webhook). */
    public static final String NOTIFY = "ai-gw.notify";
    /** Risk events for the risk engine. */
    public static final String RISK_EVENT = "ai-gw.risk.event";
    /** Profit ledger entries. */
    public static final String PROFIT_LEDGER = "ai-gw.profit.ledger";
}
