package com.aigateway.modules.model.mapper;

import com.aigateway.modules.model.entity.ModelChannelRoute;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/** MyBatis-Plus mapper for {@link ModelChannelRoute}. */
public interface ModelChannelRouteMapper extends BaseMapper<ModelChannelRoute> {
}
