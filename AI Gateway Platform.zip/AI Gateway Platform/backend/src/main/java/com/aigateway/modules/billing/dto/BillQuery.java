package com.aigateway.modules.billing.dto;

import lombok.Data;

import java.time.OffsetDateTime;

/** Filter for token-bill / call-log listing and export (design doc §11). */
@Data
public class BillQuery {

    private Long projectId;

    private String modelCode;

    /** Inclusive lower bound on created_at. */
    private OffsetDateTime from;

    /** Exclusive upper bound on created_at. */
    private OffsetDateTime to;

    private long current = 1;

    private long size = 20;
}
