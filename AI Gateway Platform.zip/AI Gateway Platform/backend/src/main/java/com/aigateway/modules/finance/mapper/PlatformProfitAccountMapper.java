package com.aigateway.modules.finance.mapper;

import com.aigateway.modules.finance.entity.PlatformProfitAccount;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/** MyBatis-Plus mapper for {@link PlatformProfitAccount}. */
public interface PlatformProfitAccountMapper extends BaseMapper<PlatformProfitAccount> {
}
