package com.aigateway.modules.model.entity;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.handlers.JacksonTypeHandler;
import lombok.Data;

import java.time.OffsetDateTime;
import java.util.Map;

/** One model-sync run summary per channel (table {@code model_sync_log}). */
@Data
@TableName(value = "model_sync_log", autoResultMap = true)
public class ModelSyncLog {

    @TableId(type = IdType.AUTO)
    private Long id;

    private Long channelId;

    private String providerName;

    private Integer newCount;

    private Integer updatedCount;

    /** Count of models that disappeared upstream and were marked unavailable. */
    private Integer staleCount;

    @TableField(typeHandler = JacksonTypeHandler.class)
    private Map<String, Object> detail;

    @TableField(fill = FieldFill.INSERT)
    private OffsetDateTime createdAt;
}
