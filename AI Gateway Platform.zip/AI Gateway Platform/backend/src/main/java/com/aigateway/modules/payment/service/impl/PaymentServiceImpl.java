package com.aigateway.modules.payment.service.impl;

import com.aigateway.common.enums.RechargeStatus;
import com.aigateway.common.exception.BizException;
import com.aigateway.common.exception.ErrorCode;
import com.aigateway.common.util.IdGen;
import com.aigateway.modules.finance.entity.FinRechargeOrder;
import com.aigateway.modules.finance.mapper.FinRechargeOrderMapper;
import com.aigateway.modules.payment.adapter.PaymentAdapter;
import com.aigateway.modules.payment.adapter.PaymentAdapterRegistry;
import com.aigateway.modules.payment.adapter.PrepayResult;
import com.aigateway.modules.payment.dto.CreatePayRequest;
import com.aigateway.modules.payment.entity.PayChannelConfig;
import com.aigateway.modules.payment.service.PayChannelConfigService;
import com.aigateway.modules.payment.service.PaymentService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.OffsetDateTime;

/** Default {@link PaymentService}. */
@Service
@RequiredArgsConstructor
public class PaymentServiceImpl implements PaymentService {

    /** Recharge orders expire after 30 minutes if unpaid. */
    private static final long ORDER_TTL_MINUTES = 30;

    private final FinRechargeOrderMapper rechargeOrderMapper;
    private final PayChannelConfigService channelConfigService;
    private final PaymentAdapterRegistry adapterRegistry;

    @Override
    public PrepayResult create(Long companyId, Long userId, CreatePayRequest req) {
        PayChannelConfig cfg = channelConfigService.getByCode(req.getChannel());
        if (!Boolean.TRUE.equals(cfg.getEnabled())) {
            throw new BizException(ErrorCode.PAY_CHANNEL_DISABLED);
        }
        validateAmount(cfg, req.getAmount());
        validateCurrency(cfg, req.getCurrency());

        FinRechargeOrder o = new FinRechargeOrder();
        o.setOrderNo(IdGen.orderNo("RC"));
        o.setCompanyId(companyId);
        o.setUserId(userId);
        o.setAmount(req.getAmount());
        o.setCurrency(req.getCurrency());
        o.setPayChannel(req.getChannel());
        o.setPayMethod(req.getPayMethod());
        o.setStatus(RechargeStatus.PENDING);
        o.setExpireAt(OffsetDateTime.now().plusMinutes(ORDER_TTL_MINUTES));
        rechargeOrderMapper.insert(o);

        PaymentAdapter adapter = adapterRegistry.require(req.getChannel());
        return adapter.createOrder(o, cfg);
    }

    private void validateAmount(PayChannelConfig cfg, BigDecimal amount) {
        if (amount == null || amount.signum() <= 0) {
            throw new BizException(ErrorCode.AMOUNT_OUT_OF_RANGE);
        }
        if (cfg.getMinAmount() != null && cfg.getMinAmount().signum() > 0
                && amount.compareTo(cfg.getMinAmount()) < 0) {
            throw new BizException(ErrorCode.AMOUNT_OUT_OF_RANGE);
        }
        if (cfg.getMaxAmount() != null && cfg.getMaxAmount().signum() > 0
                && amount.compareTo(cfg.getMaxAmount()) > 0) {
            throw new BizException(ErrorCode.AMOUNT_OUT_OF_RANGE);
        }
    }

    private void validateCurrency(PayChannelConfig cfg, String currency) {
        if (cfg.getCurrencies() != null && !cfg.getCurrencies().isEmpty()
                && !cfg.getCurrencies().contains(currency)) {
            throw new BizException(ErrorCode.AMOUNT_OUT_OF_RANGE, "currency not supported");
        }
    }
}
