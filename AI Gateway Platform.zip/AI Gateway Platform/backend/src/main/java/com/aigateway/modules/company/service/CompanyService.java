package com.aigateway.modules.company.service;

import com.aigateway.common.api.PageResult;
import com.aigateway.modules.company.dto.AcceptInviteRequest;
import com.aigateway.modules.company.dto.AuditRequest;
import com.aigateway.modules.company.dto.AuthSubmitRequest;
import com.aigateway.modules.company.dto.CompanyCreateRequest;
import com.aigateway.modules.company.dto.CompanyUpdateRequest;
import com.aigateway.modules.company.dto.InviteRequest;
import com.aigateway.modules.company.dto.MemberView;
import com.aigateway.modules.company.dto.RoleUpdateRequest;
import com.aigateway.modules.company.entity.Company;
import com.aigateway.modules.company.entity.CompanyInvite;

/** Company / membership management. */
public interface CompanyService {

    /** Create a company; the current user becomes OWNER. */
    Company create(CompanyCreateRequest req);

    /** Detail of the active company. */
    Company current();

    Company update(CompanyUpdateRequest req);

    void submitAuth(AuthSubmitRequest req);

    PageResult<MemberView> members(long current, long size);

    /** Create an invitation; returns the invite (with token). */
    CompanyInvite invite(InviteRequest req);

    /** Accept an invitation, adding the current user as a member. */
    void acceptInvite(AcceptInviteRequest req);

    void updateMemberRole(Long userId, RoleUpdateRequest req);

    void removeMember(Long userId);

    // ---- super-admin ----

    PageResult<Company> adminPage(long current, long size);

    void audit(Long companyId, AuditRequest req);
}
