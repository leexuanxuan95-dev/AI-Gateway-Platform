package com.aigateway.modules.system.mapper;

import com.aigateway.modules.system.entity.SysConfig;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/** MyBatis-Plus mapper for {@link SysConfig}. */
public interface SysConfigMapper extends BaseMapper<SysConfig> {
}
