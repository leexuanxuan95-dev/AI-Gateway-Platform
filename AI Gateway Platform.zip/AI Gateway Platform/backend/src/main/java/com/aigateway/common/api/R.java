package com.aigateway.common.api;

import com.aigateway.common.exception.ErrorCode;
import lombok.Data;

import java.io.Serializable;

/**
 * Unified API response envelope for the management/console API surface.
 * (The OpenAI-compatible {@code /v1/*} surface uses its own OpenAI-shaped bodies.)
 */
@Data
public class R<T> implements Serializable {

    private int code;
    private String msg;
    private T data;

    public static <T> R<T> ok() {
        return ok(null);
    }

    public static <T> R<T> ok(T data) {
        R<T> r = new R<>();
        r.code = 0;
        r.msg = "success";
        r.data = data;
        return r;
    }

    public static <T> R<T> fail(int code, String msg) {
        R<T> r = new R<>();
        r.code = code;
        r.msg = msg;
        return r;
    }

    public static <T> R<T> fail(ErrorCode ec) {
        return fail(ec.getCode(), ec.getMsg());
    }
}
