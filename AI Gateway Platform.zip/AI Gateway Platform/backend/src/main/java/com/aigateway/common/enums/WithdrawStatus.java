package com.aigateway.common.enums;

import com.baomidou.mybatisplus.annotation.EnumValue;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;

/** fin_withdraw_order.status. */
@Getter
public enum WithdrawStatus implements CodedEnum<Integer> {

    PENDING(0),
    APPROVED(1),
    REJECTED(2),
    PAID(3),
    FAILED(4);

    @EnumValue
    @JsonValue
    private final Integer code;

    WithdrawStatus(Integer code) {
        this.code = code;
    }

    @JsonCreator
    public static WithdrawStatus of(Integer code) {
        if (code == null) {
            return null;
        }
        for (WithdrawStatus v : values()) {
            if (v.code.equals(code)) {
                return v;
            }
        }
        return null;
    }
}
