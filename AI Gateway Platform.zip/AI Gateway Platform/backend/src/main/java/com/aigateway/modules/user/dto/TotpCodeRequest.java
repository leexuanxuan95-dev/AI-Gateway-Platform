package com.aigateway.modules.user.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

/** A single TOTP code (used to enable/disable 2FA). */
@Data
public class TotpCodeRequest {

    @NotBlank
    private String code;

    /**
     * Current account password. Required as a step-up re-verification factor when
     * disabling 2FA (design doc §3.3 sensitive operations); ignored when enabling.
     */
    private String password;
}
