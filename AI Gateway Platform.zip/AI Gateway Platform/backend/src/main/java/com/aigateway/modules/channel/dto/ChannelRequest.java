package com.aigateway.modules.channel.dto;

import com.aigateway.common.enums.CommonStatus;
import lombok.Data;

import java.math.BigDecimal;

/** Create/update payload for a channel. {@code apiKey} is plaintext on input only. */
@Data
public class ChannelRequest {

    private String providerName;
    private String channelName;
    private Long familyId;
    /** Plaintext upstream key on input; encrypted before persistence. */
    private String apiKey;
    private String baseUrl;
    private String orgId;
    private Integer weight;
    private Integer priority;
    private BigDecimal lowThreshold;
    private CommonStatus status;
}
