package com.aigateway.common.exception;

import lombok.Getter;

/**
 * Business error codes. The {@code openaiType} field maps to the OpenAI-compatible
 * error {@code type} used by the {@code /v1/*} gateway surface (see design doc §20.8).
 */
@Getter
public enum ErrorCode {

    // generic
    SUCCESS(0, "success", null, 200),
    SYSTEM_ERROR(500, "internal error", "internal_error", 500),
    PARAM_ERROR(400, "invalid parameter", "invalid_request_error", 400),
    UNAUTHORIZED(401, "unauthorized", "invalid_api_key", 401),
    FORBIDDEN(403, "forbidden", "permission_denied", 403),
    NOT_FOUND(404, "not found", "not_found", 404),

    // auth / user
    INVALID_CREDENTIALS(1001, "invalid email or password", null, 401),
    USER_NOT_FOUND(1002, "user not found", null, 404),
    USER_DISABLED(1003, "user disabled", null, 403),
    CAPTCHA_INVALID(1004, "verification code invalid or expired", null, 400),
    EMAIL_EXISTS(1005, "email already registered", null, 400),
    MOBILE_EXISTS(1006, "mobile already registered", null, 400),
    TOTP_REQUIRED(1007, "2FA code required", null, 401),
    TOTP_INVALID(1008, "2FA code invalid", null, 401),
    TOKEN_EXPIRED(1009, "token expired", null, 401),

    // rbac / company
    PERMISSION_DENIED(2001, "permission denied", "permission_denied", 403),
    COMPANY_NOT_FOUND(2002, "company not found", null, 404),
    COMPANY_NOT_VERIFIED(2003, "company not verified", null, 403),
    NOT_COMPANY_MEMBER(2004, "not a member of this company", null, 403),

    // api key / gateway
    INVALID_API_KEY(3001, "invalid api key", "invalid_api_key", 401),
    INSUFFICIENT_BALANCE(3002, "insufficient balance", "insufficient_balance", 402),
    MODEL_NOT_ALLOWED(3003, "model not allowed for this key", "model_not_allowed", 403),
    MODEL_NOT_FOUND(3004, "model not found or delisted", "model_not_found", 404),
    RATE_LIMITED(3005, "rate limited", "rate_limited", 429),
    MODEL_IN_MAINTENANCE(3006, "model in maintenance", "model_in_maintenance", 503),
    ALL_CHANNELS_UNAVAILABLE(3007, "all upstream channels unavailable", "all_channels_unavailable", 502),
    KEY_EXPIRED(3008, "api key expired", "invalid_api_key", 401),
    IP_NOT_ALLOWED(3009, "ip not in whitelist", "permission_denied", 403),
    QUOTA_EXCEEDED(3010, "quota exceeded", "quota_exceeded", 429),

    // finance / pay
    ORDER_NOT_FOUND(4001, "order not found", null, 404),
    PAY_CHANNEL_DISABLED(4002, "payment channel disabled", null, 400),
    AMOUNT_OUT_OF_RANGE(4003, "amount out of allowed range", null, 400),
    CALLBACK_SIGN_INVALID(4004, "callback signature invalid", null, 400),
    WITHDRAW_AMOUNT_INVALID(4005, "withdraw amount invalid", null, 400),
    BELOW_MIN_MARGIN(4006, "price below minimum margin - blocked", null, 400),
    PRICE_NOT_SET(4007, "model price not configured - model delisted", null, 503),

    // channel / model sync
    CHANNEL_NOT_FOUND(5001, "channel not found", null, 404),
    UPSTREAM_ERROR(5002, "upstream provider error", "internal_error", 502);

    private final int code;
    private final String msg;
    private final String openaiType;
    private final int httpStatus;

    ErrorCode(int code, String msg, String openaiType, int httpStatus) {
        this.code = code;
        this.msg = msg;
        this.openaiType = openaiType;
        this.httpStatus = httpStatus;
    }
}
