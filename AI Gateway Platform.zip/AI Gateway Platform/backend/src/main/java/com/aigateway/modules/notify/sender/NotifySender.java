package com.aigateway.modules.notify.sender;

import com.aigateway.modules.notify.dto.NotifyMessage;

/**
 * Strategy for delivering a notification over a single channel (design doc §13).
 * Implementations should be side-effect-only (actual send) and must not persist the
 * {@code notify_log} row themselves &mdash; the dispatcher records the outcome.
 */
public interface NotifySender {

    /** The channel this sender handles: email / sms / inmail / webhook. */
    String channel();

    /**
     * Deliver the message. Throws on failure so the dispatcher records status=fail.
     */
    void send(NotifyMessage msg);
}
