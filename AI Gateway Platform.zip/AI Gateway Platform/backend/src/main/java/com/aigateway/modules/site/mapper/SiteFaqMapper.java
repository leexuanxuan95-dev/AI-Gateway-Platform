package com.aigateway.modules.site.mapper;

import com.aigateway.modules.site.entity.SiteFaq;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/** MyBatis-Plus mapper for {@link SiteFaq}. */
public interface SiteFaqMapper extends BaseMapper<SiteFaq> {
}
