package com.aigateway.common.enums;

import com.baomidou.mybatisplus.annotation.EnumValue;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;

/** channel_api_key.status (key pool). */
@Getter
public enum ChannelKeyStatus implements CodedEnum<Integer> {

    ACTIVE(1),
    BANNED(2),
    DISABLED(3);

    @EnumValue
    @JsonValue
    private final Integer code;

    ChannelKeyStatus(Integer code) {
        this.code = code;
    }

    @JsonCreator
    public static ChannelKeyStatus of(Integer code) {
        if (code == null) {
            return null;
        }
        for (ChannelKeyStatus v : values()) {
            if (v.code.equals(code)) {
                return v;
            }
        }
        return null;
    }
}
