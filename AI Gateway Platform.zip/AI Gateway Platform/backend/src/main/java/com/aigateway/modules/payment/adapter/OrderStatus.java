package com.aigateway.modules.payment.adapter;

/** Normalized order status reported by a payment adapter. */
public enum OrderStatus {
    PENDING,
    PAID,
    FAILED
}
