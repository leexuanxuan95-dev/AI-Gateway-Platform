package com.aigateway.modules.apikey.service.impl;

import cn.hutool.core.util.RandomUtil;
import com.aigateway.common.api.PageResult;
import com.aigateway.common.constant.RedisKeys;
import com.aigateway.common.enums.ApiKeyStatus;
import com.aigateway.common.exception.BizException;
import com.aigateway.common.exception.ErrorCode;
import com.aigateway.common.security.UserContext;
import com.aigateway.modules.apikey.dto.ApiKeyCreateRequest;
import com.aigateway.modules.apikey.dto.ApiKeyCreateResponse;
import com.aigateway.modules.apikey.dto.ApiKeyUpdateRequest;
import com.aigateway.modules.apikey.dto.ApiKeyView;
import com.aigateway.modules.apikey.entity.ApiKey;
import com.aigateway.modules.apikey.mapper.ApiKeyMapper;
import com.aigateway.modules.apikey.service.ApiKeyService;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import lombok.RequiredArgsConstructor;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;

/** Default {@link ApiKeyService}. All operations are scoped to the active company. */
@Service
@RequiredArgsConstructor
public class ApiKeyServiceImpl implements ApiKeyService {

    private static final int KEY_RANDOM_LEN = 48;
    private static final int PREFIX_LEN = 12;
    private static final int DEFAULT_RPM_LIMIT = 60;
    private static final int DEFAULT_TPM_LIMIT = 100000;
    private static final String KEY_ALPHABET =
            "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";

    private final ApiKeyMapper apiKeyMapper;
    private final RedisTemplate<String, Object> redisTemplate;

    @Override
    @Transactional
    public ApiKeyCreateResponse create(ApiKeyCreateRequest req) {
        Long companyId = UserContext.companyId();

        String rawKey = "sk-" + RandomUtil.randomString(KEY_ALPHABET, KEY_RANDOM_LEN);
        String hash = ApiKeyAuthServiceImpl.sha256(rawKey);

        ApiKey key = new ApiKey();
        key.setCompanyId(companyId);
        key.setProjectId(req.getProjectId());
        key.setKeyName(req.getKeyName());
        key.setKeyPrefix(rawKey.substring(0, Math.min(PREFIX_LEN, rawKey.length())));
        key.setKeyHash(hash);
        key.setAllowedModels(req.getAllowedModels());
        key.setRpmLimit(req.getRpmLimit() != null ? req.getRpmLimit() : DEFAULT_RPM_LIMIT);
        key.setTpmLimit(req.getTpmLimit() != null ? req.getTpmLimit() : DEFAULT_TPM_LIMIT);
        key.setDailyQuota(req.getDailyQuota() != null ? req.getDailyQuota() : BigDecimal.ZERO);
        key.setIpWhitelist(req.getIpWhitelist());
        key.setExpireAt(req.getExpireAt());
        key.setStatus(ApiKeyStatus.ACTIVE);
        key.setCreatedBy(UserContext.userId());

        apiKeyMapper.insert(key);
        return new ApiKeyCreateResponse(rawKey, ApiKeyView.from(key));
    }

    @Override
    public PageResult<ApiKeyView> page(long current, long size) {
        Long companyId = UserContext.companyId();
        LambdaQueryWrapper<ApiKey> qw = Wrappers.<ApiKey>lambdaQuery()
                .eq(ApiKey::getCompanyId, companyId)
                .ne(ApiKey::getStatus, ApiKeyStatus.DELETED)
                .orderByDesc(ApiKey::getId);
        IPage<ApiKey> p = apiKeyMapper.selectPage(new Page<>(current, size), qw);
        IPage<ApiKeyView> view = p.convert(ApiKeyView::from);
        return PageResult.of(view);
    }

    @Override
    @Transactional
    public ApiKeyView update(Long id, ApiKeyUpdateRequest req) {
        ApiKey key = requireOwned(id);
        if (req.getKeyName() != null) {
            key.setKeyName(req.getKeyName());
        }
        if (req.getAllowedModels() != null) {
            key.setAllowedModels(req.getAllowedModels());
        }
        if (req.getRpmLimit() != null) {
            key.setRpmLimit(req.getRpmLimit());
        }
        if (req.getTpmLimit() != null) {
            key.setTpmLimit(req.getTpmLimit());
        }
        if (req.getDailyQuota() != null) {
            key.setDailyQuota(req.getDailyQuota());
        }
        if (req.getIpWhitelist() != null) {
            key.setIpWhitelist(req.getIpWhitelist());
        }
        if (req.getExpireAt() != null) {
            key.setExpireAt(req.getExpireAt());
        }
        apiKeyMapper.updateById(key);
        evictCache(key.getKeyHash());
        return ApiKeyView.from(key);
    }

    @Override
    @Transactional
    public void disable(Long id) {
        setStatus(id, ApiKeyStatus.DISABLED);
    }

    @Override
    @Transactional
    public void enable(Long id) {
        setStatus(id, ApiKeyStatus.ACTIVE);
    }

    @Override
    @Transactional
    public void delete(Long id) {
        setStatus(id, ApiKeyStatus.DELETED);
    }

    private void setStatus(Long id, ApiKeyStatus status) {
        ApiKey key = requireOwned(id);
        key.setStatus(status);
        apiKeyMapper.updateById(key);
        evictCache(key.getKeyHash());
    }

    /** Load a key and verify it belongs to the active company. */
    private ApiKey requireOwned(Long id) {
        ApiKey key = apiKeyMapper.selectById(id);
        if (key == null || !UserContext.companyId().equals(key.getCompanyId())
                || ApiKeyStatus.DELETED == key.getStatus()) {
            throw new BizException(ErrorCode.NOT_FOUND);
        }
        return key;
    }

    private void evictCache(String hash) {
        if (hash != null) {
            redisTemplate.delete(RedisKeys.apiKeyAuth(hash));
        }
    }
}
