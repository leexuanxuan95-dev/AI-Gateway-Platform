package com.aigateway.modules.channel.controller;

import com.aigateway.common.api.R;
import com.aigateway.common.exception.BizException;
import com.aigateway.common.exception.ErrorCode;
import com.aigateway.common.security.UserContext;
import com.aigateway.modules.channel.dto.ChannelApiKeyRequest;
import com.aigateway.modules.channel.dto.ChannelApiKeyView;
import com.aigateway.modules.channel.dto.ChannelKeyStats;
import com.aigateway.modules.channel.service.ChannelApiKeyService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Platform/super-admin management of a channel's upstream API-key pool. All endpoints require the
 * super-admin role. Keys are encrypted on write and masked on read; plaintext is never returned.
 */
@RestController
@RequestMapping("/api/channel/{channelId}/keys")
@RequiredArgsConstructor
public class ChannelApiKeyController {

    private final ChannelApiKeyService channelApiKeyService;

    /** List the channel's pool keys (masked) plus aggregate status counts. */
    @GetMapping
    public R<Map<String, Object>> list(@PathVariable Long channelId) {
        requireSuperAdmin();
        List<ChannelApiKeyView> keys = channelApiKeyService.list(channelId);
        ChannelKeyStats stats = channelApiKeyService.stats(channelId);
        Map<String, Object> body = new HashMap<>();
        body.put("keys", keys);
        body.put("stats", stats);
        return R.ok(body);
    }

    /** Add a key to the channel pool. */
    @PostMapping
    public R<Void> add(@PathVariable Long channelId, @RequestBody @Valid ChannelApiKeyRequest req) {
        requireSuperAdmin();
        channelApiKeyService.add(channelId, req);
        return R.ok();
    }

    /** Ban a key. Optional body {@code {"reason": "..."}}. */
    @PostMapping("/{keyId}/ban")
    public R<Void> ban(@PathVariable Long channelId, @PathVariable Long keyId,
                       @RequestBody(required = false) Map<String, String> body) {
        requireSuperAdmin();
        String reason = body == null ? null : body.get("reason");
        channelApiKeyService.ban(keyId, reason);
        return R.ok();
    }

    /** Unban a key (restore to active, clear ban reason / failure count). */
    @PostMapping("/{keyId}/unban")
    public R<Void> unban(@PathVariable Long channelId, @PathVariable Long keyId) {
        requireSuperAdmin();
        channelApiKeyService.unban(keyId);
        return R.ok();
    }

    /** Disable a key without marking it banned. */
    @PostMapping("/{keyId}/disable")
    public R<Void> disable(@PathVariable Long channelId, @PathVariable Long keyId) {
        requireSuperAdmin();
        channelApiKeyService.disable(keyId);
        return R.ok();
    }

    /** Permanently delete a key from the pool. */
    @DeleteMapping("/{keyId}")
    public R<Void> delete(@PathVariable Long channelId, @PathVariable Long keyId) {
        requireSuperAdmin();
        channelApiKeyService.delete(keyId);
        return R.ok();
    }

    private void requireSuperAdmin() {
        if (!UserContext.require().isSuperAdmin()) {
            throw new BizException(ErrorCode.FORBIDDEN);
        }
    }
}
