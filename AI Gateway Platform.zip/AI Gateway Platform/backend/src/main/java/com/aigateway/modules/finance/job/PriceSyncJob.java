package com.aigateway.modules.finance.job;

import com.aigateway.common.constant.KafkaTopics;
import com.aigateway.modules.channel.entity.Channel;
import com.aigateway.modules.channel.mapper.ChannelMapper;
import com.aigateway.modules.model.entity.ModelVersion;
import com.aigateway.modules.model.mapper.ModelVersionMapper;
import com.aigateway.modules.model.provider.ModelProvider;
import com.aigateway.modules.model.provider.ProviderFactory;
import com.aigateway.modules.model.provider.UpstreamModel;
import com.aigateway.modules.notify.dto.NotifyMessage;
import com.aigateway.modules.system.service.SysConfigService;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.aigateway.common.schedule.ManagedJob;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Daily upstream cost-price sync (design doc §15.5 / §10.4). Pulls per-token cost prices from
 * channels whose provider exposes pricing (e.g. OpenRouter) via {@link ProviderFactory} and
 * updates {@code model_version.cost_input/cost_output}.
 *
 * <p>Upstream price-increase handling (§10.4): when a new cost is higher than the stored cost
 * for a model that already has a customer price, behaviour is controlled by {@code sys_config}
 * key {@code pricing.auto_adjust_on_upstream_increase}:</p>
 * <ul>
 *   <li><b>false (default)</b>: keep the customer price unchanged and emit a NOTIFY alert to
 *       super-admin to review (margin may have shrunk).</li>
 *   <li><b>true</b>: auto-raise the customer price by the same proportion as the cost rose, so
 *       the prior margin ratio is preserved, then NOTIFY that an auto-adjustment was applied.</li>
 * </ul>
 *
 * <p>Defensive: a failing channel/provider never aborts the run; cost is only written when the
 * provider actually returns a value.</p>
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class PriceSyncJob implements ManagedJob {

    private static final String JOB_KEY = "price-sync";
    private static final int CHANNEL_ENABLED = 1;
    private static final int SCALE = 8;
    /** Intermediate division scale for the cost-increase ratio before re-scaling. */
    private static final int DIVISION_SCALE = 12;
    private static final String AUTO_ADJUST_KEY = "pricing.auto_adjust_on_upstream_increase";

    private final ChannelMapper channelMapper;
    private final ModelVersionMapper versionMapper;
    private final ProviderFactory providerFactory;
    private final SysConfigService sysConfigService;
    private final KafkaTemplate<String, String> kafkaTemplate;
    private final ObjectMapper objectMapper;

    @Override
    public String jobKey() {
        return JOB_KEY;
    }

    @Override
    public String defaultCron() {
        return "0 30 2 * * ?";
    }

    @Override
    public String description() {
        return "Daily upstream cost-price sync into model_version";
    }

    @Override
    public void execute() {
        boolean autoAdjust = sysConfigService.getBool(AUTO_ADJUST_KEY, false);
        List<Channel> channels = channelMapper.selectList(
                Wrappers.<Channel>lambdaQuery().eq(Channel::getStatus, CHANNEL_ENABLED));
        int updated = 0;
        int increases = 0;
        for (Channel ch : channels) {
            try {
                ModelProvider provider = providerFactory.get(ch.getProviderName());
                if (provider == null) {
                    continue;
                }
                List<UpstreamModel> models = provider.listModels(ch);
                for (UpstreamModel um : models) {
                    if (um.getId() == null
                            || (um.getPriceInput() == null && um.getPriceOutput() == null)) {
                        continue; // provider does not expose pricing for this model
                    }
                    ModelVersion mv = versionMapper.selectOne(
                            Wrappers.<ModelVersion>lambdaQuery().eq(ModelVersion::getModelCode, um.getId()));
                    if (mv == null) {
                        continue; // unknown model; ModelSyncJob owns discovery
                    }
                    int r = applyCost(mv, um, autoAdjust);
                    if (r > 0) {
                        updated++;
                    }
                    if (r == 2) {
                        increases++;
                    }
                }
            } catch (Exception e) {
                log.warn("[price-sync] channel {} ({}) failed: {}",
                        ch.getId(), ch.getProviderName(), e.getMessage());
            }
        }
        log.info("[price-sync] done: {} models updated, {} upstream increases (autoAdjust={})",
                updated, increases, autoAdjust);
    }

    /**
     * Apply new upstream cost to a model version. Returns 0 (no change), 1 (cost updated, no
     * increase) or 2 (cost increased - customer price adjusted or alert emitted).
     */
    private int applyCost(ModelVersion mv, UpstreamModel um, boolean autoAdjust) {
        BigDecimal oldIn = mv.getCostInput();
        BigDecimal oldOut = mv.getCostOutput();
        BigDecimal newIn = um.getPriceInput();
        BigDecimal newOut = um.getPriceOutput();

        boolean changed = false;
        boolean increased = false;

        if (newIn != null && (oldIn == null || oldIn.compareTo(newIn) != 0)) {
            if (oldIn != null && newIn.compareTo(oldIn) > 0) {
                increased = true;
            }
            mv.setCostInput(newIn);
            changed = true;
        }
        if (newOut != null && (oldOut == null || oldOut.compareTo(newOut) != 0)) {
            if (oldOut != null && newOut.compareTo(oldOut) > 0) {
                increased = true;
            }
            mv.setCostOutput(newOut);
            changed = true;
        }
        if (!changed) {
            return 0;
        }

        if (increased) {
            if (autoAdjust) {
                autoRaiseCustomerPrice(mv, oldIn, newIn, oldOut, newOut);
            }
            versionMapper.updateById(mv);
            alert(mv, oldIn, newIn, oldOut, newOut, autoAdjust);
            return 2;
        }

        versionMapper.updateById(mv);
        return 1;
    }

    /**
     * Raise the customer price by the same proportion as cost rose, preserving the prior margin
     * ratio. Only adjusts a side that already has a customer price and whose old cost was known.
     */
    private void autoRaiseCustomerPrice(ModelVersion mv, BigDecimal oldIn, BigDecimal newIn,
                                        BigDecimal oldOut, BigDecimal newOut) {
        if (mv.getPriceInput() != null && oldIn != null && oldIn.signum() > 0
                && newIn != null && newIn.compareTo(oldIn) > 0) {
            BigDecimal factor = newIn.divide(oldIn, DIVISION_SCALE, RoundingMode.HALF_UP);
            mv.setPriceInput(mv.getPriceInput().multiply(factor).setScale(SCALE, RoundingMode.HALF_UP));
        }
        if (mv.getPriceOutput() != null && oldOut != null && oldOut.signum() > 0
                && newOut != null && newOut.compareTo(oldOut) > 0) {
            BigDecimal factor = newOut.divide(oldOut, DIVISION_SCALE, RoundingMode.HALF_UP);
            mv.setPriceOutput(mv.getPriceOutput().multiply(factor).setScale(SCALE, RoundingMode.HALF_UP));
        }
    }

    /** Emit a super-admin NOTIFY alert about an upstream price increase (best-effort). */
    private void alert(ModelVersion mv, BigDecimal oldIn, BigDecimal newIn,
                       BigDecimal oldOut, BigDecimal newOut, boolean autoAdjusted) {
        try {
            Map<String, Object> params = new HashMap<>();
            params.put("modelCode", mv.getModelCode());
            params.put("oldCostInput", str(oldIn));
            params.put("newCostInput", str(newIn));
            params.put("oldCostOutput", str(oldOut));
            params.put("newCostOutput", str(newOut));
            params.put("autoAdjusted", autoAdjusted);

            NotifyMessage msg = new NotifyMessage();
            msg.setChannel("inmail");
            msg.setScene("upstream_price_increase");
            msg.setTarget("super-admin");
            msg.setParams(params);
            msg.setContent("Upstream cost increased for " + mv.getModelCode()
                    + " (input " + str(oldIn) + "->" + str(newIn)
                    + ", output " + str(oldOut) + "->" + str(newOut) + "). "
                    + (autoAdjusted ? "Customer price was auto-raised to preserve margin."
                                    : "Customer price unchanged - please review margin."));
            kafkaTemplate.send(KafkaTopics.NOTIFY, objectMapper.writeValueAsString(msg));
        } catch (Exception e) {
            log.warn("[price-sync] alert for {} failed: {}", mv.getModelCode(), e.getMessage());
        }
    }

    private String str(BigDecimal v) {
        return v == null ? "n/a" : v.toPlainString();
    }
}
