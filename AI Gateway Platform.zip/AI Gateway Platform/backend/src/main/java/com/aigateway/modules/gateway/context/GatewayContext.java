package com.aigateway.modules.gateway.context;

import com.aigateway.modules.apikey.dto.ApiKeyAuthContext;
import lombok.Data;

/**
 * Per-request gateway state for the OpenAI-compatible {@code /v1/*} surface, established by
 * {@code ApiKeyGatewayFilter} and read by the gateway controllers/proxy. Bound to the request
 * thread and always cleared in the filter's finally block.
 */
public final class GatewayContext {

    private static final ThreadLocal<Holder> HOLDER = new ThreadLocal<>();

    private GatewayContext() {
    }

    public static void set(Holder h) {
        HOLDER.set(h);
    }

    public static Holder get() {
        return HOLDER.get();
    }

    /** Authenticated context; throws nothing &mdash; callers run only after the filter set it. */
    public static ApiKeyAuthContext auth() {
        Holder h = HOLDER.get();
        return h == null ? null : h.getAuth();
    }

    public static void clear() {
        HOLDER.remove();
    }

    /** Mutable request-scoped holder. */
    @Data
    public static class Holder {
        private ApiKeyAuthContext auth;
        private String requestId;
        private String clientIp;
        /** Resolved country code (GeoIP / CF header), for risk evaluation + logging. */
        private String country;
        private String userAgent;
        /** Effective RPM limit applied (after any risk throttle), for response headers. */
        private Integer rateLimitLimit;
        /** Remaining RPM tokens after the bucket check, for response headers. */
        private Integer rateLimitRemaining;
        /** Epoch seconds when the current rate-limit window resets, for X-RateLimit-Reset. */
        private Long rateLimitResetEpoch;
    }
}
