package com.aigateway.common.util;

import cn.hutool.core.util.RandomUtil;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/** Business id / order-no / request-id generators. */
public final class IdGen {

    private static final DateTimeFormatter TS = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");

    private IdGen() {
    }

    /** User business id: U + 11 alphanumerics. */
    public static String uid() {
        return "U" + RandomUtil.randomString(11);
    }

    /** Company code: C + 9 alphanumerics. */
    public static String companyCode() {
        return "C" + RandomUtil.randomString(9);
    }

    /** Recharge/withdraw order no: prefix + timestamp + 6 digits. */
    public static String orderNo(String prefix) {
        return prefix + LocalDateTime.now().format(TS) + RandomUtil.randomNumbers(6);
    }

    /** Request id for the gateway surface. */
    public static String requestId() {
        return "req_" + RandomUtil.randomString(24);
    }
}
