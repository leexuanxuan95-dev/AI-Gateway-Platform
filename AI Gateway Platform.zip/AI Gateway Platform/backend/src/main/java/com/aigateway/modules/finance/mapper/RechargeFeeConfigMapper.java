package com.aigateway.modules.finance.mapper;

import com.aigateway.modules.finance.entity.RechargeFeeConfig;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/** MyBatis-Plus mapper for {@link RechargeFeeConfig}. */
public interface RechargeFeeConfigMapper extends BaseMapper<RechargeFeeConfig> {
}
