package com.aigateway.modules.finance.service.impl;

import com.aigateway.modules.finance.service.ExchangeRateService;
import com.aigateway.modules.system.entity.SysConfig;
import com.aigateway.modules.system.service.SysConfigService;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Locale;

/**
 * Default {@link ExchangeRateService}. Reads adjusted FX rates from the Redis hash
 * {@code gw:fx:rates} (ccy-&gt;rate, base USD); on a cache miss it falls back to the
 * {@code sys_config} key {@code fx.rates} (a JSON object) that the hourly job also persists.
 * USD is always 1.0. Unknown currencies fall back to 1.0 with a warning so a missing rate
 * never crashes settlement.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class ExchangeRateServiceImpl implements ExchangeRateService {

    /** Redis hash key holding ccy -> adjusted-rate (units per 1 USD). */
    public static final String REDIS_KEY = "gw:fx:rates";
    /** sys_config key holding the same map as JSON (durable fallback). */
    public static final String CONFIG_KEY = "fx.rates";
    private static final String BASE = "USD";
    private static final int SCALE = 8;

    private final StringRedisTemplate stringRedisTemplate;
    private final SysConfigService sysConfigService;
    private final ObjectMapper objectMapper;

    @Override
    public BigDecimal toUsd(BigDecimal amount, String ccy) {
        if (amount == null) {
            return BigDecimal.ZERO;
        }
        String c = norm(ccy);
        if (BASE.equals(c)) {
            return amount;
        }
        BigDecimal rate = rateOf(c);
        if (rate == null || rate.signum() <= 0) {
            log.warn("[fx] no rate for {} -> falling back to 1.0 USD parity", c);
            return amount;
        }
        // amount is in CCY, rate is CCY per USD -> USD = amount / rate
        return amount.divide(rate, SCALE, RoundingMode.HALF_UP);
    }

    @Override
    public BigDecimal convert(BigDecimal amount, String from, String to) {
        if (amount == null) {
            return BigDecimal.ZERO;
        }
        String f = norm(from);
        String t = norm(to);
        if (f.equals(t)) {
            return amount;
        }
        BigDecimal usd = toUsd(amount, f);
        if (BASE.equals(t)) {
            return usd;
        }
        BigDecimal toRate = rateOf(t);
        if (toRate == null || toRate.signum() <= 0) {
            log.warn("[fx] no rate for {} -> falling back to 1.0 USD parity", t);
            return usd;
        }
        // USD -> CCY = usd * (CCY per USD)
        return usd.multiply(toRate).setScale(SCALE, RoundingMode.HALF_UP);
    }

    @Override
    public BigDecimal rateOf(String ccy) {
        String c = norm(ccy);
        if (BASE.equals(c)) {
            return BigDecimal.ONE;
        }
        // 1) Redis hash (hot path)
        try {
            Object v = stringRedisTemplate.opsForHash().get(REDIS_KEY, c);
            if (v != null) {
                return new BigDecimal(v.toString());
            }
        } catch (Exception e) {
            log.warn("[fx] redis read failed for {}: {}", c, e.getMessage());
        }
        // 2) sys_config JSON fallback
        try {
            SysConfig cfg = sysConfigService.get(CONFIG_KEY);
            if (cfg != null && cfg.getConfigValue() != null) {
                JsonNode node = objectMapper.valueToTree(cfg.getConfigValue());
                JsonNode r = node.path(c);
                if (r.isNumber() || (r.isTextual() && !r.asText().isBlank())) {
                    return new BigDecimal(r.asText());
                }
            }
        } catch (Exception e) {
            log.warn("[fx] sys_config read failed for {}: {}", c, e.getMessage());
        }
        return null;
    }

    private String norm(String ccy) {
        return ccy == null ? BASE : ccy.trim().toUpperCase(Locale.ROOT);
    }
}
