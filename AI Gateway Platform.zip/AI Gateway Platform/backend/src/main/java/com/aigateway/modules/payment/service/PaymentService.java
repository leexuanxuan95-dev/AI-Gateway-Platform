package com.aigateway.modules.payment.service;

import com.aigateway.modules.payment.adapter.PrepayResult;
import com.aigateway.modules.payment.dto.CreatePayRequest;

/** Recharge order creation (design doc §10.2). */
public interface PaymentService {

    /** Validate the channel, create a pending recharge order and call the adapter. */
    PrepayResult create(Long companyId, Long userId, CreatePayRequest req);
}
