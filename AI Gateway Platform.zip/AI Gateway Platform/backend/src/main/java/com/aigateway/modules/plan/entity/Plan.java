package com.aigateway.modules.plan.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.aigateway.common.enums.CommonStatus;
import com.baomidou.mybatisplus.extension.handlers.JacksonTypeHandler;
import lombok.Data;

import java.math.BigDecimal;
import java.util.List;

/** Subscription plan entity (table {@code plan}, design doc §9). */
@Data
@TableName(value = "plan", autoResultMap = true)
public class Plan {

    @TableId(type = IdType.AUTO)
    private Long id;

    private String name;

    private BigDecimal price;

    private String currency;

    /** Validity in days. */
    private Integer duration;

    private Long tokenLimit;

    private Integer rpmLimit;

    private Integer maxApiKeys;

    private Integer maxProjects;

    @TableField(typeHandler = JacksonTypeHandler.class)
    private List<String> allowedModels;

    private Integer sort;

    /** 1 active / 0 disabled. */
    private CommonStatus status;
}
