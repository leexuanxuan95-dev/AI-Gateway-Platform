package com.aigateway.modules.finance.mapper;

import com.aigateway.modules.finance.entity.FinTransaction;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/** MyBatis-Plus mapper for {@link FinTransaction}. */
public interface FinTransactionMapper extends BaseMapper<FinTransaction> {
}
