package com.aigateway.modules.billing.mapper;

import com.aigateway.modules.billing.entity.BillToken;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * Read-side mapper for {@link BillToken}. Writes are owned by the finance settle path;
 * this mapper is used only for paged queries, CSV export and aggregation.
 */
public interface BillTokenMapper extends BaseMapper<BillToken> {
}
