package com.aigateway.modules.model.dto;

import com.aigateway.common.enums.CommonStatus;
import lombok.Data;

/** Create/update payload for a model-channel route. */
@Data
public class ModelRouteRequest {

    private Long modelId;
    private Long channelId;
    private String upstreamModel;
    private Integer weight;
    private Integer priority;
    private CommonStatus status;
}
