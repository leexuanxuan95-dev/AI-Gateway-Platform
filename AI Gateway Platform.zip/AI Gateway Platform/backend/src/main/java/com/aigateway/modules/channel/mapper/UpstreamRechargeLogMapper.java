package com.aigateway.modules.channel.mapper;

import com.aigateway.modules.channel.entity.UpstreamRechargeLog;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/** MyBatis-Plus mapper for {@link UpstreamRechargeLog}. */
public interface UpstreamRechargeLogMapper extends BaseMapper<UpstreamRechargeLog> {
}
