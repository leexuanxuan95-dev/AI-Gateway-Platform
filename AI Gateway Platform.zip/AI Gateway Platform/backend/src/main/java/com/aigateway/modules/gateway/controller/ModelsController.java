package com.aigateway.modules.gateway.controller;

import com.aigateway.modules.apikey.dto.ApiKeyAuthContext;
import com.aigateway.modules.gateway.context.GatewayContext;
import com.aigateway.modules.model.entity.ModelFamily;
import com.aigateway.modules.model.entity.ModelVersion;
import com.aigateway.modules.model.mapper.ModelFamilyMapper;
import com.aigateway.modules.model.service.ModelRouteService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.Duration;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * OpenAI-compatible {@code GET /v1/models} (design doc §20). Returns the models available to the
 * authenticated key, filtered by its allow-list, in OpenAI list shape. The {@code family} field is
 * emitted as the family CODE string (resolved from {@link ModelVersion#getFamilyId()} via
 * {@link ModelFamilyMapper}), cached in Redis (and a process-local map) to avoid per-request lookups.
 */
@Slf4j
@RestController
@RequiredArgsConstructor
public class ModelsController {

    private static final String FAMILY_CACHE_PREFIX = "gw:model:family:";
    private static final Duration FAMILY_TTL = Duration.ofHours(6);

    private final ModelRouteService modelRouteService;
    private final ModelFamilyMapper modelFamilyMapper;
    private final StringRedisTemplate stringRedisTemplate;

    /** Process-local fallback cache (familyId -> familyCode) to spare Redis on hot paths. */
    private final Map<Long, String> localFamilyCache = new ConcurrentHashMap<>();

    @GetMapping("/v1/models")
    public Map<String, Object> listModels() {
        ApiKeyAuthContext ctx = GatewayContext.auth();
        List<String> allowed = ctx == null ? null : ctx.getAllowedModels();
        List<ModelVersion> models = modelRouteService.listAvailable(allowed);

        List<Map<String, Object>> data = new ArrayList<>(models.size());
        for (ModelVersion m : models) {
            Map<String, Object> item = new LinkedHashMap<>();
            item.put("id", m.getModelCode());
            item.put("object", "model");
            item.put("owned_by", "ai-gateway");
            item.put("display_name", m.getDisplayName());
            item.put("tagline", m.getTagline());
            item.put("family", familyCode(m.getFamilyId()));
            item.put("availability", m.getAvailability());
            item.put("context_window", m.getContextWindow());
            item.put("capabilities", m.getCapabilities());
            data.add(item);
        }
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("object", "list");
        body.put("data", data);
        return body;
    }

    /** Resolve a family id to its code string, cached; returns null if unresolved. */
    private String familyCode(Long familyId) {
        if (familyId == null) {
            return null;
        }
        String local = localFamilyCache.get(familyId);
        if (local != null) {
            return local;
        }
        String cacheKey = FAMILY_CACHE_PREFIX + familyId;
        try {
            String cached = stringRedisTemplate.opsForValue().get(cacheKey);
            if (cached != null && !cached.isBlank()) {
                localFamilyCache.put(familyId, cached);
                return cached;
            }
        } catch (Exception e) {
            log.debug("family cache read failed for {}: {}", familyId, e.getMessage());
        }
        String code = null;
        try {
            ModelFamily fam = modelFamilyMapper.selectById(familyId);
            code = fam == null ? null : fam.getFamilyCode();
        } catch (Exception e) {
            log.debug("family load failed for {}: {}", familyId, e.getMessage());
        }
        if (code != null) {
            localFamilyCache.put(familyId, code);
            try {
                stringRedisTemplate.opsForValue().set(cacheKey, code, FAMILY_TTL);
            } catch (Exception e) {
                log.debug("family cache write failed for {}: {}", familyId, e.getMessage());
            }
        }
        return code;
    }
}
