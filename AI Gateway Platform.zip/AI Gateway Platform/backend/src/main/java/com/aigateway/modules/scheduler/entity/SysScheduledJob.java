package com.aigateway.modules.scheduler.entity;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.time.OffsetDateTime;

/** Runtime-managed scheduled job (design doc §15.5). */
@Data
@TableName("sys_scheduled_job")
public class SysScheduledJob {

    @TableId(type = IdType.AUTO)
    private Long id;
    private String jobKey;
    private String jobName;
    /** Spring 6-field cron expression. */
    private String cron;
    private Boolean enabled;
    private String description;
    private OffsetDateTime lastRunAt;
    /** running / success / fail. */
    private String lastStatus;
    private Long lastDurationMs;
    private String lastError;
    private Long updatedBy;
    @TableField(fill = FieldFill.INSERT)
    private OffsetDateTime createdAt;
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private OffsetDateTime updatedAt;
}
