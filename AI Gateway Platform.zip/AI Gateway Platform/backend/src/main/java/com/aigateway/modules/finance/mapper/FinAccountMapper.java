package com.aigateway.modules.finance.mapper;

import com.aigateway.modules.finance.entity.FinAccount;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/** MyBatis-Plus mapper for {@link FinAccount}. */
public interface FinAccountMapper extends BaseMapper<FinAccount> {
}
