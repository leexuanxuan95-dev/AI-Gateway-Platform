package com.aigateway.modules.payment.job;

import com.aigateway.common.crypto.AesUtil;
import com.aigateway.common.enums.RechargeStatus;
import com.aigateway.modules.finance.entity.FinRechargeOrder;
import com.aigateway.modules.finance.mapper.FinRechargeOrderMapper;
import com.aigateway.modules.payment.entity.PayChannelConfig;
import com.aigateway.modules.payment.entity.PayReconcile;
import com.aigateway.modules.payment.mapper.PayChannelConfigMapper;
import com.aigateway.modules.payment.mapper.PayReconcileMapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.stripe.model.Charge;
import com.stripe.net.RequestOptions;
import com.stripe.param.ChargeListParams;
import com.aigateway.common.schedule.ManagedJob;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.List;

/**
 * Daily payment reconciliation (design doc §10.2). Computes the platform-side paid totals
 * per channel for the previous day from {@code fin_recharge_order} and writes a
 * {@link PayReconcile} row.
 *
 * <p>Channel-side figures: for {@code stripe} they are fetched from the Stripe API
 * ({@link Charge#list} over the day's {@code created} range, counting captured+paid charges); for
 * the other channels no public day-settlement API is wired here (see per-channel note below), so
 * the channel-side figures fall back to the platform figures and the diff is left at zero.</p>
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class ReconcileJob implements ManagedJob {

    private static final String JOB_KEY = "pay-reconcile";

    private final FinRechargeOrderMapper rechargeOrderMapper;
    private final PayChannelConfigMapper channelConfigMapper;
    private final PayReconcileMapper reconcileMapper;
    private final AesUtil aesUtil;

    @Override
    public String jobKey() {
        return JOB_KEY;
    }

    @Override
    public String defaultCron() {
        return "0 30 1 * * ?";
    }

    @Override
    public String description() {
        return "Daily payment reconciliation of platform vs channel paid totals";
    }

    @Override
    public void execute() {
        LocalDate day = LocalDate.now(ZoneOffset.UTC).minusDays(1);
        OffsetDateTime start = day.atStartOfDay().atOffset(ZoneOffset.UTC);
        OffsetDateTime end = start.plusDays(1);

        List<PayChannelConfig> channels = channelConfigMapper.selectList(null);
        for (PayChannelConfig c : channels) {
            try {
                List<FinRechargeOrder> paid = rechargeOrderMapper.selectList(
                        Wrappers.<FinRechargeOrder>lambdaQuery()
                                .eq(FinRechargeOrder::getPayChannel, c.getChannelCode())
                                .eq(FinRechargeOrder::getStatus, RechargeStatus.PAID)
                                .ge(FinRechargeOrder::getPaidAt, start)
                                .lt(FinRechargeOrder::getPaidAt, end));
                int platformCnt = paid.size();
                BigDecimal platformAmount = paid.stream()
                        .map(FinRechargeOrder::getAmount)
                        .filter(java.util.Objects::nonNull)
                        .reduce(BigDecimal.ZERO, BigDecimal::add);

                // Channel-side settlement for `day`.
                int channelCnt;
                BigDecimal channelAmount;
                ChannelSide side = fetchChannelSide(c, start, end);
                if (side != null) {
                    channelCnt = side.count();
                    channelAmount = side.amount();
                } else {
                    // No channel-side day-settlement API wired for this channel:
                    //   alipay/wechat: provider settlement is a downloaded bill file (no day API here);
                    //   usdt_trc20/usdt_erc20: on-chain truth, reconciled per-tx by the adapters;
                    //   wise: statement/transfer export, not a per-day count API.
                    // Fall back to platform figures so the row records a zero diff for these.
                    channelCnt = platformCnt;
                    channelAmount = platformAmount;
                }

                PayReconcile rec = new PayReconcile();
                rec.setChannelCode(c.getChannelCode());
                rec.setReconDate(day);
                rec.setPlatformCnt(platformCnt);
                rec.setPlatformAmount(platformAmount);
                rec.setChannelCnt(channelCnt);
                rec.setChannelAmount(channelAmount);
                rec.setDiffCnt(platformCnt - channelCnt);
                rec.setDiffAmount(platformAmount.subtract(channelAmount));
                rec.setStatus(rec.getDiffCnt() == 0 && rec.getDiffAmount().signum() == 0 ? 0 : 1);
                reconcileMapper.insert(rec);
            } catch (Exception e) {
                log.warn("reconcile channel {} failed: {}", c.getChannelCode(), e.getMessage());
            }
        }
    }

    private record ChannelSide(int count, BigDecimal amount) {
    }

    /**
     * Fetch the channel-side settled count/amount for the window. Returns {@code null} when the
     * channel has no day-settlement API wired (caller then falls back to the platform figures).
     */
    private ChannelSide fetchChannelSide(PayChannelConfig c, OffsetDateTime start, OffsetDateTime end) {
        if (!"stripe".equalsIgnoreCase(c.getChannelCode())) {
            return null;
        }
        String apiKey = cred(c, "apiKey");
        if (apiKey == null) {
            return null;
        }
        try {
            RequestOptions opts = RequestOptions.builder().setApiKey(apiKey).build();
            long gte = start.toEpochSecond();
            long lt = end.toEpochSecond();
            ChargeListParams params = ChargeListParams.builder()
                    .setCreated(ChargeListParams.Created.builder()
                            .setGte(gte).setLt(lt).build())
                    .setLimit(100L)
                    .build();

            int count = 0;
            BigDecimal amount = BigDecimal.ZERO;
            // Auto-paginate over the day's charges; count only captured + paid (settled) charges.
            for (Charge ch : Charge.list(params, opts).autoPagingIterable()) {
                boolean paid = Boolean.TRUE.equals(ch.getPaid());
                boolean captured = Boolean.TRUE.equals(ch.getCaptured());
                if (!paid || !captured || Boolean.TRUE.equals(ch.getRefunded())) {
                    continue;
                }
                count++;
                if (ch.getAmount() != null) {
                    long net = ch.getAmount() - (ch.getAmountRefunded() != null ? ch.getAmountRefunded() : 0L);
                    amount = amount.add(BigDecimal.valueOf(net)
                            .divide(BigDecimal.valueOf(100), 2, RoundingMode.HALF_UP));
                }
            }
            return new ChannelSide(count, amount);
        } catch (Exception e) {
            log.warn("reconcile stripe channel-side fetch failed: {}", e.getMessage());
            return null;
        }
    }

    /** Decrypt a named credential value from the channel config (never logged). */
    private String cred(PayChannelConfig c, String key) {
        if (c.getCredentials() == null) {
            return null;
        }
        Object v = c.getCredentials().get(key);
        return v == null ? null : aesUtil.decrypt(v.toString());
    }
}
