package com.aigateway.modules.billing.entity;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.time.OffsetDateTime;

/**
 * Per-request access log (table {@code call_log}, design doc §11). RANGE-partitioned by
 * {@code created_at} with composite PK {@code (id, created_at)}. Written asynchronously by the
 * billing {@code CallLogConsumer}; never stores raw keys or prompt bodies.
 */
@Data
@TableName(value = "call_log", autoResultMap = true)
public class CallLog {

    @TableId(type = IdType.AUTO)
    private Long id;

    private String requestId;

    private Long apiKeyId;

    private Long companyId;

    private String modelCode;

    private Long channelId;

    private String ip;

    private String userAgent;

    private Integer httpStatus;

    /** Business outcome marker, e.g. {@code ok} / {@code error} / {@code rate_limited}. */
    private String bizStatus;

    /** Wall-clock response time in milliseconds. */
    private Integer responseTime;

    private Boolean isStream;

    @TableField(fill = FieldFill.INSERT)
    private OffsetDateTime createdAt;
}
