package com.aigateway.modules.site.dto;

import lombok.Data;

import java.util.Map;

/** Upsert request for a single landing section (keyed by path + lang). */
@Data
public class SiteSectionReq {

    private Boolean enabled;

    private Integer sort;

    private String title;

    private String subtitle;

    private Map<String, Object> payload;

    /** Optional auto-sync binding: {@code plan} or {@code model_version}. */
    private String bindSource;
}
