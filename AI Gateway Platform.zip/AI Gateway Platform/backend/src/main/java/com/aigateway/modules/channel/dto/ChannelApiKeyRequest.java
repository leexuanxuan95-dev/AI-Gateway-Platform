package com.aigateway.modules.channel.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

/** Request to add a key to a channel's pool. The raw key is encrypted before storage. */
@Data
public class ChannelApiKeyRequest {

    /** Human-friendly label (optional). */
    private String keyAlias;

    /** Raw upstream api key (plaintext). Encrypted at rest; never logged or returned. */
    @NotBlank
    private String apiKey;

    /** Weighted-random selection weight; defaults to 1 when null/non-positive. */
    private Integer weight;
}
