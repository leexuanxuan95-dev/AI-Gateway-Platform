package com.aigateway.modules.model.service.impl;

import com.aigateway.common.enums.CommonStatus;
import com.aigateway.common.enums.ModelAvailability;
import com.aigateway.common.enums.ModelStatus;
import com.aigateway.common.exception.BizException;
import com.aigateway.common.exception.ErrorCode;
import com.aigateway.modules.model.entity.ModelChannelRoute;
import com.aigateway.modules.model.entity.ModelVersion;
import com.aigateway.modules.model.mapper.ModelChannelRouteMapper;
import com.aigateway.modules.model.mapper.ModelVersionMapper;
import com.aigateway.modules.model.service.ModelRouteService;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/** Default {@link ModelRouteService}. Caches model versions briefly in Redis by code. */
@Slf4j
@Service
@RequiredArgsConstructor
public class ModelRouteServiceImpl implements ModelRouteService {

    private static final Duration CACHE_TTL = Duration.ofSeconds(60);
    private static final String CACHE_PREFIX = "gw:model:ver:";

    private final ModelVersionMapper modelVersionMapper;
    private final ModelChannelRouteMapper routeMapper;
    private final RedisTemplate<String, Object> redisTemplate;

    @Override
    public ModelVersion getByCode(String modelCode) {
        if (modelCode == null || modelCode.isBlank()) {
            return null;
        }
        String cacheKey = CACHE_PREFIX + modelCode;
        try {
            Object cached = redisTemplate.opsForValue().get(cacheKey);
            if (cached instanceof ModelVersion mv) {
                return mv;
            }
        } catch (Exception e) {
            log.debug("model cache read failed for {}: {}", modelCode, e.getMessage());
        }
        ModelVersion mv = modelVersionMapper.selectOne(
                Wrappers.<ModelVersion>lambdaQuery().eq(ModelVersion::getModelCode, modelCode));
        if (mv != null) {
            try {
                redisTemplate.opsForValue().set(cacheKey, mv, CACHE_TTL);
            } catch (Exception e) {
                log.debug("model cache write failed for {}: {}", modelCode, e.getMessage());
            }
        }
        return mv;
    }

    @Override
    public void assertCallable(String modelCode) {
        ModelVersion mv = getByCode(modelCode);
        if (mv == null) {
            throw new BizException(ErrorCode.MODEL_NOT_FOUND);
        }
        ModelStatus status = mv.getStatus();
        ModelAvailability avail = mv.getAvailability();
        if (ModelAvailability.UNAVAILABLE == avail || ModelStatus.DISABLED == status) {
            throw new BizException(ErrorCode.MODEL_NOT_FOUND);
        }
        if (ModelAvailability.MAINTENANCE == avail || ModelStatus.MAINTENANCE == status) {
            throw new BizException(ErrorCode.MODEL_IN_MAINTENANCE);
        }
        if (mv.getCostInput() == null || mv.getCostOutput() == null) {
            throw new BizException(ErrorCode.PRICE_NOT_SET);
        }
    }

    @Override
    public List<ModelChannelRoute> routesFor(String modelCode) {
        ModelVersion mv = getByCode(modelCode);
        if (mv == null) {
            return Collections.emptyList();
        }
        List<ModelChannelRoute> routes = routeMapper.selectList(
                Wrappers.<ModelChannelRoute>lambdaQuery()
                        .eq(ModelChannelRoute::getModelId, mv.getId())
                        .eq(ModelChannelRoute::getStatus, CommonStatus.ENABLED));
        routes.sort(Comparator
                .comparingInt((ModelChannelRoute r) -> r.getPriority() == null ? 0 : r.getPriority())
                .thenComparing(r -> r.getWeight() == null ? 0 : r.getWeight(), Comparator.reverseOrder()));
        return routes;
    }

    @Override
    public List<ModelVersion> listAvailable(List<String> allowedModelCodes) {
        var qw = Wrappers.<ModelVersion>lambdaQuery()
                .ne(ModelVersion::getAvailability, ModelAvailability.UNAVAILABLE)
                .orderByAsc(ModelVersion::getSort);
        if (allowedModelCodes != null && !allowedModelCodes.isEmpty()) {
            qw.in(ModelVersion::getModelCode, allowedModelCodes);
        }
        return modelVersionMapper.selectList(qw);
    }
}
