package com.aigateway.common.security;

import com.aigateway.common.exception.BizException;
import com.aigateway.common.exception.ErrorCode;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.reflect.MethodSignature;
import org.aspectj.lang.JoinPoint;
import org.springframework.core.annotation.AnnotatedElementUtils;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.Set;

/** Enforces {@link RequirePerm} against the current {@link LoginUser}'s permission set. */
@Aspect
@Component
public class PermissionAspect {

    @Before("@annotation(com.aigateway.common.security.RequirePerm) " +
            "|| @within(com.aigateway.common.security.RequirePerm)")
    public void check(JoinPoint jp) {
        MethodSignature sig = (MethodSignature) jp.getSignature();
        RequirePerm perm = AnnotatedElementUtils.findMergedAnnotation(sig.getMethod(), RequirePerm.class);
        if (perm == null) {
            perm = AnnotatedElementUtils.findMergedAnnotation(sig.getDeclaringType(), RequirePerm.class);
        }
        if (perm == null) {
            return;
        }
        LoginUser user = UserContext.require();
        if (user.isSuperAdmin()) {
            return;
        }
        Set<String> held = user.getPermissions();
        if (held == null || held.isEmpty()) {
            throw new BizException(ErrorCode.PERMISSION_DENIED);
        }
        boolean pass = perm.requireAll()
                ? Arrays.stream(perm.value()).allMatch(held::contains)
                : Arrays.stream(perm.value()).anyMatch(held::contains);
        if (!pass) {
            throw new BizException(ErrorCode.PERMISSION_DENIED);
        }
    }
}
