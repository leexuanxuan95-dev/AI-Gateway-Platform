package com.aigateway.modules.user.dto;

import com.aigateway.common.enums.UserStatus;
import com.aigateway.modules.user.entity.SysUser;
import lombok.Data;

import java.util.List;

/** Public profile projection (never exposes password / totp secret). */
@Data
public class UserInfo {

    private Long id;
    private String uid;
    private String email;
    private String mobile;
    private String nickname;
    private String avatar;
    private Boolean totpEnabled;
    private Boolean superAdmin;
    private UserStatus status;

    /** Active company context echoed back at login (may be null). */
    private Long companyId;
    private String companyRole;

    /** Companies this user belongs to. */
    private List<CompanyBrief> companies;

    public static UserInfo from(SysUser u) {
        UserInfo i = new UserInfo();
        i.id = u.getId();
        i.uid = u.getUid();
        i.email = u.getEmail();
        i.mobile = u.getMobile();
        i.nickname = u.getNickname();
        i.avatar = u.getAvatar();
        i.totpEnabled = u.getTotpEnabled();
        i.superAdmin = u.getSuperAdmin();
        i.status = u.getStatus();
        return i;
    }
}
