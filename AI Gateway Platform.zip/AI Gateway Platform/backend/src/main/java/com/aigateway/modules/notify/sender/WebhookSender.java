package com.aigateway.modules.notify.sender;

import com.aigateway.common.exception.BizException;
import com.aigateway.common.web.SafeUrlValidator;
import com.aigateway.modules.notify.dto.NotifyMessage;
import com.aigateway.modules.system.service.SysConfigService;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.time.Duration;

/**
 * Real webhook sender (design doc §13/§18): POSTs the JSON payload to the target URL with
 * an HMAC-SHA256 signature header so the receiver can verify authenticity, with a small
 * bounded retry. The signing secret comes from {@code sys_config} ({@code notify.webhook.secret}),
 * falling back to an env/property default. The signature is never logged.
 */
@Slf4j
@Component
public class WebhookSender implements NotifySender {

    private static final String SIG_HEADER = "X-Signature";
    private static final int MAX_RETRY = 3;
    /** Outbound HTTP call timeout, in seconds. */
    private static final int SEND_TIMEOUT_SECONDS = 10;

    private final WebClient webClient;
    private final ObjectMapper objectMapper;
    private final SysConfigService sysConfigService;
    private final String fallbackSecret;

    public WebhookSender(WebClient.Builder webClientBuilder,
                         ObjectMapper objectMapper,
                         SysConfigService sysConfigService,
                         @Value("${aigateway.notify.webhook-secret:change_me_webhook_secret}") String fallbackSecret) {
        this.webClient = webClientBuilder.build();
        this.objectMapper = objectMapper;
        this.sysConfigService = sysConfigService;
        this.fallbackSecret = fallbackSecret;
    }

    @Override
    public String channel() {
        return "webhook";
    }

    @Override
    public void send(NotifyMessage msg) {
        String url = msg.getTarget();
        if (url == null || url.isBlank()) {
            throw new IllegalArgumentException("webhook target url is blank");
        }
        // SSRF guard: the webhook target is tenant-controlled, so reject internal /
        // metadata / private addresses before we ever make the outbound request.
        try {
            SafeUrlValidator.assertSafe(url);
        } catch (BizException e) {
            log.warn("[notify:webhook] refusing unsafe target {}: {}", url, e.getMessage());
            return;
        }
        String body;
        try {
            body = objectMapper.writeValueAsString(msg);
        } catch (Exception e) {
            throw new IllegalStateException("serialize webhook payload failed", e);
        }
        String signature = hmacSha256(body, resolveSecret());

        RuntimeException last = null;
        for (int attempt = 1; attempt <= MAX_RETRY; attempt++) {
            try {
                webClient.post()
                        .uri(url)
                        .contentType(MediaType.APPLICATION_JSON)
                        .header(SIG_HEADER, signature)
                        .bodyValue(body)
                        .retrieve()
                        .toBodilessEntity()
                        .block(Duration.ofSeconds(SEND_TIMEOUT_SECONDS));
                return;
            } catch (RuntimeException e) {
                last = e;
                log.warn("[notify:webhook] attempt {}/{} to {} failed: {}",
                        attempt, MAX_RETRY, url, e.getMessage());
            }
        }
        throw last != null ? last : new IllegalStateException("webhook send failed");
    }

    private String resolveSecret() {
        return sysConfigService.getString("notify.webhook.secret", fallbackSecret);
    }

    private String hmacSha256(String payload, String secret) {
        try {
            Mac mac = Mac.getInstance("HmacSHA256");
            mac.init(new SecretKeySpec(secret.getBytes(StandardCharsets.UTF_8), "HmacSHA256"));
            byte[] raw = mac.doFinal(payload.getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder(raw.length * 2);
            for (byte b : raw) {
                sb.append(Character.forDigit((b >> 4) & 0xF, 16));
                sb.append(Character.forDigit(b & 0xF, 16));
            }
            return "sha256=" + sb;
        } catch (Exception e) {
            throw new IllegalStateException("hmac signing failed", e);
        }
    }
}
