package com.aigateway.modules.finance.mapper;

import com.aigateway.modules.finance.entity.PricingMarkup;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/** MyBatis-Plus mapper for {@link PricingMarkup}. */
public interface PricingMarkupMapper extends BaseMapper<PricingMarkup> {
}
