package com.aigateway.modules.user.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

/** TOTP enrollment material returned by {@code /totp/setup}. */
@Data
@AllArgsConstructor
public class TotpSetupResponse {

    /** Base32 shared secret to display / let the user enter manually. */
    private String secret;

    /** {@code otpauth://} provisioning URI for QR rendering by the client. */
    private String otpauthUrl;
}
