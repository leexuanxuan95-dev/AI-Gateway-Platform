package com.aigateway.modules.notify.controller;

import com.aigateway.common.api.PageResult;
import com.aigateway.common.api.R;
import com.aigateway.common.exception.BizException;
import com.aigateway.common.exception.ErrorCode;
import com.aigateway.common.security.LoginUser;
import com.aigateway.common.security.UserContext;
import com.aigateway.modules.notify.dto.NotifyMessage;
import com.aigateway.modules.notify.entity.NotifyLog;
import com.aigateway.modules.notify.entity.NotifyTemplate;
import com.aigateway.modules.notify.service.NotifyService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * Notification console (design doc §13). JWT-authed: members see their company's logs;
 * super-admin sees all and manages templates. A test-send endpoint dispatches synchronously.
 */
@RestController
@RequestMapping("/api/notify")
@RequiredArgsConstructor
public class NotifyController {

    private final NotifyService notifyService;

    /** Page notify logs; members are scoped to their company, super-admin sees all. */
    @GetMapping("/logs")
    public R<PageResult<NotifyLog>> logs(@RequestParam(defaultValue = "1") long current,
                                         @RequestParam(defaultValue = "20") long size) {
        LoginUser user = UserContext.require();
        Long scope = user.isSuperAdmin() ? null : UserContext.companyId();
        return R.ok(notifyService.pageLogs(scope, current, size));
    }

    /** List all notify templates (super-admin only). */
    @GetMapping("/templates")
    public R<List<NotifyTemplate>> templates() {
        requireSuperAdmin();
        return R.ok(notifyService.listTemplates());
    }

    /** Create or update a notify template (super-admin only). */
    @PostMapping("/templates")
    public R<NotifyTemplate> saveTemplate(@RequestBody NotifyTemplate template) {
        requireSuperAdmin();
        return R.ok(notifyService.saveTemplate(template));
    }

    /** Delete a notify template by id (super-admin only). */
    @DeleteMapping("/templates/{id}")
    public R<Void> deleteTemplate(@PathVariable Long id) {
        requireSuperAdmin();
        notifyService.deleteTemplate(id);
        return R.ok();
    }

    /** Synchronously dispatch a test notification (super-admin only). */
    @PostMapping("/test-send")
    public R<Void> testSend(@RequestBody @Valid NotifyMessage msg) {
        requireSuperAdmin();
        notifyService.dispatch(msg);
        return R.ok();
    }

    private void requireSuperAdmin() {
        if (!UserContext.require().isSuperAdmin()) {
            throw new BizException(ErrorCode.FORBIDDEN);
        }
    }
}
