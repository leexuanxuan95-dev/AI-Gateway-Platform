package com.aigateway.modules.notify.sender;

import com.aigateway.modules.notify.dto.NotifyMessage;
import com.aigateway.modules.system.service.SysConfigService;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;

import java.time.Duration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Real email sender (design doc §13): delivers via a config-driven email HTTP API
 * (SendGrid-style REST) using {@link WebClient}; no SMTP library is required. Provider
 * config comes from {@code sys_config} (group {@code notify}):
 * <ul>
 *   <li>{@code notify.email.endpoint} - full POST URL (e.g. https://api.sendgrid.com/v3/mail/send)</li>
 *   <li>{@code notify.email.apiKey}   - bearer token</li>
 *   <li>{@code notify.email.from}     - sender address</li>
 * </ul>
 * If unconfigured a clear warning is logged and the message is marked pending (no throw),
 * via {@link NotifyPendingException}. On HTTP failure it throws so the dispatcher records
 * status=fail and retries. The api key is never logged.
 */
@Slf4j
@Component
public class EmailSender implements NotifySender {

    /** Outbound HTTP call timeout, in seconds. */
    private static final int SEND_TIMEOUT_SECONDS = 15;
    /** HashMap initial capacity (P3C: size/0.75+1) for a 1-entry fixed-size map. */
    private static final int MAP_CAP_1 = 2;
    /** HashMap initial capacity (P3C: size/0.75+1) for a 2-entry fixed-size map. */
    private static final int MAP_CAP_2 = 4;
    /** HashMap initial capacity (P3C: size/0.75+1) for a 4-entry fixed-size map. */
    private static final int MAP_CAP_4 = 6;

    private final WebClient webClient;
    private final ObjectMapper objectMapper;
    private final SysConfigService sysConfigService;

    public EmailSender(WebClient.Builder webClientBuilder,
                       ObjectMapper objectMapper,
                       SysConfigService sysConfigService) {
        this.webClient = webClientBuilder.build();
        this.objectMapper = objectMapper;
        this.sysConfigService = sysConfigService;
    }

    @Override
    public String channel() {
        return "email";
    }

    @Override
    public void send(NotifyMessage msg) {
        String endpoint = sysConfigService.getString("notify.email.endpoint", null);
        String apiKey = sysConfigService.getString("notify.email.apiKey", null);
        String from = sysConfigService.getString("notify.email.from", null);
        if (isBlank(endpoint) || isBlank(apiKey) || isBlank(from)) {
            log.warn("[notify:email] not configured (notify.email.endpoint/apiKey/from); "
                    + "marking pending for target={} scene={}", msg.getTarget(), msg.getScene());
            throw new NotifyPendingException("email provider not configured");
        }
        String to = msg.getTarget();
        if (isBlank(to)) {
            throw new IllegalArgumentException("email target is blank");
        }

        Map<String, Object> body = buildSendGridPayload(from, to,
                msg.getTitle() != null ? msg.getTitle() : ("notify:" + msg.getScene()),
                msg.getContent() != null ? msg.getContent() : "");
        String json;
        try {
            json = objectMapper.writeValueAsString(body);
        } catch (Exception e) {
            throw new IllegalStateException("serialize email payload failed", e);
        }

        webClient.post()
                .uri(endpoint)
                .header("Authorization", "Bearer " + apiKey)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .retrieve()
                .toBodilessEntity()
                .block(Duration.ofSeconds(SEND_TIMEOUT_SECONDS));
        log.info("[notify:email] sent -> {} scene={}", to, msg.getScene());
    }

    /** SendGrid v3 mail/send shape; works against any compatible relay. */
    private Map<String, Object> buildSendGridPayload(String from, String to, String subject, String content) {
        Map<String, Object> toEntry = new HashMap<>(MAP_CAP_1);
        toEntry.put("email", to);
        Map<String, Object> personalization = new HashMap<>(MAP_CAP_2);
        personalization.put("to", List.of(toEntry));
        personalization.put("subject", subject);

        Map<String, Object> fromEntry = new HashMap<>(MAP_CAP_1);
        fromEntry.put("email", from);

        Map<String, Object> contentEntry = new HashMap<>(MAP_CAP_2);
        contentEntry.put("type", "text/plain");
        contentEntry.put("value", content);

        Map<String, Object> payload = new HashMap<>(MAP_CAP_4);
        payload.put("personalizations", List.of(personalization));
        payload.put("from", fromEntry);
        payload.put("subject", subject);
        payload.put("content", List.of(contentEntry));
        return payload;
    }

    private boolean isBlank(String s) {
        return s == null || s.isBlank();
    }
}
