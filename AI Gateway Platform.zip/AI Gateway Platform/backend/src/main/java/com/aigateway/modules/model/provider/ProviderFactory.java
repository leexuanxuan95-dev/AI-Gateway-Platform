package com.aigateway.modules.model.provider;

import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

/** Resolves a {@link ModelProvider} by provider name (case-insensitive). */
@Component
public class ProviderFactory {

    private final Map<String, ModelProvider> byName;

    public ProviderFactory(List<ModelProvider> providers) {
        this.byName = providers.stream().collect(Collectors.toMap(
                p -> p.name().toLowerCase(Locale.ROOT), Function.identity(), (a, b) -> a));
    }

    /** Provider for the given name, or null if unsupported. */
    public ModelProvider get(String providerName) {
        if (providerName == null) {
            return null;
        }
        return byName.get(providerName.toLowerCase(Locale.ROOT));
    }
}
