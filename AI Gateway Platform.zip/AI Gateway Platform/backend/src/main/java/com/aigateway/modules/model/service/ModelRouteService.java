package com.aigateway.modules.model.service;

import com.aigateway.modules.model.entity.ModelChannelRoute;
import com.aigateway.modules.model.entity.ModelVersion;

import java.util.List;

/**
 * Read-side model catalog/routing contract consumed by the gateway and finance modules.
 * Method signatures here are part of the cross-module contract and must not change.
 */
public interface ModelRouteService {

    /** Model version by public code, or null if none. May be Redis-cached. */
    ModelVersion getByCode(String modelCode);

    /**
     * Assert a model is callable, otherwise throw:
     * <ul>
     *   <li>{@code MODEL_NOT_FOUND} if missing, availability=="unavailable", or status==3;</li>
     *   <li>{@code MODEL_IN_MAINTENANCE} if availability=="maintenance" or status==2;</li>
     *   <li>{@code PRICE_NOT_SET} if cost_input or cost_output is not configured.</li>
     * </ul>
     */
    void assertCallable(String modelCode);

    /** Enabled routes for a model, ordered by priority asc then weight desc. */
    List<ModelChannelRoute> routesFor(String modelCode);

    /**
     * List available (availability != "unavailable") model versions, optionally filtered
     * by an allow-list of model codes. Null/empty allow-list means all.
     */
    List<ModelVersion> listAvailable(List<String> allowedModelCodes);
}
