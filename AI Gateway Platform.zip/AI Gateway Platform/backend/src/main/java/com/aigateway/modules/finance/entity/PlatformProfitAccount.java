package com.aigateway.modules.finance.entity;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.math.BigDecimal;
import java.time.OffsetDateTime;

/**
 * Singleton platform profit account (table {@code platform_profit_account}, id always 1).
 * Seeded by init.sql. Aggregates lifetime revenue/cost/profit.
 */
@Data
@TableName(value = "platform_profit_account", autoResultMap = true)
public class PlatformProfitAccount {

    /** Always 1 (singleton row). */
    @TableId(type = IdType.INPUT)
    private Integer id;

    private BigDecimal totalRevenue;

    private BigDecimal totalCost;

    private BigDecimal totalProfit;

    @TableField(fill = FieldFill.INSERT_UPDATE)
    private OffsetDateTime updatedAt;
}
