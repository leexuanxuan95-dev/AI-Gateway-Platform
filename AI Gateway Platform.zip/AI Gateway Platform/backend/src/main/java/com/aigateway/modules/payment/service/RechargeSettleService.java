package com.aigateway.modules.payment.service;

import com.aigateway.modules.finance.entity.FinRechargeOrder;
import com.aigateway.modules.payment.adapter.CallbackResult;

/** Transactional crediting of a verified, paid recharge order (split out so @Transactional proxies). */
public interface RechargeSettleService {

    /**
     * Mark the order paid, credit the company account, apply the recharge fee and store
     * the raw callback. Idempotent at the DB level: only credits when the order is still
     * pending. Runs in a single transaction.
     *
     * @return true if the order was credited by this call, false if it was already paid
     */
    boolean creditPaidOrder(FinRechargeOrder order, CallbackResult cb, String rawBody);
}
