package com.aigateway.modules.payment.integration;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;

import java.nio.charset.StandardCharsets;
import java.security.KeyFactory;
import java.security.PublicKey;
import java.security.Signature;
import java.security.spec.X509EncodedKeySpec;
import java.time.Duration;
import java.util.Base64;
import java.util.Map;

/**
 * Reusable Wise (TransferWise) Platform API client (design doc route A/B). Used by both the
 * inbound recharge {@code WiseAdapter} and the finance withdraw payout flow, so the public method
 * signatures here are stable and MUST NOT change.
 *
 * <p>Base host follows the {@code WISE_ENV} setting: {@code production} =
 * {@code https://api.wise.com}, otherwise sandbox {@code https://api.sandbox.transferwise.tech}.
 * All requests use {@code Authorization: Bearer <WISE_API_TOKEN>}. Webhook payloads are verified
 * with {@code X-Signature-SHA256} (RSA SHA256 over the raw payload) using the Wise public key.
 * The token and keys are read from config and are never logged.</p>
 */
@Slf4j
@Component
public class WiseClient {

    private static final String PROD_BASE = "https://api.wise.com";
    private static final String SANDBOX_BASE = "https://api.sandbox.transferwise.tech";
    private static final Duration TIMEOUT = Duration.ofSeconds(20);

    private final WebClient webClient;
    private final ObjectMapper objectMapper = new ObjectMapper();

    @Value("${aigateway.pay.wise.env:sandbox}")
    private String env;

    @Value("${aigateway.pay.wise.api-token:${WISE_API_TOKEN:}}")
    private String apiToken;

    /** Wise webhook public key (PEM or base64 DER, X.509) used to verify X-Signature-SHA256. */
    @Value("${aigateway.pay.wise.public-key:}")
    private String webhookPublicKey;

    public WiseClient(WebClient.Builder webClientBuilder) {
        this.webClient = webClientBuilder.build();
    }

    private String base() {
        return "production".equalsIgnoreCase(env) ? PROD_BASE : SANDBOX_BASE;
    }

    /** Create a quote (source->target conversion) for the given profile. */
    public Map createQuote(String profileId, String sourceCcy, String targetCcy, java.math.BigDecimal amount) {
        ObjectNode body = objectMapper.createObjectNode();
        body.put("sourceCurrency", sourceCcy);
        body.put("targetCurrency", targetCcy);
        body.put("targetAmount", amount);
        return post("/v3/profiles/" + profileId + "/quotes", body);
    }

    /** Create a recipient account under the given profile. {@code accountInfo} is the Wise body. */
    public Map createRecipient(String profileId, Map accountInfo) {
        JsonNode body = objectMapper.valueToTree(accountInfo);
        return post("/v1/accounts", body);
    }

    /** Create a transfer for a previously created quote + recipient. */
    public Map createTransfer(String profileId, String quoteId, String recipientId, String reference) {
        ObjectNode body = objectMapper.createObjectNode();
        body.put("targetAccount", recipientId);
        body.put("quoteUuid", quoteId);
        body.put("customerTransactionId", java.util.UUID.randomUUID().toString());
        ObjectNode details = body.putObject("details");
        details.put("reference", reference != null ? reference : "");
        return post("/v1/transfers", body);
    }

    /** Fund a transfer from the profile's balance. */
    public Map fundTransfer(String profileId, String transferId) {
        ObjectNode body = objectMapper.createObjectNode();
        body.put("type", "BALANCE");
        return post("/v3/profiles/" + profileId + "/transfers/" + transferId + "/payments", body);
    }

    /** Retrieve a transfer's current state. */
    public Map getTransfer(String transferId) {
        return get("/v1/transfers/" + transferId);
    }

    /**
     * Verify a Wise webhook signature. {@code signatureHeader} is the base64 value of the
     * {@code X-Signature-SHA256} header; the signature is RSA SHA256 over the raw request payload,
     * verified with the configured Wise public key.
     */
    public boolean verifyWebhookSignature(String payload, String signatureHeader) {
        if (payload == null || signatureHeader == null || webhookPublicKey == null
                || webhookPublicKey.isBlank()) {
            log.warn("wise webhook verify: missing payload/signature/public key");
            return false;
        }
        try {
            byte[] der = Base64.getDecoder().decode(normalizePem(webhookPublicKey));
            PublicKey pub = KeyFactory.getInstance("RSA")
                    .generatePublic(new X509EncodedKeySpec(der));
            Signature sig = Signature.getInstance("SHA256withRSA");
            sig.initVerify(pub);
            sig.update(payload.getBytes(StandardCharsets.UTF_8));
            return sig.verify(Base64.getDecoder().decode(signatureHeader.trim()));
        } catch (Exception e) {
            log.warn("wise webhook signature verify error: {}", e.getMessage());
            return false;
        }
    }

    // ---------- helpers ----------

    private Map post(String path, JsonNode body) {
        try {
            String resp = webClient.post().uri(base() + path)
                    .header("Authorization", "Bearer " + apiToken)
                    .contentType(MediaType.APPLICATION_JSON)
                    .bodyValue(objectMapper.writeValueAsString(body))
                    .retrieve().bodyToMono(String.class).block(TIMEOUT);
            return objectMapper.readValue(resp, Map.class);
        } catch (Exception e) {
            log.warn("wise POST {} failed: {}", path, e.getMessage());
            return null;
        }
    }

    private Map get(String path) {
        try {
            String resp = webClient.get().uri(base() + path)
                    .header("Authorization", "Bearer " + apiToken)
                    .retrieve().bodyToMono(String.class).block(TIMEOUT);
            return objectMapper.readValue(resp, Map.class);
        } catch (Exception e) {
            log.warn("wise GET {} failed: {}", path, e.getMessage());
            return null;
        }
    }

    private String normalizePem(String key) {
        return key.replaceAll("-----BEGIN [^-]+-----", "")
                .replaceAll("-----END [^-]+-----", "")
                .replaceAll("\\s", "");
    }
}
