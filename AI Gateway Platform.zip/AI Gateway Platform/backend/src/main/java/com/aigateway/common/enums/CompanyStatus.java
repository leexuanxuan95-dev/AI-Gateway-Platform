package com.aigateway.common.enums;

import com.baomidou.mybatisplus.annotation.EnumValue;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;

/** biz_company.status. */
@Getter
public enum CompanyStatus implements CodedEnum<Integer> {

    NORMAL(1),
    LOGGED_OFF(2),
    DISABLED(3);

    @EnumValue
    @JsonValue
    private final Integer code;

    CompanyStatus(Integer code) {
        this.code = code;
    }

    @JsonCreator
    public static CompanyStatus of(Integer code) {
        if (code == null) {
            return null;
        }
        for (CompanyStatus v : values()) {
            if (v.code.equals(code)) {
                return v;
            }
        }
        return null;
    }
}
