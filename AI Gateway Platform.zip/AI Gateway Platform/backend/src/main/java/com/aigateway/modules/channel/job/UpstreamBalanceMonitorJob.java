package com.aigateway.modules.channel.job;

import com.aigateway.common.constant.KafkaTopics;
import com.aigateway.common.enums.ChannelHealth;
import com.aigateway.common.enums.CommonStatus;
import com.aigateway.modules.channel.entity.Channel;
import com.aigateway.modules.channel.mapper.ChannelMapper;
import com.aigateway.modules.channel.service.ChannelService;
import com.aigateway.common.schedule.ManagedJob;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.List;

/**
 * Monitors upstream channel balances (design doc §8.3). Every 5 minutes: balance below
 * {@code lowThreshold} raises a low-balance alert; balance at or below zero also marks the
 * channel broken (health=0) so the selector skips it.
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class UpstreamBalanceMonitorJob implements ManagedJob {

    private static final String JOB_KEY = "upstream-balance-monitor";

    private final ChannelMapper channelMapper;
    private final ChannelService channelService;
    private final KafkaTemplate<String, String> kafkaTemplate;

    @Override
    public String jobKey() {
        return JOB_KEY;
    }

    @Override
    public String defaultCron() {
        return "0 */5 * * * *";
    }

    @Override
    public String description() {
        return "Monitor upstream channel balances and flag low/depleted channels every 5 minutes";
    }

    @Override
    public void execute() {
        List<Channel> channels = channelMapper.selectList(
                Wrappers.<Channel>lambdaQuery().eq(Channel::getStatus, CommonStatus.ENABLED));
        for (Channel ch : channels) {
            try {
                check(ch);
            } catch (Exception e) {
                log.warn("balance monitor failed for channel {}: {}", ch.getId(), e.getMessage());
            }
        }
    }

    private void check(Channel ch) {
        BigDecimal balance = channelService.estimatedBalance(ch);
        BigDecimal low = ch.getLowThreshold() == null ? BigDecimal.ZERO : ch.getLowThreshold();

        if (balance.compareTo(BigDecimal.ZERO) <= 0) {
            if (ChannelHealth.BROKEN != ch.getHealth()) {
                Channel upd = new Channel();
                upd.setId(ch.getId());
                upd.setHealth(ChannelHealth.BROKEN);
                channelMapper.updateById(upd);
                log.warn("channel {} depleted (balance<=0), marked broken", ch.getId());
            }
            notifyAlert(ch, balance, "channel_depleted");
        } else if (balance.compareTo(low) < 0) {
            notifyAlert(ch, balance, "channel_low_balance");
        }
    }

    private void notifyAlert(Channel ch, BigDecimal balance, String scene) {
        try {
            String msg = "{\"scene\":\"" + scene + "\",\"channelId\":" + ch.getId()
                    + ",\"provider\":\"" + ch.getProviderName() + "\",\"balance\":" + balance + "}";
            kafkaTemplate.send(KafkaTopics.NOTIFY, msg);
        } catch (Exception e) {
            log.warn("notify ({}) failed for channel {}: {}", scene, ch.getId(), e.getMessage());
        }
    }
}
