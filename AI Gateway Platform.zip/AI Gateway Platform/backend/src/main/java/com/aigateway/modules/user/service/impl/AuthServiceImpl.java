package com.aigateway.modules.user.service.impl;

import cn.hutool.core.util.RandomUtil;
import com.aigateway.common.constant.KafkaTopics;
import com.aigateway.common.constant.RedisKeys;
import com.aigateway.common.crypto.AesUtil;
import com.aigateway.common.exception.BizException;
import com.aigateway.common.exception.ErrorCode;
import com.aigateway.common.security.JwtUtil;
import com.aigateway.common.security.LoginAttemptService;
import com.aigateway.common.security.TokenEpochService;
import com.aigateway.common.security.UserContext;
import com.aigateway.common.enums.CommonStatus;
import com.aigateway.common.enums.ResultStatus;
import com.aigateway.common.enums.UserStatus;
import com.aigateway.common.util.IdGen;
import com.aigateway.modules.company.entity.CompanyInvite;
import com.aigateway.modules.company.entity.CompanyMember;
import com.aigateway.modules.company.mapper.CompanyInviteMapper;
import com.aigateway.modules.company.mapper.CompanyMemberMapper;
import com.aigateway.modules.notify.dto.NotifyMessage;
import com.aigateway.modules.system.service.SysConfigService;
import com.aigateway.modules.user.dto.GoogleLoginRequest;
import com.aigateway.modules.user.dto.InviteRegisterRequest;
import com.aigateway.modules.user.dto.LoginRequest;
import com.aigateway.modules.user.dto.LoginResponse;
import com.aigateway.modules.user.dto.RegisterRequest;
import com.aigateway.modules.user.dto.SendCodeRequest;
import com.aigateway.modules.user.dto.UserInfo;
import com.aigateway.modules.user.entity.LoginLog;
import com.aigateway.modules.user.entity.SysUser;
import com.aigateway.modules.user.mapper.LoginLogMapper;
import com.aigateway.modules.user.mapper.SysUserMapper;
import com.aigateway.modules.user.service.AuthService;
import com.aigateway.modules.user.service.GoogleTokenVerifier;
import com.aigateway.modules.user.service.SessionService;
import com.aigateway.modules.user.service.TotpService;
import com.aigateway.modules.user.service.UserService;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.time.Duration;
import java.time.OffsetDateTime;
import java.util.HashMap;
import java.util.Map;

/** Default {@link AuthService}. */
@Slf4j
@Service
@RequiredArgsConstructor
public class AuthServiceImpl implements AuthService {

    private static final Duration CODE_TTL = Duration.ofMinutes(5);
    /** Minimum interval between two code requests for the same target (anti-bombing). */
    private static final Duration SEND_CODE_COOLDOWN = Duration.ofSeconds(60);
    /** Max verification codes per target per day (anti-bombing). */
    private static final long SEND_CODE_DAILY_MAX = 10;
    private static final Duration SEND_CODE_DAILY_TTL = Duration.ofHours(24);
    private static final Duration REFRESH_TTL = Duration.ofDays(30);
    /** Number of digits in a verification code. */
    private static final int CODE_DIGITS = 6;
    /** Random length of the opaque refresh token suffix. */
    private static final int REFRESH_TOKEN_RANDOM_LEN = 40;
    /** Initial capacity for the access-token claim map (email, superAdmin, companyId, companyRole). */
    private static final int CLAIMS_MAP_CAPACITY = 8;

    /** Global force-2FA toggle in {@code sys_config}. */
    private static final String CFG_FORCE_2FA = "security.force_2fa";
    /** Per-company force-2FA toggle: {@code security.force_2fa.company.{id}}. */
    private static final String CFG_FORCE_2FA_COMPANY_PREFIX = "security.force_2fa.company.";

    private final SysUserMapper userMapper;
    private final LoginLogMapper loginLogMapper;
    private final CompanyMemberMapper memberMapper;
    private final CompanyInviteMapper inviteMapper;
    private final PasswordEncoder passwordEncoder;
    private final JwtUtil jwtUtil;
    private final RedisTemplate<String, Object> redisTemplate;
    private final TotpService totpService;
    private final AesUtil aesUtil;
    private final UserService userService;
    private final LoginAttemptService loginAttemptService;
    private final TokenEpochService tokenEpochService;
    private final SessionService sessionService;
    private final GoogleTokenVerifier googleTokenVerifier;
    private final SysConfigService sysConfigService;
    private final KafkaTemplate<String, String> kafkaTemplate;
    private final ObjectMapper objectMapper;

    @Override
    @Transactional
    public SysUser register(RegisterRequest req, HttpServletRequest http) {
        boolean byEmail = StringUtils.hasText(req.getEmail());
        boolean byMobile = StringUtils.hasText(req.getMobile());
        if (!byEmail && !byMobile) {
            throw new BizException(ErrorCode.PARAM_ERROR, "email or mobile required");
        }

        if (byEmail) {
            if (!StringUtils.hasText(req.getPassword())) {
                throw new BizException(ErrorCode.PARAM_ERROR, "password required");
            }
            if (exists(Wrappers.<SysUser>lambdaQuery().eq(SysUser::getEmail, req.getEmail()))) {
                throw new BizException(ErrorCode.EMAIL_EXISTS);
            }
            verifyCaptcha("register", req.getEmail(), req.getCode());
        } else {
            if (exists(Wrappers.<SysUser>lambdaQuery().eq(SysUser::getMobile, req.getMobile()))) {
                throw new BizException(ErrorCode.MOBILE_EXISTS);
            }
            verifyCaptcha("register", req.getMobile(), req.getCode());
        }

        SysUser u = new SysUser();
        u.setUid(IdGen.uid());
        u.setEmail(byEmail ? req.getEmail() : null);
        u.setMobile(byMobile ? req.getMobile() : null);
        u.setNickname(StringUtils.hasText(req.getNickname()) ? req.getNickname()
                : (byEmail ? req.getEmail() : req.getMobile()));
        u.setPassword(byEmail ? passwordEncoder.encode(req.getPassword()) : null);
        u.setTotpEnabled(false);
        u.setSuperAdmin(false);
        // dev simplicity: registered users are active immediately
        u.setStatus(UserStatus.NORMAL);
        u.setRegisterIp(clientIp(http));
        u.setRegisterTime(OffsetDateTime.now());
        userMapper.insert(u);
        return u;
    }

    @Override
    public void sendCode(SendCodeRequest req) {
        // anti-bombing (design doc §18): per-target 60s cooldown + daily cap, so an attacker
        // cannot flood a victim's phone/email or burn SMS budget.
        String cooldownKey = "gw:code:cd:" + req.getScene() + ":" + req.getTarget();
        Boolean fresh = redisTemplate.opsForValue().setIfAbsent(cooldownKey, "1", SEND_CODE_COOLDOWN);
        if (Boolean.FALSE.equals(fresh)) {
            throw new BizException(ErrorCode.RATE_LIMITED, "code requested too frequently, try later");
        }
        String dailyKey = "gw:code:daily:" + req.getScene() + ":" + req.getTarget();
        Long dailyCount = redisTemplate.opsForValue().increment(dailyKey);
        if (dailyCount != null && dailyCount == 1L) {
            redisTemplate.expire(dailyKey, SEND_CODE_DAILY_TTL);
        }
        if (dailyCount != null && dailyCount > SEND_CODE_DAILY_MAX) {
            throw new BizException(ErrorCode.RATE_LIMITED, "daily code limit reached for this target");
        }

        String code = RandomUtil.randomNumbers(CODE_DIGITS);
        redisTemplate.opsForValue()
                .set(RedisKeys.captcha(req.getScene(), req.getTarget()), code, CODE_TTL);
        // Stub: a real impl dispatches via SMS/email provider.
        log.info("[send-code] scene={} target={} (code suppressed in logs)", req.getScene(), req.getTarget());
    }

    @Override
    @Transactional
    public LoginResponse login(LoginRequest req, HttpServletRequest http) {
        String identity = req.getEmail();
        // account-level brute-force lockout (design doc §18)
        if (loginAttemptService.isLocked(identity)) {
            throw new BizException(ErrorCode.USER_DISABLED,
                    "account temporarily locked due to repeated failed logins; try again later");
        }
        SysUser u = userMapper.selectOne(
                Wrappers.<SysUser>lambdaQuery().eq(SysUser::getEmail, req.getEmail()));
        if (u == null || !StringUtils.hasText(u.getPassword())
                || !passwordEncoder.matches(req.getPassword(), u.getPassword())) {
            loginAttemptService.recordFailure(identity);
            writeLoginLog(u, http, ResultStatus.FAIL, "password");
            throw new BizException(ErrorCode.INVALID_CREDENTIALS);
        }
        if (UserStatus.DISABLED == u.getStatus()) {
            throw new BizException(ErrorCode.USER_DISABLED);
        }
        if (Boolean.TRUE.equals(u.getTotpEnabled())) {
            if (!StringUtils.hasText(req.getTotpCode())) {
                throw new BizException(ErrorCode.TOTP_REQUIRED);
            }
            String secret = aesUtil.decrypt(u.getTotpSecret());
            if (!totpService.verify(secret, req.getTotpCode())) {
                loginAttemptService.recordFailure(identity);
                throw new BizException(ErrorCode.TOTP_INVALID);
            }
        }
        // success: clear failure counter
        loginAttemptService.clear(identity);
        return completeLogin(u, http, "password");
    }

    @Override
    @Transactional
    public LoginResponse googleLogin(GoogleLoginRequest req, HttpServletRequest http) {
        GoogleTokenVerifier.GoogleClaims claims = googleTokenVerifier.verify(req.getIdToken());

        // 1) match by google_id, 2) fall back to a verified email, 3) auto-create
        SysUser u = userMapper.selectOne(
                Wrappers.<SysUser>lambdaQuery().eq(SysUser::getGoogleId, claims.getSub()));
        if (u == null && claims.isEmailVerified() && StringUtils.hasText(claims.getEmail())) {
            u = userMapper.selectOne(
                    Wrappers.<SysUser>lambdaQuery().eq(SysUser::getEmail, claims.getEmail()));
            if (u != null && !StringUtils.hasText(u.getGoogleId())) {
                // link the Google identity to the existing email account
                SysUser link = new SysUser();
                link.setId(u.getId());
                link.setGoogleId(claims.getSub());
                userMapper.updateById(link);
                u.setGoogleId(claims.getSub());
            }
        }
        if (u == null) {
            u = new SysUser();
            u.setUid(IdGen.uid());
            u.setGoogleId(claims.getSub());
            u.setEmail(claims.isEmailVerified() ? claims.getEmail() : null);
            u.setNickname(StringUtils.hasText(claims.getName()) ? claims.getName()
                    : (claims.getEmail() != null ? claims.getEmail() : "google_user"));
            u.setAvatar(claims.getPicture());
            u.setPassword(null);
            u.setTotpEnabled(false);
            u.setSuperAdmin(false);
            u.setStatus(UserStatus.NORMAL);
            u.setRegisterIp(clientIp(http));
            u.setRegisterTime(OffsetDateTime.now());
            userMapper.insert(u);
        } else if (UserStatus.DISABLED == u.getStatus()) {
            throw new BizException(ErrorCode.USER_DISABLED);
        }
        return completeLogin(u, http, "google");
    }

    @Override
    @Transactional
    public LoginResponse registerByInvite(InviteRegisterRequest req, HttpServletRequest http) {
        CompanyInvite inv = inviteMapper.selectOne(Wrappers.<CompanyInvite>lambdaQuery()
                .eq(CompanyInvite::getInviteToken, req.getInviteToken()));
        if (inv == null || Boolean.TRUE.equals(inv.getUsed())) {
            throw new BizException(ErrorCode.NOT_FOUND, "invite invalid or already used");
        }
        if (inv.getExpireAt() != null && inv.getExpireAt().isBefore(OffsetDateTime.now())) {
            throw new BizException(ErrorCode.PARAM_ERROR, "invite expired");
        }
        if (!StringUtils.hasText(req.getPassword())) {
            throw new BizException(ErrorCode.PARAM_ERROR, "password required");
        }

        // If the invited email already maps to a user, attach membership instead of duplicating.
        SysUser u = null;
        if (StringUtils.hasText(inv.getEmail())) {
            u = userMapper.selectOne(
                    Wrappers.<SysUser>lambdaQuery().eq(SysUser::getEmail, inv.getEmail()));
        }
        if (u == null) {
            u = new SysUser();
            u.setUid(IdGen.uid());
            u.setEmail(inv.getEmail());
            u.setNickname(StringUtils.hasText(req.getNickname()) ? req.getNickname()
                    : defaultNick(inv.getEmail()));
            u.setPassword(passwordEncoder.encode(req.getPassword()));
            u.setTotpEnabled(false);
            u.setSuperAdmin(false);
            u.setStatus(UserStatus.NORMAL);
            u.setRegisterIp(clientIp(http));
            u.setRegisterTime(OffsetDateTime.now());
            userMapper.insert(u);
        }

        // attach company membership (idempotent on the (company,user) pair)
        CompanyMember existing = memberMapper.selectOne(Wrappers.<CompanyMember>lambdaQuery()
                .eq(CompanyMember::getCompanyId, inv.getCompanyId())
                .eq(CompanyMember::getUserId, u.getId()));
        if (existing == null) {
            CompanyMember m = new CompanyMember();
            m.setCompanyId(inv.getCompanyId());
            m.setUserId(u.getId());
            m.setRole(inv.getRole());
            m.setStatus(CommonStatus.ENABLED);
            m.setInvitedBy(inv.getInvitedBy());
            memberMapper.insert(m);
        }

        // mark invite consumed
        inv.setUsed(true);
        inviteMapper.updateById(inv);

        // issue tokens scoped to the invite's company context
        return completeLogin(u, http, "invite", inv.getCompanyId(), inv.getRole());
    }

    @Override
    public String refresh(String refreshToken) {
        Object userIdObj = redisTemplate.opsForValue().get(RedisKeys.refreshToken(refreshToken));
        if (userIdObj == null) {
            throw new BizException(ErrorCode.TOKEN_EXPIRED);
        }
        Long userId = Long.valueOf(String.valueOf(userIdObj));
        SysUser u = userMapper.selectById(userId);
        if (u == null) {
            throw new BizException(ErrorCode.USER_NOT_FOUND);
        }
        // A disabled account must not be able to mint fresh access tokens via refresh.
        if (UserStatus.DISABLED == u.getStatus()) {
            throw new BizException(ErrorCode.USER_DISABLED);
        }
        CompanyMember first = firstMembership(u.getId());
        Long companyId = first != null ? first.getCompanyId() : null;
        String companyRole = first != null ? first.getRole() : null;
        return issueAccess(u, companyId, companyRole);
    }

    @Override
    public void logout(String refreshToken) {
        if (StringUtils.hasText(refreshToken)) {
            Object userIdObj = redisTemplate.opsForValue().get(RedisKeys.refreshToken(refreshToken));
            redisTemplate.delete(RedisKeys.refreshToken(refreshToken));
            if (userIdObj != null) {
                try {
                    sessionService.deregister(Long.valueOf(String.valueOf(userIdObj)), refreshToken);
                } catch (Exception e) {
                    log.warn("logout session deregister failed: {}", e.getMessage());
                }
            }
        }
    }

    @Override
    public String switchCompany(Long companyId) {
        Long userId = UserContext.userId();
        SysUser u = userMapper.selectById(userId);
        if (u == null) {
            throw new BizException(ErrorCode.USER_NOT_FOUND);
        }
        if (UserStatus.DISABLED == u.getStatus()) {
            throw new BizException(ErrorCode.USER_DISABLED);
        }
        CompanyMember m = memberMapper.selectOne(Wrappers.<CompanyMember>lambdaQuery()
                .eq(CompanyMember::getUserId, userId)
                .eq(CompanyMember::getCompanyId, companyId));
        if (m == null) {
            throw new BizException(ErrorCode.NOT_COMPANY_MEMBER);
        }
        return issueAccess(u, companyId, m.getRole());
    }

    // ---- shared login completion ----

    private LoginResponse completeLogin(SysUser u, HttpServletRequest http, String loginType) {
        CompanyMember first = firstMembership(u.getId());
        Long companyId = first != null ? first.getCompanyId() : null;
        String companyRole = first != null ? first.getRole() : null;
        return completeLogin(u, http, loginType, companyId, companyRole);
    }

    /**
     * Common post-authentication steps: 2FA-policy enforcement, abnormal-login alerting,
     * token issuance, session registration, last-login bookkeeping and login logging.
     */
    private LoginResponse completeLogin(SysUser u, HttpServletRequest http, String loginType,
                                        Long companyId, String companyRole) {
        String ip = clientIp(http);
        String ua = http != null ? http.getHeader("User-Agent") : null;

        // §3.3 abnormal-login alert: new device/IP not seen in this user's active sessions
        boolean newDevice = false;
        try {
            newDevice = sessionService.isNewDevice(u.getId(), ip, ua);
        } catch (Exception e) {
            log.debug("new-device check failed: {}", e.getMessage());
        }

        String accessToken = issueAccess(u, companyId, companyRole);
        String refreshToken = issueRefresh(u.getId(), ip, ua);

        // last login bookkeeping
        SysUser upd = new SysUser();
        upd.setId(u.getId());
        upd.setLastLoginTime(OffsetDateTime.now());
        upd.setLastLoginIp(ip);
        userMapper.updateById(upd);
        writeLoginLog(u, http, ResultStatus.SUCCESS, loginType);

        if (newDevice) {
            emitLoginAlert(u, ip, ua);
        }

        UserInfo info = userService.buildUserInfo(u, companyId, companyRole);
        LoginResponse resp = LoginResponse.of(accessToken, refreshToken, info);

        // §3 force-2FA policy: require enrollment before the session is considered complete
        if (!Boolean.TRUE.equals(u.getTotpEnabled()) && force2faRequired(companyId)) {
            resp.setRequire2faSetup(true);
        }
        return resp;
    }

    // ---- helpers ----

    private CompanyMember firstMembership(Long userId) {
        return memberMapper.selectOne(Wrappers.<CompanyMember>lambdaQuery()
                .eq(CompanyMember::getUserId, userId)
                .orderByAsc(CompanyMember::getId)
                .last("limit 1"));
    }

    /** A force-2FA policy applies if the global toggle is on OR the active company's toggle is on. */
    private boolean force2faRequired(Long companyId) {
        try {
            if (sysConfigService.getBool(CFG_FORCE_2FA, false)) {
                return true;
            }
            if (companyId != null
                    && sysConfigService.getBool(CFG_FORCE_2FA_COMPANY_PREFIX + companyId, false)) {
                return true;
            }
        } catch (Exception e) {
            log.debug("force-2fa policy lookup failed: {}", e.getMessage());
        }
        return false;
    }

    private void emitLoginAlert(SysUser u, String ip, String ua) {
        if (!StringUtils.hasText(u.getEmail())) {
            return; // nowhere to send
        }
        try {
            NotifyMessage msg = new NotifyMessage();
            msg.setChannel("email");
            msg.setScene("login_alert");
            msg.setTarget(u.getEmail());
            msg.setContent("New sign-in to your AI Gateway account from IP " + ip
                    + (ua != null ? " (" + ua + ")" : "")
                    + ". If this wasn't you, change your password and review active devices.");
            kafkaTemplate.send(KafkaTopics.NOTIFY, String.valueOf(u.getId()),
                    objectMapper.writeValueAsString(msg));
        } catch (Exception e) {
            log.warn("emit login_alert failed for user {}: {}", u.getId(), e.getMessage());
        }
    }

    private boolean exists(com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper<SysUser> qw) {
        return userMapper.selectCount(qw) > 0;
    }

    private void verifyCaptcha(String scene, String target, String code) {
        Object stored = redisTemplate.opsForValue().get(RedisKeys.captcha(scene, target));
        if (stored == null || !String.valueOf(stored).equals(code)) {
            throw new BizException(ErrorCode.CAPTCHA_INVALID);
        }
        redisTemplate.delete(RedisKeys.captcha(scene, target));
    }

    private String defaultNick(String email) {
        if (!StringUtils.hasText(email)) {
            return "member";
        }
        int at = email.indexOf('@');
        return at > 0 ? email.substring(0, at) : email;
    }

    /** Build access-token claims. {@code companyId} is stored as Long for the JWT filter. */
    private String issueAccess(SysUser u, Long companyId, String companyRole) {
        Map<String, Object> claims = new HashMap<>(CLAIMS_MAP_CAPACITY);
        claims.put("email", u.getEmail());
        claims.put("superAdmin", Boolean.TRUE.equals(u.getSuperAdmin()));
        // Stamp the current revoke-all epoch so JwtAuthFilter can reject this token once the
        // user's epoch is bumped (password change, revoke-all, account disable, 2FA disable).
        claims.put("epoch", tokenEpochService.current(u.getId()));
        // omit null company claims so they are not serialized into the JWT
        if (companyId != null) {
            claims.put("companyId", companyId);
        }
        if (companyRole != null) {
            claims.put("companyRole", companyRole);
        }
        return jwtUtil.issueAccessToken(u.getId(), u.getUid(), claims);
    }

    /**
     * Mint an opaque refresh token, store its token->userId mapping and register it as an
     * active session/device for the user (design doc §3.3).
     */
    private String issueRefresh(Long userId, String ip, String userAgent) {
        String token = "rt_" + RandomUtil.randomString(REFRESH_TOKEN_RANDOM_LEN);
        redisTemplate.opsForValue()
                .set(RedisKeys.refreshToken(token), String.valueOf(userId), REFRESH_TTL);
        sessionService.register(userId, token, ip, userAgent);
        return token;
    }

    private void writeLoginLog(SysUser u, HttpServletRequest http, ResultStatus status, String loginType) {
        if (u == null) {
            return;
        }
        LoginLog logRow = new LoginLog();
        logRow.setUserId(u.getId());
        logRow.setLoginType(loginType);
        logRow.setIp(clientIp(http));
        logRow.setUserAgent(http != null ? http.getHeader("User-Agent") : null);
        logRow.setStatus(status);
        loginLogMapper.insert(logRow);
    }

    private String clientIp(HttpServletRequest http) {
        if (http == null) {
            return null;
        }
        String xff = http.getHeader("X-Forwarded-For");
        if (StringUtils.hasText(xff)) {
            int comma = xff.indexOf(',');
            return comma > 0 ? xff.substring(0, comma).trim() : xff.trim();
        }
        return http.getRemoteAddr();
    }
}
