package com.aigateway.modules.company.service.impl;

import cn.hutool.core.util.RandomUtil;
import com.aigateway.common.api.PageResult;
import com.aigateway.common.enums.AuthStatus;
import com.aigateway.common.enums.CommonStatus;
import com.aigateway.common.enums.CompanyStatus;
import com.aigateway.common.exception.BizException;
import com.aigateway.common.exception.ErrorCode;
import com.aigateway.common.security.UserContext;
import com.aigateway.common.util.IdGen;
import com.aigateway.common.util.UploadValidator;
import com.aigateway.modules.company.dto.AcceptInviteRequest;
import com.aigateway.modules.company.dto.AuditRequest;
import com.aigateway.modules.company.dto.AuthSubmitRequest;
import com.aigateway.modules.company.dto.CompanyCreateRequest;
import com.aigateway.modules.company.dto.CompanyUpdateRequest;
import com.aigateway.modules.company.dto.InviteRequest;
import com.aigateway.modules.company.dto.MemberView;
import com.aigateway.modules.company.dto.RoleUpdateRequest;
import com.aigateway.modules.company.entity.Company;
import com.aigateway.modules.company.entity.CompanyInvite;
import com.aigateway.modules.company.entity.CompanyMember;
import com.aigateway.modules.company.service.CompanyService;
import com.aigateway.modules.company.mapper.CompanyInviteMapper;
import com.aigateway.modules.company.mapper.CompanyMapper;
import com.aigateway.modules.company.mapper.CompanyMemberMapper;
import com.aigateway.modules.user.entity.SysUser;
import com.aigateway.modules.user.mapper.SysUserMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.OffsetDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

/** Default {@link CompanyService}. */
@Service
@RequiredArgsConstructor
public class CompanyServiceImpl implements CompanyService {

    private static final String ROLE_OWNER = "OWNER";
    private static final Set<String> ASSIGNABLE_ROLES = Set.of("ADMIN", "DEVELOPER", "VIEWER");
    private static final int INVITE_TTL_DAYS = 7;
    /** Random length of the opaque invite token suffix. */
    private static final int INVITE_TOKEN_RANDOM_LEN = 40;

    private final CompanyMapper companyMapper;
    private final CompanyMemberMapper memberMapper;
    private final CompanyInviteMapper inviteMapper;
    private final SysUserMapper userMapper;

    @Override
    @Transactional
    public Company create(CompanyCreateRequest req) {
        Long userId = UserContext.userId();

        Company c = new Company();
        c.setCompanyCode(IdGen.companyCode());
        c.setCompanyName(req.getCompanyName());
        c.setContactName(req.getContactName());
        c.setContactMobile(req.getContactMobile());
        c.setContactEmail(req.getContactEmail());
        c.setOwnerUserId(userId);
        c.setAuthStatus(AuthStatus.PENDING);
        c.setStatus(CompanyStatus.NORMAL);
        companyMapper.insert(c);

        CompanyMember owner = new CompanyMember();
        owner.setCompanyId(c.getId());
        owner.setUserId(userId);
        owner.setRole(ROLE_OWNER);
        owner.setStatus(CommonStatus.ENABLED);
        owner.setInvitedBy(userId);
        memberMapper.insert(owner);

        return c;
    }

    @Override
    public Company current() {
        return requireCompany(UserContext.companyId());
    }

    @Override
    public Company update(CompanyUpdateRequest req) {
        Company c = requireCompany(UserContext.companyId());
        if (req.getCompanyName() != null) {
            c.setCompanyName(req.getCompanyName());
        }
        if (req.getContactName() != null) {
            c.setContactName(req.getContactName());
        }
        if (req.getContactMobile() != null) {
            c.setContactMobile(req.getContactMobile());
        }
        if (req.getContactEmail() != null) {
            c.setContactEmail(req.getContactEmail());
        }
        companyMapper.updateById(c);
        return c;
    }

    @Override
    public void submitAuth(AuthSubmitRequest req) {
        Company c = requireCompany(UserContext.companyId());
        // The console submits object-store keys (bytes uploaded out-of-band); reject traversal /
        // illegal characters and enforce the document extension allow-list before persisting.
        UploadValidator.validateObjectKey("businessLicense", req.getBusinessLicense());
        UploadValidator.validateObjectKey("legalIdFront", req.getLegalIdFront());
        c.setBusinessLicense(req.getBusinessLicense());
        c.setLegalIdFront(req.getLegalIdFront());
        c.setAuthStatus(AuthStatus.PENDING);
        companyMapper.updateById(c);
    }

    @Override
    public PageResult<MemberView> members(long current, long size) {
        Long companyId = UserContext.companyId();
        IPage<CompanyMember> p = memberMapper.selectPage(new Page<>(current, size),
                Wrappers.<CompanyMember>lambdaQuery()
                        .eq(CompanyMember::getCompanyId, companyId)
                        .orderByAsc(CompanyMember::getId));

        List<CompanyMember> rows = p.getRecords();
        Map<Long, SysUser> users = new HashMap<>();
        if (!rows.isEmpty()) {
            List<Long> uids = rows.stream().map(CompanyMember::getUserId).collect(Collectors.toList());
            for (SysUser u : userMapper.selectBatchIds(uids)) {
                users.put(u.getId(), u);
            }
        }
        IPage<MemberView> view = p.convert(m -> toMemberView(m, users.get(m.getUserId())));
        return PageResult.of(view);
    }

    @Override
    @Transactional
    public CompanyInvite invite(InviteRequest req) {
        String role = req.getRole() == null ? "" : req.getRole().toUpperCase();
        if (!ASSIGNABLE_ROLES.contains(role)) {
            throw new BizException(ErrorCode.PARAM_ERROR, "invalid role");
        }
        Long companyId = UserContext.companyId();
        CompanyInvite inv = new CompanyInvite();
        inv.setCompanyId(companyId);
        inv.setInviteToken("inv_" + RandomUtil.randomString(INVITE_TOKEN_RANDOM_LEN));
        inv.setRole(role);
        inv.setEmail(req.getEmail());
        inv.setInvitedBy(UserContext.userId());
        inv.setExpireAt(OffsetDateTime.now().plusDays(INVITE_TTL_DAYS));
        inv.setUsed(false);
        inviteMapper.insert(inv);
        return inv;
    }

    @Override
    @Transactional
    public void acceptInvite(AcceptInviteRequest req) {
        CompanyInvite inv = inviteMapper.selectOne(Wrappers.<CompanyInvite>lambdaQuery()
                .eq(CompanyInvite::getInviteToken, req.getInviteToken()));
        if (inv == null || Boolean.TRUE.equals(inv.getUsed())) {
            throw new BizException(ErrorCode.NOT_FOUND, "invite invalid or already used");
        }
        if (inv.getExpireAt() != null && inv.getExpireAt().isBefore(OffsetDateTime.now())) {
            throw new BizException(ErrorCode.PARAM_ERROR, "invite expired");
        }
        Long userId = UserContext.userId();
        CompanyMember existing = memberMapper.selectOne(Wrappers.<CompanyMember>lambdaQuery()
                .eq(CompanyMember::getCompanyId, inv.getCompanyId())
                .eq(CompanyMember::getUserId, userId));
        if (existing == null) {
            CompanyMember m = new CompanyMember();
            m.setCompanyId(inv.getCompanyId());
            m.setUserId(userId);
            m.setRole(inv.getRole());
            m.setStatus(CommonStatus.ENABLED);
            m.setInvitedBy(inv.getInvitedBy());
            memberMapper.insert(m);
        }
        inv.setUsed(true);
        inviteMapper.updateById(inv);
    }

    @Override
    public void updateMemberRole(Long userId, RoleUpdateRequest req) {
        String role = req.getRole() == null ? "" : req.getRole().toUpperCase();
        if (!ASSIGNABLE_ROLES.contains(role)) {
            throw new BizException(ErrorCode.PARAM_ERROR, "invalid role");
        }
        CompanyMember m = requireMember(userId);
        if (ROLE_OWNER.equals(m.getRole())) {
            throw new BizException(ErrorCode.PARAM_ERROR, "cannot change OWNER role");
        }
        m.setRole(role);
        memberMapper.updateById(m);
    }

    @Override
    public void removeMember(Long userId) {
        CompanyMember m = requireMember(userId);
        if (ROLE_OWNER.equals(m.getRole())) {
            throw new BizException(ErrorCode.PARAM_ERROR, "cannot remove OWNER");
        }
        memberMapper.deleteById(m.getId());
    }

    @Override
    public PageResult<Company> adminPage(long current, long size) {
        requireSuperAdmin();
        IPage<Company> p = companyMapper.selectPage(new Page<>(current, size),
                Wrappers.<Company>lambdaQuery().orderByDesc(Company::getId));
        return PageResult.of(p);
    }

    @Override
    public void audit(Long companyId, AuditRequest req) {
        requireSuperAdmin();
        AuthStatus target = req.getAuthStatus();
        if (target != AuthStatus.PASSED && target != AuthStatus.REJECTED) {
            throw new BizException(ErrorCode.PARAM_ERROR, "authStatus must be 1 or 2");
        }
        Company c = companyMapper.selectById(companyId);
        if (c == null) {
            throw new BizException(ErrorCode.COMPANY_NOT_FOUND);
        }
        c.setAuthStatus(target);
        companyMapper.updateById(c);
    }

    // ---- helpers ----

    private Company requireCompany(Long companyId) {
        Company c = companyMapper.selectById(companyId);
        if (c == null) {
            throw new BizException(ErrorCode.COMPANY_NOT_FOUND);
        }
        return c;
    }

    /** Load a membership in the active company; 404 if not found. */
    private CompanyMember requireMember(Long userId) {
        CompanyMember m = memberMapper.selectOne(Wrappers.<CompanyMember>lambdaQuery()
                .eq(CompanyMember::getCompanyId, UserContext.companyId())
                .eq(CompanyMember::getUserId, userId));
        if (m == null) {
            throw new BizException(ErrorCode.NOT_COMPANY_MEMBER);
        }
        return m;
    }

    private void requireSuperAdmin() {
        if (!UserContext.require().isSuperAdmin()) {
            throw new BizException(ErrorCode.FORBIDDEN);
        }
    }

    private MemberView toMemberView(CompanyMember m, SysUser u) {
        MemberView v = new MemberView();
        v.setUserId(m.getUserId());
        v.setRole(m.getRole());
        v.setStatus(m.getStatus());
        v.setJoinedAt(m.getJoinedAt());
        if (u != null) {
            v.setUid(u.getUid());
            v.setEmail(u.getEmail());
            v.setNickname(u.getNickname());
        }
        return v;
    }
}
