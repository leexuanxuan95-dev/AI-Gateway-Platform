package com.aigateway.modules.user.dto;

import lombok.Data;

/**
 * Change the bound email or mobile (design doc §3.3 sensitive operation). Requires step-up
 * re-verification: either the current account {@code password} OR a fresh verification
 * {@code code} sent to the new target via {@code /api/auth/send-code} (scene
 * {@code change_email} / {@code change_mobile}).
 */
@Data
public class ChangeContactRequest {

    /** New email (provide either email or mobile, not both). */
    private String email;

    /** New mobile (provide either email or mobile, not both). */
    private String mobile;

    /** Current account password for step-up re-verification (optional if code provided). */
    private String password;

    /** Verification code sent to the new target for step-up re-verification (optional if password provided). */
    private String code;
}
