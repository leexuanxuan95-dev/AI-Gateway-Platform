package com.aigateway.modules.model.service;

import com.fasterxml.jackson.databind.JsonNode;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;

import java.time.Duration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Thin admin client for LiteLLM's dynamic model-routing API (design doc §7.6). Model
 * routes are registered/removed at runtime so nothing lives in a static yaml. All calls
 * are best-effort: failures are logged (warn) and swallowed so callers never break.
 *
 * <p>Authenticates with the LiteLLM master key as a Bearer token. Api keys are never logged.</p>
 */
@Slf4j
@Component
public class LiteLlmAdminClient {

    private static final Duration TIMEOUT = Duration.ofSeconds(15);

    private final WebClient litellmWebClient;
    private final String masterKey;

    public LiteLlmAdminClient(WebClient litellmWebClient,
                              @Value("${aigateway.litellm.master-key}") String masterKey) {
        this.litellmWebClient = litellmWebClient;
        this.masterKey = masterKey;
    }

    /**
     * Register (or upsert) a model route in LiteLLM via POST {@code /model/new}.
     * The upstream model id is qualified with the provider, e.g. {@code anthropic/claude-...}.
     */
    public void registerModel(String modelName, String upstreamModel, String provider,
                              String apiKey, String baseUrl) {
        try {
            Map<String, Object> params = new HashMap<>();
            params.put("model", provider + "/" + upstreamModel);
            params.put("api_key", apiKey);
            if (baseUrl != null && !baseUrl.isBlank()) {
                params.put("api_base", baseUrl);
            }
            Map<String, Object> body = new HashMap<>();
            body.put("model_name", modelName);
            body.put("litellm_params", params);

            litellmWebClient.post()
                    .uri("/model/new")
                    .header(HttpHeaders.AUTHORIZATION, "Bearer " + masterKey)
                    .contentType(MediaType.APPLICATION_JSON)
                    .bodyValue(body)
                    .retrieve()
                    .bodyToMono(String.class)
                    .block(TIMEOUT);
            log.debug("LiteLLM registered model {}", modelName);
        } catch (Exception e) {
            log.warn("LiteLLM registerModel {} failed: {}", modelName, e.getMessage());
        }
    }

    /**
     * Register one deployment in LiteLLM via POST {@code /model/new} and RETURN the
     * {@code model_id} parsed from the JSON response (used later to delete the deployment).
     * Each upstream key becomes its own deployment so LiteLLM load-balances/fails-over across keys.
     *
     * @param modelName     public model code exposed to clients (LiteLLM {@code model_name})
     * @param litellmModel  provider-qualified upstream model, e.g. {@code openai/gpt-4o}
     * @param apiKey        decrypted upstream api key (never logged)
     * @param baseUrl       upstream base url; omitted when blank
     * @return the LiteLLM {@code model_id}, or {@code null} on failure
     */
    public String registerDeployment(String modelName, String litellmModel,
                                     String apiKey, String baseUrl) {
        try {
            Map<String, Object> params = new HashMap<>();
            params.put("model", litellmModel);
            params.put("api_key", apiKey);
            if (baseUrl != null && !baseUrl.isBlank()) {
                params.put("api_base", baseUrl);
            }
            Map<String, Object> body = new HashMap<>();
            body.put("model_name", modelName);
            body.put("litellm_params", params);

            JsonNode resp = litellmWebClient.post()
                    .uri("/model/new")
                    .header(HttpHeaders.AUTHORIZATION, "Bearer " + masterKey)
                    .contentType(MediaType.APPLICATION_JSON)
                    .bodyValue(body)
                    .retrieve()
                    .bodyToMono(JsonNode.class)
                    .block(TIMEOUT);
            if (resp == null) {
                log.warn("LiteLLM registerDeployment {} returned empty response", modelName);
                return null;
            }
            JsonNode idNode = resp.path("model_id");
            if (idNode.isMissingNode() || idNode.isNull()) {
                log.warn("LiteLLM registerDeployment {} response had no model_id", modelName);
                return null;
            }
            String modelId = idNode.asText();
            log.debug("LiteLLM registered deployment {} -> {}", modelName, modelId);
            return modelId;
        } catch (Exception e) {
            log.warn("LiteLLM registerDeployment {} failed: {}", modelName, e.getMessage());
            return null;
        }
    }

    /** Remove a model route via POST {@code /model/delete}. Best-effort. */
    public void deleteModel(String modelId) {
        try {
            litellmWebClient.post()
                    .uri("/model/delete")
                    .header(HttpHeaders.AUTHORIZATION, "Bearer " + masterKey)
                    .contentType(MediaType.APPLICATION_JSON)
                    .bodyValue(Map.of("id", modelId))
                    .retrieve()
                    .bodyToMono(String.class)
                    .block(TIMEOUT);
            log.debug("LiteLLM deleted model {}", modelId);
        } catch (Exception e) {
            log.warn("LiteLLM deleteModel {} failed: {}", modelId, e.getMessage());
        }
    }

    /** List currently registered models via GET {@code /model/info}; empty on failure. */
    public List<?> listModels() {
        try {
            JsonNode resp = litellmWebClient.get()
                    .uri("/model/info")
                    .header(HttpHeaders.AUTHORIZATION, "Bearer " + masterKey)
                    .retrieve()
                    .bodyToMono(JsonNode.class)
                    .block(TIMEOUT);
            if (resp == null) {
                return List.of();
            }
            JsonNode data = resp.path("data");
            java.util.List<Object> out = new java.util.ArrayList<>();
            if (data.isArray()) {
                data.forEach(out::add);
            }
            return out;
        } catch (Exception e) {
            log.warn("LiteLLM listModels failed: {}", e.getMessage());
            return List.of();
        }
    }
}
