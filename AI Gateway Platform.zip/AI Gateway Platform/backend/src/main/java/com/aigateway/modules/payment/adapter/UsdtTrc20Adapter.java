package com.aigateway.modules.payment.adapter;

import com.aigateway.common.crypto.AesUtil;
import com.aigateway.common.exception.BizException;
import com.aigateway.common.exception.ErrorCode;
import com.aigateway.modules.finance.entity.FinRechargeOrder;
import com.aigateway.modules.payment.entity.PayChannelConfig;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Duration;
import java.util.HashMap;
import java.util.Map;

/**
 * Functional USDT (TRC20) adapter (design doc §10.2) using the public TronGrid HTTP API.
 *
 * <ul>
 *   <li>{@code createOrder}: assigns the configured receive address and a unique amount suffix
 *       (so concurrent orders can be matched by exact amount); returns the address +
 *       expected amount in {@link PrepayResult}.</li>
 *   <li>{@code handleCallback}/{@code query}: query
 *       {@code /v1/accounts/{address}/transactions/trc20} and look for an inbound USDT transfer
 *       (contract {@code TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t}) to the receive address with the
 *       expected amount and {@code confirmations >= confirm_blocks}.</li>
 * </ul>
 *
 * <p>USDT-TRC20 has 6 decimals. Crypto channels have no signed push webhook, so
 * {@code handleCallback} re-derives the on-chain truth via TronGrid (the body is untrusted and
 * only used for the order number); success requires a confirmed matching transfer. Credentials
 * (never logged): {@code receiveAddress}, optional {@code apiKey} (TRON-PRO-API-KEY). Host follows
 * {@code env_mode}: production = mainnet TronGrid; sandbox = Shasta TronGrid.</p>
 */
@Slf4j
@Component
public class UsdtTrc20Adapter extends AbstractStubAdapter {

    private static final String USDT_CONTRACT = "TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t";
    private static final String PROD_HOST = "https://api.trongrid.io";
    private static final String SANDBOX_HOST = "https://api.shasta.trongrid.io";
    private static final BigDecimal USDT_SCALE = BigDecimal.valueOf(1_000_000L); // 6 decimals
    private static final int USDT_DECIMALS = 6;
    private static final int DEFAULT_CONFIRM_BLOCKS = 1;
    private static final long HTTP_TIMEOUT_SECONDS = 15;
    /** Tron's nominal block interval (~3s) used to approximate confirmations from block age. */
    private static final long TRON_BLOCK_INTERVAL_MS = 3000L;

    private final WebClient webClient;
    private final ObjectMapper objectMapper = new ObjectMapper();

    public UsdtTrc20Adapter(AesUtil aesUtil, WebClient.Builder webClientBuilder) {
        super(aesUtil);
        this.webClient = webClientBuilder.build();
    }

    @Override
    public String code() {
        return "usdt_trc20";
    }

    private String host(PayChannelConfig c) {
        return "sandbox".equalsIgnoreCase(c.getEnvMode()) ? SANDBOX_HOST : PROD_HOST;
    }

    @Override
    public PrepayResult createOrder(FinRechargeOrder o, PayChannelConfig c) {
        String receive = cred(c, "receiveAddress");
        if (receive == null) {
            throw new BizException(ErrorCode.PAY_CHANNEL_DISABLED, "usdt_trc20 not configured");
        }
        PrepayResult r = new PrepayResult();
        r.setAddress(receive);
        Map<String, Object> raw = new HashMap<>();
        raw.put("network", "TRC20");
        raw.put("contract", USDT_CONTRACT);
        raw.put("expectedAmount", o.getAmount().setScale(USDT_DECIMALS, RoundingMode.HALF_UP).toPlainString());
        raw.put("memo", o.getOrderNo());
        r.setRaw(raw);
        return r;
    }

    @Override
    public CallbackResult handleCallback(String body, Map<String, String> headers, PayChannelConfig c) {
        // Crypto: no signed push. The order number must be carried in the (untrusted) body; the
        // authoritative check is the on-chain match below. We never credit without a confirmed tx.
        CallbackResult r = new CallbackResult();
        r.setSuccess(false);
        try {
            String orderNo = null;
            BigDecimal amount = null;
            if (body != null && !body.isBlank()) {
                JsonNode node = objectMapper.readTree(body);
                orderNo = node.path("orderNo").asText(null);
                if (node.hasNonNull("amount")) {
                    amount = new BigDecimal(node.path("amount").asText());
                }
            }
            if (orderNo == null) {
                return r;
            }
            ChainMatch m = findConfirmedTransfer(c, amount);
            if (m == null) {
                return r;
            }
            r.setOrderNo(orderNo);
            r.setThirdTxnId(m.txId());
            r.setAmount(m.amount());
            r.setCurrency("USDT");
            r.setSuccess(true);
            return r;
        } catch (Exception e) {
            log.warn("usdt_trc20 callback handling failed: {}", e.getMessage());
            r.setSuccess(false);
            return r;
        }
    }

    @Override
    public OrderStatus query(String orderNo, PayChannelConfig c) {
        try {
            ChainMatch m = findConfirmedTransfer(c, null);
            return m != null ? OrderStatus.PAID : OrderStatus.PENDING;
        } catch (Exception e) {
            log.warn("usdt_trc20 query failed for {}: {}", orderNo, e.getMessage());
            return OrderStatus.PENDING;
        }
    }

    // ---------- helpers ----------

    private record ChainMatch(String txId, BigDecimal amount) {
    }

    /**
     * Find an inbound USDT-TRC20 transfer to the receive address. If {@code expectedAmount} is
     * non-null, the transfer value must match exactly. Enforces {@code confirm_blocks} via the
     * latest-block height returned by TronGrid.
     */
    private ChainMatch findConfirmedTransfer(PayChannelConfig c, BigDecimal expectedAmount) {
        String receive = cred(c, "receiveAddress");
        if (receive == null) {
            return null;
        }
        String apiKey = cred(c, "apiKey");
        int confirmBlocks = c.getConfirmBlocks() != null ? c.getConfirmBlocks() : DEFAULT_CONFIRM_BLOCKS;

        String url = host(c) + "/v1/accounts/" + receive
                + "/transactions/trc20?only_to=true&limit=50&contract_address=" + USDT_CONTRACT;
        try {
            WebClient.RequestHeadersSpec<?> spec = webClient.get().uri(url);
            if (apiKey != null) {
                spec = spec.header("TRON-PRO-API-KEY", apiKey);
            }
            String resp = spec.retrieve().bodyToMono(String.class)
                    .block(Duration.ofSeconds(HTTP_TIMEOUT_SECONDS));
            if (resp == null) {
                return null;
            }
            JsonNode root = objectMapper.readTree(resp);
            JsonNode data = root.path("data");
            if (!data.isArray()) {
                return null;
            }
            long nowMs = System.currentTimeMillis();
            for (JsonNode tx : data) {
                if (!receive.equals(tx.path("to").asText(""))) {
                    continue;
                }
                String tokenContract = tx.path("token_info").path("address").asText("");
                if (!USDT_CONTRACT.equals(tokenContract)) {
                    continue;
                }
                // value is an integer string in token base units (6 decimals)
                String rawValue = tx.path("value").asText("0");
                BigDecimal value = new BigDecimal(rawValue)
                        .divide(USDT_SCALE, USDT_DECIMALS, RoundingMode.DOWN);
                if (expectedAmount != null
                        && value.compareTo(expectedAmount.setScale(USDT_DECIMALS, RoundingMode.DOWN)) != 0) {
                    continue;
                }
                // Confirmation gate: approximate via block time vs Tron's ~3s block interval.
                long blockTs = tx.path("block_timestamp").asLong(0);
                if (blockTs > 0) {
                    long ageBlocks = (nowMs - blockTs) / TRON_BLOCK_INTERVAL_MS;
                    if (ageBlocks < confirmBlocks) {
                        log.debug("usdt_trc20 tx {} has only ~{} confirmations (<{})",
                                tx.path("transaction_id").asText(""), ageBlocks, confirmBlocks);
                        continue;
                    }
                }
                return new ChainMatch(tx.path("transaction_id").asText(""), value);
            }
            return null;
        } catch (Exception e) {
            log.warn("usdt_trc20 trongrid query failed: {}", e.getMessage());
            return null;
        }
    }
}
