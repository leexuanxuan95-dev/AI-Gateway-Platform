package com.aigateway.modules.payment.adapter;

import com.aigateway.common.crypto.AesUtil;
import com.aigateway.common.exception.BizException;
import com.aigateway.common.exception.ErrorCode;
import com.aigateway.modules.finance.entity.FinRechargeOrder;
import com.aigateway.modules.payment.entity.PayChannelConfig;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;

import javax.crypto.Cipher;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.nio.charset.StandardCharsets;
import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.Signature;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.security.spec.PKCS8EncodedKeySpec;
import java.time.Duration;
import java.util.Base64;
import java.util.Map;

/**
 * Functional WeChat Pay v3 adapter (design doc §10.2) implemented with only
 * {@code java.security}/{@code javax.crypto} and {@link WebClient} (no wechatpay-java SDK).
 *
 * <ul>
 *   <li>{@code createOrder}: POST {@code /v3/pay/transactions/native} with the v3
 *       {@code Authorization: WECHATPAY2-SHA256-RSA2048 ...} header (signature = RSA SHA256 over
 *       {@code METHOD\nURL\nTIMESTAMP\nNONCE\nBODY}); returns {@code code_url} as the QR payload.</li>
 *   <li>{@code handleCallback}: verifies {@code Wechatpay-Signature} (RSA SHA256 over
 *       {@code timestamp\nnonce\nbody} using the WeChat Pay platform certificate public key),
 *       then AES-256-GCM decrypts the {@code resource} ciphertext with the APIv3 key
 *       ({@code nonce} + {@code associated_data} + {@code ciphertext}); requires
 *       {@code trade_state=SUCCESS}.</li>
 *   <li>{@code query}: signed GET {@code /v3/pay/transactions/out-trade-no/{no}?mchid=}.</li>
 * </ul>
 *
 * <p>Credentials (AES-encrypted at rest, never logged): {@code appId}, {@code mchId},
 * {@code apiV3Key} (32 bytes), {@code merchantPrivateKey} (PKCS8 base64), {@code merchantSerialNo}
 * (cert serial for the request signature), {@code platformPublicKey} (WeChat Pay platform
 * certificate, PEM or base64 DER, used to verify callback signatures). Host is always
 * {@code https://api.mch.weixin.qq.com} (WeChat Pay v3 has no separate sandbox host).</p>
 */
@Slf4j
@Component
public class WechatAdapter extends AbstractStubAdapter {

    private static final String HOST = "https://api.mch.weixin.qq.com";
    private static final SecureRandom RANDOM = new SecureRandom();

    private final WebClient webClient;
    private final ObjectMapper objectMapper = new ObjectMapper();

    @Value("${aigateway.pay.wechat.notify-url:https://app.example.com/api/pay/callback/wechat}")
    private String notifyUrl;

    public WechatAdapter(AesUtil aesUtil, WebClient.Builder webClientBuilder) {
        super(aesUtil);
        this.webClient = webClientBuilder.build();
    }

    @Override
    public String code() {
        return "wechat";
    }

    @Override
    public PrepayResult createOrder(FinRechargeOrder o, PayChannelConfig c) {
        String appId = cred(c, "appId");
        String mchId = cred(c, "mchId");
        String privateKey = cred(c, "merchantPrivateKey");
        String serialNo = cred(c, "merchantSerialNo");
        if (appId == null || mchId == null || privateKey == null || serialNo == null) {
            throw new BizException(ErrorCode.PAY_CHANNEL_DISABLED, "wechat not configured");
        }
        try {
            // amount in cents (WeChat uses fen)
            long total = o.getAmount().multiply(BigDecimal.valueOf(100))
                    .setScale(0, RoundingMode.HALF_UP).longValueExact();
            String currency = o.getCurrency() != null ? o.getCurrency().toUpperCase() : "CNY";

            ObjectNode bodyNode = objectMapper.createObjectNode();
            bodyNode.put("appid", appId);
            bodyNode.put("mchid", mchId);
            bodyNode.put("description", "Account recharge " + o.getOrderNo());
            bodyNode.put("out_trade_no", o.getOrderNo());
            bodyNode.put("notify_url", notifyUrl);
            ObjectNode amountNode = bodyNode.putObject("amount");
            amountNode.put("total", total);
            amountNode.put("currency", currency);
            String body = objectMapper.writeValueAsString(bodyNode);

            String path = "/v3/pay/transactions/native";
            String auth = buildAuthHeader("POST", path, body, mchId, serialNo, privateKey);

            String resp = webClient.post().uri(HOST + path)
                    .header("Authorization", auth)
                    .header("Accept", "application/json")
                    .contentType(MediaType.APPLICATION_JSON)
                    .bodyValue(body)
                    .retrieve()
                    .bodyToMono(String.class)
                    .block(Duration.ofSeconds(15));

            JsonNode root = objectMapper.readTree(resp);
            String codeUrl = root.path("code_url").asText(null);
            if (codeUrl == null) {
                log.warn("wechat create order no code_url for {}", o.getOrderNo());
                throw new BizException(ErrorCode.SYSTEM_ERROR, "wechat create order failed");
            }
            PrepayResult r = new PrepayResult();
            r.setQrCode(codeUrl);
            return r;
        } catch (BizException e) {
            throw e;
        } catch (Exception e) {
            log.error("wechat create order failed for {}: {}", o.getOrderNo(), e.getMessage());
            throw new BizException(ErrorCode.SYSTEM_ERROR, "wechat create order failed");
        }
    }

    @Override
    public CallbackResult handleCallback(String body, Map<String, String> headers, PayChannelConfig c) {
        CallbackResult r = new CallbackResult();
        r.setSuccess(false);
        try {
            String timestamp = header(headers, "Wechatpay-Timestamp");
            String nonce = header(headers, "Wechatpay-Nonce");
            String signature = header(headers, "Wechatpay-Signature");
            String platformPublicKey = cred(c, "platformPublicKey");
            String apiV3Key = cred(c, "apiV3Key");
            if (timestamp == null || nonce == null || signature == null
                    || platformPublicKey == null || apiV3Key == null || body == null) {
                log.warn("wechat callback missing signature/headers/keys");
                return r;
            }
            // 1) verify signature over timestamp\nnonce\nbody using platform cert public key
            String message = timestamp + "\n" + nonce + "\n" + body + "\n";
            if (!verifyPlatformSignature(message, signature, platformPublicKey)) {
                log.warn("wechat callback signature invalid");
                return r;
            }
            // 2) decrypt the resource (AES-256-GCM with apiV3Key)
            JsonNode root = objectMapper.readTree(body);
            if (!"TRANSACTION.SUCCESS".equals(root.path("event_type").asText(""))) {
                return r;
            }
            JsonNode resource = root.path("resource");
            String associatedData = resource.path("associated_data").asText("");
            String resNonce = resource.path("nonce").asText("");
            String ciphertext = resource.path("ciphertext").asText("");
            String plain = aesGcmDecrypt(apiV3Key, associatedData, resNonce, ciphertext);
            JsonNode tx = objectMapper.readTree(plain);

            if (!"SUCCESS".equals(tx.path("trade_state").asText(""))) {
                return r;
            }
            r.setOrderNo(tx.path("out_trade_no").asText(null));
            r.setThirdTxnId(tx.path("transaction_id").asText(null));
            JsonNode amount = tx.path("amount");
            if (amount.has("total")) {
                r.setAmount(BigDecimal.valueOf(amount.path("total").asLong())
                        .divide(BigDecimal.valueOf(100), 2, RoundingMode.HALF_UP));
            }
            if (amount.has("currency")) {
                r.setCurrency(amount.path("currency").asText().toUpperCase());
            }
            r.setSuccess(true);
            return r;
        } catch (Exception e) {
            log.warn("wechat callback handling failed: {}", e.getMessage());
            r.setSuccess(false);
            return r;
        }
    }

    @Override
    public OrderStatus query(String orderNo, PayChannelConfig c) {
        String mchId = cred(c, "mchId");
        String privateKey = cred(c, "merchantPrivateKey");
        String serialNo = cred(c, "merchantSerialNo");
        if (mchId == null || privateKey == null || serialNo == null) {
            return OrderStatus.PENDING;
        }
        try {
            String path = "/v3/pay/transactions/out-trade-no/" + orderNo + "?mchid=" + mchId;
            String auth = buildAuthHeader("GET", path, "", mchId, serialNo, privateKey);
            String resp = webClient.get().uri(HOST + path)
                    .header("Authorization", auth)
                    .header("Accept", "application/json")
                    .retrieve()
                    .bodyToMono(String.class)
                    .block(Duration.ofSeconds(15));
            JsonNode root = objectMapper.readTree(resp);
            String state = root.path("trade_state").asText("");
            if ("SUCCESS".equals(state)) {
                return OrderStatus.PAID;
            }
            if ("CLOSED".equals(state) || "REVOKED".equals(state) || "PAYERROR".equals(state)) {
                return OrderStatus.FAILED;
            }
            return OrderStatus.PENDING;
        } catch (Exception e) {
            log.warn("wechat query failed for {}: {}", orderNo, e.getMessage());
            return OrderStatus.PENDING;
        }
    }

    // ---------- helpers ----------

    /** Build the WECHATPAY2-SHA256-RSA2048 Authorization header. */
    private String buildAuthHeader(String method, String urlPath, String body,
                                   String mchId, String serialNo, String privateKeyB64) throws Exception {
        long timestamp = System.currentTimeMillis() / 1000;
        String nonce = randomHex(32);
        String message = method + "\n" + urlPath + "\n" + timestamp + "\n" + nonce + "\n" + body + "\n";
        String signature = rsaSign(message, privateKeyB64);
        return "WECHATPAY2-SHA256-RSA2048 "
                + "mchid=\"" + mchId + "\","
                + "nonce_str=\"" + nonce + "\","
                + "timestamp=\"" + timestamp + "\","
                + "serial_no=\"" + serialNo + "\","
                + "signature=\"" + signature + "\"";
    }

    private String rsaSign(String content, String privateKeyB64) throws Exception {
        byte[] keyBytes = Base64.getDecoder().decode(normalizePem(privateKeyB64));
        PrivateKey priv = KeyFactory.getInstance("RSA")
                .generatePrivate(new PKCS8EncodedKeySpec(keyBytes));
        Signature sig = Signature.getInstance("SHA256withRSA");
        sig.initSign(priv);
        sig.update(content.getBytes(StandardCharsets.UTF_8));
        return Base64.getEncoder().encodeToString(sig.sign());
    }

    /**
     * Verify a callback signature. {@code platformPublicKey} may be a PEM/DER X.509 certificate
     * (preferred) or a raw RSA public key; we extract the public key from a certificate when given.
     */
    private boolean verifyPlatformSignature(String message, String signatureB64, String platformPublicKey) {
        try {
            PublicKey pub = loadPublicKey(platformPublicKey);
            Signature sig = Signature.getInstance("SHA256withRSA");
            sig.initVerify(pub);
            sig.update(message.getBytes(StandardCharsets.UTF_8));
            return sig.verify(Base64.getDecoder().decode(signatureB64));
        } catch (Exception e) {
            log.warn("wechat platform signature verify error: {}", e.getMessage());
            return false;
        }
    }

    private PublicKey loadPublicKey(String material) throws Exception {
        byte[] der = Base64.getDecoder().decode(normalizePem(material));
        // Try as an X.509 certificate first (WeChat Pay platform cert), then as a raw public key.
        try {
            CertificateFactory cf = CertificateFactory.getInstance("X.509");
            X509Certificate cert = (X509Certificate) cf.generateCertificate(
                    new java.io.ByteArrayInputStream(der));
            return cert.getPublicKey();
        } catch (Exception ignore) {
            return KeyFactory.getInstance("RSA")
                    .generatePublic(new java.security.spec.X509EncodedKeySpec(der));
        }
    }

    /** AES-256-GCM decrypt: tag is appended to ciphertext per WeChat Pay v3. */
    private String aesGcmDecrypt(String apiV3Key, String associatedData, String nonce,
                                 String ciphertextB64) throws Exception {
        byte[] key = apiV3Key.getBytes(StandardCharsets.UTF_8);
        if (key.length != 32) {
            throw new IllegalStateException("apiV3Key must be 32 bytes");
        }
        byte[] cipherBytes = Base64.getDecoder().decode(ciphertextB64);
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.DECRYPT_MODE, new SecretKeySpec(key, "AES"),
                new GCMParameterSpec(128, nonce.getBytes(StandardCharsets.UTF_8)));
        if (associatedData != null && !associatedData.isEmpty()) {
            cipher.updateAAD(associatedData.getBytes(StandardCharsets.UTF_8));
        }
        return new String(cipher.doFinal(cipherBytes), StandardCharsets.UTF_8);
    }

    private String randomHex(int len) {
        byte[] b = new byte[len / 2];
        RANDOM.nextBytes(b);
        StringBuilder sb = new StringBuilder();
        for (byte x : b) {
            sb.append(String.format("%02x", x));
        }
        return sb.toString();
    }

    private String normalizePem(String key) {
        return key.replaceAll("-----BEGIN [^-]+-----", "")
                .replaceAll("-----END [^-]+-----", "")
                .replaceAll("\\s", "");
    }
}
