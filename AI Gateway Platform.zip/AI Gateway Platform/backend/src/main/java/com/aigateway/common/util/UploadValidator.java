package com.aigateway.common.util;

import com.aigateway.common.exception.BizException;
import com.aigateway.common.exception.ErrorCode;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import java.util.Locale;
import java.util.Set;
import java.util.regex.Pattern;

/**
 * Anti-malicious-upload validation (design doc §18). Two entry points:
 *
 * <ul>
 *   <li>{@link #validateFile(MultipartFile)} &mdash; for real multipart uploads: enforces a
 *       size ceiling, an allow-list of content-types (images + pdf), an extension allow-list and
 *       rejects path-traversal in the client-supplied filename.</li>
 *   <li>{@link #validateObjectKey(String, String)} &mdash; for endpoints that accept only an
 *       object-store <em>key</em> string (the bytes were uploaded out-of-band): rejects
 *       path-traversal ({@code ..}), absolute/UNC paths, control characters and out-of-charset
 *       keys, and enforces the same extension allow-list. The object-store upload service that
 *       mints these keys MUST still validate the actual bytes/content-type at write time &mdash;
 *       this is a defense-in-depth check on what the console submits, not a substitute.</li>
 * </ul>
 *
 * <p>All failures raise {@link BizException} with {@link ErrorCode#PARAM_ERROR}.</p>
 */
public final class UploadValidator {

    /** Maximum accepted document/image upload size in bytes (10 MiB). */
    public static final long MAX_FILE_BYTES = 10L * 1024 * 1024;

    /** Maximum accepted audio upload size in bytes (25 MiB; matches common ASR provider limits). */
    public static final long MAX_AUDIO_BYTES = 25L * 1024 * 1024;

    /** Allowed content-types for document/image uploads. */
    private static final Set<String> ALLOWED_CONTENT_TYPES = Set.of(
            "image/jpeg", "image/png", "image/webp", "image/gif", "application/pdf");

    /** Allowed lower-cased audio extensions for transcription uploads. */
    private static final Set<String> ALLOWED_AUDIO_EXTENSIONS = Set.of(
            "mp3", "mp4", "mpeg", "mpga", "m4a", "wav", "webm", "flac", "ogg", "oga");

    /** Allowed lower-cased file extensions (without the dot). */
    private static final Set<String> ALLOWED_EXTENSIONS = Set.of(
            "jpg", "jpeg", "png", "webp", "gif", "pdf");

    /**
     * Allowed object-key charset: letters, digits and a small set of safe separators. Deliberately
     * excludes {@code ..}-forming sequences, whitespace and shell/URL metacharacters.
     */
    private static final Pattern SAFE_KEY = Pattern.compile("^[A-Za-z0-9._/\\-]+$");

    /** Maximum accepted object-key length. */
    private static final int MAX_KEY_LEN = 512;

    private UploadValidator() {
    }

    /**
     * Validate an actual multipart upload: non-empty, within {@link #MAX_FILE_BYTES}, an allowed
     * content-type, an allowed extension and a traversal-free filename.
     */
    public static void validateFile(MultipartFile file) {
        if (file == null || file.isEmpty()) {
            throw new BizException(ErrorCode.PARAM_ERROR, "upload is empty");
        }
        if (file.getSize() > MAX_FILE_BYTES) {
            throw new BizException(ErrorCode.PARAM_ERROR, "upload exceeds the size limit");
        }
        String contentType = file.getContentType();
        if (contentType == null
                || !ALLOWED_CONTENT_TYPES.contains(contentType.toLowerCase(Locale.ROOT))) {
            throw new BizException(ErrorCode.PARAM_ERROR, "unsupported content type");
        }
        String filename = file.getOriginalFilename();
        if (!StringUtils.hasText(filename)) {
            throw new BizException(ErrorCode.PARAM_ERROR, "upload has no filename");
        }
        assertNoTraversal(filename);
        assertAllowedExtension(filename);
    }

    /**
     * Validate an object-store key supplied by the console (no bytes handled here).
     *
     * @param field human-readable field name for the error message
     * @param key   the object-store key
     */
    public static void validateObjectKey(String field, String key) {
        if (!StringUtils.hasText(key)) {
            throw new BizException(ErrorCode.PARAM_ERROR, field + " is required");
        }
        if (key.length() > MAX_KEY_LEN) {
            throw new BizException(ErrorCode.PARAM_ERROR, field + " is too long");
        }
        assertNoTraversal(key);
        if (key.startsWith("/") || key.startsWith("\\") || key.contains("\\")) {
            throw new BizException(ErrorCode.PARAM_ERROR, field + " has an invalid path");
        }
        if (!SAFE_KEY.matcher(key).matches()) {
            throw new BizException(ErrorCode.PARAM_ERROR, field + " contains illegal characters");
        }
        assertAllowedExtension(key);
    }

    /**
     * Validate an audio upload for transcription passthrough: non-empty, within
     * {@link #MAX_AUDIO_BYTES}, a traversal-free filename and an allowed audio extension.
     * Content-type is intentionally not allow-listed here because clients send a wide and
     * inconsistent set of audio MIME types; the extension + size + filename checks are the guard.
     */
    public static void validateAudioFile(MultipartFile file) {
        if (file == null || file.isEmpty()) {
            throw new BizException(ErrorCode.PARAM_ERROR, "upload is empty");
        }
        if (file.getSize() > MAX_AUDIO_BYTES) {
            throw new BizException(ErrorCode.PARAM_ERROR, "audio upload exceeds the size limit");
        }
        String filename = file.getOriginalFilename();
        if (!StringUtils.hasText(filename)) {
            throw new BizException(ErrorCode.PARAM_ERROR, "upload has no filename");
        }
        assertNoTraversal(filename);
        int dot = filename.lastIndexOf('.');
        if (dot < 0 || dot == filename.length() - 1) {
            throw new BizException(ErrorCode.PARAM_ERROR, "upload has no file extension");
        }
        String ext = filename.substring(dot + 1).toLowerCase(Locale.ROOT);
        if (!ALLOWED_AUDIO_EXTENSIONS.contains(ext)) {
            throw new BizException(ErrorCode.PARAM_ERROR, "unsupported audio format");
        }
    }

    /** Reject any path-traversal sequence in a filename/key. */
    private static void assertNoTraversal(String value) {
        if (value.contains("..") || value.contains("\0")) {
            throw new BizException(ErrorCode.PARAM_ERROR, "illegal path in upload name");
        }
    }

    /** Enforce the extension allow-list against the trailing token after the last dot. */
    private static void assertAllowedExtension(String name) {
        int dot = name.lastIndexOf('.');
        if (dot < 0 || dot == name.length() - 1) {
            throw new BizException(ErrorCode.PARAM_ERROR, "upload has no file extension");
        }
        String ext = name.substring(dot + 1).toLowerCase(Locale.ROOT);
        if (!ALLOWED_EXTENSIONS.contains(ext)) {
            throw new BizException(ErrorCode.PARAM_ERROR, "unsupported file extension");
        }
    }
}
