package com.aigateway.common.security;

import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.annotation.Order;
import org.springframework.http.MediaType;
import org.springframework.lang.NonNull;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.regex.Pattern;

/**
 * Lightweight application WAF (design doc §18 / §12 risk control): inspects the request
 * line, query string and a few high-risk headers for common attack signatures
 * (SQL injection, XSS, path traversal, command/OGNL injection, log4shell) and blocks
 * obvious scanner traffic. Runs very early, before auth.
 *
 * <p>This is a defense-in-depth backstop, NOT a substitute for a real edge WAF — it only
 * scans the URI/query/headers (cheap) and never the body (handlers use parameterized
 * MyBatis + bean validation). It deliberately errs toward low false positives.</p>
 */
@Slf4j
@Order(0)
@Component
public class WafFilter extends OncePerRequestFilter {

    private static final int MAX_SCAN_LEN = 8192;

    /** Attack-signature patterns (case-insensitive). */
    private static final Pattern SQLI = Pattern.compile(
            "(?i)(\\bunion\\b\\s+\\bselect\\b|\\bselect\\b.+\\bfrom\\b|\\binsert\\b\\s+\\binto\\b|" +
            "\\bdelete\\b\\s+\\bfrom\\b|\\bdrop\\b\\s+\\btable\\b|\\bupdate\\b.+\\bset\\b|" +
            "\\bor\\b\\s+1\\s*=\\s*1|;\\s*--|/\\*.*\\*/|\\bsleep\\s*\\(|\\bbenchmark\\s*\\()");
    private static final Pattern XSS = Pattern.compile(
            "(?i)(<script\\b|javascript:|onerror\\s*=|onload\\s*=|<iframe\\b|document\\.cookie|" +
            "<img[^>]+src[^>]+onerror)");
    private static final Pattern TRAVERSAL = Pattern.compile(
            "(\\.\\./|\\.\\.\\\\|%2e%2e%2f|%2e%2e/|/etc/passwd|c:\\\\windows)");
    private static final Pattern CMD_OGNL = Pattern.compile(
            "(?i)(\\$\\{jndi:|\\$\\{.*:-|%24%7bjndi|\\bRuntime\\b.*\\bexec\\b|/bin/(ba)?sh|\\bnc\\s+-e)");
    /** Known scanner / vuln-probe user agents. */
    private static final Pattern BAD_UA = Pattern.compile(
            "(?i)(sqlmap|nikto|nessus|acunetix|nmap|masscan|dirbuster|gobuster|wpscan|" +
            "havij|hydra|fimap|zgrab)");

    private final ObjectMapper objectMapper = new ObjectMapper();

    @Override
    protected boolean shouldNotFilter(@NonNull HttpServletRequest request) {
        // never scan the model-traffic body endpoints' bodies (we don't read bodies anyway);
        // still scan their URI/query though, so do not skip.
        return false;
    }

    @Override
    protected void doFilterInternal(@NonNull HttpServletRequest request,
                                    @NonNull HttpServletResponse response,
                                    @NonNull FilterChain chain) throws ServletException, IOException {
        String ua = request.getHeader("User-Agent");
        if (ua != null && BAD_UA.matcher(ua).find()) {
            block(response, request, "scanner user-agent");
            return;
        }
        String target = decode(request.getRequestURI() + "?"
                + (request.getQueryString() == null ? "" : request.getQueryString()));
        if (target.length() > MAX_SCAN_LEN) {
            target = target.substring(0, MAX_SCAN_LEN);
        }
        String hit = match(target);
        if (hit == null) {
            // also scan a couple of commonly-abused headers
            hit = match(decode(safe(request.getHeader("Referer")) + " " + safe(request.getHeader("X-Forwarded-For"))));
        }
        if (hit != null) {
            block(response, request, hit);
            return;
        }
        chain.doFilter(request, response);
    }

    private String match(String s) {
        if (s == null || s.isEmpty()) {
            return null;
        }
        if (SQLI.matcher(s).find()) {
            return "sqli";
        }
        if (XSS.matcher(s).find()) {
            return "xss";
        }
        if (TRAVERSAL.matcher(s).find()) {
            return "path-traversal";
        }
        if (CMD_OGNL.matcher(s).find()) {
            return "cmd/jndi";
        }
        return null;
    }

    private void block(HttpServletResponse response, HttpServletRequest request, String reason)
            throws IOException {
        String ip = AuthRateLimitFilter.clientIp(request);
        log.warn("[WAF] blocked {} {} from {} reason={}", request.getMethod(),
                request.getRequestURI(), ip, reason);
        response.setStatus(HttpServletResponse.SC_FORBIDDEN);
        response.setContentType(MediaType.APPLICATION_JSON_VALUE);
        objectMapper.writeValue(response.getOutputStream(),
                Map.of("code", 403, "msg", "request blocked by security policy"));
    }

    private String decode(String s) {
        if (s == null) {
            return "";
        }
        try {
            // double-decode to catch %2e%2e style evasions
            return URLDecoder.decode(URLDecoder.decode(s, StandardCharsets.UTF_8), StandardCharsets.UTF_8);
        } catch (Exception e) {
            return s;
        }
    }

    private String safe(String s) {
        return s == null ? "" : s;
    }
}
