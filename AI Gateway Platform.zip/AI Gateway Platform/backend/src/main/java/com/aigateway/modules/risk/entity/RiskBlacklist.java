package com.aigateway.modules.risk.entity;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.time.OffsetDateTime;

/**
 * Blacklist entry (table {@code risk_blacklist}, design doc §12). An entry blocks a
 * dimension {@code value} of a given {@code type}; honoring {@code expireAt} (null = permanent).
 */
@Data
@TableName(value = "risk_blacklist", autoResultMap = true)
public class RiskBlacklist {

    @TableId(type = IdType.AUTO)
    private Long id;

    /** ip / country / user. */
    private String type;

    private String value;

    private String reason;

    /** Expiry; null means permanent. */
    private OffsetDateTime expireAt;

    @TableField(fill = FieldFill.INSERT)
    private OffsetDateTime createdAt;
}
