package com.aigateway.modules.finance.service;

import com.aigateway.common.api.PageResult;
import com.aigateway.modules.finance.dto.WithdrawAuditRequest;
import com.aigateway.modules.finance.dto.WithdrawRequest;
import com.aigateway.modules.finance.entity.FinWithdrawOrder;

/** Withdrawal apply / list / audit (design doc §10). */
public interface WithdrawService {

    /** Apply: freeze the amount and create a pending withdraw order. */
    FinWithdrawOrder apply(Long companyId, Long userId, WithdrawRequest req);

    /** List withdraw orders for the current company. */
    PageResult<FinWithdrawOrder> list(Long companyId, long current, long size);

    /** Super-admin: approve (pay via Wise stub) or reject (unfreeze). */
    FinWithdrawOrder audit(Long orderId, Long auditorId, WithdrawAuditRequest req);
}
