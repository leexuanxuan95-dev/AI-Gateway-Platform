package com.aigateway.modules.user.dto;

import lombok.Data;

/** Editable profile fields. */
@Data
public class ProfileUpdateRequest {

    private String nickname;

    private String avatar;
}
