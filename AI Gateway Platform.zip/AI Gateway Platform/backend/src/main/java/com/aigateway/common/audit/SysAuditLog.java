package com.aigateway.common.audit;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.time.OffsetDateTime;

/** Operation audit record (design doc §18). */
@Data
@TableName("sys_audit_log")
public class SysAuditLog {

    @TableId(type = IdType.AUTO)
    private Long id;
    private Long userId;
    private Long companyId;
    private String module;
    private String action;
    private String method;
    private String uri;
    private String ip;
    private String requestId;
    /** 1 success 0 failure. */
    private Integer status;
    private String errorMsg;
    private Long costMs;
    private OffsetDateTime createdAt;
}
