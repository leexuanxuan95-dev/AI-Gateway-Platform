package com.aigateway.modules.finance.entity;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.aigateway.common.enums.WithdrawStatus;
import com.baomidou.mybatisplus.extension.handlers.JacksonTypeHandler;
import lombok.Data;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.Map;

/**
 * Withdraw order (table {@code fin_withdraw_order}, design doc §10).
 * {@code accountInfo} stores the beneficiary bank/crypto details AES-encrypted
 * at rest (a JSON string ciphertext), never in plaintext.
 */
@Data
@TableName(value = "fin_withdraw_order", autoResultMap = true)
public class FinWithdrawOrder {

    @TableId(type = IdType.AUTO)
    private Long id;

    private String orderNo;

    private Long companyId;

    private BigDecimal amount;

    private BigDecimal fee;

    /** wise/bank/usdt. */
    private String channel;

    /**
     * Beneficiary account info stored as a JSONB envelope {@code {"enc": "<ciphertext>"}}
     * where the ciphertext is AES-encrypted JSON. Never store plaintext here.
     */
    @TableField(typeHandler = JacksonTypeHandler.class)
    private Map<String, Object> accountInfo;

    /** 0 pending / 1 approved / 2 rejected / 3 paid / 4 failed. */
    private WithdrawStatus status;

    private Long auditBy;

    private OffsetDateTime auditAt;

    private OffsetDateTime paidAt;

    @TableField(fill = FieldFill.INSERT)
    private OffsetDateTime createdAt;
}
