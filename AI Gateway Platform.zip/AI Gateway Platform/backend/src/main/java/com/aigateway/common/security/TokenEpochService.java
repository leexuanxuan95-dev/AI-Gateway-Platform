package com.aigateway.common.security;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

/**
 * Per-user token epoch for immediate "revoke all sessions" of already-issued, still-valid
 * access tokens (design doc §18). Each access token embeds the epoch in effect when it was
 * minted; {@link #bump(Long)} advances the epoch so every token minted earlier is rejected
 * by {@link JwtAuthFilter} on its next request. Call {@code bump} on password change,
 * forced logout, account disable, or suspected compromise.
 *
 * <p>Fail-open: if Redis is unavailable, the epoch reads as 0 and tokens are not rejected
 * solely on this check (availability over this single defense layer).</p>
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class TokenEpochService {

    private static final String KEY_PREFIX = "gw:jwt:epoch:";

    private final StringRedisTemplate redis;

    public long current(Long userId) {
        try {
            String v = redis.opsForValue().get(KEY_PREFIX + userId);
            return v == null ? 0L : Long.parseLong(v);
        } catch (Exception e) {
            log.debug("token epoch read failed for {}: {}", userId, e.getMessage());
            return 0L;
        }
    }

    /** Advance the epoch, invalidating all access tokens minted before now. */
    public void bump(Long userId) {
        try {
            redis.opsForValue().set(KEY_PREFIX + userId, String.valueOf(System.currentTimeMillis()));
        } catch (Exception e) {
            log.warn("token epoch bump failed for {}: {}", userId, e.getMessage());
        }
    }
}
