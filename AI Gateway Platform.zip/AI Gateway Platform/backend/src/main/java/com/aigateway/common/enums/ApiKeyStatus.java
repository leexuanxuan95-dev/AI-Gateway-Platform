package com.aigateway.common.enums;

import com.baomidou.mybatisplus.annotation.EnumValue;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;

/** biz_api_key.status. */
@Getter
public enum ApiKeyStatus implements CodedEnum<Integer> {

    ACTIVE(1),
    DISABLED(2),
    DELETED(3);

    @EnumValue
    @JsonValue
    private final Integer code;

    ApiKeyStatus(Integer code) {
        this.code = code;
    }

    @JsonCreator
    public static ApiKeyStatus of(Integer code) {
        if (code == null) {
            return null;
        }
        for (ApiKeyStatus v : values()) {
            if (v.code.equals(code)) {
                return v;
            }
        }
        return null;
    }
}
