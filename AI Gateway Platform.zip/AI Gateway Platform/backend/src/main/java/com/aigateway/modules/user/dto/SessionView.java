package com.aigateway.modules.user.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/** A single active device/session (refresh token) for the current user (design doc §3.3). */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class SessionView implements Serializable {

    /** Opaque refresh-token id used to revoke this specific session. */
    private String tokenId;

    private String ip;

    private String userAgent;

    /** Epoch millis the session was created. */
    private Long createdAt;

    /** Whether this id matches the refresh token presented on the listing request. */
    private boolean current;
}
