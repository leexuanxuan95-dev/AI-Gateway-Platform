package com.aigateway.modules.user.controller;

import com.aigateway.common.api.PageResult;
import com.aigateway.common.api.R;
import com.aigateway.modules.user.entity.LoginLog;
import com.aigateway.modules.user.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/** Paged login-log listing for the current user. */
@RestController
@RequestMapping("/api/user")
@RequiredArgsConstructor
public class LoginLogController {

    private final UserService userService;

    @GetMapping("/login-logs")
    public R<PageResult<LoginLog>> loginLogs(@RequestParam(defaultValue = "1") long current,
                                             @RequestParam(defaultValue = "20") long size) {
        return R.ok(userService.loginLogs(current, size));
    }
}
