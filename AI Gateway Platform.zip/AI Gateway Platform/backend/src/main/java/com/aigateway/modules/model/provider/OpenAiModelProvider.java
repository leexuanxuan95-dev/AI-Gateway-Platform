package com.aigateway.modules.model.provider;

import com.aigateway.common.crypto.AesUtil;
import com.aigateway.modules.channel.entity.Channel;
import com.fasterxml.jackson.databind.JsonNode;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.ArrayList;
import java.util.List;

/** OpenAI model catalog provider (GET {base|https://api.openai.com}/v1/models). */
@Component
public class OpenAiModelProvider extends AbstractWebClientProvider {

    public OpenAiModelProvider(WebClient.Builder builder, AesUtil aesUtil) {
        super(builder, aesUtil);
    }

    @Override
    public String name() {
        return "openai";
    }

    @Override
    public List<UpstreamModel> listModels(Channel ch) {
        List<UpstreamModel> out = new ArrayList<>();
        String key = decryptKey(ch.getApiKey());
        if (key == null) {
            return out;
        }
        String url = baseOr(ch.getBaseUrl(), "https://api.openai.com") + "/v1/models";
        JsonNode body = getJson(url, spec -> spec.header(HttpHeaders.AUTHORIZATION, "Bearer " + key));
        if (body == null) {
            return out;
        }
        JsonNode data = body.path("data");
        if (data.isArray()) {
            for (JsonNode m : data) {
                String id = m.path("id").asText(null);
                if (id == null) {
                    continue;
                }
                UpstreamModel um = new UpstreamModel();
                um.setId(id);
                um.setDisplayName(id);
                out.add(um);
            }
        }
        return out;
    }
}
