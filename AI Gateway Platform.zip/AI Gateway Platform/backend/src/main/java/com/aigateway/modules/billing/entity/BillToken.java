package com.aigateway.modules.billing.entity;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.math.BigDecimal;
import java.time.OffsetDateTime;

/**
 * Per-request token billing record (table {@code bill_token}, design doc §11). The table is
 * RANGE-partitioned by {@code created_at}; the composite PK is {@code (id, created_at)}.
 *
 * <p><b>Write-side note:</b> rows are written by the finance module's settle path (single
 * source of truth). The billing module only reads/aggregates this entity &mdash; never insert
 * here.</p>
 */
@Data
@TableName(value = "bill_token", autoResultMap = true)
public class BillToken {

    @TableId(type = IdType.AUTO)
    private Long id;

    private String requestId;

    private Long companyId;

    private Long userId;

    private Long projectId;

    private Long apiKeyId;

    private String modelCode;

    private Long channelId;

    private Integer promptTokens;

    private Integer completionTokens;

    private Integer cachedTokens;

    private Integer totalTokens;

    /** Customer charge for this request. */
    private BigDecimal cost;

    /** Upstream cost (before margin). */
    private BigDecimal upstreamCost;

    @TableField(fill = FieldFill.INSERT)
    private OffsetDateTime createdAt;
}
