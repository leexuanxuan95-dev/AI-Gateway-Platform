package com.aigateway.modules.company.entity;

import com.aigateway.common.enums.AuthStatus;
import com.aigateway.common.enums.CompanyStatus;
import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableLogic;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.time.OffsetDateTime;

/** Company / tenant entity (table {@code biz_company}). */
@Data
@TableName("biz_company")
public class Company {

    @TableId(type = IdType.AUTO)
    private Long id;

    private String companyCode;

    private String companyName;

    private String contactName;

    private String contactMobile;

    private String contactEmail;

    private String businessLicense;

    private String legalIdFront;

    private Long ownerUserId;

    private Long planId;

    private OffsetDateTime planExpireAt;

    /** 0 pending, 1 passed, 2 rejected. */
    private AuthStatus authStatus;

    /** 1 normal, 2 logged-off, 3 disabled. */
    private CompanyStatus status;

    @TableLogic
    private Integer deleted;

    @TableField(fill = FieldFill.INSERT)
    private OffsetDateTime createdAt;

    @TableField(fill = FieldFill.INSERT_UPDATE)
    private OffsetDateTime updatedAt;
}
