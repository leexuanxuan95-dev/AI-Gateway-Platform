package com.aigateway.modules.company.mapper;

import com.aigateway.modules.company.entity.CompanyMember;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/** MyBatis-Plus mapper for {@link CompanyMember}. */
public interface CompanyMemberMapper extends BaseMapper<CompanyMember> {
}
