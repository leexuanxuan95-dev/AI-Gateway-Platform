package com.aigateway.common.audit.mapper;

import com.aigateway.common.audit.SysAuditLog;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/** MyBatis-Plus mapper for {@link SysAuditLog}. */
@Mapper
public interface SysAuditLogMapper extends BaseMapper<SysAuditLog> {
}
