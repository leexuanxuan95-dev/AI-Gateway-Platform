package com.aigateway.modules.payment.adapter;

import com.aigateway.common.crypto.AesUtil;
import com.aigateway.common.exception.BizException;
import com.aigateway.common.exception.ErrorCode;
import com.aigateway.modules.finance.entity.FinRechargeOrder;
import com.aigateway.modules.payment.entity.PayChannelConfig;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Duration;
import java.util.HashMap;
import java.util.Map;

/**
 * Functional USDT (ERC20) adapter (design doc §10.2) using an Etherscan-compatible HTTP API.
 *
 * <ul>
 *   <li>{@code createOrder}: assigns the configured receive address; returns it + the expected
 *       amount in {@link PrepayResult}.</li>
 *   <li>{@code handleCallback}/{@code query}: query
 *       {@code /api?module=account&action=tokentx&contractaddress=USDT&address=...} and look for an
 *       inbound USDT transfer (contract {@code 0xdAC17F958D2ee523a2206206994597C13D831ec7}) to the
 *       receive address with the expected amount and confirmations (from the {@code confirmations}
 *       field) {@code >= confirm_blocks}.</li>
 * </ul>
 *
 * <p>USDT-ERC20 has 6 decimals. Like TRC20, crypto channels have no signed push webhook, so the
 * authoritative check is on-chain; success requires a confirmed matching transfer. Credentials
 * (never logged): {@code receiveAddress}, optional {@code apiKey} (Etherscan apikey). Host follows
 * {@code env_mode}: production = mainnet Etherscan; sandbox = Sepolia Etherscan.</p>
 */
@Slf4j
@Component
public class UsdtErc20Adapter extends AbstractStubAdapter {

    private static final String USDT_CONTRACT = "0xdAC17F958D2ee523a2206206994597C13D831ec7";
    private static final String PROD_HOST = "https://api.etherscan.io";
    private static final String SANDBOX_HOST = "https://api-sepolia.etherscan.io";
    private static final BigDecimal USDT_SCALE = BigDecimal.valueOf(1_000_000L); // 6 decimals
    private static final int USDT_DECIMALS = 6;
    private static final int DEFAULT_CONFIRM_BLOCKS = 12;
    private static final long HTTP_TIMEOUT_SECONDS = 15;

    private final WebClient webClient;
    private final ObjectMapper objectMapper = new ObjectMapper();

    public UsdtErc20Adapter(AesUtil aesUtil, WebClient.Builder webClientBuilder) {
        super(aesUtil);
        this.webClient = webClientBuilder.build();
    }

    @Override
    public String code() {
        return "usdt_erc20";
    }

    private String host(PayChannelConfig c) {
        return "sandbox".equalsIgnoreCase(c.getEnvMode()) ? SANDBOX_HOST : PROD_HOST;
    }

    @Override
    public PrepayResult createOrder(FinRechargeOrder o, PayChannelConfig c) {
        String receive = cred(c, "receiveAddress");
        if (receive == null) {
            throw new BizException(ErrorCode.PAY_CHANNEL_DISABLED, "usdt_erc20 not configured");
        }
        PrepayResult r = new PrepayResult();
        r.setAddress(receive);
        Map<String, Object> raw = new HashMap<>();
        raw.put("network", "ERC20");
        raw.put("contract", USDT_CONTRACT);
        raw.put("expectedAmount", o.getAmount().setScale(USDT_DECIMALS, RoundingMode.HALF_UP).toPlainString());
        raw.put("memo", o.getOrderNo());
        r.setRaw(raw);
        return r;
    }

    @Override
    public CallbackResult handleCallback(String body, Map<String, String> headers, PayChannelConfig c) {
        CallbackResult r = new CallbackResult();
        r.setSuccess(false);
        try {
            String orderNo = null;
            BigDecimal amount = null;
            if (body != null && !body.isBlank()) {
                JsonNode node = objectMapper.readTree(body);
                orderNo = node.path("orderNo").asText(null);
                if (node.hasNonNull("amount")) {
                    amount = new BigDecimal(node.path("amount").asText());
                }
            }
            if (orderNo == null) {
                return r;
            }
            ChainMatch m = findConfirmedTransfer(c, amount);
            if (m == null) {
                return r;
            }
            r.setOrderNo(orderNo);
            r.setThirdTxnId(m.txId());
            r.setAmount(m.amount());
            r.setCurrency("USDT");
            r.setSuccess(true);
            return r;
        } catch (Exception e) {
            log.warn("usdt_erc20 callback handling failed: {}", e.getMessage());
            r.setSuccess(false);
            return r;
        }
    }

    @Override
    public OrderStatus query(String orderNo, PayChannelConfig c) {
        try {
            ChainMatch m = findConfirmedTransfer(c, null);
            return m != null ? OrderStatus.PAID : OrderStatus.PENDING;
        } catch (Exception e) {
            log.warn("usdt_erc20 query failed for {}: {}", orderNo, e.getMessage());
            return OrderStatus.PENDING;
        }
    }

    // ---------- helpers ----------

    private record ChainMatch(String txId, BigDecimal amount) {
    }

    /**
     * Find an inbound USDT-ERC20 transfer to the receive address via the Etherscan tokentx API.
     * If {@code expectedAmount} is non-null, the value must match exactly. Enforces
     * {@code confirm_blocks} using the per-transaction {@code confirmations} field.
     */
    private ChainMatch findConfirmedTransfer(PayChannelConfig c, BigDecimal expectedAmount) {
        String receive = cred(c, "receiveAddress");
        if (receive == null) {
            return null;
        }
        String apiKey = cred(c, "apiKey");
        int confirmBlocks = c.getConfirmBlocks() != null ? c.getConfirmBlocks() : DEFAULT_CONFIRM_BLOCKS;

        StringBuilder url = new StringBuilder(host(c))
                .append("/api?module=account&action=tokentx")
                .append("&contractaddress=").append(USDT_CONTRACT)
                .append("&address=").append(receive)
                .append("&page=1&offset=50&sort=desc");
        if (apiKey != null) {
            url.append("&apikey=").append(apiKey);
        }
        try {
            String resp = webClient.get().uri(url.toString())
                    .retrieve().bodyToMono(String.class).block(Duration.ofSeconds(HTTP_TIMEOUT_SECONDS));
            if (resp == null) {
                return null;
            }
            JsonNode root = objectMapper.readTree(resp);
            if (!"1".equals(root.path("status").asText(""))) {
                // status 0 = no transactions / error message; not a match.
                return null;
            }
            JsonNode result = root.path("result");
            if (!result.isArray()) {
                return null;
            }
            for (JsonNode tx : result) {
                if (!receive.equalsIgnoreCase(tx.path("to").asText(""))) {
                    continue;
                }
                if (!USDT_CONTRACT.equalsIgnoreCase(tx.path("contractAddress").asText(""))) {
                    continue;
                }
                BigDecimal value = new BigDecimal(tx.path("value").asText("0"))
                        .divide(USDT_SCALE, USDT_DECIMALS, RoundingMode.DOWN);
                if (expectedAmount != null
                        && value.compareTo(expectedAmount.setScale(USDT_DECIMALS, RoundingMode.DOWN)) != 0) {
                    continue;
                }
                long confirmations = tx.path("confirmations").asLong(0);
                if (confirmations < confirmBlocks) {
                    log.debug("usdt_erc20 tx {} has {} confirmations (<{})",
                            tx.path("hash").asText(""), confirmations, confirmBlocks);
                    continue;
                }
                return new ChainMatch(tx.path("hash").asText(""), value);
            }
            return null;
        } catch (Exception e) {
            log.warn("usdt_erc20 etherscan query failed: {}", e.getMessage());
            return null;
        }
    }
}
