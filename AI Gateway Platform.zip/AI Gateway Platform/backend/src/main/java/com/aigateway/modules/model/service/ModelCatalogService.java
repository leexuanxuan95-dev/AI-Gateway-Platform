package com.aigateway.modules.model.service;

import com.aigateway.common.api.PageResult;
import com.aigateway.modules.model.dto.ModelFamilyRequest;
import com.aigateway.modules.model.dto.ModelRouteRequest;
import com.aigateway.modules.model.dto.ModelVersionQuery;
import com.aigateway.modules.model.dto.ModelVersionRequest;
import com.aigateway.modules.model.entity.ModelChannelRoute;
import com.aigateway.modules.model.entity.ModelFamily;
import com.aigateway.modules.model.entity.ModelVersion;

import java.util.List;

/** Write/admin side of the model catalog (families, versions, routes). */
public interface ModelCatalogService {

    // ---- families ----
    List<ModelFamily> listFamilies();

    ModelFamily createFamily(ModelFamilyRequest req);

    ModelFamily updateFamily(Long id, ModelFamilyRequest req);

    void deleteFamily(Long id);

    // ---- versions ----
    PageResult<ModelVersion> pageVersions(ModelVersionQuery query, long current, long size);

    ModelVersion createVersion(ModelVersionRequest req);

    ModelVersion updateVersion(Long id, ModelVersionRequest req);

    /** List (publish): availability=available, status=active. */
    ModelVersion listVersion(Long id);

    /** Delist (unpublish): availability=unavailable, status=disabled. */
    ModelVersion delistVersion(Long id);

    void deleteVersion(Long id);

    // ---- routes ----
    List<ModelChannelRoute> routesForVersion(Long versionId);

    ModelChannelRoute createRoute(ModelRouteRequest req);

    ModelChannelRoute updateRoute(Long id, ModelRouteRequest req);

    void deleteRoute(Long id);
}
