package com.aigateway.modules.finance.service.impl;

import com.aigateway.common.api.PageResult;
import com.aigateway.common.crypto.AesUtil;
import com.aigateway.common.enums.TransactionType;
import com.aigateway.common.enums.WithdrawStatus;
import com.aigateway.common.exception.BizException;
import com.aigateway.common.exception.ErrorCode;
import com.aigateway.common.util.IdGen;
import com.aigateway.modules.finance.dto.WithdrawAuditRequest;
import com.aigateway.modules.finance.dto.WithdrawRequest;
import com.aigateway.modules.finance.entity.FinWithdrawOrder;
import com.aigateway.modules.finance.mapper.FinWithdrawOrderMapper;
import com.aigateway.modules.finance.service.FinanceService;
import com.aigateway.modules.finance.service.WithdrawService;
import com.aigateway.modules.payment.integration.WiseClient;
import com.aigateway.modules.system.service.SysConfigService;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.HashMap;
import java.util.Map;

/**
 * Default {@link WithdrawService}. On apply the amount is moved available -&gt; freeze;
 * on approve the freeze is released (consumed) and a Wise payout is triggered (stub);
 * on reject the freeze is returned to available.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class WithdrawServiceImpl implements WithdrawService {

    private final FinWithdrawOrderMapper withdrawOrderMapper;
    private final FinanceService financeService;
    private final AesUtil aesUtil;
    private final ObjectMapper objectMapper;
    private final WiseClient wiseClient;
    private final SysConfigService sysConfigService;

    @Override
    @Transactional
    public FinWithdrawOrder apply(Long companyId, Long userId, WithdrawRequest req) {
        BigDecimal amount = req.getAmount();
        if (amount == null || amount.signum() <= 0) {
            throw new BizException(ErrorCode.WITHDRAW_AMOUNT_INVALID);
        }
        // Freeze the funds: available -= amount, freeze += amount.
        financeService.adjustForWithdraw(companyId, amount, amount.negate(),
                TransactionType.WITHDRAW, null, "withdraw apply");

        FinWithdrawOrder o = new FinWithdrawOrder();
        o.setOrderNo(IdGen.orderNo("WD"));
        o.setCompanyId(companyId);
        o.setAmount(amount);
        o.setFee(BigDecimal.ZERO);
        o.setChannel(req.getChannel());
        o.setAccountInfo(encryptAccount(req.getAccountInfo()));
        o.setStatus(WithdrawStatus.PENDING);
        withdrawOrderMapper.insert(o);
        return o;
    }

    @Override
    public PageResult<FinWithdrawOrder> list(Long companyId, long current, long size) {
        IPage<FinWithdrawOrder> p = withdrawOrderMapper.selectPage(new Page<>(current, size),
                Wrappers.<FinWithdrawOrder>lambdaQuery()
                        .eq(FinWithdrawOrder::getCompanyId, companyId)
                        .orderByDesc(FinWithdrawOrder::getId));
        return PageResult.of(p);
    }

    @Override
    @Transactional
    public FinWithdrawOrder audit(Long orderId, Long auditorId, WithdrawAuditRequest req) {
        FinWithdrawOrder o = withdrawOrderMapper.selectById(orderId);
        if (o == null) {
            throw new BizException(ErrorCode.ORDER_NOT_FOUND);
        }
        if (o.getStatus() != null && WithdrawStatus.PENDING != o.getStatus()) {
            throw new BizException(ErrorCode.PARAM_ERROR, "order already audited");
        }
        o.setAuditBy(auditorId);
        o.setAuditAt(OffsetDateTime.now());
        if (Boolean.TRUE.equals(req.getApprove())) {
            // Release the frozen amount (it leaves the platform): freeze -= amount.
            financeService.adjustForWithdraw(o.getCompanyId(), o.getAmount().negate(), BigDecimal.ZERO,
                    TransactionType.WITHDRAW, o.getOrderNo(), "withdraw approved");
            o.setStatus(WithdrawStatus.APPROVED);
            withdrawOrderMapper.updateById(o);
            payViaWise(o); // best-effort stub
        } else {
            // Reject: unfreeze -> back to available. freeze -= amount, available += amount.
            financeService.adjustForWithdraw(o.getCompanyId(), o.getAmount().negate(), o.getAmount(),
                    TransactionType.REFUND, o.getOrderNo(), "withdraw rejected");
            o.setStatus(WithdrawStatus.REJECTED);
            withdrawOrderMapper.updateById(o);
        }
        return o;
    }

    /**
     * Trigger a real Wise Platform payout for an approved withdrawal (design doc route B):
     * decrypt accountInfo -&gt; createQuote -&gt; createRecipient -&gt; createTransfer -&gt; fundTransfer.
     * On a funded transfer the order becomes status=3 (paid) with a paid_at timestamp; on any
     * failure the order is left at status=4 (failed) for retry &mdash; we NEVER mark it paid on a
     * failed payout. Money stays in BigDecimal. The whole flow is wrapped so a failing external
     * API never corrupts the already-committed ledger state.
     *
     * <p>NOTE: this calls {@code com.aigateway.modules.payment.integration.WiseClient}, which is
     * built by a parallel agent. If its package or method signatures differ from the agreed
     * contract this will not compile and must be reconciled.</p>
     */
    private void payViaWise(FinWithdrawOrder o) {
        String profileId = sysConfigService.getString("wise.profileId", null);
        if (profileId == null || profileId.isBlank()) {
            log.warn("withdraw {} approved but wise.profileId not configured; leaving for retry",
                    o.getOrderNo());
            markFailed(o);
            return;
        }
        try {
            Map<String, Object> account = decryptAccount(o.getAccountInfo());
            String targetCcy = asString(account.get("currency"), asString(account.get("targetCcy"), "USD"));
            String sourceCcy = "USD";

            // 1) Quote
            Map<?, ?> quote = wiseClient.createQuote(profileId, sourceCcy, targetCcy, o.getAmount());
            String quoteId = idOf(quote);
            if (quoteId == null) {
                throw new IllegalStateException("wise quote returned no id");
            }
            // 2) Recipient (beneficiary account details)
            Map<String, Object> accountInfo = new HashMap<>(account);
            Map<?, ?> recipient = wiseClient.createRecipient(profileId, accountInfo);
            String recipientId = idOf(recipient);
            if (recipientId == null) {
                throw new IllegalStateException("wise recipient returned no id");
            }
            // 3) Transfer
            Map<?, ?> transfer = wiseClient.createTransfer(profileId, quoteId, recipientId, o.getOrderNo());
            String transferId = idOf(transfer);
            if (transferId == null) {
                throw new IllegalStateException("wise transfer returned no id");
            }
            // 4) Fund (move money out of the Wise balance)
            Map<?, ?> funded = wiseClient.fundTransfer(profileId, transferId);
            if (funded == null) {
                throw new IllegalStateException("wise fund returned null");
            }
            String fundStatus = asString(funded.get("status"), null);
            // Wise funding success states; treat explicit errors as failure.
            boolean ok = fundStatus == null
                    || "COMPLETED".equalsIgnoreCase(fundStatus)
                    || "outgoing_payment_sent".equalsIgnoreCase(fundStatus)
                    || "processing".equalsIgnoreCase(fundStatus)
                    || "BALANCE".equalsIgnoreCase(fundStatus);
            if (!ok) {
                throw new IllegalStateException("wise fund returned status=" + fundStatus);
            }

            o.setStatus(WithdrawStatus.PAID);
            o.setPaidAt(OffsetDateTime.now());
            withdrawOrderMapper.updateById(o);
            log.info("withdraw {} paid via Wise (transferId={})", o.getOrderNo(), transferId);
        } catch (Exception e) {
            log.warn("wise payout failed for {}: {} (left for retry, NOT marked paid)",
                    o.getOrderNo(), e.getMessage());
            markFailed(o);
        }
    }

    /** Mark the order failed (status=4) so it can be retried; best-effort, never throws. */
    private void markFailed(FinWithdrawOrder o) {
        try {
            o.setStatus(WithdrawStatus.FAILED);
            withdrawOrderMapper.updateById(o);
        } catch (Exception e) {
            log.warn("mark withdraw {} failed errored: {}", o.getOrderNo(), e.getMessage());
        }
    }

    /** Pull an {@code id} out of a Wise response map (numeric or string), or null. */
    private String idOf(Map<?, ?> resp) {
        if (resp == null) {
            return null;
        }
        Object id = resp.get("id");
        if (id == null) {
            id = resp.get("targetAccount");
        }
        return id == null ? null : String.valueOf(id);
    }

    private String asString(Object v, String def) {
        return v == null ? def : String.valueOf(v);
    }

    /** Decrypt the {@code {"enc": "<ciphertext>"}} envelope back into the beneficiary map. */
    private Map<String, Object> decryptAccount(Map<String, Object> envelope) {
        if (envelope == null || envelope.get("enc") == null) {
            return new HashMap<>();
        }
        try {
            String json = aesUtil.decrypt(String.valueOf(envelope.get("enc")));
            return objectMapper.readValue(json, new TypeReference<Map<String, Object>>() {});
        } catch (Exception e) {
            throw new BizException(ErrorCode.PARAM_ERROR, "cannot decrypt withdraw account info");
        }
    }

    /** Encrypt the beneficiary account JSON into a {@code {"enc": "<ciphertext>"}} envelope. */
    private Map<String, Object> encryptAccount(Map<String, Object> accountInfo) {
        try {
            String json = objectMapper.writeValueAsString(accountInfo);
            Map<String, Object> env = new HashMap<>();
            env.put("enc", aesUtil.encrypt(json));
            return env;
        } catch (Exception e) {
            throw new BizException(ErrorCode.PARAM_ERROR, "invalid account info");
        }
    }
}
