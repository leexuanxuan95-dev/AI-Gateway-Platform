package com.aigateway.modules.channel.mapper;

import com.aigateway.modules.channel.entity.ChannelApiKey;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/** MyBatis-Plus mapper for {@link ChannelApiKey} (channel upstream key pool). */
@Mapper
public interface ChannelApiKeyMapper extends BaseMapper<ChannelApiKey> {
}
