package com.aigateway.modules.site.dto;

import lombok.Data;

import java.util.Map;

/** Upsert request for the site-level setting (brand / SEO / theme / footer). */
@Data
public class SiteSettingReq {

    private Map<String, Object> brand;

    private Map<String, Object> seo;

    private Map<String, Object> theme;

    private Map<String, Object> footer;
}
