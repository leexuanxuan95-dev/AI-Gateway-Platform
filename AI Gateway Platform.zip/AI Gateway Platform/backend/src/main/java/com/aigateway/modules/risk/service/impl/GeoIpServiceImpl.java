package com.aigateway.modules.risk.service.impl;

import com.aigateway.modules.risk.service.GeoIpService;
import com.aigateway.modules.system.service.SysConfigService;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import java.time.Duration;
import java.util.Map;

/**
 * Default {@link GeoIpService}. Calls an ip-api / ipinfo style HTTP endpoint whose URL template and
 * (optional) API key live in {@code sys_config}:
 * <ul>
 *   <li>{@code risk.geoip.enabled} (bool, default false) - master switch;</li>
 *   <li>{@code risk.geoip.url} - URL template with {@code {ip}} and optional {@code {key}}
 *       placeholders, e.g. {@code http://ip-api.com/json/{ip}?fields=countryCode} or
 *       {@code https://ipinfo.io/{ip}/json?token={key}};</li>
 *   <li>{@code risk.geoip.key} - API token (optional);</li>
 *   <li>{@code risk.geoip.field} - JSON field holding the country code (default {@code countryCode}).</li>
 * </ul>
 * Results are Redis-cached for 24h under {@code gw:risk:geo:<ip>}. Every failure path returns
 * {@link #UNKNOWN} (fail-open).
 */
@Slf4j
@Service
public class GeoIpServiceImpl implements GeoIpService {

    private static final String CACHE_PREFIX = "gw:risk:geo:";
    private static final Duration TTL = Duration.ofHours(24);
    /** Max time to wait on the geo provider HTTP call before failing open. */
    private static final Duration LOOKUP_TIMEOUT = Duration.ofSeconds(3);
    /** Lower bound of the 172.16.0.0/12 private second octet range. */
    private static final int PRIVATE_172_LOW = 16;
    /** Upper bound of the 172.16.0.0/12 private second octet range. */
    private static final int PRIVATE_172_HIGH = 31;

    private final WebClient webClient;
    private final SysConfigService sysConfigService;
    private final StringRedisTemplate stringRedisTemplate;
    private final ObjectMapper objectMapper;

    public GeoIpServiceImpl(WebClient.Builder webClientBuilder,
                            SysConfigService sysConfigService,
                            StringRedisTemplate stringRedisTemplate,
                            ObjectMapper objectMapper) {
        this.webClient = webClientBuilder.build();
        this.sysConfigService = sysConfigService;
        this.stringRedisTemplate = stringRedisTemplate;
        this.objectMapper = objectMapper;
    }

    @Override
    public String countryOf(String ip) {
        if (ip == null || ip.isBlank() || isPrivate(ip)) {
            return UNKNOWN;
        }
        // 1) cache
        String cacheKey = CACHE_PREFIX + ip;
        try {
            String cached = stringRedisTemplate.opsForValue().get(cacheKey);
            if (cached != null && !cached.isBlank()) {
                return cached;
            }
        } catch (Exception e) {
            log.debug("geoip cache read failed for {}: {}", ip, e.getMessage());
        }

        // 2) config-driven lookup (disabled by default)
        String country = UNKNOWN;
        try {
            if (sysConfigService.getBool("risk.geoip.enabled", false)) {
                country = lookup(ip);
            }
        } catch (Exception e) {
            log.debug("geoip lookup failed for {}: {}", ip, e.getMessage());
            country = UNKNOWN;
        }

        // 3) cache the (possibly UNKNOWN) result to avoid hammering the provider
        try {
            stringRedisTemplate.opsForValue().set(cacheKey, country, TTL);
        } catch (Exception e) {
            log.debug("geoip cache write failed for {}: {}", ip, e.getMessage());
        }
        return country;
    }

    private String lookup(String ip) throws com.fasterxml.jackson.core.JsonProcessingException {
        String urlTpl = sysConfigService.getString("risk.geoip.url", null);
        if (urlTpl == null || urlTpl.isBlank()) {
            return UNKNOWN;
        }
        String key = sysConfigService.getString("risk.geoip.key", "");
        String field = sysConfigService.getString("risk.geoip.field", "countryCode");
        String url = urlTpl.replace("{ip}", ip).replace("{key}", key == null ? "" : key);

        String json = webClient.get()
                .uri(url)
                .retrieve()
                .bodyToMono(String.class)
                .block(LOOKUP_TIMEOUT);
        if (json == null || json.isBlank()) {
            return UNKNOWN;
        }
        Map<String, Object> map = objectMapper.readValue(json, new TypeReference<>() {});
        Object cc = map.get(field);
        if (cc == null) {
            // common alternate field names
            cc = map.get("countryCode");
            if (cc == null) {
                cc = map.get("country");
            }
        }
        if (cc == null) {
            return UNKNOWN;
        }
        String code = String.valueOf(cc).trim().toUpperCase();
        return code.isEmpty() ? UNKNOWN : code;
    }

    /** Private / loopback / link-local ranges never resolve to a public country. */
    private boolean isPrivate(String ip) {
        return ip.startsWith("10.") || ip.startsWith("192.168.") || ip.startsWith("127.")
                || ip.startsWith("169.254.") || ip.equals("::1") || ip.startsWith("fc")
                || ip.startsWith("fd") || isPrivate172(ip);
    }

    private boolean isPrivate172(String ip) {
        if (!ip.startsWith("172.")) {
            return false;
        }
        int dot = ip.indexOf('.', 4);
        if (dot < 0) {
            return false;
        }
        try {
            int second = Integer.parseInt(ip.substring(4, dot));
            return second >= PRIVATE_172_LOW && second <= PRIVATE_172_HIGH;
        } catch (NumberFormatException e) {
            return false;
        }
    }
}
