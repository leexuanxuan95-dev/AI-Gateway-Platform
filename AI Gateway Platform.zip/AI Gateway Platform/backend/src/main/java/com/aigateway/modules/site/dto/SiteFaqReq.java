package com.aigateway.modules.site.dto;

import lombok.Data;

/** Create / update request for a FAQ entry. */
@Data
public class SiteFaqReq {

    private String lang;

    private String question;

    private String answer;

    private Integer sort;

    private Boolean enabled;
}
