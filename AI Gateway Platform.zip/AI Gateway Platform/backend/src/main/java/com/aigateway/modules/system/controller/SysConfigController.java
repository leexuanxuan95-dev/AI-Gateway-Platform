package com.aigateway.modules.system.controller;

import com.aigateway.common.api.R;
import com.aigateway.common.exception.BizException;
import com.aigateway.common.exception.ErrorCode;
import com.aigateway.common.security.UserContext;
import com.aigateway.modules.system.dto.SysConfigRequest;
import com.aigateway.modules.system.entity.SysConfig;
import com.aigateway.modules.system.service.SysConfigService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * System config center management (design doc §15.4). Super-admin only: lists by group,
 * upserts and deletes dynamic platform parameters. The {@code /v1/*} surface and jobs read
 * these via {@link SysConfigService} typed getters.
 */
@RestController
@RequestMapping("/api/system/config")
@RequiredArgsConstructor
public class SysConfigController {

    private final SysConfigService sysConfigService;

    /** Lists config entries, optionally filtered by group (super-admin only). */
    @GetMapping
    public R<List<SysConfig>> list(@RequestParam(required = false) String group) {
        requireSuperAdmin();
        return R.ok(sysConfigService.listByGroup(group));
    }

    /** Returns a single config entry by key (super-admin only). */
    @GetMapping("/{key}")
    public R<SysConfig> get(@PathVariable String key) {
        requireSuperAdmin();
        return R.ok(sysConfigService.get(key));
    }

    /** Inserts or updates a config entry (super-admin only). */
    @PostMapping
    public R<SysConfig> upsert(@RequestBody @Valid SysConfigRequest req) {
        requireSuperAdmin();
        return R.ok(sysConfigService.upsert(req.getConfigKey(), req.getConfigValue(),
                req.getGroupName(), req.getRemark(), UserContext.userId()));
    }

    /** Deletes a config entry by key (super-admin only). */
    @DeleteMapping("/{key}")
    public R<Void> delete(@PathVariable String key) {
        requireSuperAdmin();
        sysConfigService.delete(key);
        return R.ok();
    }

    private void requireSuperAdmin() {
        if (!UserContext.require().isSuperAdmin()) {
            throw new BizException(ErrorCode.FORBIDDEN);
        }
    }
}
