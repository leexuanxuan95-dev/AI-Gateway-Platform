package com.aigateway.modules.model.provider;

import com.aigateway.common.crypto.AesUtil;
import com.aigateway.modules.channel.entity.Channel;
import com.fasterxml.jackson.databind.JsonNode;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.ArrayList;
import java.util.List;

/**
 * Google Gemini model catalog provider. Uses the Generative Language API
 * GET {base|https://generativelanguage.googleapis.com}/v1beta/models?key=API_KEY.
 */
@Component
public class GeminiModelProvider extends AbstractWebClientProvider {

    public GeminiModelProvider(WebClient.Builder builder, AesUtil aesUtil) {
        super(builder, aesUtil);
    }

    @Override
    public String name() {
        return "gemini";
    }

    @Override
    public List<UpstreamModel> listModels(Channel ch) {
        List<UpstreamModel> out = new ArrayList<>();
        String key = decryptKey(ch.getApiKey());
        if (key == null) {
            return out;
        }
        String base = baseOr(ch.getBaseUrl(), "https://generativelanguage.googleapis.com");
        String url = base + "/v1beta/models?key=" + key;
        JsonNode body = getJson(url, null);
        if (body == null) {
            return out;
        }
        JsonNode models = body.path("models");
        if (models.isArray()) {
            for (JsonNode m : models) {
                // name looks like "models/gemini-1.5-pro"; strip the prefix.
                String full = m.path("name").asText(null);
                if (full == null) {
                    continue;
                }
                String id = full.startsWith("models/") ? full.substring("models/".length()) : full;
                UpstreamModel um = new UpstreamModel();
                um.setId(id);
                um.setDisplayName(m.path("displayName").asText(id));
                JsonNode ctx = m.path("inputTokenLimit");
                if (ctx.isNumber()) {
                    um.setContextWindow(ctx.asInt());
                }
                out.add(um);
            }
        }
        return out;
    }
}
