package com.aigateway.modules.apikey.dto;

import com.aigateway.common.enums.ApiKeyStatus;
import com.aigateway.modules.apikey.entity.ApiKey;
import lombok.Data;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.List;

/** Safe list/detail projection of an API key — never exposes the hash or raw key. */
@Data
public class ApiKeyView {

    private Long id;
    private Long companyId;
    private Long projectId;
    private String keyName;
    private String keyPrefix;
    private List<String> allowedModels;
    private Integer rpmLimit;
    private Integer tpmLimit;
    private BigDecimal dailyQuota;
    private List<String> ipWhitelist;
    private ApiKeyStatus status;
    private OffsetDateTime expireAt;
    private OffsetDateTime lastUsedAt;
    private OffsetDateTime createdAt;

    public static ApiKeyView from(ApiKey k) {
        ApiKeyView v = new ApiKeyView();
        v.id = k.getId();
        v.companyId = k.getCompanyId();
        v.projectId = k.getProjectId();
        v.keyName = k.getKeyName();
        v.keyPrefix = k.getKeyPrefix();
        v.allowedModels = k.getAllowedModels();
        v.rpmLimit = k.getRpmLimit();
        v.tpmLimit = k.getTpmLimit();
        v.dailyQuota = k.getDailyQuota();
        v.ipWhitelist = k.getIpWhitelist();
        v.status = k.getStatus();
        v.expireAt = k.getExpireAt();
        v.lastUsedAt = k.getLastUsedAt();
        v.createdAt = k.getCreatedAt();
        return v;
    }
}
