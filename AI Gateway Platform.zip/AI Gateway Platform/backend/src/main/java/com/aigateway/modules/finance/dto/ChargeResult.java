package com.aigateway.modules.finance.dto;

import lombok.Data;

import java.math.BigDecimal;

/**
 * Result of a pricing calculation (design doc §10.4). The gateway integrates
 * against this exact shape: {@code charge} is the customer-facing amount, {@code cost}
 * is the upstream cost, and the markup fields document how the charge was derived.
 */
@Data
public class ChargeResult {

    /** Customer-facing charge (always >= cost). */
    private BigDecimal charge;

    /** Upstream cost. */
    private BigDecimal cost;

    /** Effective markup rate applied. */
    private BigDecimal markupRate;

    /** Minimum margin floor applied. */
    private BigDecimal minMargin;
}
