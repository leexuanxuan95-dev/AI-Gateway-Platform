package com.aigateway.common.security;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Declares a permission point required to invoke a controller method, e.g.
 * {@code @RequirePerm("billing:read")}. Enforced by {@link PermissionAspect}.
 * The platform super-admin bypasses all checks.
 */
@Target({ElementType.METHOD, ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
public @interface RequirePerm {

    /** Required permission points. */
    String[] value();

    /** If true, the user must hold ALL listed points; otherwise ANY one suffices. */
    boolean requireAll() default false;
}
