package com.aigateway.modules.model.provider;

import com.aigateway.common.crypto.AesUtil;
import com.aigateway.modules.channel.entity.Channel;
import com.fasterxml.jackson.databind.JsonNode;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * OpenRouter model catalog provider (GET https://openrouter.ai/api/v1/models).
 * OpenRouter exposes per-token pricing (USD per token); we normalise it to per-1M-tokens
 * so it can populate cost_input / cost_output on the model version.
 */
@Component
public class OpenRouterModelProvider extends AbstractWebClientProvider {

    private static final BigDecimal PER_MILLION = new BigDecimal("1000000");

    public OpenRouterModelProvider(WebClient.Builder builder, AesUtil aesUtil) {
        super(builder, aesUtil);
    }

    @Override
    public String name() {
        return "openrouter";
    }

    @Override
    public List<UpstreamModel> listModels(Channel ch) {
        List<UpstreamModel> out = new ArrayList<>();
        // OpenRouter /models is public; key is optional but sent if present.
        String key = decryptKey(ch.getApiKey());
        String url = baseOr(ch.getBaseUrl(), "https://openrouter.ai/api") + "/v1/models";
        JsonNode body = getJson(url, spec -> {
            if (key != null) {
                spec.header("Authorization", "Bearer " + key);
            }
        });
        if (body == null) {
            return out;
        }
        JsonNode data = body.path("data");
        if (data.isArray()) {
            for (JsonNode m : data) {
                String id = m.path("id").asText(null);
                if (id == null) {
                    continue;
                }
                UpstreamModel um = new UpstreamModel();
                um.setId(id);
                um.setDisplayName(m.path("name").asText(id));
                JsonNode ctx = m.path("context_length");
                if (ctx.isNumber()) {
                    um.setContextWindow(ctx.asInt());
                }
                JsonNode pricing = m.path("pricing");
                um.setPriceInput(perMillion(pricing.path("prompt").asText(null)));
                um.setPriceOutput(perMillion(pricing.path("completion").asText(null)));
                out.add(um);
            }
        }
        return out;
    }

    /** Convert OpenRouter per-token price string to per-1M-tokens BigDecimal; null-safe. */
    private BigDecimal perMillion(String perToken) {
        if (perToken == null || perToken.isBlank()) {
            return null;
        }
        try {
            return new BigDecimal(perToken).multiply(PER_MILLION);
        } catch (NumberFormatException e) {
            return null;
        }
    }
}
