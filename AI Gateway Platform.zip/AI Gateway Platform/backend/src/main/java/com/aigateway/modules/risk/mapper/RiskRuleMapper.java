package com.aigateway.modules.risk.mapper;

import com.aigateway.modules.risk.entity.RiskRule;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/** MyBatis-Plus mapper for {@link RiskRule}. */
public interface RiskRuleMapper extends BaseMapper<RiskRule> {
}
