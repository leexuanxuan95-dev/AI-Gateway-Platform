package com.aigateway.common.audit;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Marks a sensitive operation that must be recorded to the operation audit log
 * (design doc §18 "all sensitive operations require step-up verification + audit log").
 * Apply to management controller/service methods, e.g. payment-config changes,
 * withdrawals, member role changes, channel key updates.
 */
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
public @interface AuditLog {

    /** Human-readable action, e.g. "pay-config.update". */
    String value();

    /** Logical module, e.g. "payment". */
    String module() default "";
}
