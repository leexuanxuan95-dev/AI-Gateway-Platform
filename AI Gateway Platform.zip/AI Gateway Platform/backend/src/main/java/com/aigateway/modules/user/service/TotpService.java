package com.aigateway.modules.user.service;

import dev.samstevens.totp.code.CodeVerifier;
import dev.samstevens.totp.code.DefaultCodeGenerator;
import dev.samstevens.totp.code.DefaultCodeVerifier;
import dev.samstevens.totp.code.HashingAlgorithm;
import dev.samstevens.totp.secret.DefaultSecretGenerator;
import dev.samstevens.totp.secret.SecretGenerator;
import dev.samstevens.totp.time.SystemTimeProvider;
import dev.samstevens.totp.time.TimeProvider;
import org.springframework.stereotype.Component;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

/**
 * Thin wrapper around {@code dev.samstevens.totp} for 2FA. Generates Base32
 * secrets, validates 6-digit codes (SHA1 / 30s period), and builds the
 * {@code otpauth://} provisioning URI for client-side QR rendering.
 */
@Component
public class TotpService {

    private static final String ISSUER = "AI Gateway";

    private final SecretGenerator secretGenerator = new DefaultSecretGenerator();
    private final TimeProvider timeProvider = new SystemTimeProvider();
    private final CodeVerifier codeVerifier =
            new DefaultCodeVerifier(new DefaultCodeGenerator(HashingAlgorithm.SHA1), timeProvider);

    /** Generate a fresh Base32 shared secret. */
    public String generateSecret() {
        return secretGenerator.generate();
    }

    /** Verify a code against the given secret (tolerates clock drift per library default). */
    public boolean verify(String secret, String code) {
        if (secret == null || code == null) {
            return false;
        }
        return codeVerifier.isValidCode(secret, code);
    }

    /** Build an {@code otpauth://totp/...} URI for authenticator apps. */
    public String otpauthUrl(String accountLabel, String secret) {
        String label = URLEncoder.encode(ISSUER + ":" + accountLabel, StandardCharsets.UTF_8);
        String issuer = URLEncoder.encode(ISSUER, StandardCharsets.UTF_8);
        return "otpauth://totp/" + label
                + "?secret=" + secret
                + "&issuer=" + issuer
                + "&algorithm=SHA1&digits=6&period=30";
    }
}
