package com.aigateway.modules.finance.entity;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.math.BigDecimal;
import java.time.OffsetDateTime;

/** Profit ledger entry (table {@code profit_ledger}, design doc §10.4). */
@Data
@TableName(value = "profit_ledger", autoResultMap = true)
public class ProfitLedger {

    @TableId(type = IdType.AUTO)
    private Long id;

    /** consume / recharge_fee. */
    private String source;

    private String refId;

    private Long companyId;

    private String modelCode;

    private BigDecimal revenue;

    private BigDecimal cost;

    private BigDecimal profit;

    @TableField(fill = FieldFill.INSERT)
    private OffsetDateTime createdAt;
}
