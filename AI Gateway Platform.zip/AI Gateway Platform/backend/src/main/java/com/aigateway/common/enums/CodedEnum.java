package com.aigateway.common.enums;

/**
 * Marker for status/type enums backed by a stable wire/DB code (Alibaba P3C: prefer enums
 * over scattered magic numbers). Implementations expose the code via {@code getCode()},
 * persist it through MyBatis-Plus {@code @EnumValue}, and serialize/deserialize it as the
 * raw code through Jackson {@code @JsonValue}/{@code @JsonCreator} — so the database column
 * and the JSON contract are unchanged.
 *
 * @param <T> the code type (Integer or String)
 */
public interface CodedEnum<T> {

    T getCode();
}
