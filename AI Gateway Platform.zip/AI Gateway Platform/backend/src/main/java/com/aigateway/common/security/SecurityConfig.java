package com.aigateway.common.security;

import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.security.web.header.writers.ReferrerPolicyHeaderWriter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import java.util.Arrays;
import java.util.List;

/** Spring Security setup: stateless JWT auth, CORS, security headers and the public URL allow-list. */
@Configuration
@RequiredArgsConstructor
public class SecurityConfig {

    /** bcrypt hashing cost factor (design doc §3.2). */
    private static final int BCRYPT_STRENGTH = 12;
    /** HSTS max-age in seconds (one year). */
    private static final long HSTS_MAX_AGE_SECONDS = 31536000;
    /** CORS preflight cache max-age in seconds (one hour). */
    private static final long CORS_MAX_AGE_SECONDS = 3600L;

    private final JwtAuthFilter jwtAuthFilter;
    private final StringRedisTemplate stringRedisTemplate;

    /** Comma-separated allowed CORS origins. Default = local dev console only. */
    @Value("${aigateway.cors.allowed-origins:http://localhost,http://localhost:80,http://localhost:5173}")
    private String allowedOrigins;

    /** bcrypt cost=12 per design doc §3.2. */
    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder(BCRYPT_STRENGTH);
    }

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
                .csrf(AbstractHttpConfigurer::disable)
                .cors(c -> c.configurationSource(corsConfigurationSource()))
                .sessionManagement(s -> s.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
                // security response headers (design doc §18: HSTS / anti-clickjacking / no-sniff / CSP)
                .headers(h -> h
                        .frameOptions(f -> f.deny())
                        .contentTypeOptions(co -> {})
                        .httpStrictTransportSecurity(hsts -> hsts
                                .includeSubDomains(true).maxAgeInSeconds(HSTS_MAX_AGE_SECONDS))
                        .referrerPolicy(r -> r.policy(ReferrerPolicyHeaderWriter.ReferrerPolicy.SAME_ORIGIN))
                        .addHeaderWriter((req, res) -> {
                            res.setHeader("Content-Security-Policy",
                                    "default-src 'self'; frame-ancestors 'none'; object-src 'none'");
                            res.setHeader("Permissions-Policy", "geolocation=(), microphone=(), camera=()");
                            res.setHeader("X-Permitted-Cross-Domain-Policies", "none");
                        }))
                .authorizeHttpRequests(auth -> auth
                        // OpenAI-compatible surface: authenticated by the gateway api-key filter
                        .requestMatchers("/v1/**").permitAll()
                        // public auth + payment callbacks + public channel list
                        .requestMatchers("/api/auth/**").permitAll()
                        .requestMatchers("/api/pay/callback/**").permitAll()
                        .requestMatchers("/api/pay/channels").permitAll()
                        // public OmniRoute landing content (read-only, CDN-cached; OmniRoute doc §4.3)
                        .requestMatchers("/api/site/landing").permitAll()
                        // token-gated draft preview (OmniRoute doc §4.4)
                        .requestMatchers("/api/site/preview/**").permitAll()
                        // only liveness/readiness public; metrics/prometheus must be network-restricted in prod
                        .requestMatchers("/actuator/health/**", "/actuator/info").permitAll()
                        // everything else needs a valid console JWT
                        .requestMatchers("/api/**").authenticated()
                        .requestMatchers("/actuator/**").authenticated()
                        .anyRequest().permitAll())
                // IP throttle on the auth surface, then JWT resolution
                .addFilterBefore(new AuthRateLimitFilter(stringRedisTemplate),
                        UsernamePasswordAuthenticationFilter.class)
                .addFilterBefore(jwtAuthFilter, UsernamePasswordAuthenticationFilter.class);
        return http.build();
    }

    @Bean
    public CorsConfigurationSource corsConfigurationSource() {
        CorsConfiguration cfg = new CorsConfiguration();
        // explicit origin allow-list (no wildcard-with-credentials, which browsers reject and is unsafe)
        cfg.setAllowedOrigins(Arrays.stream(allowedOrigins.split(",")).map(String::trim).toList());
        cfg.setAllowedMethods(List.of("GET", "POST", "PUT", "DELETE", "OPTIONS", "PATCH"));
        cfg.setAllowedHeaders(List.of("Authorization", "Content-Type", "X-Project-Id", "X-Request-Id"));
        cfg.setExposedHeaders(List.of("X-Request-Id", "X-Tokens-Used", "X-Cost", "X-Balance",
                "X-RateLimit-Limit", "X-RateLimit-Remaining", "X-RateLimit-Reset"));
        cfg.setAllowCredentials(true);
        cfg.setMaxAge(CORS_MAX_AGE_SECONDS);
        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", cfg);
        return source;
    }
}
