package com.aigateway.modules.finance.controller;

import com.aigateway.common.api.PageResult;
import com.aigateway.common.api.R;
import com.aigateway.common.exception.BizException;
import com.aigateway.common.exception.ErrorCode;
import com.aigateway.common.security.RequirePerm;
import com.aigateway.common.security.RolePermissions;
import com.aigateway.common.security.UserContext;
import com.aigateway.modules.finance.dto.WithdrawAuditRequest;
import com.aigateway.modules.finance.dto.WithdrawRequest;
import com.aigateway.modules.finance.entity.FinWithdrawOrder;
import com.aigateway.modules.finance.service.WithdrawService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/** Withdrawal endpoints (design doc §10). */
@RestController
@RequestMapping("/api/finance/withdraw")
@RequiredArgsConstructor
public class WithdrawController {

    private final WithdrawService withdrawService;

    /** Apply for a withdrawal (freezes balance). */
    @PostMapping
    @RequirePerm(RolePermissions.WITHDRAW_APPLY)
    public R<FinWithdrawOrder> apply(@RequestBody @Valid WithdrawRequest req) {
        return R.ok(withdrawService.apply(UserContext.companyId(), UserContext.userId(), req));
    }

    /** List the current company's withdraw orders. */
    @GetMapping
    @RequirePerm(RolePermissions.WITHDRAW_APPLY)
    public R<PageResult<FinWithdrawOrder>> list(@RequestParam(defaultValue = "1") long current,
                                                @RequestParam(defaultValue = "20") long size) {
        return R.ok(withdrawService.list(UserContext.companyId(), current, size));
    }

    /** Super-admin: approve or reject a withdrawal. */
    @PostMapping("/{id}/audit")
    public R<FinWithdrawOrder> audit(@PathVariable Long id, @RequestBody @Valid WithdrawAuditRequest req) {
        if (!UserContext.require().isSuperAdmin()) {
            throw new BizException(ErrorCode.PERMISSION_DENIED);
        }
        return R.ok(withdrawService.audit(id, UserContext.userId(), req));
    }
}
