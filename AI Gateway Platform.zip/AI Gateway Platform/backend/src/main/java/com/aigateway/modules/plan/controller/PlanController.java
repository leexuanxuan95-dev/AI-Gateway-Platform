package com.aigateway.modules.plan.controller;

import com.aigateway.common.api.R;
import com.aigateway.common.exception.BizException;
import com.aigateway.common.exception.ErrorCode;
import com.aigateway.common.security.UserContext;
import com.aigateway.modules.plan.entity.Plan;
import com.aigateway.modules.plan.mapper.PlanMapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * Plan endpoints (design doc §9). List is available to any authenticated console
 * user; create/update/delete are restricted to the platform super-admin.
 */
@RestController
@RequestMapping("/api/plan")
@RequiredArgsConstructor
public class PlanController {

    private final PlanMapper planMapper;

    /** List all active plans (ordered by sort). Authenticated. */
    @GetMapping
    public R<List<Plan>> list() {
        return R.ok(planMapper.selectList(
                Wrappers.<Plan>lambdaQuery().orderByAsc(Plan::getSort)));
    }

    /** Plan detail. Authenticated. */
    @GetMapping("/{id}")
    public R<Plan> get(@PathVariable Long id) {
        return R.ok(planMapper.selectById(id));
    }

    /** Create a plan. Super-admin only. */
    @PostMapping
    public R<Plan> create(@RequestBody @Valid Plan plan) {
        requireSuperAdmin();
        plan.setId(null);
        planMapper.insert(plan);
        return R.ok(plan);
    }

    /** Update a plan. Super-admin only. */
    @PutMapping("/{id}")
    public R<Plan> update(@PathVariable Long id, @RequestBody Plan plan) {
        requireSuperAdmin();
        plan.setId(id);
        planMapper.updateById(plan);
        return R.ok(planMapper.selectById(id));
    }

    /** Delete a plan. Super-admin only. */
    @DeleteMapping("/{id}")
    public R<Void> delete(@PathVariable Long id) {
        requireSuperAdmin();
        planMapper.deleteById(id);
        return R.ok();
    }

    private void requireSuperAdmin() {
        if (!UserContext.require().isSuperAdmin()) {
            throw new BizException(ErrorCode.PERMISSION_DENIED);
        }
    }
}
