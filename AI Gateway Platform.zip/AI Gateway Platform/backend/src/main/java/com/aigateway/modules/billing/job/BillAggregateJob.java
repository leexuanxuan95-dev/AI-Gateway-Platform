package com.aigateway.modules.billing.job;

import com.aigateway.common.schedule.ManagedJob;
import com.aigateway.modules.billing.mapper.BillingStatMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.ZoneOffset;
import java.util.Map;

/**
 * Daily billing aggregation (design doc §11). Computes the prior day's platform-wide
 * consumption totals from {@code bill_token} and logs the materialized summary. Kept lean:
 * a SQL group-by/sum is sufficient for the daily roll-up; richer marts can build on this later.
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class BillAggregateJob implements ManagedJob {

    private static final String JOB_KEY = "bill-aggregate";

    private final BillingStatMapper billingStatMapper;

    @Override
    public String jobKey() {
        return JOB_KEY;
    }

    @Override
    public String defaultCron() {
        return "0 30 0 * * ?";
    }

    @Override
    public String description() {
        return "Daily billing aggregation of the previous calendar day (UTC)";
    }

    @Override
    public void execute() {
        LocalDate yesterday = LocalDate.now(ZoneOffset.UTC).minusDays(1);
        String from = yesterday.atStartOfDay().atOffset(ZoneOffset.UTC).toString();
        String to = yesterday.plusDays(1).atStartOfDay().atOffset(ZoneOffset.UTC).toString();
        try {
            Map<String, Object> sum = billingStatMapper.sumWindow(null, from, to);
            log.info("[bill-aggregate] {} charge={} cost={} tokens={} requests={}",
                    yesterday, sum.get("charge"), sum.get("cost"),
                    sum.get("tokens"), sum.get("requests"));
        } catch (Exception e) {
            log.warn("bill aggregate for {} failed: {}", yesterday, e.getMessage());
        }
    }
}
