package com.aigateway.modules.finance.service;

import com.aigateway.modules.finance.dto.SettleCmd;

import java.math.BigDecimal;

/**
 * Balance freeze/settle engine (design doc §10.4-E / §11.1). The gateway calls
 * {@link #freeze} before dispatching a request and {@link #settle} after it completes.
 */
public interface BillingService {

    /**
     * Freeze an estimated charge: moves {@code estimate} from available to freeze balance
     * under an optimistic lock. Throws {@link com.aigateway.common.exception.ErrorCode#INSUFFICIENT_BALANCE}
     * when the available balance is too low.
     *
     * @return the actually frozen amount
     */
    BigDecimal freeze(Long companyId, BigDecimal estimate);

    /**
     * Release a previously frozen estimate back to available balance WITHOUT charging
     * (the call failed before producing billable usage, e.g. no channel available or an
     * upstream error). Moves {@code frozen} from freeze to available under an optimistic
     * lock. No-op for non-positive amounts; best-effort (logged, never throws).
     */
    void release(Long companyId, BigDecimal frozen);

    /**
     * Settle a completed request: release the frozen estimate, deduct the actual charge,
     * accumulate consumption, write the finance/profit/billing ledgers and earmark upstream
     * cost. Atomic (single transaction).
     */
    void settle(SettleCmd cmd);
}
