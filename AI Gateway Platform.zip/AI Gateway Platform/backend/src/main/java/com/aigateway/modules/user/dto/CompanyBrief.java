package com.aigateway.modules.user.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

/** Brief company entry for a user's membership list. */
@Data
@AllArgsConstructor
public class CompanyBrief {

    private Long companyId;
    private String companyName;
    private String role;
}
