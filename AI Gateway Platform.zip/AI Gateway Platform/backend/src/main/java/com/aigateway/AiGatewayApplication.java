package com.aigateway;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;

/**
 * AI Gateway SaaS platform entry point.
 *
 * <p>Enterprise AI model aggregation / billing / risk / finance gateway.
 * Exposes an OpenAI-compatible API surface and proxies to upstream providers
 * via LiteLLM. See the design doc for the full module map.</p>
 */
@SpringBootApplication
@EnableScheduling
@EnableAsync
@MapperScan("com.aigateway.**.mapper")
public class AiGatewayApplication {

    public static void main(String[] args) {
        SpringApplication.run(AiGatewayApplication.class, args);
    }
}
