package com.aigateway.common.schedule;

/**
 * A scheduled job whose timing is managed at runtime from the admin console
 * (design doc §15.5: task switches/timing are configurable, not hard-coded).
 *
 * <p>Implement this on a Spring {@code @Component} instead of using {@code @Scheduled}.
 * The {@code DynamicJobScheduler} discovers all beans, persists one row per job in
 * {@code sys_scheduled_job} (seeded from {@link #defaultCron()} on first start), and
 * schedules the enabled ones by their stored cron. Super-admins can enable/disable,
 * change the cron, or trigger a job on demand — no redeploy.</p>
 */
public interface ManagedJob {

    /** Stable unique key, e.g. {@code "model-sync"} (used as the DB key and in the API). */
    String jobKey();

    /** Default cron used to seed the job on first start (Spring 6-field cron). */
    String defaultCron();

    /** Human-readable description shown in the console. */
    String description();

    /** The job body. Exceptions are caught and recorded by the scheduler. */
    void execute();

    /** Whether to also run once at application startup (e.g. partition pre-creation). */
    default boolean runOnStartup() {
        return false;
    }
}
