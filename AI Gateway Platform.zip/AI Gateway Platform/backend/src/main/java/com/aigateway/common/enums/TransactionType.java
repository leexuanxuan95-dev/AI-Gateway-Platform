package com.aigateway.common.enums;

import com.baomidou.mybatisplus.annotation.EnumValue;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;

/** fin_transaction.biz_type. */
@Getter
public enum TransactionType implements CodedEnum<String> {

    RECHARGE("recharge"),
    CONSUME("consume"),
    REFUND("refund"),
    WITHDRAW("withdraw"),
    FREEZE("freeze");

    @EnumValue
    @JsonValue
    private final String code;

    TransactionType(String code) {
        this.code = code;
    }

    @JsonCreator
    public static TransactionType of(String code) {
        if (code == null) {
            return null;
        }
        for (TransactionType v : values()) {
            if (v.code.equals(code)) {
                return v;
            }
        }
        return null;
    }
}
