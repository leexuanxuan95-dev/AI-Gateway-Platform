package com.aigateway.modules.channel.service;

import com.aigateway.modules.channel.dto.ChannelApiKeyRequest;
import com.aigateway.modules.channel.dto.ChannelApiKeyView;
import com.aigateway.modules.channel.dto.ChannelKeyStats;
import com.aigateway.modules.channel.entity.ChannelApiKey;

import java.util.List;

/**
 * Manages a channel's upstream API-key pool: admins add/ban/unban/disable/replenish keys so
 * dead keys can be rotated without a redeploy. The gateway picks an active key per request and
 * reports upstream auth/quota failures back so the specific dead key gets banned automatically.
 * Plaintext keys are never returned or logged.
 */
public interface ChannelApiKeyService {

    /** Add a key to the channel pool: encrypt the raw key and insert it as active (status=1). */
    void add(Long channelId, ChannelApiKeyRequest req);

    /** List the channel's keys (masked) for admin display. */
    List<ChannelApiKeyView> list(Long channelId);

    /** Count the channel's keys by status. */
    ChannelKeyStats stats(Long channelId);

    /** Ban a key (status=2) with a reason; notifies admins so a replacement key can be added. */
    void ban(Long keyId, String reason);

    /** Unban a key: restore to active (status=1) and clear the ban reason / failure count. */
    void unban(Long keyId);

    /** Disable a key (status=3) without marking it banned. */
    void disable(Long keyId);

    /** Permanently delete a key from the pool. */
    void delete(Long keyId);

    /**
     * Pick an active key (status=1) for the channel via weighted-random selection; returns
     * {@code null} when the pool has no active key. Best-effort bumps usedCount + lastUsedAt.
     */
    ChannelApiKey pickActive(Long channelId);

    /**
     * Report an upstream failure for the specific key so it can be banned/aged out:
     * 401/403 bans immediately (key dead), 402/429 bans for quota exhaustion, otherwise the
     * failure count is bumped and the key is banned once it crosses the threshold. No-op if
     * {@code keyId} is null.
     */
    void reportKeyResult(Long keyId, Integer upstreamStatus);

    /** Whether the channel has at least one active (status=1) key. */
    boolean hasActiveKey(Long channelId);
}
