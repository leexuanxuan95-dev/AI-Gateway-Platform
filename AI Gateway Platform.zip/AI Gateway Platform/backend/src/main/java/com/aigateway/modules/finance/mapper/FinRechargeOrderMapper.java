package com.aigateway.modules.finance.mapper;

import com.aigateway.modules.finance.entity.FinRechargeOrder;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/** MyBatis-Plus mapper for {@link FinRechargeOrder}. */
public interface FinRechargeOrderMapper extends BaseMapper<FinRechargeOrder> {
}
