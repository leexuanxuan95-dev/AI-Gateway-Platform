package com.aigateway.modules.finance.mapper;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Update;

import java.math.BigDecimal;

/**
 * Raw cross-table writes performed inside the settlement transaction (design doc
 * §8.4 / §11.1). These touch the {@code channel}, {@code upstream_reserve} and
 * {@code bill_token} tables which are owned by other modules, but the settlement
 * flow needs to update them atomically with the finance writes, so they live here
 * as plain SQL rather than going through those modules' entities.
 */
@Mapper
public interface SettlementMapper {

    /** Accumulate upstream cost onto the channel's used quota. */
    @Update("UPDATE channel SET used_quota = used_quota + #{cost}, updated_at = now() WHERE id = #{channelId}")
    int addChannelUsedQuota(@Param("channelId") Long channelId, @Param("cost") BigDecimal cost);

    /**
     * Earmark the cost to refill the upstream reserve. Upsert by channel_id so the
     * first settlement for a channel creates the row.
     */
    @Update("INSERT INTO upstream_reserve (channel_id, reserve_amount, updated_at) " +
            "VALUES (#{channelId}, #{cost}, now()) " +
            "ON CONFLICT (channel_id) DO UPDATE SET " +
            "reserve_amount = upstream_reserve.reserve_amount + EXCLUDED.reserve_amount, updated_at = now()")
    int addUpstreamReserve(@Param("channelId") Long channelId, @Param("cost") BigDecimal cost);

    /** Insert a token billing record (partitioned table; created_at must be set). */
    @Insert("INSERT INTO bill_token (request_id, company_id, project_id, api_key_id, model_code, channel_id, " +
            "prompt_tokens, completion_tokens, cached_tokens, total_tokens, cost, upstream_cost, created_at) " +
            "VALUES (#{requestId}, #{companyId}, #{projectId}, #{apiKeyId}, #{modelCode}, #{channelId}, " +
            "#{promptTokens}, #{completionTokens}, #{cachedTokens}, #{totalTokens}, #{charge}, #{cost}, now())")
    int insertBillToken(@Param("requestId") String requestId,
                        @Param("companyId") Long companyId,
                        @Param("projectId") Long projectId,
                        @Param("apiKeyId") Long apiKeyId,
                        @Param("modelCode") String modelCode,
                        @Param("channelId") Long channelId,
                        @Param("promptTokens") long promptTokens,
                        @Param("completionTokens") long completionTokens,
                        @Param("cachedTokens") long cachedTokens,
                        @Param("totalTokens") long totalTokens,
                        @Param("charge") BigDecimal charge,
                        @Param("cost") BigDecimal cost);
}
