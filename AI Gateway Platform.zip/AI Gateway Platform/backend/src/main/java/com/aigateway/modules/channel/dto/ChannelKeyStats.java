package com.aigateway.modules.channel.dto;

import lombok.Data;

/** Aggregate counts of a channel's key pool by status. */
@Data
public class ChannelKeyStats {

    private Long channelId;
    private long total;
    private long active;
    private long banned;
    private long disabled;
}
