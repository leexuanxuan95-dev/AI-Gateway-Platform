package com.aigateway.modules.model.job;

import com.aigateway.common.schedule.ManagedJob;
import com.aigateway.modules.model.service.LiteLlmSyncService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * Periodically reconciles LiteLLM deployments with the channel key pools so the gateway self-heals
 * if a register/remove was missed (e.g. LiteLLM was unreachable at the time). Runs every 10 minutes.
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class LiteLlmReconcileJob implements ManagedJob {

    private static final String JOB_KEY = "litellm-reconcile";

    private final LiteLlmSyncService liteLlmSyncService;

    @Override
    public String jobKey() {
        return JOB_KEY;
    }

    @Override
    public String defaultCron() {
        return "0 */10 * * * *";
    }

    @Override
    public String description() {
        return "Reconcile LiteLLM deployments with channel key pools every 10 minutes";
    }

    @Override
    public void execute() {
        try {
            liteLlmSyncService.reconcileAll();
        } catch (Exception e) {
            log.warn("LiteLLM reconcile job failed: {}", e.getMessage());
        }
    }
}
