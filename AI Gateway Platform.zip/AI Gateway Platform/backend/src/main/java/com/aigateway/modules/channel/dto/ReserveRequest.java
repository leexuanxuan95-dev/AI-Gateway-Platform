package com.aigateway.modules.channel.dto;

import lombok.Data;

import java.math.BigDecimal;

/** Update payload for a channel's auto-recharge reserve configuration. */
@Data
public class ReserveRequest {

    private BigDecimal reserveAmount;
    private Boolean autoRecharge;
    private BigDecimal threshold;
    private BigDecimal rechargeAmount;
}
