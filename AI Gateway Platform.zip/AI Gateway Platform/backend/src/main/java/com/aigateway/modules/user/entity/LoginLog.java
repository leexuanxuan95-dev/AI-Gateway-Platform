package com.aigateway.modules.user.entity;

import com.aigateway.common.enums.ResultStatus;
import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.time.OffsetDateTime;

/** Login audit log entity (table {@code sys_login_log}). */
@Data
@TableName("sys_login_log")
public class LoginLog {

    @TableId(type = IdType.AUTO)
    private Long id;

    private Long userId;

    private String loginType;

    private String ip;

    private String location;

    private String userAgent;

    private String deviceId;

    /** 1 success, 0 fail. */
    private ResultStatus status;

    @TableField(fill = FieldFill.INSERT)
    private OffsetDateTime createdAt;
}
