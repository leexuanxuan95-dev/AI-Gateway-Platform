package com.aigateway.modules.model.mapper;

import com.aigateway.modules.model.entity.ModelFamily;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/** MyBatis-Plus mapper for {@link ModelFamily}. */
public interface ModelFamilyMapper extends BaseMapper<ModelFamily> {
}
