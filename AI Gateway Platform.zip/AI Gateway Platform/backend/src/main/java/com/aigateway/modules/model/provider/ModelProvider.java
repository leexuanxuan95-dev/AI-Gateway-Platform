package com.aigateway.modules.model.provider;

import com.aigateway.modules.channel.entity.Channel;

import java.util.List;

/**
 * Pulls the catalog of available models from a single upstream provider, using the
 * channel's decrypted api key and base url. Implementations must be defensive and
 * return an empty list on any error rather than throwing.
 */
public interface ModelProvider {

    /** Provider name this implementation handles (matches {@code channel.provider_name}). */
    String name();

    /** List upstream models for the given channel; empty on error. */
    List<UpstreamModel> listModels(Channel ch);
}
