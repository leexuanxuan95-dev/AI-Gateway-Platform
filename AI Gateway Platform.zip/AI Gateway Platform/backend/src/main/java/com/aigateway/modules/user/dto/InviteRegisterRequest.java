package com.aigateway.modules.user.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

/**
 * Registration via a company invite token (design doc §3). Creates (or attaches) a user
 * and grants the invite's company membership in one transactional step.
 */
@Data
public class InviteRegisterRequest {

    @NotBlank
    private String inviteToken;

    @NotBlank
    private String password;

    /** Optional display name; defaults to the invited email local part. */
    private String nickname;
}
