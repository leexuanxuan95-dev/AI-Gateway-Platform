package com.aigateway.modules.gateway.service;

import com.aigateway.common.constant.KafkaTopics;
import com.aigateway.common.constant.RedisKeys;
import com.aigateway.common.exception.BizException;
import com.aigateway.common.exception.ErrorCode;
import com.aigateway.modules.apikey.dto.ApiKeyAuthContext;
import com.aigateway.modules.billing.entity.CallLog;
import com.aigateway.modules.channel.dto.ChannelPick;
import com.aigateway.modules.channel.service.ChannelApiKeyService;
import com.aigateway.modules.channel.service.ChannelSelector;
import com.aigateway.modules.finance.dto.ChargeResult;
import com.aigateway.modules.finance.dto.SettleCmd;
import com.aigateway.modules.finance.entity.FinAccount;
import com.aigateway.modules.finance.mapper.FinAccountMapper;
import com.aigateway.modules.finance.service.BillingService;
import com.aigateway.modules.finance.service.PricingService;
import com.aigateway.modules.gateway.context.GatewayContext;
import com.aigateway.modules.gateway.dto.TokenUsage;
import com.aigateway.modules.model.entity.ModelVersion;
import com.aigateway.modules.model.service.ModelRouteService;
import com.aigateway.modules.risk.service.RiskService;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.data.redis.core.script.DefaultRedisScript;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import org.springframework.web.servlet.mvc.method.annotation.StreamingResponseBody;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;

/**
 * Shared proxy + billing orchestration for the OpenAI-compatible surface (design doc §1.2/§11/§20).
 * Centralizes the freeze &rarr; channel-pick &rarr; proxy-to-LiteLLM &rarr; settle/release flow plus
 * call-log emission, so the per-endpoint controllers stay thin. Raw keys and prompt bodies are
 * never logged.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class GatewayProxyService {

    private static final int DEFAULT_MAX_OUTPUT = 1024;
    /** Crude char-per-token heuristic for pre-call estimation only (actuals come from usage). */
    private static final int CHARS_PER_TOKEN = 4;
    private static final DateTimeFormatter DAY = DateTimeFormatter.ofPattern("yyyyMMdd");
    /** Per-call transcription floor (seconds) when audio duration is unknown. */
    private static final int TRANSCRIBE_FLOOR_SECONDS = 60;
    /** HTTP status reported on a successful proxy call. */
    private static final int HTTP_OK = 200;
    /** HTTP status reported when the upstream call fails without a status (bad gateway). */
    private static final int HTTP_BAD_GATEWAY = 502;
    /** Hard wall-clock cap for a single upstream LiteLLM call. */
    private static final Duration UPSTREAM_TIMEOUT = Duration.ofMinutes(5);
    /** Seconds in a minute (per-minute audio pro-rating). */
    private static final int SECONDS_PER_MINUTE = 60;
    /** TPM/RPM token-bucket rate denominator (limit per minute -&gt; per second). */
    private static final double SECONDS_PER_MINUTE_RATE = 60.0;
    /** Per-million pricing divisor (cost fields are quoted per 1M units). */
    private static final BigDecimal ONE_MILLION = new BigDecimal("1000000");
    /** Working scale for intermediate pricing division. */
    private static final int PRICE_CALC_SCALE = 12;
    /** Final scale for an upstream cost value. */
    private static final int COST_SCALE = 6;
    /** Daily token counter TTL. */
    private static final Duration DAILY_TOKEN_TTL = Duration.ofDays(2);
    /** Max stored user-agent length. */
    private static final int USER_AGENT_MAX_LEN = 500;

    private final WebClient litellmWebClient;
    private final ModelRouteService modelRouteService;
    private final PricingService pricingService;
    private final BillingService billingService;
    private final ChannelSelector channelSelector;
    private final ChannelApiKeyService channelApiKeyService;
    private final RiskService riskService;
    private final FinAccountMapper finAccountMapper;
    private final StringRedisTemplate stringRedisTemplate;
    private final DefaultRedisScript<Long> tokenBucketScript;
    private final ObjectMapper objectMapper;
    private final KafkaTemplate<String, String> kafkaTemplate;

    @Value("${aigateway.litellm.master-key}")
    private String masterKey;

    // ===================================================================================
    // Non-streaming JSON proxy with full billing (chat / embeddings / images / audio / rerank)
    // ===================================================================================

    /**
     * Proxy a JSON request to LiteLLM, bill it, and return the upstream JSON string.
     *
     * @param path        upstream path, e.g. {@code /v1/chat/completions}
     * @param body        parsed request body (model is read from it where present)
     * @param modelCode   resolved model code (already allow-checked + assertCallable'd)
     * @param projectId   effective project id (header override honored by caller)
     * @param estPrompt   estimated prompt tokens for the freeze
     * @param estOutput   estimated output tokens for the freeze
     * @param resp        servlet response, for billing headers
     */
    public String proxyAndBill(String path, Map<String, Object> body, String modelCode,
                               Long projectId, long estPrompt, long estOutput,
                               HttpServletResponse resp) {
        ApiKeyAuthContext ctx = requireAuth();
        long started = System.currentTimeMillis();

        // 0) TPM pre-check with the prompt+output estimate (post-account actuals after settle)
        enforceTpm(ctx, estPrompt + estOutput);

        // 1) estimate + freeze
        ChargeResult est = pricingService.calc(modelCode, estPrompt, estOutput, 0, ctx.getCompanyId());
        BigDecimal frozen = billingService.freeze(ctx.getCompanyId(), est.getCharge());

        // 2) channel pick (cost attribution + breaker)
        ChannelPick pick;
        try {
            pick = channelSelector.pick(modelCode);
        } catch (RuntimeException e) {
            // no channel available -> return the frozen estimate so funds are not locked
            billingService.release(ctx.getCompanyId(), frozen);
            throw e;
        }

        String responseJson;
        int httpStatus = HTTP_OK;
        String bizStatus = "ok";
        try {
            responseJson = litellmWebClient.post()
                    .uri(path)
                    .header(HttpHeaders.AUTHORIZATION, "Bearer " + masterKey)
                    .contentType(MediaType.APPLICATION_JSON)
                    .bodyValue(writeJson(body))
                    .retrieve()
                    .bodyToMono(String.class)
                    .block(UPSTREAM_TIMEOUT);
        } catch (WebClientResponseException e) {
            channelSelector.reportFailure(pick.getChannelId());
            channelApiKeyService.reportKeyResult(pick.getKeyId(), e.getStatusCode().value());
            releaseOnFailure(ctx, pick, modelCode, projectId, frozen);
            httpStatus = e.getStatusCode().value();
            bizStatus = "upstream_error";
            emitCallLog(modelCode, pick.getChannelId(), httpStatus, bizStatus,
                    (int) (System.currentTimeMillis() - started), false);
            log.warn("upstream error {} for model {}", httpStatus, modelCode);
            throw new BizException(ErrorCode.UPSTREAM_ERROR, "upstream returned " + httpStatus);
        } catch (Exception e) {
            channelSelector.reportFailure(pick.getChannelId());
            releaseOnFailure(ctx, pick, modelCode, projectId, frozen);
            emitCallLog(modelCode, pick.getChannelId(), HTTP_BAD_GATEWAY, "upstream_error",
                    (int) (System.currentTimeMillis() - started), false);
            log.warn("upstream call failed for model {}: {}", modelCode, e.getMessage());
            throw new BizException(ErrorCode.UPSTREAM_ERROR);
        }

        // 3) extract usage and settle
        TokenUsage usage = extractUsage(responseJson, estPrompt, estOutput);
        ChargeResult actual = pricingService.calc(modelCode, usage.getPromptTokens(),
                usage.getCompletionTokens(), usage.getCachedTokens(), ctx.getCompanyId());
        settle(ctx, pick, modelCode, projectId, usage, actual, frozen);
        channelSelector.reportSuccess(pick.getChannelId(), actual.getCost());

        // post-account actual tokens against TPM + daily quota, then run anomaly rules
        accountTpmActual(ctx, usage.getCompletionTokens());
        enforceDailyTokenQuota(ctx, usage.total());
        riskService.recordTokensAndCheckSpike(ctx.getCompanyId(), usage.total());
        evaluateAfterCall(ctx, usage.total());

        writeBillingHeaders(resp, usage.total(), actual.getCharge());
        emitCallLog(modelCode, pick.getChannelId(), httpStatus, bizStatus,
                (int) (System.currentTimeMillis() - started), false);
        return responseJson;
    }

    // ===================================================================================
    // Streaming chat proxy (SSE passthrough) with billing from the final usage chunk
    // ===================================================================================

    /**
     * Proxy a streaming chat request: forwards upstream SSE chunks verbatim to the client and
     * settles from the {@code usage} carried in the final chunk (the caller must have injected
     * {@code stream_options.include_usage=true}); falls back to estimation if absent.
     */
    public StreamingResponseBody proxyStream(String path, Map<String, Object> body, String modelCode,
                                             Long projectId, long estPrompt, long estOutput) {
        ApiKeyAuthContext ctx = requireAuth();
        long started = System.currentTimeMillis();

        enforceTpm(ctx, estPrompt + estOutput);
        ChargeResult est = pricingService.calc(modelCode, estPrompt, estOutput, 0, ctx.getCompanyId());
        BigDecimal frozen = billingService.freeze(ctx.getCompanyId(), est.getCharge());
        ChannelPick pick;
        try {
            pick = channelSelector.pick(modelCode);
        } catch (RuntimeException e) {
            // no channel available -> return the frozen estimate so funds are not locked
            billingService.release(ctx.getCompanyId(), frozen);
            throw e;
        }

        return out -> {
            AtomicReference<TokenUsage> usageRef = new AtomicReference<>();
            StringBuilder contentAcc = new StringBuilder();
            boolean ok = true;
            try {
                litellmWebClient.post()
                        .uri(path)
                        .header(HttpHeaders.AUTHORIZATION, "Bearer " + masterKey)
                        .contentType(MediaType.APPLICATION_JSON)
                        .bodyValue(writeJson(body))
                        .retrieve()
                        .bodyToFlux(String.class)
                        .toIterable()
                        .forEach(chunk -> {
                            try {
                                // forward verbatim as an SSE line
                                out.write(("data: " + chunk + "\n\n").getBytes(StandardCharsets.UTF_8));
                                out.flush();
                            } catch (Exception ioe) {
                                throw new RuntimeException(ioe);
                            }
                            TokenUsage u = tryParseChunkUsage(chunk);
                            if (u != null) {
                                usageRef.set(u);
                            }
                            String delta = tryParseDeltaContent(chunk);
                            if (delta != null) {
                                contentAcc.append(delta);
                            }
                        });
                out.write("data: [DONE]\n\n".getBytes(StandardCharsets.UTF_8));
                out.flush();
            } catch (Exception e) {
                ok = false;
                channelSelector.reportFailure(pick.getChannelId());
                log.warn("stream upstream failed for model {}: {}", modelCode, e.getMessage());
            }

            TokenUsage usage = usageRef.get();
            if (usage == null) {
                long out2 = Math.max(1, contentAcc.length() / CHARS_PER_TOKEN);
                usage = new TokenUsage(estPrompt, out2, 0);
            }
            ChargeResult actual = pricingService.calc(modelCode, usage.getPromptTokens(),
                    usage.getCompletionTokens(), usage.getCachedTokens(), ctx.getCompanyId());
            settle(ctx, pick, modelCode, projectId, usage, actual, frozen);
            if (ok) {
                channelSelector.reportSuccess(pick.getChannelId(), actual.getCost());
                accountTpmActual(ctx, usage.getCompletionTokens());
                enforceDailyTokenQuota(ctx, usage.total());
                riskService.recordTokensAndCheckSpike(ctx.getCompanyId(), usage.total());
                evaluateAfterCall(ctx, usage.total());
            }
            emitCallLog(modelCode, pick.getChannelId(), ok ? HTTP_OK : HTTP_BAD_GATEWAY,
                    ok ? "ok" : "upstream_error", (int) (System.currentTimeMillis() - started), true);
        };
    }

    // ===================================================================================
    // Unit-based billing for non-chat endpoints (images / audio / rerank) - design doc §20.4
    // ===================================================================================

    /**
     * Proxy a JSON request whose cost is unit-based (not token-based) and bill it through the SAME
     * hard min-margin rule via {@link PricingService#calcByCost}. The upstream cost is computed from
     * the model's price fields x the {@code unitCount} for {@code unitKind}:
     * <ul>
     *   <li>{@code image} - {@code costOutput} (price-per-image, optionally scaled by size/quality);</li>
     *   <li>{@code char} - {@code costInput} per 1k input characters (audio speech / TTS);</li>
     *   <li>{@code second} - {@code costOutput} per minute of audio, pro-rated by seconds (transcriptions);</li>
     *   <li>{@code query} - {@code costInput} per query+doc unit (rerank).</li>
     * </ul>
     *
     * @param unitKind  one of {@code image}/{@code char}/{@code second}/{@code query}
     * @param unitCount number of billable units (e.g. images, characters, seconds, query+docs)
     */
    public String proxyUnitAndBill(String path, Map<String, Object> body, String modelCode,
                                   Long projectId, String unitKind, long unitCount,
                                   HttpServletResponse resp) {
        ApiKeyAuthContext ctx = requireAuth();
        long started = System.currentTimeMillis();

        BigDecimal upstreamCost = unitCost(modelCode, unitKind, unitCount);
        ChargeResult est = pricingService.calcByCost(upstreamCost, ctx.getCompanyId());
        BigDecimal frozen = billingService.freeze(ctx.getCompanyId(), est.getCharge());
        ChannelPick pick;
        try {
            pick = channelSelector.pick(modelCode);
        } catch (RuntimeException e) {
            // no channel available -> return the frozen estimate so funds are not locked
            billingService.release(ctx.getCompanyId(), frozen);
            throw e;
        }
        try {
            String json = litellmWebClient.post()
                    .uri(path)
                    .header(HttpHeaders.AUTHORIZATION, "Bearer " + masterKey)
                    .contentType(MediaType.APPLICATION_JSON)
                    .bodyValue(writeJson(body))
                    .retrieve()
                    .bodyToMono(String.class)
                    .block(UPSTREAM_TIMEOUT);
            settleUnit(ctx, pick, modelCode, projectId, est, frozen);
            channelSelector.reportSuccess(pick.getChannelId(), est.getCost());
            evaluateAfterCall(ctx, 0);
            writeBillingHeaders(resp, 0, est.getCharge());
            emitCallLog(modelCode, pick.getChannelId(), HTTP_OK, "ok",
                    (int) (System.currentTimeMillis() - started), false);
            return json;
        } catch (WebClientResponseException e) {
            channelSelector.reportFailure(pick.getChannelId());
            channelApiKeyService.reportKeyResult(pick.getKeyId(), e.getStatusCode().value());
            releaseOnFailure(ctx, pick, modelCode, projectId, frozen);
            emitCallLog(modelCode, pick.getChannelId(), e.getStatusCode().value(), "upstream_error",
                    (int) (System.currentTimeMillis() - started), false);
            log.warn("unit upstream error {} for model {}", e.getStatusCode().value(), modelCode);
            throw new BizException(ErrorCode.UPSTREAM_ERROR, "upstream returned " + e.getStatusCode().value());
        } catch (Exception e) {
            channelSelector.reportFailure(pick.getChannelId());
            releaseOnFailure(ctx, pick, modelCode, projectId, frozen);
            emitCallLog(modelCode, pick.getChannelId(), HTTP_BAD_GATEWAY, "upstream_error",
                    (int) (System.currentTimeMillis() - started), false);
            log.warn("unit upstream failed for model {}: {}", modelCode, e.getMessage());
            throw new BizException(ErrorCode.UPSTREAM_ERROR);
        }
    }

    /**
     * Raw (multipart) audio-transcription proxy billed per-second (pro-rated per minute) via
     * {@link PricingService#calcByCost}; when duration is unknown a per-call floor of
     * {@value #TRANSCRIBE_FLOOR_SECONDS}s is billed. Returns the upstream JSON string.
     *
     * @param durationSeconds known audio duration, or &lt;=0 to apply the per-call floor
     */
    public String proxyTranscriptionAndBill(String path, byte[] rawBody, MediaType contentType,
                                            String modelCode, Long projectId, long durationSeconds,
                                            HttpServletResponse resp) {
        ApiKeyAuthContext ctx = requireAuth();
        long started = System.currentTimeMillis();
        long seconds = durationSeconds > 0 ? durationSeconds : TRANSCRIBE_FLOOR_SECONDS;

        BigDecimal upstreamCost = unitCost(modelCode, "second", seconds);
        ChargeResult est = pricingService.calcByCost(upstreamCost, ctx.getCompanyId());
        BigDecimal frozen = billingService.freeze(ctx.getCompanyId(), est.getCharge());
        ChannelPick pick;
        try {
            pick = channelSelector.pick(modelCode);
        } catch (RuntimeException e) {
            // no channel available -> return the frozen estimate so funds are not locked
            billingService.release(ctx.getCompanyId(), frozen);
            throw e;
        }
        try {
            String json = litellmWebClient.post()
                    .uri(path)
                    .header(HttpHeaders.AUTHORIZATION, "Bearer " + masterKey)
                    .contentType(contentType)
                    .bodyValue(rawBody)
                    .retrieve()
                    .bodyToMono(String.class)
                    .block(UPSTREAM_TIMEOUT);
            settleUnit(ctx, pick, modelCode, projectId, est, frozen);
            channelSelector.reportSuccess(pick.getChannelId(), est.getCost());
            evaluateAfterCall(ctx, 0);
            writeBillingHeaders(resp, 0, est.getCharge());
            emitCallLog(modelCode, pick.getChannelId(), HTTP_OK, "ok",
                    (int) (System.currentTimeMillis() - started), false);
            return json;
        } catch (Exception e) {
            channelSelector.reportFailure(pick.getChannelId());
            releaseOnFailure(ctx, pick, modelCode, projectId, frozen);
            emitCallLog(modelCode, pick.getChannelId(), HTTP_BAD_GATEWAY, "upstream_error",
                    (int) (System.currentTimeMillis() - started), false);
            log.warn("transcription upstream failed for model {}: {}", modelCode, e.getMessage());
            throw new BizException(ErrorCode.UPSTREAM_ERROR);
        }
    }

    /**
     * Upstream cost for a unit-based endpoint = unit-count x the relevant per-unit cost from the
     * model version. Throws {@code PRICE_NOT_SET} if the relevant cost is not configured.
     */
    private BigDecimal unitCost(String modelCode, String unitKind, long unitCount) {
        ModelVersion mv = modelRouteService.getByCode(modelCode);
        if (mv == null) {
            throw new BizException(ErrorCode.MODEL_NOT_FOUND);
        }
        long units = Math.max(1, unitCount);
        BigDecimal cost;
        switch (unitKind) {
            case "image":
                // costOutput holds the per-image price for image models.
                cost = mulNonNull(mv.getCostOutput(), BigDecimal.valueOf(units));
                break;
            case "char":
                // costInput is per 1M units; speech is priced per character -> /1M is applied in part().
                cost = perMillion(mv.getCostInput(), units);
                break;
            case "second":
                // costOutput is the per-minute audio price; pro-rate by seconds.
                cost = mulNonNull(mv.getCostOutput(), BigDecimal.valueOf(units)
                        .divide(BigDecimal.valueOf(SECONDS_PER_MINUTE), PRICE_CALC_SCALE, RoundingMode.HALF_UP));
                break;
            case "query":
                // costInput is per 1M query+doc units.
                cost = perMillion(mv.getCostInput(), units);
                break;
            default:
                cost = perMillion(mv.getCostInput(), units);
                break;
        }
        if (cost == null || cost.signum() <= 0) {
            throw new BizException(ErrorCode.PRICE_NOT_SET);
        }
        return cost.setScale(COST_SCALE, RoundingMode.HALF_UP);
    }

    private BigDecimal mulNonNull(BigDecimal price, BigDecimal factor) {
        return price == null ? null : price.multiply(factor);
    }

    private BigDecimal perMillion(BigDecimal pricePerMillion, long units) {
        if (pricePerMillion == null) {
            return null;
        }
        return BigDecimal.valueOf(units).divide(ONE_MILLION, PRICE_CALC_SCALE, RoundingMode.HALF_UP)
                .multiply(pricePerMillion);
    }

    /** Settle a unit-billed (zero-token) request. */
    private void settleUnit(ApiKeyAuthContext ctx, ChannelPick pick, String modelCode, Long projectId,
                            ChargeResult charge, BigDecimal frozen) {
        settle(ctx, pick, modelCode, projectId, new TokenUsage(0, 0, 0), charge, frozen);
    }

    // ===================================================================================
    // helpers
    // ===================================================================================

    private ApiKeyAuthContext requireAuth() {
        ApiKeyAuthContext ctx = GatewayContext.auth();
        if (ctx == null) {
            throw new BizException(ErrorCode.INVALID_API_KEY);
        }
        return ctx;
    }

    /**
     * Pre-check the per-minute token budget against {@code tpmLimit} using the shared token-bucket
     * Lua script (rate = tpm/60, cap = tpm), consuming {@code estTokens}. Over budget -&gt; 429
     * rate_limited. Fails open on Redis error so a cache outage never blocks a legitimate call.
     */
    private void enforceTpm(ApiKeyAuthContext ctx, long estTokens) {
        Integer tpm = ctx.getTpmLimit();
        if (tpm == null || tpm <= 0) {
            return;
        }
        long req = Math.max(1, estTokens);
        try {
            double rate = tpm / SECONDS_PER_MINUTE_RATE;
            Long ok = stringRedisTemplate.execute(tokenBucketScript,
                    Collections.singletonList(RedisKeys.tpm(ctx.getApiKeyId())),
                    String.valueOf(rate), String.valueOf(tpm),
                    String.valueOf(System.currentTimeMillis() / 1000.0), String.valueOf(req));
            if (ok != null && ok == 0L) {
                throw new BizException(ErrorCode.RATE_LIMITED, "tpm limit exceeded");
            }
        } catch (BizException be) {
            throw be;
        } catch (Exception e) {
            log.warn("tpm pre-check failed for key {} (fail-open): {}", ctx.getApiKeyId(), e.getMessage());
        }
    }

    /**
     * Post-account the actual completion tokens against the TPM bucket (best-effort drain so the
     * window reflects real usage; never blocks the response that already succeeded).
     */
    private void accountTpmActual(ApiKeyAuthContext ctx, long completionTokens) {
        Integer tpm = ctx.getTpmLimit();
        if (tpm == null || tpm <= 0 || completionTokens <= 0) {
            return;
        }
        try {
            double rate = tpm / SECONDS_PER_MINUTE_RATE;
            stringRedisTemplate.execute(tokenBucketScript,
                    Collections.singletonList(RedisKeys.tpm(ctx.getApiKeyId())),
                    String.valueOf(rate), String.valueOf(tpm),
                    String.valueOf(System.currentTimeMillis() / 1000.0),
                    String.valueOf(completionTokens));
        } catch (Exception e) {
            log.debug("tpm post-account failed for key {}: {}", ctx.getApiKeyId(), e.getMessage());
        }
    }

    /**
     * Increment the daily token counter by the actual total tokens consumed. The over-quota gate
     * itself is enforced as a pre-check in {@code ApiKeyGatewayFilter} (so a successful, already-paid
     * response is never discarded); this only accumulates the running total. Fails open on Redis error.
     */
    private void enforceDailyTokenQuota(ApiKeyAuthContext ctx, long totalTokens) {
        if (totalTokens <= 0) {
            return;
        }
        try {
            String key = RedisKeys.dailyTokens(ctx.getApiKeyId(), LocalDate.now().format(DAY));
            Long total = stringRedisTemplate.opsForValue().increment(key, totalTokens);
            if (total != null && total == totalTokens) {
                stringRedisTemplate.expire(key, DAILY_TOKEN_TTL);
            }
        } catch (Exception e) {
            log.warn("daily token accounting failed for key {} (fail-open): {}",
                    ctx.getApiKeyId(), e.getMessage());
        }
    }

    /** Run anomaly rules defensively against the completed call; never throws. */
    private void evaluateAfterCall(ApiKeyAuthContext ctx, long totalTokens) {
        try {
            GatewayContext.Holder h = GatewayContext.get();
            String ip = h == null ? null : h.getClientIp();
            String country = h == null ? null : h.getCountry();
            riskService.evaluateAfterCall(ctx.getCompanyId(), ctx.getApiKeyId(), ip, country, totalTokens);
        } catch (Exception e) {
            log.debug("after-call risk evaluation failed: {}", e.getMessage());
        }
    }

    /** Current available balance for the company (for the X-Balance header); null on any error. */
    private BigDecimal currentBalance(Long companyId) {
        if (companyId == null) {
            return null;
        }
        try {
            FinAccount acc = finAccountMapper.selectOne(Wrappers.<FinAccount>lambdaQuery()
                    .eq(FinAccount::getCompanyId, companyId).last("limit 1"));
            return acc == null ? null : acc.getAvailableBalance();
        } catch (Exception e) {
            log.debug("balance read failed for company {}: {}", companyId, e.getMessage());
            return null;
        }
    }

    /** Settle a completed request (release frozen, deduct actual, write ledgers). */
    private void settle(ApiKeyAuthContext ctx, ChannelPick pick, String modelCode, Long projectId,
                        TokenUsage usage, ChargeResult actual, BigDecimal frozen) {
        SettleCmd cmd = new SettleCmd();
        cmd.setCompanyId(ctx.getCompanyId());
        cmd.setApiKeyId(ctx.getApiKeyId());
        cmd.setProjectId(projectId != null ? projectId : ctx.getProjectId());
        cmd.setChannelId(pick.getChannelId());
        cmd.setModelCode(modelCode);
        cmd.setRequestId(currentRequestId());
        cmd.setPromptTokens(usage.getPromptTokens());
        cmd.setCompletionTokens(usage.getCompletionTokens());
        cmd.setCachedTokens(usage.getCachedTokens());
        cmd.setCharge(actual.getCharge());
        cmd.setCost(actual.getCost());
        cmd.setFrozen(frozen);
        billingService.settle(cmd);
    }

    /** On upstream failure, settle a zero-usage request so the frozen estimate is released. */
    private void releaseOnFailure(ApiKeyAuthContext ctx, ChannelPick pick, String modelCode,
                                  Long projectId, BigDecimal frozen) {
        try {
            SettleCmd cmd = new SettleCmd();
            cmd.setCompanyId(ctx.getCompanyId());
            cmd.setApiKeyId(ctx.getApiKeyId());
            cmd.setProjectId(projectId != null ? projectId : ctx.getProjectId());
            cmd.setChannelId(pick.getChannelId());
            cmd.setModelCode(modelCode);
            cmd.setRequestId(currentRequestId());
            cmd.setPromptTokens(0);
            cmd.setCompletionTokens(0);
            cmd.setCachedTokens(0);
            cmd.setCharge(BigDecimal.ZERO);
            cmd.setCost(BigDecimal.ZERO);
            cmd.setFrozen(frozen);
            billingService.settle(cmd);
        } catch (Exception e) {
            log.warn("release-on-failure settle failed: {}", e.getMessage());
        }
    }

    /** Estimate prompt tokens from message content lengths (chars/4); output from max_tokens or default. */
    @SuppressWarnings("unchecked")
    public long estimatePromptTokens(Map<String, Object> body) {
        Object messages = body.get("messages");
        long chars = 0;
        if (messages instanceof List<?> list) {
            for (Object m : list) {
                if (m instanceof Map<?, ?> msg) {
                    Object c = msg.get("content");
                    if (c instanceof String s) {
                        chars += s.length();
                    } else if (c != null) {
                        chars += String.valueOf(c).length();
                    }
                }
            }
        }
        Object input = body.get("input");
        if (input instanceof String s) {
            chars += s.length();
        } else if (input instanceof List<?> list) {
            for (Object o : list) {
                chars += String.valueOf(o).length();
            }
        }
        return Math.max(1, chars / CHARS_PER_TOKEN);
    }

    public long estimateOutputTokens(Map<String, Object> body) {
        Object mt = body.get("max_tokens");
        if (mt instanceof Number n) {
            return n.longValue();
        }
        return DEFAULT_MAX_OUTPUT;
    }

    /** Parse usage{prompt_tokens,completion_tokens,prompt_tokens_details.cached_tokens}. */
    @SuppressWarnings("unchecked")
    private TokenUsage extractUsage(String json, long estPrompt, long estOutput) {
        try {
            Map<String, Object> map = objectMapper.readValue(json, new TypeReference<>() {});
            Object usageObj = map.get("usage");
            if (usageObj instanceof Map<?, ?> usage) {
                long prompt = asLong(usage.get("prompt_tokens"));
                long completion = asLong(usage.get("completion_tokens"));
                long cached = 0;
                Object details = usage.get("prompt_tokens_details");
                if (details instanceof Map<?, ?> d) {
                    cached = asLong(d.get("cached_tokens"));
                }
                return new TokenUsage(prompt, completion, cached);
            }
        } catch (Exception e) {
            log.debug("usage parse failed, estimating: {}", e.getMessage());
        }
        return new TokenUsage(estPrompt, estOutput, 0);
    }

    @SuppressWarnings("unchecked")
    private TokenUsage tryParseChunkUsage(String chunk) {
        if (chunk == null || !chunk.contains("usage")) {
            return null;
        }
        try {
            Map<String, Object> map = objectMapper.readValue(chunk, new TypeReference<>() {});
            Object usageObj = map.get("usage");
            if (usageObj instanceof Map<?, ?> usage && usage.get("prompt_tokens") != null) {
                long prompt = asLong(usage.get("prompt_tokens"));
                long completion = asLong(usage.get("completion_tokens"));
                long cached = 0;
                Object details = usage.get("prompt_tokens_details");
                if (details instanceof Map<?, ?> d) {
                    cached = asLong(d.get("cached_tokens"));
                }
                return new TokenUsage(prompt, completion, cached);
            }
        } catch (Exception ignore) {
            // not a usage-bearing chunk
        }
        return null;
    }

    @SuppressWarnings("unchecked")
    private String tryParseDeltaContent(String chunk) {
        try {
            Map<String, Object> map = objectMapper.readValue(chunk, new TypeReference<>() {});
            Object choices = map.get("choices");
            if (choices instanceof List<?> list && !list.isEmpty()
                    && list.get(0) instanceof Map<?, ?> choice
                    && choice.get("delta") instanceof Map<?, ?> delta
                    && delta.get("content") instanceof String s) {
                return s;
            }
        } catch (Exception ignore) {
            // non-content chunk
        }
        return null;
    }

    private void writeBillingHeaders(HttpServletResponse resp, long totalTokens, BigDecimal charge) {
        GatewayContext.Holder h = GatewayContext.get();
        resp.setHeader("X-Request-Id", currentRequestId());
        resp.setHeader("X-Tokens-Used", String.valueOf(totalTokens));
        resp.setHeader("X-Cost", charge == null ? "0" : charge.toPlainString());
        if (h != null && h.getAuth() != null) {
            Integer limit = h.getRateLimitLimit() != null ? h.getRateLimitLimit() : h.getAuth().getRpmLimit();
            if (limit != null) {
                resp.setHeader("X-RateLimit-Limit", String.valueOf(limit));
            }
            if (h.getRateLimitRemaining() != null) {
                resp.setHeader("X-RateLimit-Remaining", String.valueOf(h.getRateLimitRemaining()));
            }
            if (h.getRateLimitResetEpoch() != null) {
                resp.setHeader("X-RateLimit-Reset", String.valueOf(h.getRateLimitResetEpoch()));
            }
            // §20.7: surface the company's current available balance.
            BigDecimal balance = currentBalance(h.getAuth().getCompanyId());
            if (balance != null) {
                resp.setHeader("X-Balance", balance.toPlainString());
            }
        }
    }

    private void emitCallLog(String modelCode, Long channelId, int httpStatus, String bizStatus,
                             int responseTimeMs, boolean stream) {
        try {
            GatewayContext.Holder h = GatewayContext.get();
            ApiKeyAuthContext ctx = h == null ? null : h.getAuth();
            CallLog entry = new CallLog();
            entry.setRequestId(currentRequestId());
            entry.setApiKeyId(ctx == null ? null : ctx.getApiKeyId());
            entry.setCompanyId(ctx == null ? null : ctx.getCompanyId());
            entry.setModelCode(modelCode);
            entry.setChannelId(channelId);
            entry.setIp(h == null ? null : h.getClientIp());
            entry.setUserAgent(h == null ? null : truncate(h.getUserAgent()));
            entry.setHttpStatus(httpStatus);
            entry.setBizStatus(bizStatus);
            entry.setResponseTime(responseTimeMs);
            entry.setIsStream(stream);
            kafkaTemplate.send(KafkaTopics.CALL_LOG, entry.getRequestId(), objectMapper.writeValueAsString(entry));
        } catch (Exception e) {
            log.debug("emit call-log failed: {}", e.getMessage());
        }
    }

    private String currentRequestId() {
        GatewayContext.Holder h = GatewayContext.get();
        return h == null ? null : h.getRequestId();
    }

    private String writeJson(Map<String, Object> body) {
        try {
            return objectMapper.writeValueAsString(body);
        } catch (Exception e) {
            throw new BizException(ErrorCode.PARAM_ERROR, "invalid request body");
        }
    }

    private static long asLong(Object v) {
        if (v instanceof Number n) {
            return n.longValue();
        }
        if (v instanceof String s) {
            try {
                return Long.parseLong(s.trim());
            } catch (NumberFormatException ignore) {
                return 0;
            }
        }
        return 0;
    }

    private static String truncate(String s) {
        if (s == null) {
            return null;
        }
        return s.length() > USER_AGENT_MAX_LEN ? s.substring(0, USER_AGENT_MAX_LEN) : s;
    }
}
