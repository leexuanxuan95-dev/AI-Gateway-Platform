package com.aigateway.modules.model.job;

import com.aigateway.common.constant.KafkaTopics;
import com.aigateway.common.enums.CommonStatus;
import com.aigateway.common.enums.ModelAvailability;
import com.aigateway.common.enums.ModelStatus;
import com.aigateway.modules.channel.entity.Channel;
import com.aigateway.modules.channel.mapper.ChannelMapper;
import com.aigateway.modules.model.entity.ModelChannelRoute;
import com.aigateway.modules.model.entity.ModelSyncLog;
import com.aigateway.modules.model.entity.ModelVersion;
import com.aigateway.modules.model.mapper.ModelChannelRouteMapper;
import com.aigateway.modules.model.mapper.ModelSyncLogMapper;
import com.aigateway.modules.model.mapper.ModelVersionMapper;
import com.aigateway.modules.model.provider.ModelProvider;
import com.aigateway.modules.model.provider.ProviderFactory;
import com.aigateway.modules.model.provider.UpstreamModel;
import com.aigateway.modules.model.service.LiteLlmSyncService;
import com.aigateway.common.schedule.ManagedJob;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Periodically (every 6h) pulls each enabled channel's upstream model catalog and reconciles
 * it into {@code model_version} (design doc §7.6). New models are inserted as drafts
 * (status=3/disabled, availability=unavailable, no customer/cost price). Existing models have
 * their info refreshed; models that vanished upstream are marked unavailable. Where pricing is
 * exposed (e.g. OpenRouter), cost fields are filled. Active versions are (re)registered with
 * LiteLLM so routing stays dynamic, and a Kafka alert is emitted for new unpriced models.
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class ModelSyncJob implements ManagedJob {

    private static final String JOB_KEY = "model-sync";

    private final ChannelMapper channelMapper;
    private final ModelVersionMapper versionMapper;
    private final ModelChannelRouteMapper routeMapper;
    private final ModelSyncLogMapper syncLogMapper;
    private final ProviderFactory providerFactory;
    private final LiteLlmSyncService liteLlmSyncService;
    private final KafkaTemplate<String, String> kafkaTemplate;

    @Override
    public String jobKey() {
        return JOB_KEY;
    }

    @Override
    public String defaultCron() {
        return "0 0 */6 * * ?";
    }

    @Override
    public String description() {
        return "Reconcile upstream model catalogs into model_version every 6 hours";
    }

    @Override
    public void execute() {
        List<Channel> channels = channelMapper.selectList(
                Wrappers.<Channel>lambdaQuery().eq(Channel::getStatus, CommonStatus.ENABLED));
        for (Channel ch : channels) {
            try {
                syncChannel(ch);
            } catch (Exception e) {
                log.warn("model sync failed for channel {}: {}", ch.getId(), e.getMessage());
            }
        }
    }

    /** Reconcile one channel's upstream catalog. */
    private void syncChannel(Channel ch) {
        ModelProvider provider = providerFactory.get(ch.getProviderName());
        if (provider == null) {
            log.debug("no provider impl for {}, skipping channel {}", ch.getProviderName(), ch.getId());
            return;
        }
        List<UpstreamModel> upstream = provider.listModels(ch);
        if (upstream.isEmpty()) {
            log.debug("channel {} ({}) returned no models", ch.getId(), ch.getProviderName());
            return;
        }

        int newCount = 0;
        int updatedCount = 0;
        Set<String> seenCodes = new HashSet<>();

        for (UpstreamModel um : upstream) {
            if (um.getId() == null) {
                continue;
            }
            seenCodes.add(um.getId());
            ModelVersion existing = versionMapper.selectOne(
                    Wrappers.<ModelVersion>lambdaQuery().eq(ModelVersion::getModelCode, um.getId()));
            if (existing == null) {
                ModelVersion draft = newDraft(ch, um);
                versionMapper.insert(draft);
                newCount++;
                if (draft.getCostInput() == null || draft.getCostOutput() == null) {
                    notifyUnpriced(ch, draft);
                }
            } else {
                if (updateExisting(existing, um)) {
                    versionMapper.updateById(existing);
                }
                updatedCount++;
            }
        }

        int staleCount = markStale(ch, seenCodes);
        // Register LiteLLM deployments per ACTIVE upstream key of this channel (per-key routing).
        liteLlmSyncService.syncChannel(ch.getId());
        writeSyncLog(ch, newCount, updatedCount, staleCount);
    }

    /** A new upstream model -> draft: delisted, no customer price; cost only if provider gave it. */
    private ModelVersion newDraft(Channel ch, UpstreamModel um) {
        ModelVersion v = new ModelVersion();
        v.setFamilyId(ch.getFamilyId());
        v.setModelCode(um.getId());
        v.setDisplayName(um.getDisplayName() != null ? um.getDisplayName() : um.getId());
        v.setContextWindow(um.getContextWindow());
        v.setCurrency("USD");
        // upstream cost only where provider exposes pricing (e.g. OpenRouter)
        v.setCostInput(um.getPriceInput());
        v.setCostOutput(um.getPriceOutput());
        // new model: delisted draft, no customer price
        v.setStatus(ModelStatus.DISABLED);
        v.setAvailability(ModelAvailability.UNAVAILABLE);
        v.setSort(0);
        return v;
    }

    /** Refresh mutable info / cost from upstream. Returns true if anything changed. */
    private boolean updateExisting(ModelVersion existing, UpstreamModel um) {
        boolean changed = false;
        if (um.getDisplayName() != null && !um.getDisplayName().equals(existing.getDisplayName())) {
            existing.setDisplayName(um.getDisplayName());
            changed = true;
        }
        if (um.getContextWindow() != null && !um.getContextWindow().equals(existing.getContextWindow())) {
            existing.setContextWindow(um.getContextWindow());
            changed = true;
        }
        if (um.getPriceInput() != null) {
            existing.setCostInput(um.getPriceInput());
            changed = true;
        }
        if (um.getPriceOutput() != null) {
            existing.setCostOutput(um.getPriceOutput());
            changed = true;
        }
        // a model that had been marked unavailable but reappeared upstream regains availability
        // only if an admin has listed it; we never auto-list. We just clear the stale flag.
        return changed;
    }

    /** Mark versions routed to this channel that no longer exist upstream as unavailable. */
    private int markStale(Channel ch, Set<String> seenCodes) {
        List<ModelChannelRoute> routes = routeMapper.selectList(
                Wrappers.<ModelChannelRoute>lambdaQuery().eq(ModelChannelRoute::getChannelId, ch.getId()));
        int stale = 0;
        for (ModelChannelRoute route : routes) {
            ModelVersion v = versionMapper.selectById(route.getModelId());
            if (v == null || v.getModelCode() == null) {
                continue;
            }
            if (!seenCodes.contains(v.getModelCode()) && ModelAvailability.UNAVAILABLE != v.getAvailability()) {
                v.setAvailability(ModelAvailability.UNAVAILABLE);
                versionMapper.updateById(v);
                stale++;
            }
        }
        return stale;
    }

    /** Emit a notify alert for a newly discovered, unpriced model (best-effort). */
    private void notifyUnpriced(Channel ch, ModelVersion v) {
        try {
            String msg = "{\"scene\":\"new_model_unpriced\",\"channelId\":" + ch.getId()
                    + ",\"provider\":\"" + ch.getProviderName() + "\",\"modelCode\":\""
                    + v.getModelCode() + "\"}";
            kafkaTemplate.send(KafkaTopics.NOTIFY, msg);
        } catch (Exception e) {
            log.warn("notify (new unpriced model {}) failed: {}", v.getModelCode(), e.getMessage());
        }
    }

    private void writeSyncLog(Channel ch, int newCount, int updatedCount, int staleCount) {
        try {
            ModelSyncLog entry = new ModelSyncLog();
            entry.setChannelId(ch.getId());
            entry.setProviderName(ch.getProviderName());
            entry.setNewCount(newCount);
            entry.setUpdatedCount(updatedCount);
            entry.setStaleCount(staleCount);
            Map<String, Object> detail = new HashMap<>();
            detail.put("new", newCount);
            detail.put("updated", updatedCount);
            detail.put("stale", staleCount);
            entry.setDetail(detail);
            syncLogMapper.insert(entry);
        } catch (Exception e) {
            log.warn("writeSyncLog failed for channel {}: {}", ch.getId(), e.getMessage());
        }
    }
}
