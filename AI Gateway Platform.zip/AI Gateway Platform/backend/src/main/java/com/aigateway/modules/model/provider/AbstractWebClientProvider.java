package com.aigateway.modules.model.provider;

import com.aigateway.common.crypto.AesUtil;
import com.fasterxml.jackson.databind.JsonNode;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.reactive.function.client.WebClient;

import java.time.Duration;

/**
 * Base for HTTP-based {@link ModelProvider}s. Provides a shared {@link WebClient} and a
 * helper to decrypt the channel api key. Never logs decrypted keys.
 */
@Slf4j
abstract class AbstractWebClientProvider implements ModelProvider {

    protected static final Duration TIMEOUT = Duration.ofSeconds(15);

    protected final WebClient webClient;
    protected final AesUtil aesUtil;

    protected AbstractWebClientProvider(WebClient.Builder builder, AesUtil aesUtil) {
        this.webClient = builder.build();
        this.aesUtil = aesUtil;
    }

    /** Decrypt the channel's stored api key; returns null if absent. */
    protected String decryptKey(String encrypted) {
        if (encrypted == null || encrypted.isBlank()) {
            return null;
        }
        return aesUtil.decrypt(encrypted);
    }

    /** Resolve effective base url, falling back to the provider default. */
    protected String baseOr(String baseUrl, String fallback) {
        return (baseUrl == null || baseUrl.isBlank()) ? fallback : baseUrl.replaceAll("/+$", "");
    }

    /** GET a JSON document, returning null on any failure. */
    protected JsonNode getJson(String url, java.util.function.Consumer<WebClient.RequestHeadersSpec<?>> headers) {
        try {
            WebClient.RequestHeadersSpec<?> spec = webClient.get().uri(url);
            if (headers != null) {
                headers.accept(spec);
            }
            return spec.retrieve().bodyToMono(JsonNode.class).block(TIMEOUT);
        } catch (Exception e) {
            log.warn("provider {} GET {} failed: {}", name(), url, e.getMessage());
            return null;
        }
    }
}
