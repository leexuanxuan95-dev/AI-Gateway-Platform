package com.aigateway.modules.channel.service.impl;

import com.aigateway.common.api.PageResult;
import com.aigateway.common.crypto.AesUtil;
import com.aigateway.common.enums.ChannelHealth;
import com.aigateway.common.enums.CommonStatus;
import com.aigateway.common.exception.BizException;
import com.aigateway.common.exception.ErrorCode;
import com.aigateway.common.security.UserContext;
import com.aigateway.modules.channel.dto.ChannelRequest;
import com.aigateway.modules.channel.dto.ChannelView;
import com.aigateway.modules.channel.dto.RechargeRequest;
import com.aigateway.modules.channel.dto.ReserveRequest;
import com.aigateway.modules.channel.entity.Channel;
import com.aigateway.modules.channel.entity.UpstreamRechargeLog;
import com.aigateway.modules.channel.entity.UpstreamReserve;
import com.aigateway.modules.channel.mapper.ChannelMapper;
import com.aigateway.modules.channel.mapper.UpstreamRechargeLogMapper;
import com.aigateway.modules.channel.mapper.UpstreamReserveMapper;
import com.aigateway.modules.channel.service.ChannelService;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;

/**
 * Default {@link ChannelService}. Encrypts upstream keys at rest, masks them in responses,
 * and performs platform-side recharge / reserve bookkeeping. Never logs decrypted keys.
 */
@Service
@RequiredArgsConstructor
public class ChannelServiceImpl implements ChannelService {

    /** Number of trailing key characters left visible when masking. */
    private static final int MASK_VISIBLE_CHARS = 4;

    private final ChannelMapper channelMapper;
    private final UpstreamRechargeLogMapper rechargeLogMapper;
    private final UpstreamReserveMapper reserveMapper;
    private final AesUtil aesUtil;

    @Override
    public ChannelView create(ChannelRequest req) {
        Channel ch = new Channel();
        ch.setProviderName(req.getProviderName());
        ch.setChannelName(req.getChannelName());
        ch.setFamilyId(req.getFamilyId());
        ch.setApiKey(aesUtil.encrypt(req.getApiKey()));
        ch.setBaseUrl(req.getBaseUrl());
        ch.setOrgId(req.getOrgId());
        ch.setQuota(BigDecimal.ZERO);
        ch.setUsedQuota(BigDecimal.ZERO);
        ch.setWeight(req.getWeight() != null ? req.getWeight() : 1);
        ch.setPriority(req.getPriority() != null ? req.getPriority() : 0);
        ch.setHealth(ChannelHealth.HEALTHY);
        ch.setLowThreshold(req.getLowThreshold() != null ? req.getLowThreshold() : BigDecimal.ZERO);
        ch.setStatus(req.getStatus() != null ? req.getStatus() : CommonStatus.ENABLED);
        channelMapper.insert(ch);
        return toView(ch);
    }

    @Override
    public PageResult<ChannelView> page(long current, long size) {
        IPage<Channel> p = channelMapper.selectPage(new Page<>(current, size),
                Wrappers.<Channel>lambdaQuery().orderByDesc(Channel::getId));
        PageResult<ChannelView> r = new PageResult<>();
        r.setRecords(p.getRecords().stream().map(this::toView).toList());
        r.setTotal(p.getTotal());
        r.setCurrent(p.getCurrent());
        r.setSize(p.getSize());
        return r;
    }

    @Override
    public ChannelView get(Long id) {
        return toView(require(id));
    }

    @Override
    public ChannelView update(Long id, ChannelRequest req) {
        Channel ch = require(id);
        if (req.getProviderName() != null) {
            ch.setProviderName(req.getProviderName());
        }
        if (req.getChannelName() != null) {
            ch.setChannelName(req.getChannelName());
        }
        if (req.getFamilyId() != null) {
            ch.setFamilyId(req.getFamilyId());
        }
        // Only re-encrypt when a new key is supplied; blank means "keep existing".
        if (req.getApiKey() != null && !req.getApiKey().isBlank()) {
            ch.setApiKey(aesUtil.encrypt(req.getApiKey()));
        }
        if (req.getBaseUrl() != null) {
            ch.setBaseUrl(req.getBaseUrl());
        }
        if (req.getOrgId() != null) {
            ch.setOrgId(req.getOrgId());
        }
        if (req.getWeight() != null) {
            ch.setWeight(req.getWeight());
        }
        if (req.getPriority() != null) {
            ch.setPriority(req.getPriority());
        }
        if (req.getLowThreshold() != null) {
            ch.setLowThreshold(req.getLowThreshold());
        }
        if (req.getStatus() != null) {
            ch.setStatus(req.getStatus());
        }
        channelMapper.updateById(ch);
        return toView(ch);
    }

    @Override
    public void delete(Long id) {
        require(id);
        channelMapper.deleteById(id);
    }

    @Override
    @Transactional
    public ChannelView recharge(Long id, RechargeRequest req) {
        Channel ch = require(id);
        if (req.getAmount() == null || req.getAmount().compareTo(BigDecimal.ZERO) <= 0) {
            throw new BizException(ErrorCode.AMOUNT_OUT_OF_RANGE);
        }
        BigDecimal newQuota = (ch.getQuota() == null ? BigDecimal.ZERO : ch.getQuota())
                .add(req.getAmount());
        Channel upd = new Channel();
        upd.setId(id);
        upd.setQuota(newQuota);
        channelMapper.updateById(upd);

        UpstreamRechargeLog log = new UpstreamRechargeLog();
        log.setChannelId(id);
        log.setAmount(req.getAmount());
        log.setCurrency(req.getCurrency() != null ? req.getCurrency() : "USD");
        log.setAuto(false);
        log.setOperator(UserContext.userId());
        log.setRemark(req.getRemark());
        rechargeLogMapper.insert(log);

        ch.setQuota(newQuota);
        return toView(ch);
    }

    @Override
    public BigDecimal balance(Long id) {
        return estimatedBalance(require(id));
    }

    @Override
    public UpstreamReserve getReserve(Long id) {
        require(id);
        UpstreamReserve reserve = reserveMapper.selectOne(
                Wrappers.<UpstreamReserve>lambdaQuery().eq(UpstreamReserve::getChannelId, id));
        if (reserve == null) {
            reserve = new UpstreamReserve();
            reserve.setChannelId(id);
            reserve.setReserveAmount(BigDecimal.ZERO);
            reserve.setAutoRecharge(false);
            reserve.setThreshold(BigDecimal.ZERO);
            reserve.setRechargeAmount(BigDecimal.ZERO);
        }
        return reserve;
    }

    @Override
    public UpstreamReserve updateReserve(Long id, ReserveRequest req) {
        Channel ch = require(id);
        UpstreamReserve reserve = reserveMapper.selectOne(
                Wrappers.<UpstreamReserve>lambdaQuery().eq(UpstreamReserve::getChannelId, id));
        boolean insert = reserve == null;
        if (insert) {
            reserve = new UpstreamReserve();
            reserve.setChannelId(id);
            reserve.setProviderName(ch.getProviderName());
            reserve.setReserveAmount(BigDecimal.ZERO);
            reserve.setAutoRecharge(false);
            reserve.setThreshold(BigDecimal.ZERO);
            reserve.setRechargeAmount(BigDecimal.ZERO);
        }
        if (req.getReserveAmount() != null) {
            reserve.setReserveAmount(req.getReserveAmount());
        }
        if (req.getAutoRecharge() != null) {
            reserve.setAutoRecharge(req.getAutoRecharge());
        }
        if (req.getThreshold() != null) {
            reserve.setThreshold(req.getThreshold());
        }
        if (req.getRechargeAmount() != null) {
            reserve.setRechargeAmount(req.getRechargeAmount());
        }
        if (insert) {
            reserveMapper.insert(reserve);
        } else {
            reserveMapper.updateById(reserve);
        }
        return reserve;
    }

    @Override
    public List<UpstreamRechargeLog> rechargeLogs(Long id) {
        require(id);
        return rechargeLogMapper.selectList(
                Wrappers.<UpstreamRechargeLog>lambdaQuery()
                        .eq(UpstreamRechargeLog::getChannelId, id)
                        .orderByDesc(UpstreamRechargeLog::getId));
    }

    @Override
    public BigDecimal estimatedBalance(Channel ch) {
        BigDecimal quota = ch.getQuota() == null ? BigDecimal.ZERO : ch.getQuota();
        BigDecimal used = ch.getUsedQuota() == null ? BigDecimal.ZERO : ch.getUsedQuota();
        return quota.subtract(used);
    }

    private Channel require(Long id) {
        Channel ch = channelMapper.selectById(id);
        if (ch == null) {
            throw new BizException(ErrorCode.CHANNEL_NOT_FOUND);
        }
        return ch;
    }

    private ChannelView toView(Channel ch) {
        return ChannelView.of(ch, mask(ch.getApiKey()), estimatedBalance(ch));
    }

    /**
     * Decrypt then mask the key for display: keep a hint of the last 4 chars only.
     * The plaintext is never returned or logged.
     */
    private String mask(String encrypted) {
        if (encrypted == null || encrypted.isBlank()) {
            return null;
        }
        String plain;
        try {
            plain = aesUtil.decrypt(encrypted);
        } catch (Exception e) {
            return "****";
        }
        if (plain == null || plain.length() <= MASK_VISIBLE_CHARS) {
            return "****";
        }
        return "****" + plain.substring(plain.length() - MASK_VISIBLE_CHARS);
    }
}
