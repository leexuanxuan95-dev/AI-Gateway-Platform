package com.aigateway.modules.scheduler.service;

import com.aigateway.common.exception.BizException;
import com.aigateway.common.exception.ErrorCode;
import com.aigateway.common.security.UserContext;
import com.aigateway.modules.scheduler.dto.JobUpdateRequest;
import com.aigateway.modules.scheduler.dto.JobView;
import com.aigateway.modules.scheduler.entity.SysScheduledJob;
import com.aigateway.modules.scheduler.mapper.SysScheduledJobMapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import lombok.RequiredArgsConstructor;
import org.springframework.scheduling.support.CronExpression;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.List;

/** Admin operations over the managed scheduled jobs. */
@Service
@RequiredArgsConstructor
public class JobAdminService {

    private final SysScheduledJobMapper jobMapper;
    private final DynamicJobScheduler scheduler;

    public List<JobView> list() {
        return jobMapper.selectList(Wrappers.<SysScheduledJob>lambdaQuery()
                        .orderByAsc(SysScheduledJob::getJobKey))
                .stream().map(this::toView).toList();
    }

    /** Update cron and/or enabled, then apply live. */
    public JobView update(String jobKey, JobUpdateRequest req) {
        SysScheduledJob job = jobMapper.selectOne(
                Wrappers.<SysScheduledJob>lambdaQuery().eq(SysScheduledJob::getJobKey, jobKey));
        if (job == null) {
            throw new BizException(ErrorCode.NOT_FOUND, "job not found: " + jobKey);
        }
        if (StringUtils.hasText(req.getCron())) {
            if (!CronExpression.isValidExpression(req.getCron())) {
                throw new BizException(ErrorCode.PARAM_ERROR, "invalid cron expression");
            }
            job.setCron(req.getCron());
        }
        if (req.getEnabled() != null) {
            job.setEnabled(req.getEnabled());
        }
        job.setUpdatedBy(UserContext.userId());
        jobMapper.updateById(job);
        scheduler.apply(job.getJobKey(), job.getCron(), Boolean.TRUE.equals(job.getEnabled()));
        return toView(job);
    }

    /** Trigger a job immediately. */
    public void runNow(String jobKey) {
        SysScheduledJob job = jobMapper.selectOne(
                Wrappers.<SysScheduledJob>lambdaQuery().eq(SysScheduledJob::getJobKey, jobKey));
        if (job == null) {
            throw new BizException(ErrorCode.NOT_FOUND, "job not found: " + jobKey);
        }
        scheduler.runNow(jobKey);
    }

    private JobView toView(SysScheduledJob job) {
        JobView v = new JobView();
        v.setJobKey(job.getJobKey());
        v.setJobName(job.getJobName());
        v.setCron(job.getCron());
        v.setEnabled(job.getEnabled());
        v.setDescription(job.getDescription());
        v.setLastRunAt(job.getLastRunAt());
        v.setLastStatus(job.getLastStatus());
        v.setLastDurationMs(job.getLastDurationMs());
        v.setLastError(job.getLastError());
        v.setScheduled(scheduler.isScheduled(job.getJobKey()));
        v.setNextRunAt(Boolean.TRUE.equals(job.getEnabled()) ? scheduler.nextRun(job.getCron()) : null);
        return v;
    }
}
