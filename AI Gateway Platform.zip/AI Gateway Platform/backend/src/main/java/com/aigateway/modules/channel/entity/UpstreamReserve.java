package com.aigateway.modules.channel.entity;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.math.BigDecimal;
import java.time.OffsetDateTime;

/**
 * Per-channel reserve pool used by the auto-recharge job (table {@code upstream_reserve}).
 * {@code channelId} is unique. When {@code autoRecharge} is on and the channel balance
 * drops below {@code threshold}, {@code rechargeAmount} is moved from the reserve into
 * the channel quota.
 */
@Data
@TableName(value = "upstream_reserve", autoResultMap = true)
public class UpstreamReserve {

    @TableId(type = IdType.AUTO)
    private Long id;

    /** Unique channel id this reserve belongs to. */
    private Long channelId;

    private String providerName;

    /** Funds held in reserve for top-ups. */
    private BigDecimal reserveAmount;

    private Boolean autoRecharge;

    /** Trigger threshold: top up when channel balance falls below this. */
    private BigDecimal threshold;

    /** Amount to move into channel quota on each auto-recharge. */
    private BigDecimal rechargeAmount;

    @TableField(fill = FieldFill.INSERT_UPDATE)
    private OffsetDateTime updatedAt;
}
