package com.aigateway.modules.channel.job;

import com.aigateway.common.constant.KafkaTopics;
import com.aigateway.common.enums.ChannelHealth;
import com.aigateway.modules.channel.entity.Channel;
import com.aigateway.modules.channel.entity.UpstreamRechargeLog;
import com.aigateway.modules.channel.entity.UpstreamReserve;
import com.aigateway.modules.channel.mapper.ChannelMapper;
import com.aigateway.modules.channel.mapper.UpstreamRechargeLogMapper;
import com.aigateway.modules.channel.mapper.UpstreamReserveMapper;
import com.aigateway.modules.channel.service.ChannelService;
import com.aigateway.common.schedule.ManagedJob;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;

/**
 * Auto top-up of upstream channels from their reserve pool (design doc §8.4). Every 5 minutes,
 * for each reserve with {@code autoRecharge=true}: if the channel balance has dropped below the
 * reserve {@code threshold} and the reserve holds at least {@code rechargeAmount}, move
 * {@code rechargeAmount} from the reserve into the channel quota and log it (auto=true). If the
 * reserve is insufficient, raise an alert instead.
 *
 * <p>Note (design doc §8.4-D): a real per-provider top-up (calling the provider's billing API)
 * is provider-dependent and out of scope here. This job performs only the platform-side
 * reserve&rarr;quota bookkeeping; actual cost flows into the reserve at settle time, which is
 * handled by the finance module.</p>
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class UpstreamAutoRechargeJob implements ManagedJob {

    private static final String JOB_KEY = "upstream-auto-recharge";

    private final ChannelMapper channelMapper;
    private final UpstreamReserveMapper reserveMapper;
    private final UpstreamRechargeLogMapper rechargeLogMapper;
    private final ChannelService channelService;
    private final KafkaTemplate<String, String> kafkaTemplate;

    @Override
    public String jobKey() {
        return JOB_KEY;
    }

    @Override
    public String defaultCron() {
        return "0 */5 * * * *";
    }

    @Override
    public String description() {
        return "Auto top-up upstream channels from their reserve pool every 5 minutes";
    }

    @Override
    public void execute() {
        List<UpstreamReserve> reserves = reserveMapper.selectList(
                Wrappers.<UpstreamReserve>lambdaQuery().eq(UpstreamReserve::getAutoRecharge, true));
        for (UpstreamReserve reserve : reserves) {
            try {
                process(reserve);
            } catch (Exception e) {
                log.warn("auto-recharge failed for channel {}: {}",
                        reserve.getChannelId(), e.getMessage());
            }
        }
    }

    /**
     * Process a single reserve. Public + {@code @Transactional} so the move (quota up,
     * reserve down, log) is atomic; invoked per-reserve by {@link #autoRecharge()}.
     */
    @Transactional
    public void process(UpstreamReserve reserve) {
        Channel ch = channelMapper.selectById(reserve.getChannelId());
        if (ch == null) {
            return;
        }
        BigDecimal balance = channelService.estimatedBalance(ch);
        BigDecimal threshold = nz(reserve.getThreshold());
        if (balance.compareTo(threshold) >= 0) {
            return;
        }
        BigDecimal amount = nz(reserve.getRechargeAmount());
        if (amount.compareTo(BigDecimal.ZERO) <= 0) {
            return;
        }
        BigDecimal reserveAmt = nz(reserve.getReserveAmount());
        if (reserveAmt.compareTo(amount) < 0) {
            // insufficient reserve -> alert, do nothing
            notifyAlert(ch, reserveAmt, amount);
            return;
        }

        // move funds: channel.quota += amount; reserve.reserveAmount -= amount
        Channel cu = new Channel();
        cu.setId(ch.getId());
        cu.setQuota(nz(ch.getQuota()).add(amount));
        // channel regains health once topped up
        cu.setHealth(ChannelHealth.HEALTHY);
        channelMapper.updateById(cu);

        reserve.setReserveAmount(reserveAmt.subtract(amount));
        reserveMapper.updateById(reserve);

        UpstreamRechargeLog entry = new UpstreamRechargeLog();
        entry.setChannelId(ch.getId());
        entry.setAmount(amount);
        entry.setCurrency("USD");
        entry.setAuto(true);
        entry.setRemark("auto-recharge from reserve");
        rechargeLogMapper.insert(entry);
    }

    private void notifyAlert(Channel ch, BigDecimal reserveAmt, BigDecimal needed) {
        try {
            String msg = "{\"scene\":\"reserve_insufficient\",\"channelId\":" + ch.getId()
                    + ",\"provider\":\"" + ch.getProviderName() + "\",\"reserve\":" + reserveAmt
                    + ",\"needed\":" + needed + "}";
            kafkaTemplate.send(KafkaTopics.NOTIFY, msg);
        } catch (Exception e) {
            log.warn("notify (reserve insufficient) failed for channel {}: {}",
                    ch.getId(), e.getMessage());
        }
    }

    private BigDecimal nz(BigDecimal v) {
        return v == null ? BigDecimal.ZERO : v;
    }
}
