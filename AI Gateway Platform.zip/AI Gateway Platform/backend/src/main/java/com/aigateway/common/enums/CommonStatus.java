package com.aigateway.common.enums;

import com.baomidou.mybatisplus.annotation.EnumValue;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;

/** Generic enabled/disabled/deleted status (plan/project/route/model-binding/channel). */
@Getter
public enum CommonStatus implements CodedEnum<Integer> {

    ENABLED(1),
    DISABLED(2),
    DELETED(3);

    @EnumValue
    @JsonValue
    private final Integer code;

    CommonStatus(Integer code) {
        this.code = code;
    }

    @JsonCreator
    public static CommonStatus of(Integer code) {
        if (code == null) {
            return null;
        }
        for (CommonStatus v : values()) {
            if (v.code.equals(code)) {
                return v;
            }
        }
        return null;
    }
}
