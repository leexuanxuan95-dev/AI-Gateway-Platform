package com.aigateway.modules.billing.job;

import com.aigateway.common.schedule.ManagedJob;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Component;

import java.util.Set;

/**
 * Clears per-key daily Redis counters at midnight (design doc §11/§6). The daily request and
 * token counters are keyed by {@code yyyymmdd} so they expire naturally, but this sweep removes
 * the previous day's keys promptly to keep the keyspace tidy.
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class KeyQuotaResetJob implements ManagedJob {

    private static final String JOB_KEY = "key-quota-reset";

    private final StringRedisTemplate stringRedisTemplate;

    @Override
    public String jobKey() {
        return JOB_KEY;
    }

    @Override
    public String defaultCron() {
        return "0 0 0 * * ?";
    }

    @Override
    public String description() {
        return "Clear per-key daily Redis counters at midnight";
    }

    @Override
    public void execute() {
        try {
            int removed = 0;
            removed += sweep("gw:daily:req:*");
            removed += sweep("gw:daily:tok:*");
            log.info("[key-quota-reset] cleared {} daily counter keys", removed);
        } catch (Exception e) {
            log.warn("key-quota reset failed: {}", e.getMessage());
        }
    }

    private int sweep(String pattern) {
        Set<String> keys = stringRedisTemplate.keys(pattern);
        if (keys == null || keys.isEmpty()) {
            return 0;
        }
        Long deleted = stringRedisTemplate.delete(keys);
        return deleted == null ? 0 : deleted.intValue();
    }
}
