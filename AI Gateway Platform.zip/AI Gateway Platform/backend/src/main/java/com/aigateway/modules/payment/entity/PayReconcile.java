package com.aigateway.modules.payment.entity;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.OffsetDateTime;

/** Daily payment reconciliation record (table {@code pay_reconcile}, design doc §10.2). */
@Data
@TableName(value = "pay_reconcile", autoResultMap = true)
public class PayReconcile {

    @TableId(type = IdType.AUTO)
    private Long id;

    private String channelCode;

    private LocalDate reconDate;

    private Integer platformCnt;

    private BigDecimal platformAmount;

    private Integer channelCnt;

    private BigDecimal channelAmount;

    private Integer diffCnt;

    private BigDecimal diffAmount;

    /** 0 ok / 1 has-diff. */
    private Integer status;

    @TableField(fill = FieldFill.INSERT)
    private OffsetDateTime createdAt;
}
