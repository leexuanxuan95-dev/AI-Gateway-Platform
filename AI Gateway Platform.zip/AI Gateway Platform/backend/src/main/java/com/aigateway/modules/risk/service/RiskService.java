package com.aigateway.modules.risk.service;

import com.aigateway.modules.risk.entity.RiskBlacklist;
import com.aigateway.modules.risk.entity.RiskRule;

import java.util.List;

/**
 * Risk engine (design doc §12). Provides blacklist checks consumed by the gateway
 * filter, plus multi-dimension (company/user/ip) fixed-window rate-limit helpers and
 * a simple token-spike detector. Blacklist/rule CRUD is exposed via the admin controller.
 */
public interface RiskService {

    /**
     * Whether a request should be blocked. Returns true if any of {ip, country, company}
     * matches an active (non-expired) blacklist entry. Any argument may be null/blank.
     */
    boolean isBlocked(String ip, String country, Long companyId);

    /**
     * Fixed-window counter check for a dimension. Increments the counter for
     * {@code dimension:value} and returns true if it is now within {@code limit} for the
     * window, false if it exceeded the limit. Fails open on Redis errors.
     */
    boolean allow(String dimension, String value, int limit, int windowSeconds);

    /**
     * Record token usage for a company and flag a spike when the rolling window total
     * exceeds the configured {@code token_spike} threshold. Best-effort; emits a risk
     * event when tripped. Returns true if a spike was detected.
     */
    boolean recordTokensAndCheckSpike(Long companyId, long tokens);

    /**
     * Resolve a client IP to an ISO country code (via GeoIP), or {@code "UNKNOWN"} on failure.
     * Fail-open: never throws.
     */
    String resolveCountry(String ip);

    /**
     * Run the configured anomaly-detection rules ({@code high_freq}, {@code proxy_ip},
     * {@code token_spike}) against a just-completed call and apply each matched rule's action
     * ({@code alert} / {@code throttle} / {@code ban}). Defensive and cheap; never throws and
     * never blocks the caller. Intended to be invoked after a request is served.
     *
     * @param companyId calling company id (may be null)
     * @param apiKeyId  calling api key id (may be null)
     * @param ip        client ip (may be null)
     * @param country   resolved country code (may be null)
     * @param tokens    total tokens consumed by this call
     */
    void evaluateAfterCall(Long companyId, Long apiKeyId, String ip, String country, long tokens);

    /**
     * Effective RPM for a key after applying any temporary throttle imposed by a {@code throttle}
     * rule action. Returns {@code configuredRpm} when no throttle is active. Fail-open: returns
     * {@code configuredRpm} on any error.
     */
    int effectiveRpm(Long apiKeyId, int configuredRpm);

    // ---- admin CRUD ----

    List<RiskRule> listRules();

    RiskRule saveRule(RiskRule rule);

    void deleteRule(Long id);

    List<RiskBlacklist> listBlacklist(String type);

    RiskBlacklist addBlacklist(RiskBlacklist entry);

    void removeBlacklist(Long id);
}
