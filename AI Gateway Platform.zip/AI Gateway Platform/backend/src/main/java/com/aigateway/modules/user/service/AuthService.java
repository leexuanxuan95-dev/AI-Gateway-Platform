package com.aigateway.modules.user.service;

import com.aigateway.modules.user.dto.GoogleLoginRequest;
import com.aigateway.modules.user.dto.InviteRegisterRequest;
import com.aigateway.modules.user.dto.LoginRequest;
import com.aigateway.modules.user.dto.LoginResponse;
import com.aigateway.modules.user.dto.RegisterRequest;
import com.aigateway.modules.user.dto.SendCodeRequest;
import com.aigateway.modules.user.entity.SysUser;
import jakarta.servlet.http.HttpServletRequest;

/** Authentication / session lifecycle. */
public interface AuthService {

    SysUser register(RegisterRequest req, HttpServletRequest http);

    void sendCode(SendCodeRequest req);

    LoginResponse login(LoginRequest req, HttpServletRequest http);

    /** Google OAuth login: verify the ID token, find-or-create the user, issue tokens. */
    LoginResponse googleLogin(GoogleLoginRequest req, HttpServletRequest http);

    /** Register (or attach an existing user) via a company invite token; issues tokens. */
    LoginResponse registerByInvite(InviteRegisterRequest req, HttpServletRequest http);

    /** Exchange a refresh token for a new access token. */
    String refresh(String refreshToken);

    void logout(String refreshToken);

    /** Switch active company; reissues an access token with that company's claims. */
    String switchCompany(Long companyId);
}
