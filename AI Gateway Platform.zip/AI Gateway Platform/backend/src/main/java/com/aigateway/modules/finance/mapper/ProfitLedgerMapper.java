package com.aigateway.modules.finance.mapper;

import com.aigateway.modules.finance.entity.ProfitLedger;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;
import java.util.Map;

/** MyBatis-Plus mapper for {@link ProfitLedger}. */
public interface ProfitLedgerMapper extends BaseMapper<ProfitLedger> {

    /** Aggregate revenue/cost/profit grouped by model for the profit dashboard. */
    @Select("SELECT model_code AS \"modelCode\", " +
            "COALESCE(SUM(revenue),0) AS revenue, " +
            "COALESCE(SUM(cost),0) AS cost, " +
            "COALESCE(SUM(profit),0) AS profit " +
            "FROM profit_ledger GROUP BY model_code ORDER BY SUM(profit) DESC")
    List<Map<String, Object>> aggregateByModel();
}
