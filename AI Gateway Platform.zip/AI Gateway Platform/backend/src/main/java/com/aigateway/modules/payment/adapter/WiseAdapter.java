package com.aigateway.modules.payment.adapter;

import com.aigateway.common.crypto.AesUtil;
import com.aigateway.common.exception.BizException;
import com.aigateway.common.exception.ErrorCode;
import com.aigateway.modules.finance.entity.FinRechargeOrder;
import com.aigateway.modules.payment.entity.PayChannelConfig;
import com.aigateway.modules.payment.integration.WiseClient;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.Map;

/**
 * Functional Wise adapter (design doc route A/B). Inbound recharge via Wise is bank-transfer
 * based: {@code createOrder} surfaces transfer instructions (no hosted redirect for inbound).
 * The authoritative paid signal arrives as a Wise webhook ({@code transfers#state-change}),
 * whose {@code X-Signature-SHA256} signature is verified via {@link WiseClient} BEFORE any field
 * is trusted; {@code query} re-checks the transfer state through Wise. Outbound payouts (withdraw)
 * use the same {@link WiseClient}.
 *
 * <p>Credentials (never logged): {@code profileId} (Wise business profile). The API token and the
 * webhook public key live in {@link WiseClient} config. Sandbox vs production is controlled by the
 * Wise client {@code env}.</p>
 */
@Slf4j
@Component
public class WiseAdapter extends AbstractStubAdapter {

    private final WiseClient wiseClient;
    private final ObjectMapper objectMapper = new ObjectMapper();

    public WiseAdapter(AesUtil aesUtil, WiseClient wiseClient) {
        super(aesUtil);
        this.wiseClient = wiseClient;
    }

    @Override
    public String code() {
        return "wise";
    }

    @Override
    public PrepayResult createOrder(FinRechargeOrder o, PayChannelConfig c) {
        String profileId = cred(c, "profileId");
        if (profileId == null) {
            throw new BizException(ErrorCode.PAY_CHANNEL_DISABLED, "wise not configured");
        }
        // Inbound Wise recharge is bank-transfer based: present instructions keyed by the order.
        // The payment is confirmed asynchronously via the signed Wise webhook.
        PrepayResult r = new PrepayResult();
        Map<String, Object> raw = new java.util.HashMap<>();
        raw.put("method", "bank_transfer");
        raw.put("reference", o.getOrderNo());
        raw.put("currency", o.getCurrency());
        raw.put("amount", o.getAmount() != null ? o.getAmount().toPlainString() : null);
        r.setRaw(raw);
        return r;
    }

    @Override
    public CallbackResult handleCallback(String body, Map<String, String> headers, PayChannelConfig c) {
        CallbackResult r = new CallbackResult();
        r.setSuccess(false);
        try {
            String signature = header(headers, "X-Signature-SHA256");
            if (signature == null) {
                signature = header(headers, "X-Signature");
            }
            if (body == null || signature == null) {
                log.warn("wise callback missing body/signature");
                return r;
            }
            // 1) verify signature BEFORE trusting any field
            if (!wiseClient.verifyWebhookSignature(body, signature)) {
                log.warn("wise callback signature invalid");
                return r;
            }
            // 2) parse the verified payload; only credit on outgoing_payment_sent / completed state
            JsonNode root = objectMapper.readTree(body);
            JsonNode data = root.path("data");
            String state = data.path("current_state").asText(
                    data.path("status").asText(""));
            boolean paid = "outgoing_payment_sent".equalsIgnoreCase(state)
                    || "funds_received".equalsIgnoreCase(state)
                    || "COMPLETED".equalsIgnoreCase(state)
                    || "incoming_payment_done".equalsIgnoreCase(state);
            if (!paid) {
                return r;
            }
            // Wise carries our order reference; resource id maps to the transfer.
            String reference = data.path("reference").asText(null);
            if (reference == null) {
                reference = data.path("merchant_reference").asText(null);
            }
            r.setOrderNo(reference);
            r.setThirdTxnId(data.path("resource").path("id").asText(
                    data.path("transfer_id").asText(null)));
            if (data.hasNonNull("amount")) {
                r.setAmount(new BigDecimal(data.path("amount").asText()));
            }
            String ccy = data.path("currency").asText(null);
            if (ccy != null) {
                r.setCurrency(ccy.toUpperCase());
            }
            r.setSuccess(r.getOrderNo() != null);
            return r;
        } catch (Exception e) {
            log.warn("wise callback handling failed: {}", e.getMessage());
            r.setSuccess(false);
            return r;
        }
    }

    @Override
    public OrderStatus query(String orderNo, PayChannelConfig c) {
        // Recharge orders don't retain the Wise transfer id here; the signed webhook is the
        // primary settlement path. Without a stored transfer id we cannot actively poll Wise.
        return OrderStatus.PENDING;
    }
}
