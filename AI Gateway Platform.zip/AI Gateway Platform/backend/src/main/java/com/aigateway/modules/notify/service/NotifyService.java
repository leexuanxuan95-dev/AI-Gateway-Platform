package com.aigateway.modules.notify.service;

import com.aigateway.common.api.PageResult;
import com.aigateway.modules.notify.dto.NotifyMessage;
import com.aigateway.modules.notify.entity.NotifyTemplate;

import java.util.List;

/**
 * Notification dispatch + bookkeeping (design doc §13). Routes a message to the matching
 * {@code NotifySender}, records a {@code notify_log} row with the outcome, and exposes
 * template CRUD and log paging for the console.
 */
public interface NotifyService {

    /** Dispatch a message via the channel sender and record the outcome. */
    void dispatch(NotifyMessage msg);

    /** Paged notify logs, optionally scoped to a company (null = all). */
    PageResult<com.aigateway.modules.notify.entity.NotifyLog> pageLogs(Long companyId, long current, long size);

    /** List all notify templates ordered by scene. */
    List<NotifyTemplate> listTemplates();

    /** Insert (no id) or update (with id) a template, returning the persisted row. */
    NotifyTemplate saveTemplate(NotifyTemplate template);

    /** Delete the template with the given id. */
    void deleteTemplate(Long id);
}
