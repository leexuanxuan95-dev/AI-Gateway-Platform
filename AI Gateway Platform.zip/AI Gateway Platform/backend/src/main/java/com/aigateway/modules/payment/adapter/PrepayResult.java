package com.aigateway.modules.payment.adapter;

import lombok.Data;

import java.util.Map;

/** Result of creating an order at the payment channel (design doc §10.2). */
@Data
public class PrepayResult {

    /** Hosted checkout / redirect URL (card / wallet channels). */
    private String payUrl;

    /** QR code payload (alipay/wechat). */
    private String qrCode;

    /** Deposit address (crypto channels). */
    private String address;

    /** Raw provider response for debugging/audit (no secrets). */
    private Map<String, Object> raw;
}
