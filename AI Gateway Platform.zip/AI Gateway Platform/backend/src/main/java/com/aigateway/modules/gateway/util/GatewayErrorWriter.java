package com.aigateway.modules.gateway.util;

import com.aigateway.common.exception.ErrorCode;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;

import java.io.IOException;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Writes OpenAI-shaped error bodies for the {@code /v1/*} surface:
 * <pre>{"error":{"type":..,"message":..,"code":..}}</pre>
 * Used directly by {@code ApiKeyGatewayFilter} (servlet filters run before, and so bypass,
 * {@code @RestControllerAdvice}). The companion {@code GatewayExceptionHandler} reuses the same
 * shape for exceptions thrown inside controllers.
 */
@Slf4j
public final class GatewayErrorWriter {

    private static final ObjectMapper OM = new ObjectMapper();

    private GatewayErrorWriter() {
    }

    /** Write an error derived from an {@link ErrorCode} (its httpStatus + openaiType + msg). */
    public static void write(HttpServletResponse resp, ErrorCode ec, String message) {
        write(resp, ec.getHttpStatus(),
                ec.getOpenaiType() == null ? "invalid_request_error" : ec.getOpenaiType(),
                message == null ? ec.getMsg() : message,
                ec.getOpenaiType());
    }

    /** Write a fully-specified OpenAI error body with the given HTTP status. */
    public static void write(HttpServletResponse resp, int httpStatus, String type,
                             String message, String code) {
        try {
            resp.setStatus(httpStatus);
            resp.setContentType("application/json;charset=UTF-8");
            Map<String, Object> err = new LinkedHashMap<>();
            err.put("type", type);
            err.put("message", message);
            err.put("code", code);
            Map<String, Object> body = new HashMap<>();
            body.put("error", err);
            OM.writeValue(resp.getOutputStream(), body);
        } catch (IOException e) {
            log.warn("failed to write gateway error response: {}", e.getMessage());
        }
    }

    /** Build the OpenAI error map (for the @RestControllerAdvice path which returns a body). */
    public static Map<String, Object> body(String type, String message, String code) {
        Map<String, Object> err = new LinkedHashMap<>();
        err.put("type", type);
        err.put("message", message);
        err.put("code", code);
        Map<String, Object> body = new HashMap<>();
        body.put("error", err);
        return body;
    }
}
