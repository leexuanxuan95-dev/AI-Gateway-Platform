package com.aigateway.modules.user.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

/** Change-password request; requires re-verifying the old password. */
@Data
public class ChangePasswordRequest {

    @NotBlank
    private String oldPassword;

    @NotBlank
    private String newPassword;
}
