package com.aigateway.modules.model.provider;

import lombok.Data;

import java.math.BigDecimal;

/**
 * A model as reported by an upstream provider's {@code /models} API. Pricing fields are
 * only populated by providers that expose them (e.g. OpenRouter); otherwise null.
 */
@Data
public class UpstreamModel {

    /** Upstream model id, e.g. {@code gpt-4o} or {@code anthropic/claude-3.5-sonnet}. */
    private String id;

    private String displayName;

    private Integer contextWindow;

    /** Upstream cost per 1M input tokens (USD), if known. */
    private BigDecimal priceInput;

    /** Upstream cost per 1M output tokens (USD), if known. */
    private BigDecimal priceOutput;
}
