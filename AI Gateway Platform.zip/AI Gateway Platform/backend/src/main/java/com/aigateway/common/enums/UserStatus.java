package com.aigateway.common.enums;

import com.baomidou.mybatisplus.annotation.EnumValue;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;

/** sys_user.status (design doc §3.4). */
@Getter
public enum UserStatus implements CodedEnum<Integer> {

    PENDING(0),
    NORMAL(1),
    LOGGED_OFF(2),
    DISABLED(3),
    CANCELLED(4);

    @EnumValue
    @JsonValue
    private final Integer code;

    UserStatus(Integer code) {
        this.code = code;
    }

    @JsonCreator
    public static UserStatus of(Integer code) {
        if (code == null) {
            return null;
        }
        for (UserStatus v : values()) {
            if (v.code.equals(code)) {
                return v;
            }
        }
        return null;
    }
}
