package com.aigateway.common.security;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Set;

/** Authenticated console user resolved from a JWT and bound to the request thread. */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class LoginUser implements Serializable {

    private Long userId;
    private String uid;
    private String email;
    /** Whether this user is the platform super-admin. */
    private boolean superAdmin;
    /** Active company context (selected company), may be null before a company is chosen. */
    private Long companyId;
    /** Role within the active company: OWNER/ADMIN/DEVELOPER/VIEWER. */
    private String companyRole;
    /** Flattened permission points resolved from role, cached in Redis. */
    private Set<String> permissions;
}
