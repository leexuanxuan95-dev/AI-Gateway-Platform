package com.aigateway.modules.company.mapper;

import com.aigateway.modules.company.entity.Company;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/** MyBatis-Plus mapper for {@link Company}. */
public interface CompanyMapper extends BaseMapper<Company> {
}
