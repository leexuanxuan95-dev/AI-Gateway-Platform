package com.aigateway.modules.site.entity;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.handlers.JacksonTypeHandler;
import lombok.Data;

import java.time.OffsetDateTime;
import java.util.Map;

/**
 * A landing-page content section (table {@code site_section}, OmniRoute doc §4.2):
 * hero / providers / features / how / code / models / pricing / security / cta.
 * Unique per ({@code sectionKey}, {@code lang}). Disabled sections are not rendered.
 */
@Data
@TableName(value = "site_section", autoResultMap = true)
public class SiteSection {

    @TableId(type = IdType.AUTO)
    private Long id;

    /** Stable section identifier: {@code hero}, {@code features}, {@code pricing}... */
    private String sectionKey;

    /** Content language: {@code zh} / {@code en}. */
    private String lang;

    private Boolean enabled;

    private Integer sort;

    private String title;

    private String subtitle;

    /** Structured section content (card arrays / CTAs / code samples...). */
    @TableField(typeHandler = JacksonTypeHandler.class)
    private Map<String, Object> payload;

    /** Optional auto-sync binding: {@code plan} or {@code model_version}. */
    private String bindSource;

    @TableField(fill = FieldFill.INSERT_UPDATE)
    private OffsetDateTime updatedAt;
}
