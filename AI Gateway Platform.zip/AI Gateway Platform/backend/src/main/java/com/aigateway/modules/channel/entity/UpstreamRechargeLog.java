package com.aigateway.modules.channel.entity;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.math.BigDecimal;
import java.time.OffsetDateTime;

/** Channel recharge audit record (table {@code upstream_recharge_log}). */
@Data
@TableName(value = "upstream_recharge_log", autoResultMap = true)
public class UpstreamRechargeLog {

    @TableId(type = IdType.AUTO)
    private Long id;

    private Long channelId;

    private BigDecimal amount;

    private String currency;

    /** Whether this top-up was performed by the auto-recharge job. */
    private Boolean auto;

    /** Operator user id (null for system/auto recharges). */
    private Long operator;

    private String remark;

    @TableField(fill = FieldFill.INSERT)
    private OffsetDateTime createdAt;
}
