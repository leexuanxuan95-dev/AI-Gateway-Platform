package com.aigateway.common.enums;

import com.baomidou.mybatisplus.annotation.EnumValue;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;

/** site_publish.status (OmniRoute CMS). */
@Getter
public enum SitePublishStatus implements CodedEnum<Integer> {

    DRAFT(0),
    PUBLISHED(1),
    SUPERSEDED(2);

    @EnumValue
    @JsonValue
    private final Integer code;

    SitePublishStatus(Integer code) {
        this.code = code;
    }

    @JsonCreator
    public static SitePublishStatus of(Integer code) {
        if (code == null) {
            return null;
        }
        for (SitePublishStatus v : values()) {
            if (v.code.equals(code)) {
                return v;
            }
        }
        return null;
    }
}
