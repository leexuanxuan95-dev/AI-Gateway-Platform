package com.aigateway.modules.notify.sender;

/**
 * Thrown by a {@link NotifySender} when delivery could not be attempted because the channel
 * provider is not configured (design doc §13). The dispatcher records the {@code notify_log}
 * row as status=0 (pending) rather than 2 (fail) and does NOT retry, since retrying an
 * unconfigured channel would never succeed. This is distinct from a transient delivery error.
 */
public class NotifyPendingException extends RuntimeException {

    public NotifyPendingException(String message) {
        super(message);
    }
}
