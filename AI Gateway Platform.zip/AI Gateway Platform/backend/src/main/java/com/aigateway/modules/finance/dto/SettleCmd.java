package com.aigateway.modules.finance.dto;

import lombok.Data;

import java.math.BigDecimal;

/**
 * Settlement command issued by the gateway after a request completes
 * (design doc §10.4-E / §11.1). Carries the actual token usage and the
 * pre-computed charge/cost so the finance module can settle atomically.
 */
@Data
public class SettleCmd {

    private Long companyId;
    private Long apiKeyId;
    private Long projectId;
    private Long channelId;
    private String modelCode;
    private String requestId;
    private long promptTokens;
    private long completionTokens;
    private long cachedTokens;
    /** Actual customer charge to deduct. */
    private BigDecimal charge;
    /** Actual upstream cost. */
    private BigDecimal cost;
    /** The estimate frozen at request start, to be released. */
    private BigDecimal frozen;
}
