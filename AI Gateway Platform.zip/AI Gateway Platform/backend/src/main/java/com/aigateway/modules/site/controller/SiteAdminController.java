package com.aigateway.modules.site.controller;

import com.aigateway.common.api.R;
import com.aigateway.common.exception.BizException;
import com.aigateway.common.exception.ErrorCode;
import com.aigateway.common.security.UserContext;
import com.aigateway.modules.site.dto.PreviewResp;
import com.aigateway.modules.site.dto.SiteFaqReq;
import com.aigateway.modules.site.dto.SiteSectionReq;
import com.aigateway.modules.site.dto.SiteSettingReq;
import com.aigateway.modules.site.entity.SiteFaq;
import com.aigateway.modules.site.entity.SitePublish;
import com.aigateway.modules.site.entity.SiteSection;
import com.aigateway.modules.site.entity.SiteSetting;
import com.aigateway.modules.site.service.SiteCmsService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

/**
 * OmniRoute landing CMS back-office API (OmniRoute doc §4.3). Every endpoint is
 * restricted to the platform super-admin. Mounted under {@code /api/admin/site}
 * (authenticated by {@code SecurityConfig}'s {@code /api/**} rule).
 */
@RestController
@RequestMapping("/api/admin/site")
@RequiredArgsConstructor
public class SiteAdminController {

    private final SiteCmsService siteCmsService;

    /** Draft content (settings + sections + faq) for a language. */
    @GetMapping
    public R<Map<String, Object>> getDraft(@RequestParam(defaultValue = "zh") String lang) {
        requireSuperAdmin();
        return R.ok(siteCmsService.getDraft(lang));
    }

    /** Upsert the site-level setting (brand / SEO / theme / footer). */
    @PutMapping("/setting")
    public R<SiteSetting> upsertSetting(@RequestParam(defaultValue = "zh") String lang,
                                        @RequestBody SiteSettingReq req) {
        requireSuperAdmin();
        return R.ok(siteCmsService.upsertSetting(lang, req, UserContext.userId()));
    }

    /** Upsert a single section. */
    @PutMapping("/section/{key}")
    public R<SiteSection> upsertSection(@PathVariable("key") String key,
                                        @RequestParam(defaultValue = "zh") String lang,
                                        @RequestBody SiteSectionReq req) {
        requireSuperAdmin();
        return R.ok(siteCmsService.upsertSection(key, lang, req));
    }

    /** Create a FAQ entry. */
    @PostMapping("/faq")
    public R<SiteFaq> createFaq(@RequestBody SiteFaqReq req) {
        requireSuperAdmin();
        return R.ok(siteCmsService.createFaq(req));
    }

    /** Update / re-sort a FAQ entry. */
    @PutMapping("/faq/{id}")
    public R<SiteFaq> updateFaq(@PathVariable Long id, @RequestBody SiteFaqReq req) {
        requireSuperAdmin();
        return R.ok(siteCmsService.updateFaq(id, req));
    }

    /** Delete a FAQ entry. */
    @DeleteMapping("/faq/{id}")
    public R<Void> deleteFaq(@PathVariable Long id) {
        requireSuperAdmin();
        siteCmsService.deleteFaq(id);
        return R.ok();
    }

    /** Generate a preview snapshot (token + url, TTL 30min) from the current draft. */
    @PostMapping("/preview")
    public R<PreviewResp> preview(@RequestParam(defaultValue = "zh") String lang) {
        requireSuperAdmin();
        return R.ok(siteCmsService.createPreview(lang));
    }

    /** Publish the current draft as a new resolved snapshot. */
    @PostMapping("/publish")
    public R<Map<String, Object>> publish(@RequestParam(defaultValue = "zh") String lang) {
        requireSuperAdmin();
        return R.ok(siteCmsService.publish(lang, UserContext.userId()));
    }

    /** Publish version history for a language. */
    @GetMapping("/publish/history")
    public R<List<SitePublish>> publishHistory(@RequestParam(defaultValue = "zh") String lang) {
        requireSuperAdmin();
        return R.ok(siteCmsService.publishHistory(lang));
    }

    /** Roll back to (re-publish) a historical snapshot. */
    @PostMapping("/rollback/{id}")
    public R<Map<String, Object>> rollback(@PathVariable Long id) {
        requireSuperAdmin();
        return R.ok(siteCmsService.rollback(id, UserContext.userId()));
    }

    private void requireSuperAdmin() {
        if (!UserContext.require().isSuperAdmin()) {
            throw new BizException(ErrorCode.FORBIDDEN);
        }
    }
}
