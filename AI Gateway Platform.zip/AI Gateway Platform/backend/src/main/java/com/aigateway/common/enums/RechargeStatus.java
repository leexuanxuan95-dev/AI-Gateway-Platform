package com.aigateway.common.enums;

import com.baomidou.mybatisplus.annotation.EnumValue;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;

/** fin_recharge_order.status. */
@Getter
public enum RechargeStatus implements CodedEnum<Integer> {

    PENDING(0),
    PAID(1),
    CANCELLED(2),
    EXPIRED(3),
    REFUNDED(4);

    @EnumValue
    @JsonValue
    private final Integer code;

    RechargeStatus(Integer code) {
        this.code = code;
    }

    @JsonCreator
    public static RechargeStatus of(Integer code) {
        if (code == null) {
            return null;
        }
        for (RechargeStatus v : values()) {
            if (v.code.equals(code)) {
                return v;
            }
        }
        return null;
    }
}
