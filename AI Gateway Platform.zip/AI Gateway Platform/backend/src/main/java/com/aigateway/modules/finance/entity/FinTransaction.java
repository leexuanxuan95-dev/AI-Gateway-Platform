package com.aigateway.modules.finance.entity;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.aigateway.common.enums.TransactionType;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.math.BigDecimal;
import java.time.OffsetDateTime;

/** Finance ledger transaction (table {@code fin_transaction}, design doc §10). */
@Data
@TableName(value = "fin_transaction", autoResultMap = true)
public class FinTransaction {

    @TableId(type = IdType.AUTO)
    private Long id;

    private Long companyId;

    /** recharge / consume / refund / withdraw / freeze. */
    private TransactionType bizType;

    private BigDecimal amount;

    private BigDecimal balanceAfter;

    private String refId;

    private String remark;

    @TableField(fill = FieldFill.INSERT)
    private OffsetDateTime createdAt;
}
