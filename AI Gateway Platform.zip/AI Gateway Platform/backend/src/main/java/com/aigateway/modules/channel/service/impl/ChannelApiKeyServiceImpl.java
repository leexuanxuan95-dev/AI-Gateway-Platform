package com.aigateway.modules.channel.service.impl;

import com.aigateway.common.constant.KafkaTopics;
import com.aigateway.common.crypto.AesUtil;
import com.aigateway.common.enums.ChannelKeyStatus;
import com.aigateway.common.exception.BizException;
import com.aigateway.common.exception.ErrorCode;
import com.aigateway.modules.channel.dto.ChannelApiKeyRequest;
import com.aigateway.modules.channel.dto.ChannelApiKeyView;
import com.aigateway.modules.channel.dto.ChannelKeyStats;
import com.aigateway.modules.channel.entity.ChannelApiKey;
import com.aigateway.modules.channel.mapper.ChannelApiKeyMapper;
import com.aigateway.modules.channel.service.ChannelApiKeyService;
import com.aigateway.modules.model.service.LiteLlmSyncService;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import java.time.OffsetDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Default {@link ChannelApiKeyService}. Encrypts keys at rest, masks them in responses, does
 * weighted-random selection over active keys, and bans dead/quota-exhausted keys on report.
 * MUST NOT depend on {@code ChannelSelector} (would create a circular bean dependency).
 * Never logs decrypted keys.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class ChannelApiKeyServiceImpl implements ChannelApiKeyService {

    /** Failure count at/after which a non-auth/non-quota failing key is banned. */
    private static final int FAIL_BAN_THRESHOLD = 5;
    /** Upstream auth/forbidden statuses → the key is dead. */
    private static final int HTTP_UNAUTHORIZED = 401;
    private static final int HTTP_FORBIDDEN = 403;
    /** Upstream quota statuses → the key is out of quota. */
    private static final int HTTP_PAYMENT_REQUIRED = 402;
    private static final int HTTP_TOO_MANY_REQUESTS = 429;
    /** Masking: leading/trailing plaintext chars left visible around {@code ***}. */
    private static final int MASK_PREFIX_CHARS = 6;
    private static final int MASK_SUFFIX_CHARS = 3;
    private static final String MASK_INFIX = "***";
    private static final String NOTIFY_SCENE_KEY_BANNED = "upstream_key_banned";

    private final ChannelApiKeyMapper channelApiKeyMapper;
    private final AesUtil aesUtil;
    private final KafkaTemplate<String, String> kafkaTemplate;
    private final ObjectMapper objectMapper;
    private final LiteLlmSyncService liteLlmSyncService;

    @Override
    public void add(Long channelId, ChannelApiKeyRequest req) {
        if (req.getApiKey() == null || req.getApiKey().isBlank()) {
            throw new BizException(ErrorCode.PARAM_ERROR, "api key is required");
        }
        ChannelApiKey key = new ChannelApiKey();
        key.setChannelId(channelId);
        key.setKeyAlias(req.getKeyAlias());
        key.setApiKey(aesUtil.encrypt(req.getApiKey()));
        key.setStatus(ChannelKeyStatus.ACTIVE);
        key.setWeight(req.getWeight() != null && req.getWeight() > 0 ? req.getWeight() : 1);
        key.setFailCount(0);
        key.setUsedCount(0L);
        channelApiKeyMapper.insert(key);
        syncDeployments(key.getId());
    }

    @Override
    public List<ChannelApiKeyView> list(Long channelId) {
        List<ChannelApiKey> keys = channelApiKeyMapper.selectList(
                Wrappers.<ChannelApiKey>lambdaQuery()
                        .eq(ChannelApiKey::getChannelId, channelId)
                        .orderByDesc(ChannelApiKey::getId));
        return keys.stream().map(this::toView).toList();
    }

    @Override
    public ChannelKeyStats stats(Long channelId) {
        List<ChannelApiKey> keys = channelApiKeyMapper.selectList(
                Wrappers.<ChannelApiKey>lambdaQuery().eq(ChannelApiKey::getChannelId, channelId));
        ChannelKeyStats s = new ChannelKeyStats();
        s.setChannelId(channelId);
        s.setTotal(keys.size());
        s.setActive(keys.stream().filter(k -> statusOf(k) == ChannelKeyStatus.ACTIVE).count());
        s.setBanned(keys.stream().filter(k -> statusOf(k) == ChannelKeyStatus.BANNED).count());
        s.setDisabled(keys.stream().filter(k -> statusOf(k) == ChannelKeyStatus.DISABLED).count());
        return s;
    }

    @Override
    public void ban(Long keyId, String reason) {
        ChannelApiKey key = require(keyId);
        ChannelApiKey upd = new ChannelApiKey();
        upd.setId(keyId);
        upd.setStatus(ChannelKeyStatus.BANNED);
        upd.setBanReason(reason);
        upd.setBannedAt(OffsetDateTime.now());
        channelApiKeyMapper.updateById(upd);
        removeDeployments(keyId);
        emitBanNotify(key.getChannelId(), keyId, reason);
    }

    @Override
    public void unban(Long keyId) {
        require(keyId);
        ChannelApiKey upd = new ChannelApiKey();
        upd.setId(keyId);
        upd.setStatus(ChannelKeyStatus.ACTIVE);
        // null in an entity field is ignored by updateById; null out reason/failCount explicitly.
        channelApiKeyMapper.update(upd, Wrappers.<ChannelApiKey>lambdaUpdate()
                .eq(ChannelApiKey::getId, keyId)
                .set(ChannelApiKey::getStatus, ChannelKeyStatus.ACTIVE)
                .set(ChannelApiKey::getBanReason, null)
                .set(ChannelApiKey::getFailCount, 0)
                .set(ChannelApiKey::getBannedAt, null));
        syncDeployments(keyId);
    }

    @Override
    public void disable(Long keyId) {
        require(keyId);
        ChannelApiKey upd = new ChannelApiKey();
        upd.setId(keyId);
        upd.setStatus(ChannelKeyStatus.DISABLED);
        channelApiKeyMapper.updateById(upd);
        removeDeployments(keyId);
    }

    @Override
    public void delete(Long keyId) {
        require(keyId);
        channelApiKeyMapper.deleteById(keyId);
        removeDeployments(keyId);
    }

    @Override
    public ChannelApiKey pickActive(Long channelId) {
        List<ChannelApiKey> active = channelApiKeyMapper.selectList(
                Wrappers.<ChannelApiKey>lambdaQuery()
                        .eq(ChannelApiKey::getChannelId, channelId)
                        .eq(ChannelApiKey::getStatus, ChannelKeyStatus.ACTIVE));
        if (active.isEmpty()) {
            return null;
        }
        ChannelApiKey chosen = weightedPick(active);
        if (chosen != null) {
            bumpUsage(chosen.getId());
        }
        return chosen;
    }

    @Override
    public void reportKeyResult(Long keyId, Integer upstreamStatus) {
        if (keyId == null) {
            return;
        }
        ChannelApiKey key = channelApiKeyMapper.selectById(keyId);
        if (key == null) {
            return;
        }
        int status = upstreamStatus == null ? 0 : upstreamStatus;
        if (status == HTTP_UNAUTHORIZED || status == HTTP_FORBIDDEN) {
            ban(keyId, "upstream " + status + " (auth/forbidden)");
            return;
        }
        if (status == HTTP_PAYMENT_REQUIRED || status == HTTP_TOO_MANY_REQUESTS) {
            ban(keyId, "quota exhausted (upstream " + status + ")");
            return;
        }
        int fails = (key.getFailCount() == null ? 0 : key.getFailCount()) + 1;
        if (fails >= FAIL_BAN_THRESHOLD) {
            ban(keyId, "failure count >= " + FAIL_BAN_THRESHOLD);
        } else {
            ChannelApiKey upd = new ChannelApiKey();
            upd.setId(keyId);
            upd.setFailCount(fails);
            channelApiKeyMapper.updateById(upd);
        }
    }

    @Override
    public boolean hasActiveKey(Long channelId) {
        Long count = channelApiKeyMapper.selectCount(
                Wrappers.<ChannelApiKey>lambdaQuery()
                        .eq(ChannelApiKey::getChannelId, channelId)
                        .eq(ChannelApiKey::getStatus, ChannelKeyStatus.ACTIVE));
        return count != null && count > 0;
    }

    // ===================================================================================
    // helpers
    // ===================================================================================

    /** Weighted-random selection over candidate keys by weight (min 1). */
    private ChannelApiKey weightedPick(List<ChannelApiKey> candidates) {
        int total = 0;
        for (ChannelApiKey k : candidates) {
            total += Math.max(1, k.getWeight() == null ? 1 : k.getWeight());
        }
        int roll = ThreadLocalRandom.current().nextInt(total);
        int acc = 0;
        for (ChannelApiKey k : candidates) {
            acc += Math.max(1, k.getWeight() == null ? 1 : k.getWeight());
            if (roll < acc) {
                return k;
            }
        }
        return candidates.get(candidates.size() - 1);
    }

    /** Best-effort bump of usedCount + lastUsedAt; never blocks/throws on the hot path. */
    private void bumpUsage(Long keyId) {
        try {
            channelApiKeyMapper.update(null, Wrappers.<ChannelApiKey>lambdaUpdate()
                    .eq(ChannelApiKey::getId, keyId)
                    .setSql("used_count = used_count + 1")
                    .set(ChannelApiKey::getLastUsedAt, OffsetDateTime.now()));
        } catch (Exception e) {
            log.debug("bump key usage failed for {}: {}", keyId, e.getMessage());
        }
    }

    /**
     * Register this key's LiteLLM deployments (after add/unban). Best-effort: the admin operation
     * must still succeed if LiteLLM is unreachable.
     */
    private void syncDeployments(Long keyId) {
        try {
            liteLlmSyncService.syncKey(keyId);
        } catch (Exception e) {
            log.warn("LiteLLM syncKey {} failed: {}", keyId, e.getMessage());
        }
    }

    /**
     * Remove this key's LiteLLM deployments (after ban/disable/delete). Best-effort: the admin
     * operation must still succeed if LiteLLM is unreachable.
     */
    private void removeDeployments(Long keyId) {
        try {
            liteLlmSyncService.removeKeyDeployments(keyId);
        } catch (Exception e) {
            log.warn("LiteLLM removeKeyDeployments {} failed: {}", keyId, e.getMessage());
        }
    }

    private void emitBanNotify(Long channelId, Long keyId, String reason) {
        try {
            Map<String, Object> msg = new HashMap<>();
            msg.put("scene", NOTIFY_SCENE_KEY_BANNED);
            msg.put("channelId", channelId);
            msg.put("keyId", keyId);
            msg.put("reason", reason);
            msg.put("content", "upstream key banned for channel " + channelId + ": " + reason);
            kafkaTemplate.send(KafkaTopics.NOTIFY, String.valueOf(channelId),
                    objectMapper.writeValueAsString(msg));
        } catch (Exception e) {
            log.warn("emit upstream-key-banned notify failed for channel {}: {}", channelId, e.getMessage());
        }
    }

    private ChannelKeyStatus statusOf(ChannelApiKey k) {
        return k.getStatus() == null ? ChannelKeyStatus.ACTIVE : k.getStatus();
    }

    private ChannelApiKey require(Long keyId) {
        ChannelApiKey key = channelApiKeyMapper.selectById(keyId);
        if (key == null) {
            throw new BizException(ErrorCode.NOT_FOUND);
        }
        return key;
    }

    private ChannelApiKeyView toView(ChannelApiKey k) {
        ChannelApiKeyView v = new ChannelApiKeyView();
        v.setId(k.getId());
        v.setChannelId(k.getChannelId());
        v.setKeyAlias(k.getKeyAlias());
        v.setKeyMasked(mask(k.getApiKey()));
        v.setStatus(k.getStatus());
        v.setBanReason(k.getBanReason());
        v.setWeight(k.getWeight());
        v.setFailCount(k.getFailCount());
        v.setUsedCount(k.getUsedCount());
        v.setLastUsedAt(k.getLastUsedAt());
        v.setBannedAt(k.getBannedAt());
        v.setCreatedAt(k.getCreatedAt());
        return v;
    }

    /**
     * Decrypt then mask the key for display, e.g. {@code sk-abc***xyz}: keep a short prefix and
     * suffix around {@code ***}. The plaintext is never returned or logged.
     */
    private String mask(String encrypted) {
        if (encrypted == null || encrypted.isBlank()) {
            return null;
        }
        String plain;
        try {
            plain = aesUtil.decrypt(encrypted);
        } catch (Exception e) {
            return MASK_INFIX;
        }
        if (plain == null || plain.length() <= MASK_PREFIX_CHARS + MASK_SUFFIX_CHARS) {
            return MASK_INFIX;
        }
        return plain.substring(0, MASK_PREFIX_CHARS) + MASK_INFIX
                + plain.substring(plain.length() - MASK_SUFFIX_CHARS);
    }
}
