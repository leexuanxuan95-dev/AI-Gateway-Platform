package com.aigateway.modules.finance.service.impl;

import com.aigateway.common.api.PageResult;
import com.aigateway.common.enums.CommonStatus;
import com.aigateway.common.enums.TransactionType;
import com.aigateway.common.exception.BizException;
import com.aigateway.common.exception.ErrorCode;
import com.aigateway.modules.finance.dto.ModelBindingRequest;
import com.aigateway.modules.finance.dto.ProfitDashboard;
import com.aigateway.modules.finance.entity.FinAccount;
import com.aigateway.modules.finance.entity.FinModelBinding;
import com.aigateway.modules.finance.entity.FinTransaction;
import com.aigateway.modules.finance.entity.PlatformProfitAccount;
import com.aigateway.modules.finance.entity.ProfitLedger;
import com.aigateway.modules.finance.entity.RechargeFeeConfig;
import com.aigateway.modules.finance.mapper.FinAccountMapper;
import com.aigateway.modules.finance.mapper.FinModelBindingMapper;
import com.aigateway.modules.finance.mapper.FinTransactionMapper;
import com.aigateway.modules.finance.mapper.PlatformProfitAccountMapper;
import com.aigateway.modules.finance.mapper.ProfitLedgerMapper;
import com.aigateway.modules.finance.mapper.RechargeFeeConfigMapper;
import com.aigateway.modules.finance.service.FinanceService;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Default {@link FinanceService}. */
@Service
@RequiredArgsConstructor
public class FinanceServiceImpl implements FinanceService {

    private static final int SCALE = 6;
    private static final int FREEZE_RETRIES = 5;

    private final FinAccountMapper finAccountMapper;
    private final FinTransactionMapper finTransactionMapper;
    private final FinModelBindingMapper finModelBindingMapper;
    private final PlatformProfitAccountMapper platformProfitAccountMapper;
    private final ProfitLedgerMapper profitLedgerMapper;
    private final RechargeFeeConfigMapper rechargeFeeConfigMapper;

    @Override
    public FinAccount getOrCreateAccount(Long companyId) {
        FinAccount acc = finAccountMapper.selectOne(
                Wrappers.<FinAccount>lambdaQuery().eq(FinAccount::getCompanyId, companyId).last("limit 1"));
        if (acc == null) {
            acc = new FinAccount();
            acc.setCompanyId(companyId);
            acc.setAvailableBalance(BigDecimal.ZERO);
            acc.setFreezeBalance(BigDecimal.ZERO);
            acc.setTotalRecharge(BigDecimal.ZERO);
            acc.setTotalConsume(BigDecimal.ZERO);
            acc.setCurrency("USD");
            finAccountMapper.insert(acc);
        }
        return acc;
    }

    @Override
    public PageResult<FinTransaction> transactions(Long companyId, long current, long size) {
        IPage<FinTransaction> p = finTransactionMapper.selectPage(new Page<>(current, size),
                Wrappers.<FinTransaction>lambdaQuery()
                        .eq(FinTransaction::getCompanyId, companyId)
                        .orderByDesc(FinTransaction::getId));
        return PageResult.of(p);
    }

    @Override
    public ProfitDashboard profitDashboard() {
        PlatformProfitAccount p = platformProfitAccountMapper.selectById(1);
        ProfitDashboard dash = new ProfitDashboard();
        BigDecimal revenue = p != null ? nz(p.getTotalRevenue()) : BigDecimal.ZERO;
        BigDecimal cost = p != null ? nz(p.getTotalCost()) : BigDecimal.ZERO;
        BigDecimal profit = p != null ? nz(p.getTotalProfit()) : BigDecimal.ZERO;
        dash.setTotalRevenue(revenue);
        dash.setTotalCost(cost);
        dash.setTotalProfit(profit);
        dash.setMargin(margin(profit, revenue));

        List<ProfitDashboard.ModelMargin> byModel = new ArrayList<>();
        for (Map<String, Object> row : profitLedgerMapper.aggregateByModel()) {
            ProfitDashboard.ModelMargin mm = new ProfitDashboard.ModelMargin();
            mm.setModelCode((String) row.get("modelCode"));
            BigDecimal r = toBd(row.get("revenue"));
            BigDecimal c = toBd(row.get("cost"));
            BigDecimal pr = toBd(row.get("profit"));
            mm.setRevenue(r);
            mm.setCost(c);
            mm.setProfit(pr);
            mm.setMargin(margin(pr, r));
            byModel.add(mm);
        }
        dash.setByModel(byModel);
        return dash;
    }

    @Override
    @Transactional
    public FinModelBinding allocate(Long companyId, ModelBindingRequest req) {
        BigDecimal amount = scale(req.getAmount());
        if (amount.signum() <= 0) {
            throw new BizException(ErrorCode.PARAM_ERROR, "amount must be positive");
        }
        // Move from account available balance into the model allocation.
        FinAccount acc = adjustAvailable(companyId, amount.negate(), TransactionType.FREEZE,
                req.getModelCode(), "allocate to model " + req.getModelCode());
        if (acc == null) {
            throw new BizException(ErrorCode.INSUFFICIENT_BALANCE);
        }
        FinModelBinding b = finModelBindingMapper.selectOne(
                Wrappers.<FinModelBinding>lambdaQuery()
                        .eq(FinModelBinding::getCompanyId, companyId)
                        .eq(FinModelBinding::getModelCode, req.getModelCode())
                        .last("limit 1"));
        if (b == null) {
            b = new FinModelBinding();
            b.setCompanyId(companyId);
            b.setModelCode(req.getModelCode());
            b.setAllocated(amount);
            b.setUsed(BigDecimal.ZERO);
            b.setStatus(CommonStatus.ENABLED);
            finModelBindingMapper.insert(b);
        } else {
            b.setAllocated(scale(nz(b.getAllocated()).add(amount)));
            finModelBindingMapper.updateById(b);
        }
        return b;
    }

    @Override
    public List<FinModelBinding> bindings(Long companyId) {
        return finModelBindingMapper.selectList(
                Wrappers.<FinModelBinding>lambdaQuery().eq(FinModelBinding::getCompanyId, companyId));
    }

    @Override
    @Transactional
    public void creditRecharge(Long companyId, BigDecimal amount, String orderNo, RechargeFeeConfig feeConfig) {
        BigDecimal amt = scale(amount);
        FinAccount acc = creditAvailable(companyId, amt, TransactionType.RECHARGE, orderNo, "recharge " + orderNo);
        acc.setTotalRecharge(scale(nz(acc.getTotalRecharge()).add(amt)));
        finAccountMapper.updateById(acc);

        if (feeConfig != null && Boolean.TRUE.equals(feeConfig.getEnabled())
                && feeConfig.getFeeRate() != null && feeConfig.getFeeRate().signum() > 0) {
            BigDecimal fee = scale(amt.multiply(feeConfig.getFeeRate()));
            recordRechargeFee(companyId, orderNo, fee);
        }
    }

    @Override
    public RechargeFeeConfig resolveRechargeFee(Long companyId) {
        RechargeFeeConfig company = rechargeFeeConfigMapper.selectOne(
                Wrappers.<RechargeFeeConfig>lambdaQuery()
                        .eq(RechargeFeeConfig::getScope, "company")
                        .eq(RechargeFeeConfig::getScopeRef, companyId.toString())
                        .eq(RechargeFeeConfig::getEnabled, true)
                        .last("limit 1"));
        if (company != null) {
            return company;
        }
        return rechargeFeeConfigMapper.selectOne(
                Wrappers.<RechargeFeeConfig>lambdaQuery()
                        .eq(RechargeFeeConfig::getScope, "global")
                        .eq(RechargeFeeConfig::getEnabled, true)
                        .last("limit 1"));
    }

    @Override
    @Transactional
    public void recordRechargeFee(Long companyId, String orderNo, BigDecimal fee) {
        if (fee == null || fee.signum() <= 0) {
            return;
        }
        BigDecimal f = scale(fee);
        PlatformProfitAccount p = platformProfitAccountMapper.selectById(1);
        if (p == null) {
            p = new PlatformProfitAccount();
            p.setId(1);
            p.setTotalRevenue(BigDecimal.ZERO);
            p.setTotalCost(BigDecimal.ZERO);
            p.setTotalProfit(BigDecimal.ZERO);
            platformProfitAccountMapper.insert(p);
        }
        // Recharge fee is pure profit (no upstream cost).
        p.setTotalRevenue(scale(nz(p.getTotalRevenue()).add(f)));
        p.setTotalProfit(scale(nz(p.getTotalProfit()).add(f)));
        platformProfitAccountMapper.updateById(p);

        ProfitLedger ledger = new ProfitLedger();
        ledger.setSource("recharge_fee");
        ledger.setRefId(orderNo);
        ledger.setCompanyId(companyId);
        ledger.setRevenue(f);
        ledger.setCost(BigDecimal.ZERO);
        ledger.setProfit(f);
        profitLedgerMapper.insert(ledger);
    }

    @Override
    @Transactional
    public FinAccount adjustForWithdraw(Long companyId, BigDecimal freezeDelta, BigDecimal availableDelta,
                                        TransactionType bizType, String refId, String remark) {
        for (int i = 0; i < FREEZE_RETRIES; i++) {
            FinAccount acc = requireAccount(companyId);
            BigDecimal newAvail = scale(nz(acc.getAvailableBalance()).add(scale(availableDelta)));
            BigDecimal newFreeze = scale(nz(acc.getFreezeBalance()).add(scale(freezeDelta)));
            if (newAvail.signum() < 0) {
                throw new BizException(ErrorCode.INSUFFICIENT_BALANCE);
            }
            acc.setAvailableBalance(newAvail);
            acc.setFreezeBalance(newFreeze);
            if (finAccountMapper.updateById(acc) > 0) {
                writeTxn(companyId, bizType, scale(availableDelta), newAvail, refId, remark);
                return acc;
            }
        }
        throw new BizException(ErrorCode.SYSTEM_ERROR, "withdraw adjust failed: contention");
    }

    @Override
    public Map<String, Object> profitSummary() {
        PlatformProfitAccount p = platformProfitAccountMapper.selectById(1);
        Map<String, Object> m = new HashMap<>();
        m.put("totalRevenue", p != null ? nz(p.getTotalRevenue()) : BigDecimal.ZERO);
        m.put("totalCost", p != null ? nz(p.getTotalCost()) : BigDecimal.ZERO);
        m.put("totalProfit", p != null ? nz(p.getTotalProfit()) : BigDecimal.ZERO);
        return m;
    }

    // ---- internal balance helpers (optimistic-lock) ----

    private FinAccount adjustAvailable(Long companyId, BigDecimal delta, TransactionType bizType,
                                       String refId, String remark) {
        for (int i = 0; i < FREEZE_RETRIES; i++) {
            FinAccount acc = requireAccount(companyId);
            BigDecimal newAvail = scale(nz(acc.getAvailableBalance()).add(scale(delta)));
            if (newAvail.signum() < 0) {
                throw new BizException(ErrorCode.INSUFFICIENT_BALANCE);
            }
            acc.setAvailableBalance(newAvail);
            if (finAccountMapper.updateById(acc) > 0) {
                writeTxn(companyId, bizType, scale(delta), newAvail, refId, remark);
                return acc;
            }
        }
        throw new BizException(ErrorCode.SYSTEM_ERROR, "balance adjust failed: contention");
    }

    private FinAccount creditAvailable(Long companyId, BigDecimal amount, TransactionType bizType,
                                       String refId, String remark) {
        FinAccount acc = getOrCreateAccount(companyId);
        for (int i = 0; i < FREEZE_RETRIES; i++) {
            acc = requireAccount(companyId);
            BigDecimal newAvail = scale(nz(acc.getAvailableBalance()).add(scale(amount)));
            acc.setAvailableBalance(newAvail);
            if (finAccountMapper.updateById(acc) > 0) {
                writeTxn(companyId, bizType, scale(amount), newAvail, refId, remark);
                return acc;
            }
        }
        throw new BizException(ErrorCode.SYSTEM_ERROR, "credit failed: contention");
    }

    private void writeTxn(Long companyId, TransactionType bizType, BigDecimal amount,
                          BigDecimal balanceAfter, String refId, String remark) {
        FinTransaction t = new FinTransaction();
        t.setCompanyId(companyId);
        t.setBizType(bizType);
        t.setAmount(amount);
        t.setBalanceAfter(balanceAfter);
        t.setRefId(refId);
        t.setRemark(remark);
        finTransactionMapper.insert(t);
    }

    private FinAccount requireAccount(Long companyId) {
        FinAccount acc = finAccountMapper.selectOne(
                Wrappers.<FinAccount>lambdaQuery().eq(FinAccount::getCompanyId, companyId).last("limit 1"));
        if (acc == null) {
            throw new BizException(ErrorCode.INSUFFICIENT_BALANCE, "no finance account");
        }
        return acc;
    }

    private static BigDecimal margin(BigDecimal profit, BigDecimal revenue) {
        if (revenue == null || revenue.signum() <= 0) {
            return BigDecimal.ZERO;
        }
        return nz(profit).divide(revenue, SCALE, RoundingMode.HALF_UP);
    }

    private static BigDecimal toBd(Object o) {
        if (o == null) {
            return BigDecimal.ZERO;
        }
        if (o instanceof BigDecimal bd) {
            return bd;
        }
        return new BigDecimal(o.toString());
    }

    private static BigDecimal nz(BigDecimal v) {
        return v == null ? BigDecimal.ZERO : v;
    }

    private static BigDecimal scale(BigDecimal v) {
        return nz(v).setScale(SCALE, RoundingMode.HALF_UP);
    }
}
