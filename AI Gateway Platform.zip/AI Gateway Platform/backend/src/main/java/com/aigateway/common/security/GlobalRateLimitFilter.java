package com.aigateway.common.security;

import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.annotation.Order;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.http.MediaType;
import org.springframework.lang.NonNull;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.time.Duration;
import java.util.Map;

/**
 * Coarse per-IP flood backstop across the whole surface (design doc §12 / §17). This is a
 * DoS/scraping guardrail only; fine-grained limits live per-API-key (gateway) and per-account
 * (auth). Generous cap so legitimate bursts pass; fail-open if Redis is unavailable so a cache
 * outage never takes the site down.
 */
@Slf4j
@Order(3)
@Component
@RequiredArgsConstructor
public class GlobalRateLimitFilter extends OncePerRequestFilter {

    private static final int MAX_PER_WINDOW = 600;
    private static final Duration WINDOW = Duration.ofMinutes(1);
    private static final String KEY_PREFIX = "gw:rl:global:";

    private final StringRedisTemplate redis;
    private final ObjectMapper objectMapper = new ObjectMapper();

    @Override
    protected boolean shouldNotFilter(@NonNull HttpServletRequest request) {
        String uri = request.getRequestURI();
        // health/readiness probes must never be throttled
        return uri.startsWith("/actuator/health") || uri.equals("/actuator/info");
    }

    @Override
    protected void doFilterInternal(@NonNull HttpServletRequest request,
                                    @NonNull HttpServletResponse response,
                                    @NonNull FilterChain chain) throws ServletException, IOException {
        String ip = AuthRateLimitFilter.clientIp(request);
        String key = KEY_PREFIX + ip;
        try {
            Long count = redis.opsForValue().increment(key);
            if (count != null && count == 1L) {
                redis.expire(key, WINDOW);
            }
            if (count != null && count > MAX_PER_WINDOW) {
                log.warn("[ratelimit] global flood block ip={} count={}", ip, count);
                response.setStatus(429);
                response.setContentType(MediaType.APPLICATION_JSON_VALUE);
                response.setHeader("Retry-After", String.valueOf(WINDOW.getSeconds()));
                objectMapper.writeValue(response.getOutputStream(),
                        Map.of("code", 3005, "msg", "too many requests"));
                return;
            }
        } catch (Exception e) {
            log.debug("global rate limit check skipped: {}", e.getMessage());
        }
        chain.doFilter(request, response);
    }
}
