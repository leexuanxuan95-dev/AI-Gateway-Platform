package com.aigateway.modules.payment.controller;

import com.aigateway.common.api.R;
import com.aigateway.common.exception.BizException;
import com.aigateway.common.exception.ErrorCode;
import com.aigateway.common.security.UserContext;
import com.aigateway.modules.payment.entity.PayChannelConfig;
import com.aigateway.modules.payment.service.PayChannelConfigService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/** Payment channel config center (super-admin, design doc §10.2.1). */
@RestController
@RequestMapping("/api/pay/config")
@RequiredArgsConstructor
public class PayChannelConfigController {

    private final PayChannelConfigService channelConfigService;

    @GetMapping
    public R<List<PayChannelConfig>> list() {
        requireSuperAdmin();
        return R.ok(channelConfigService.listMasked());
    }

    @PostMapping
    public R<PayChannelConfig> create(@RequestBody PayChannelConfig cfg) {
        requireSuperAdmin();
        return R.ok(channelConfigService.create(cfg, UserContext.userId()));
    }

    @PutMapping("/{id}")
    public R<PayChannelConfig> update(@PathVariable Long id, @RequestBody PayChannelConfig cfg) {
        requireSuperAdmin();
        return R.ok(channelConfigService.update(id, cfg, UserContext.userId()));
    }

    @PutMapping("/{id}/enabled")
    public R<PayChannelConfig> setEnabled(@PathVariable Long id, @RequestParam boolean enabled) {
        requireSuperAdmin();
        return R.ok(channelConfigService.setEnabled(id, enabled, UserContext.userId()));
    }

    private void requireSuperAdmin() {
        if (!UserContext.require().isSuperAdmin()) {
            throw new BizException(ErrorCode.PERMISSION_DENIED);
        }
    }
}
