package com.aigateway.modules.user.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

/** Request to send a verification code to an email/mobile for a given scene. */
@Data
public class SendCodeRequest {

    /** Email address or mobile number. */
    @NotBlank
    private String target;

    /** Scene, e.g. {@code register} / {@code login} / {@code reset}. */
    @NotBlank
    private String scene;
}
