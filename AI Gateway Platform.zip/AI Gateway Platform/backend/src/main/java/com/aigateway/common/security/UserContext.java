package com.aigateway.common.security;

import com.aigateway.common.exception.BizException;
import com.aigateway.common.exception.ErrorCode;

/** Thread-local holder for the current console {@link LoginUser}. */
public final class UserContext {

    private static final ThreadLocal<LoginUser> HOLDER = new ThreadLocal<>();

    private UserContext() {
    }

    /** Bind the current request's login user to this thread. */
    public static void set(LoginUser user) {
        HOLDER.set(user);
    }

    /** Current login user, or {@code null} if the request is unauthenticated. */
    public static LoginUser get() {
        return HOLDER.get();
    }

    /** Current login user; throws {@link ErrorCode#UNAUTHORIZED} if none is bound. */
    public static LoginUser require() {
        LoginUser u = HOLDER.get();
        if (u == null) {
            throw new BizException(ErrorCode.UNAUTHORIZED);
        }
        return u;
    }

    /** Current user id; throws if unauthenticated. */
    public static Long userId() {
        return require().getUserId();
    }

    /** Active company id; throws if no company selected. */
    public static Long companyId() {
        Long cid = require().getCompanyId();
        if (cid == null) {
            throw new BizException(ErrorCode.NOT_COMPANY_MEMBER);
        }
        return cid;
    }

    /** Clear the thread-bound login user (must run at request end). */
    public static void clear() {
        HOLDER.remove();
    }
}
