package com.aigateway.modules.billing.controller;

import com.aigateway.common.api.PageResult;
import com.aigateway.common.api.R;
import com.aigateway.common.security.LoginUser;
import com.aigateway.common.security.RequirePerm;
import com.aigateway.common.security.RolePermissions;
import com.aigateway.common.security.UserContext;
import com.aigateway.modules.billing.dto.BillQuery;
import com.aigateway.modules.billing.entity.BillToken;
import com.aigateway.modules.billing.entity.CallLog;
import com.aigateway.modules.billing.service.BillingQueryService;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.util.Map;

/**
 * Billing query console (design doc §11). JWT-authed and company-scoped: members read their
 * own company's token bills / call logs; the platform super-admin sees all companies. Backed by
 * the {@code billing:read} permission point.
 */
@RestController
@RequestMapping("/api/billing")
@RequiredArgsConstructor
public class BillingQueryController {

    private final BillingQueryService billingQueryService;

    /** Paged token bills for the caller's company scope, filtered by the given query. */
    @GetMapping("/bills")
    @RequirePerm(RolePermissions.BILLING_READ)
    public R<PageResult<BillToken>> bills(BillQuery q) {
        return R.ok(billingQueryService.pageBills(scope(), q));
    }

    /** Paged call logs for the caller's company scope, filtered by the given query. */
    @GetMapping("/calls")
    @RequirePerm(RolePermissions.BILLING_READ)
    public R<PageResult<CallLog>> calls(BillQuery q) {
        return R.ok(billingQueryService.pageCallLogs(scope(), q));
    }

    /** Consumption summary (today / yesterday / month / total) for the caller's company scope. */
    @GetMapping("/summary")
    @RequirePerm(RolePermissions.BILLING_READ)
    public R<Map<String, Object>> summary() {
        return R.ok(billingQueryService.summary(scope()));
    }

    /** Streams matching token bills as a CSV attachment for the caller's company scope. */
    @GetMapping("/export")
    @RequirePerm(RolePermissions.BILLING_READ)
    public void export(BillQuery q, HttpServletResponse response) throws IOException {
        Long scope = scope();
        response.setContentType("text/csv;charset=UTF-8");
        response.setCharacterEncoding(StandardCharsets.UTF_8.name());
        response.setHeader("Content-Disposition", "attachment; filename=\"bill_token_export.csv\"");
        try (PrintWriter writer = response.getWriter()) {
            billingQueryService.exportBillsCsv(scope, q, writer);
        }
    }

    /** Company scope: super-admin = all (null), otherwise the active company. */
    private Long scope() {
        LoginUser user = UserContext.require();
        return user.isSuperAdmin() ? null : UserContext.companyId();
    }
}
