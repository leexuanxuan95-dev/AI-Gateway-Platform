package com.aigateway.modules.payment.controller;

import com.aigateway.common.api.R;
import com.aigateway.common.security.RequirePerm;
import com.aigateway.common.security.RolePermissions;
import com.aigateway.common.security.UserContext;
import com.aigateway.modules.payment.adapter.PrepayResult;
import com.aigateway.modules.payment.dto.ChannelOption;
import com.aigateway.modules.payment.dto.CreatePayRequest;
import com.aigateway.modules.payment.service.PayChannelConfigService;
import com.aigateway.modules.payment.service.PaymentCallbackHandler;
import com.aigateway.modules.payment.service.PaymentService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.math.BigDecimal;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Recharge / callback / public channel listing endpoints (design doc §10.2). */
@RestController
@RequestMapping("/api/pay")
@RequiredArgsConstructor
public class PaymentController {

    private final PaymentService paymentService;
    private final PaymentCallbackHandler callbackHandler;
    private final PayChannelConfigService channelConfigService;

    /** Create a recharge order and return the prepay payload. Authenticated. */
    @PostMapping("/create")
    @RequirePerm(RolePermissions.RECHARGE)
    public R<PrepayResult> create(@RequestBody @Valid CreatePayRequest req) {
        return R.ok(paymentService.create(UserContext.companyId(), UserContext.userId(), req));
    }

    /**
     * Unified payment webhook (PUBLIC). The raw body is required for signature verification,
     * so it is read directly from the request. Always idempotent + signature-verified.
     */
    @PostMapping("/callback/{code}")
    public String callback(@PathVariable String code,
                           @RequestBody(required = false) String body,
                           HttpServletRequest request) {
        return callbackHandler.handle(code, body, extractHeaders(request));
    }

    /** PUBLIC: enabled channels matching the amount/currency filter (§10.2.1-C). */
    @GetMapping("/channels")
    public R<List<ChannelOption>> channels(@RequestParam(required = false) BigDecimal amount,
                                           @RequestParam(required = false) String currency) {
        return R.ok(channelConfigService.publicChannels(amount, currency));
    }

    private Map<String, String> extractHeaders(HttpServletRequest request) {
        Map<String, String> headers = new HashMap<>();
        Enumeration<String> names = request.getHeaderNames();
        if (names != null) {
            while (names.hasMoreElements()) {
                String n = names.nextElement();
                headers.put(n, request.getHeader(n));
            }
        }
        return headers;
    }
}
