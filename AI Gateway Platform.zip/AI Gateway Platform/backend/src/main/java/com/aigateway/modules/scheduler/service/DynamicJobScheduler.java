package com.aigateway.modules.scheduler.service;

import com.aigateway.common.schedule.ManagedJob;
import com.aigateway.modules.scheduler.entity.SysScheduledJob;
import com.aigateway.modules.scheduler.mapper.SysScheduledJobMapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import jakarta.annotation.PreDestroy;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler;
import org.springframework.scheduling.support.CronExpression;
import org.springframework.scheduling.support.CronTrigger;
import org.springframework.stereotype.Service;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ScheduledFuture;

/**
 * Runtime-managed scheduler (design doc §15.5). Discovers all {@link ManagedJob} beans,
 * persists one {@code sys_scheduled_job} row per job (seeded from its default cron on first
 * start), and schedules the enabled ones via a dedicated thread pool. Cron/enabled changes
 * and on-demand runs are applied live with no redeploy. Every execution records its
 * status/duration/error back to the row.
 */
@Slf4j
@Service
public class DynamicJobScheduler implements ApplicationRunner {

    private static final int POOL_SIZE = 8;
    private static final String STATUS_RUNNING = "running";
    private static final String STATUS_SUCCESS = "success";
    private static final String STATUS_FAIL = "fail";
    private static final int MAX_ERROR_LEN = 512;

    private final SysScheduledJobMapper jobMapper;
    private final Map<String, ManagedJob> registry = new ConcurrentHashMap<>();
    private final Map<String, ScheduledFuture<?>> futures = new ConcurrentHashMap<>();
    private final ThreadPoolTaskScheduler scheduler;

    public DynamicJobScheduler(SysScheduledJobMapper jobMapper, List<ManagedJob> jobs) {
        this.jobMapper = jobMapper;
        this.scheduler = new ThreadPoolTaskScheduler();
        this.scheduler.setPoolSize(POOL_SIZE);
        this.scheduler.setThreadNamePrefix("gw-job-");
        this.scheduler.setWaitForTasksToCompleteOnShutdown(true);
        this.scheduler.setAwaitTerminationSeconds(20);
        this.scheduler.initialize();
        jobs.forEach(j -> registry.put(j.jobKey(), j));
    }

    @Override
    public void run(ApplicationArguments args) {
        for (ManagedJob job : registry.values()) {
            try {
                SysScheduledJob row = seedRow(job);
                if (Boolean.TRUE.equals(row.getEnabled())) {
                    scheduleInternal(job.jobKey(), row.getCron());
                }
                if (job.runOnStartup()) {
                    scheduler.execute(() -> runWrapped(job.jobKey()));
                }
            } catch (Exception e) {
                log.error("[scheduler] failed to init job {}: {}", job.jobKey(), e.getMessage());
            }
        }
        log.info("[scheduler] {} managed jobs registered, {} scheduled", registry.size(), futures.size());
    }

    /** Insert the job row on first start; return the current (DB) row. */
    private SysScheduledJob seedRow(ManagedJob job) {
        SysScheduledJob row = jobMapper.selectOne(
                Wrappers.<SysScheduledJob>lambdaQuery().eq(SysScheduledJob::getJobKey, job.jobKey()));
        if (row == null) {
            row = new SysScheduledJob();
            row.setJobKey(job.jobKey());
            row.setJobName(job.getClass().getSimpleName());
            row.setCron(job.defaultCron());
            row.setEnabled(true);
            row.setDescription(job.description());
            jobMapper.insert(row);
        }
        return row;
    }

    private void scheduleInternal(String key, String cron) {
        cancelFuture(key);
        if (!CronExpression.isValidExpression(cron)) {
            log.error("[scheduler] invalid cron '{}' for job {}, not scheduled", cron, key);
            return;
        }
        ScheduledFuture<?> future = scheduler.schedule(() -> runWrapped(key), new CronTrigger(cron));
        if (future != null) {
            futures.put(key, future);
        }
    }

    /** Run a job once, recording status/duration/error. */
    private void runWrapped(String key) {
        ManagedJob job = registry.get(key);
        if (job == null) {
            return;
        }
        long start = System.currentTimeMillis();
        markStatus(key, STATUS_RUNNING, null, null);
        try {
            job.execute();
            markStatus(key, STATUS_SUCCESS, System.currentTimeMillis() - start, null);
        } catch (Throwable t) {
            log.error("[scheduler] job {} failed: {}", key, t.getMessage(), t);
            markStatus(key, STATUS_FAIL, System.currentTimeMillis() - start, truncate(t.getMessage()));
        }
    }

    private void markStatus(String key, String status, Long durationMs, String error) {
        try {
            SysScheduledJob upd = new SysScheduledJob();
            upd.setLastStatus(status);
            upd.setLastError(error);
            if (STATUS_RUNNING.equals(status)) {
                upd.setLastRunAt(OffsetDateTime.now());
            } else {
                upd.setLastDurationMs(durationMs);
            }
            jobMapper.update(upd, Wrappers.<SysScheduledJob>lambdaUpdate()
                    .eq(SysScheduledJob::getJobKey, key));
        } catch (Exception e) {
            log.debug("[scheduler] status update failed for {}: {}", key, e.getMessage());
        }
    }

    // ---- admin operations ----

    /** Apply a cron/enabled change: persist and (re)schedule or cancel live. */
    public void apply(String key, String cron, boolean enabled) {
        cancelFuture(key);
        if (enabled) {
            scheduleInternal(key, cron);
        }
    }

    /** Trigger a job immediately, off the request thread. */
    public void runNow(String key) {
        if (!registry.containsKey(key)) {
            return;
        }
        scheduler.execute(() -> runWrapped(key));
    }

    public boolean isScheduled(String key) {
        ScheduledFuture<?> f = futures.get(key);
        return f != null && !f.isCancelled();
    }

    /** Next fire time for a cron, or null if invalid/never. */
    public OffsetDateTime nextRun(String cron) {
        if (cron == null || !CronExpression.isValidExpression(cron)) {
            return null;
        }
        return CronExpression.parse(cron).next(OffsetDateTime.now());
    }

    private void cancelFuture(String key) {
        ScheduledFuture<?> f = futures.remove(key);
        if (f != null) {
            f.cancel(false);
        }
    }

    private String truncate(String s) {
        if (s == null) {
            return null;
        }
        return s.length() > MAX_ERROR_LEN ? s.substring(0, MAX_ERROR_LEN) : s;
    }

    @PreDestroy
    public void shutdown() {
        scheduler.shutdown();
    }
}
