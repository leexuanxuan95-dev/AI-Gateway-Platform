package com.aigateway.modules.finance.service;

import com.aigateway.common.api.PageResult;
import com.aigateway.common.enums.TransactionType;
import com.aigateway.modules.finance.dto.ModelBindingRequest;
import com.aigateway.modules.finance.dto.ProfitDashboard;
import com.aigateway.modules.finance.entity.FinAccount;
import com.aigateway.modules.finance.entity.FinModelBinding;
import com.aigateway.modules.finance.entity.FinTransaction;

import java.math.BigDecimal;
import java.util.Map;

/** Console-facing finance operations (design doc §10). */
public interface FinanceService {

    /** Current company balance, creating an empty account on first access. */
    FinAccount getOrCreateAccount(Long companyId);

    /** Paged transactions for the current company. */
    PageResult<FinTransaction> transactions(Long companyId, long current, long size);

    /** Super-admin profit dashboard (revenue/cost/profit + by-model margin). */
    ProfitDashboard profitDashboard();

    /** Allocate balance to a model binding for the current company. */
    FinModelBinding allocate(Long companyId, ModelBindingRequest req);

    /** List the model bindings of the current company. */
    java.util.List<FinModelBinding> bindings(Long companyId);

    /**
     * Credit a successful recharge to the account (called by the payment callback,
     * inside the callback transaction). Increases available balance + total recharge,
     * writes a recharge transaction, and applies the platform recharge fee if enabled.
     *
     * @param feeConfig optional applicable {@link com.aigateway.modules.finance.entity.RechargeFeeConfig}
     */
    void creditRecharge(Long companyId, BigDecimal amount, String orderNo,
                        com.aigateway.modules.finance.entity.RechargeFeeConfig feeConfig);

    /** Resolve the applicable recharge-fee config for a company (company &gt; global). */
    com.aigateway.modules.finance.entity.RechargeFeeConfig resolveRechargeFee(Long companyId);

    /** Apply the recharge fee to the platform profit (called within recharge credit). */
    void recordRechargeFee(Long companyId, String orderNo, BigDecimal fee);

    /** Adjust freeze balance directly (used by withdraw apply/reject). */
    FinAccount adjustForWithdraw(Long companyId, BigDecimal freezeDelta, BigDecimal availableDelta,
                                 TransactionType bizType, String refId, String remark);

    /** Raw map list for super-admin reports. */
    Map<String, Object> profitSummary();
}
