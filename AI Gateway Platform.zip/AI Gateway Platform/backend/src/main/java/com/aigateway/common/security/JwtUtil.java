package com.aigateway.common.security;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.crypto.SecretKey;
import java.nio.charset.StandardCharsets;
import java.util.Date;
import java.util.Map;
import java.util.UUID;

/**
 * Issues and parses access JWTs (HS256). Refresh tokens are opaque and stored in Redis.
 *
 * <p>Hardening (design doc §18): the signing key must be &ge; 256 bits; every token carries
 * a bound {@code issuer} (verified on parse, prevents cross-service token reuse) and a unique
 * {@code jti} (enables denylist-based revocation). The HMAC verification rejects {@code alg=none}
 * and algorithm-confusion attacks by construction.</p>
 */
@Component
public class JwtUtil {

    private static final int MILLIS_PER_SECOND = 1000;
    private static final int MIN_SECRET_BYTES = 32;
    /** Bound issuer claim; verified on every parse. */
    public static final String ISSUER = "ai-gateway";

    private final SecretKey key;
    private final long accessTtlSeconds;

    public JwtUtil(@Value("${aigateway.jwt.secret}") String secret,
                   @Value("${aigateway.jwt.access-ttl-seconds}") long accessTtlSeconds) {
        byte[] keyBytes = secret.getBytes(StandardCharsets.UTF_8);
        if (keyBytes.length < MIN_SECRET_BYTES) {
            throw new IllegalStateException(
                    "aigateway.jwt.secret must be at least 32 bytes (256 bits) for HS256");
        }
        this.key = Keys.hmacShaKeyFor(keyBytes);
        this.accessTtlSeconds = accessTtlSeconds;
    }

    public String issueAccessToken(Long userId, String uid, Map<String, Object> extra) {
        long now = System.currentTimeMillis();
        return Jwts.builder()
                .claims(extra)
                .subject(String.valueOf(userId))
                .claim("uid", uid)
                .id(UUID.randomUUID().toString())
                .issuer(ISSUER)
                .issuedAt(new Date(now))
                .expiration(new Date(now + accessTtlSeconds * MILLIS_PER_SECOND))
                .signWith(key)
                .compact();
    }

    /** Parse + verify signature and bound issuer; throws if invalid/expired/forged. */
    public Claims parse(String token) {
        return Jwts.parser()
                .verifyWith(key)
                .requireIssuer(ISSUER)
                .build()
                .parseSignedClaims(token)
                .getPayload();
    }
}
