package com.aigateway.modules.notify.dto;

import lombok.Data;

import java.io.Serializable;
import java.util.Map;

/**
 * Notification message carried on the {@code KafkaTopics.NOTIFY} topic and accepted by the
 * test-send endpoint (design doc §13). JSON shape:
 * {@code {companyId,channel,scene,target,content,params}}.
 *
 * <p>When {@code content} is blank the dispatcher renders the body from the {@code scene}'s
 * {@code notify_template}, substituting {@code {placeholder}} tokens with {@code params}. When
 * {@code content} is present its own {@code {placeholder}} tokens are still substituted.</p>
 */
@Data
public class NotifyMessage implements Serializable {

    private Long companyId;

    /** email / sms / inmail / webhook. */
    private String channel;

    private String scene;

    /** Recipient: email address, mobile, user id, or webhook URL. */
    private String target;

    private String content;

    /** Optional title/subject override (else taken from the template). */
    private String title;

    /** Template placeholder values, substituted into {@code {token}} markers. */
    private Map<String, Object> params;
}
