package com.aigateway.modules.gateway.controller;

import com.aigateway.common.exception.BizException;
import com.aigateway.common.exception.ErrorCode;
import com.aigateway.modules.gateway.util.GatewayErrorWriter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.util.Map;

/**
 * OpenAI-shaped error handler for the gateway controllers only (design doc §20.8). Scoped via
 * {@code assignableTypes} and bumped to the highest precedence so it wins over the console-wide
 * {@code GlobalExceptionHandler} (which returns the {@code R} envelope) for {@code /v1/*} routes.
 */
@Slf4j
@Order(Ordered.HIGHEST_PRECEDENCE)
@RestControllerAdvice(assignableTypes = {
        ChatCompletionsController.class,
        ModelsController.class,
        EmbeddingsController.class,
        ImagesController.class,
        AudioController.class,
        RerankController.class
})
public class GatewayExceptionHandler {

    /** HTTP status for an unexpected internal failure. */
    private static final int HTTP_INTERNAL_ERROR = 500;

    @ExceptionHandler(BizException.class)
    public ResponseEntity<Map<String, Object>> handleBiz(BizException e) {
        ErrorCode ec = e.getErrorCode();
        String type = ec.getOpenaiType() == null ? "invalid_request_error" : ec.getOpenaiType();
        return ResponseEntity.status(ec.getHttpStatus())
                .body(GatewayErrorWriter.body(type, e.getMessage(), ec.getOpenaiType()));
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<Map<String, Object>> handleOther(Exception e) {
        log.error("gateway internal error", e);
        return ResponseEntity.status(HTTP_INTERNAL_ERROR)
                .body(GatewayErrorWriter.body("internal_error", "internal error", null));
    }
}
