package com.aigateway.common.security;

import io.jsonwebtoken.Claims;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.lang.NonNull;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.List;

/**
 * Resolves the console JWT for {@code /api/**} requests, populating {@link UserContext}
 * and the Spring Security context. The OpenAI-compatible {@code /v1/**} surface is
 * authenticated separately by the gateway's API-key filter and is ignored here.
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class JwtAuthFilter extends OncePerRequestFilter {

    private static final String BEARER_PREFIX = "Bearer ";

    private final JwtUtil jwtUtil;
    private final TokenEpochService tokenEpochService;

    @Override
    protected boolean shouldNotFilter(@NonNull HttpServletRequest request) {
        String uri = request.getRequestURI();
        return uri.startsWith("/v1/")
                || uri.startsWith("/api/auth/")
                || uri.startsWith("/api/pay/callback/")
                || uri.startsWith("/actuator/");
    }

    @Override
    protected void doFilterInternal(@NonNull HttpServletRequest request,
                                    @NonNull HttpServletResponse response,
                                    @NonNull FilterChain chain) throws ServletException, IOException {
        String header = request.getHeader("Authorization");
        if (header != null && header.startsWith(BEARER_PREFIX)) {
            String token = header.substring(BEARER_PREFIX.length());
            try {
                Claims c = jwtUtil.parse(token);
                Long userId = Long.valueOf(c.getSubject());
                // revoke-all check: reject tokens minted before the user's current epoch
                Long tokenEpoch = c.get("epoch", Long.class);
                long mintedEpoch = tokenEpoch == null ? 0L : tokenEpoch;
                if (mintedEpoch < tokenEpochService.current(userId)) {
                    throw new io.jsonwebtoken.JwtException("token revoked");
                }
                String companyRole = c.get("companyRole", String.class);
                LoginUser user = LoginUser.builder()
                        .userId(userId)
                        .uid(c.get("uid", String.class))
                        .email(c.get("email", String.class))
                        .superAdmin(Boolean.TRUE.equals(c.get("superAdmin", Boolean.class)))
                        .companyId(c.get("companyId", Long.class))
                        .companyRole(companyRole)
                        .permissions(RolePermissions.forRole(companyRole))
                        .build();
                UserContext.set(user);

                var authorities = user.isSuperAdmin()
                        ? List.of(new SimpleGrantedAuthority("ROLE_SUPER_ADMIN"))
                        : List.<SimpleGrantedAuthority>of();
                var auth = new UsernamePasswordAuthenticationToken(user, null, authorities);
                SecurityContextHolder.getContext().setAuthentication(auth);
            } catch (Exception e) {
                log.debug("jwt parse failed: {}", e.getMessage());
            }
        }
        try {
            chain.doFilter(request, response);
        } finally {
            UserContext.clear();
        }
    }
}
