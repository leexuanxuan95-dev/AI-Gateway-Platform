package com.aigateway.modules.model.mapper;

import com.aigateway.modules.model.entity.LitellmDeployment;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/** MyBatis-Plus mapper for {@link LitellmDeployment}. */
public interface LitellmDeploymentMapper extends BaseMapper<LitellmDeployment> {
}
