package com.aigateway.modules.project.mapper;

import com.aigateway.modules.project.entity.Project;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/** MyBatis-Plus mapper for {@link Project}. */
public interface ProjectMapper extends BaseMapper<Project> {
}
