package com.aigateway.modules.risk.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

import java.time.OffsetDateTime;

/** Add-to-blacklist payload. */
@Data
public class BlacklistRequest {

    /** ip / country / user. */
    @NotBlank
    private String type;

    @NotBlank
    private String value;

    private String reason;

    /** Optional expiry; null = permanent. */
    private OffsetDateTime expireAt;
}
