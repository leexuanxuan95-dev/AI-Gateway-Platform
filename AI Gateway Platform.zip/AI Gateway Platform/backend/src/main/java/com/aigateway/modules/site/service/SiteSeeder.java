package com.aigateway.modules.site.service;

import com.aigateway.modules.site.entity.SiteFaq;
import com.aigateway.modules.site.entity.SiteSection;
import com.aigateway.modules.site.entity.SiteSetting;
import com.aigateway.modules.site.mapper.SiteFaqMapper;
import com.aigateway.modules.site.mapper.SiteSectionMapper;
import com.aigateway.modules.site.mapper.SiteSettingMapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Seeds the OmniRoute landing CMS with the default zh content (OmniRoute doc §3) so a
 * fresh install renders out of the box. Idempotent: only seeds when {@code site_section}
 * is empty. Wrapped defensively so a startup DB hiccup never crashes the app.
 */
@Slf4j
@Component
@Order(100)
@RequiredArgsConstructor
public class SiteSeeder implements ApplicationRunner {

    private static final String LANG_ZH = "zh";

    private final SiteSettingMapper siteSettingMapper;
    private final SiteSectionMapper siteSectionMapper;
    private final SiteFaqMapper siteFaqMapper;

    @Override
    public void run(ApplicationArguments args) {
        try {
            Long existing = siteSectionMapper.selectCount(Wrappers.<SiteSection>lambdaQuery());
            if (existing != null && existing > 0) {
                log.info("[site] sections already present ({}), skip seeding", existing);
                return;
            }
            seedSetting();
            seedSections();
            seedFaq();
            log.info("[site] default zh landing content seeded");
        } catch (Exception e) {
            log.warn("[site] seeding skipped due to error: {}", e.getMessage());
        }
    }

    // ---------------------------------------------------------------- setting

    private void seedSetting() {
        if (siteSettingMapper.selectCount(Wrappers.<SiteSetting>lambdaQuery()
                .eq(SiteSetting::getLang, LANG_ZH)) > 0) {
            return;
        }
        SiteSetting s = new SiteSetting();
        s.setLang(LANG_ZH);

        Map<String, Object> brand = new LinkedHashMap<>();
        brand.put("name", "OmniRoute");
        brand.put("domain", "omniroute.ai");
        brand.put("copyright", "© 2026 OmniRoute");
        s.setBrand(brand);

        Map<String, Object> seo = new LinkedHashMap<>();
        seo.put("title", "OmniRoute - 一个 Key，接入所有大模型");
        seo.put("description", "GPT-5、Claude Opus 4.8、Gemini、Grok、DeepSeek……统一计费、统一额度、智能故障转移，完全兼容 OpenAI SDK。");
        seo.put("keywords", "AI Gateway,大模型,OpenAI兼容,API聚合,OmniRoute");
        s.setSeo(seo);

        Map<String, Object> theme = new LinkedHashMap<>();
        theme.put("bg", "#0B1719");
        theme.put("amber", "#F6B53C");
        theme.put("mint", "#57E3BE");
        theme.put("text", "#E8F1EF");
        theme.put("border", "#21454B");
        Map<String, Object> font = new LinkedHashMap<>();
        font.put("heading", "Space Grotesk");
        font.put("body", "Noto Sans SC");
        font.put("mono", "IBM Plex Mono");
        theme.put("font", font);
        s.setTheme(theme);

        Map<String, Object> footer = new LinkedHashMap<>();
        footer.put("copyright", "© 2026 OmniRoute");
        footer.put("groups", List.of(
                group("产品", link("能力", "#features"), link("价格", "#pricing"), link("模型", "#models")),
                group("开发者", link("快速开始", "#how"), link("代码示例", "#code"), link("控制台", "/console")),
                group("公司", link("关于", "#"), link("联系", "#"), link("条款", "#"))
        ));
        s.setFooter(footer);

        siteSettingMapper.insert(s);
    }

    // --------------------------------------------------------------- sections

    private void seedSections() {
        int sort = 0;

        // hero
        Map<String, Object> heroPayload = new LinkedHashMap<>();
        heroPayload.put("subtitle", "GPT-5、Claude Opus 4.8、Gemini、Grok、DeepSeek…… 在 model 字段一填即换版本。"
                + "统一计费、统一额度、智能故障转移。完全兼容 OpenAI SDK，迁移只改两行。");
        heroPayload.put("ctas", List.of(
                cta("免费获取 API Key", "/signup", true),
                cta("看如何接入", "#how", false)));
        heroPayload.put("badges", List.of("9+ 供应商接入", "数十个模型版本", "多渠道充值（含 Wise 卡）"));
        heroPayload.put("showConsole", true);
        addSection("hero", sort++, "一个 Key，接入所有大模型。", null, heroPayload, null);

        // providers
        Map<String, Object> providersPayload = new LinkedHashMap<>();
        providersPayload.put("items", List.of(
                "OpenAI", "Anthropic", "Google Gemini", "xAI Grok", "DeepSeek",
                "Mistral", "Cohere", "OpenRouter", "Azure OpenAI"));
        addSection("providers", sort++, "已接入供应商", null, providersPayload, null);

        // features (6 cards)
        Map<String, Object> featuresPayload = new LinkedHashMap<>();
        featuresPayload.put("cards", List.of(
                card("hub", "全模型聚合", "9+ 供应商一个入口，屏蔽协议差异。"),
                card("swap", "版本自由切换", "像选 Opus 4.8 / Sonnet 4.6 / Haiku 4.5 一样填 model。"),
                card("wallet", "统一计费与额度", "按 token 实时计费，预冻结防超支，响应回显花费与余额。"),
                card("failover", "负载均衡 + 故障转移", "一家挂了自动切，客户端无感。"),
                card("shield", "企业多租户 + 风控", "四级隔离、RBAC、限流、黑名单、异常监控。"),
                card("card", "多渠道充值", "Stripe（含 Wise/国际卡）、支付宝、微信、USDT。")));
        addSection("features", sort++, "核心能力", null, featuresPayload, null);

        // how (4 steps)
        Map<String, Object> howPayload = new LinkedHashMap<>();
        howPayload.put("steps", List.of(
                step("01", "创建 API Key", "在控制台一键生成。"),
                step("02", "指向 base_url", "base_url 指向 api.omniroute.ai/v1。"),
                step("03", "选版本调用", "在 model 字段填入想要的模型版本。"),
                step("04", "充值看账单", "后台充值，实时查看花费与账单。")));
        addSection("how", sort++, "如何接入", "四步上线，迁移只改两行。", howPayload, null);

        // code (cURL / Python / Node)
        Map<String, Object> codePayload = new LinkedHashMap<>();
        codePayload.put("domain", "api.omniroute.ai");
        codePayload.put("tabs", List.of(
                codeTab("cURL", "shell",
                        "curl https://api.omniroute.ai/v1/chat/completions \\\n"
                                + "  -H \"Authorization: Bearer $OMNIROUTE_API_KEY\" \\\n"
                                + "  -H \"Content-Type: application/json\" \\\n"
                                + "  -d '{\"model\":\"claude-opus-4-8\",\"messages\":[{\"role\":\"user\",\"content\":\"Hello\"}]}'"),
                codeTab("Python", "python",
                        "from openai import OpenAI\n"
                                + "client = OpenAI(\n"
                                + "    base_url=\"https://api.omniroute.ai/v1\",\n"
                                + "    api_key=\"$OMNIROUTE_API_KEY\",\n"
                                + ")\n"
                                + "resp = client.chat.completions.create(\n"
                                + "    model=\"claude-opus-4-8\",\n"
                                + "    messages=[{\"role\": \"user\", \"content\": \"Hello\"}],\n"
                                + ")\n"
                                + "print(resp.choices[0].message.content)"),
                codeTab("Node", "javascript",
                        "import OpenAI from \"openai\";\n"
                                + "const client = new OpenAI({\n"
                                + "  baseURL: \"https://api.omniroute.ai/v1\",\n"
                                + "  apiKey: process.env.OMNIROUTE_API_KEY,\n"
                                + "});\n"
                                + "const resp = await client.chat.completions.create({\n"
                                + "  model: \"claude-opus-4-8\",\n"
                                + "  messages: [{ role: \"user\", content: \"Hello\" }],\n"
                                + "});\n"
                                + "console.log(resp.choices[0].message.content);")));
        addSection("code", sort++, "Drop-in 替换", "改两行，无缝迁移。", codePayload, null);

        // models (bind model_version)
        Map<String, Object> modelsPayload = new LinkedHashMap<>();
        modelsPayload.put("note", "上新自动显示，无需手改。");
        addSection("models", sort++, "支持模型", "数十个版本，持续上新。", modelsPayload, "model_version");

        // pricing (bind plan, highlight pro)
        Map<String, Object> pricingPayload = new LinkedHashMap<>();
        pricingPayload.put("highlight", "pro");
        pricingPayload.put("ctaText", "立即开始");
        pricingPayload.put("ctaHref", "/signup");
        addSection("pricing", sort++, "价格", "按需选择，随时升级。", pricingPayload, "plan");

        // security (4 cards)
        Map<String, Object> securityPayload = new LinkedHashMap<>();
        securityPayload.put("cards", List.of(
                card("lock", "密钥只存哈希", "API 密钥仅存哈希值，不可逆。"),
                card("tls", "全链路 TLS + 回调验签", "传输加密，支付回调强制验签。"),
                card("isolate", "企业级数据隔离", "四级租户隔离，数据互不可见。"),
                card("freeze", "预冻结防超支", "调用前预冻结额度，杜绝超支。")));
        addSection("security", sort++, "安全合规", null, securityPayload, null);

        // cta
        Map<String, Object> ctaPayload = new LinkedHashMap<>();
        ctaPayload.put("subtitle", "一个 Key，接入所有大模型。现在就开始。");
        ctaPayload.put("ctas", List.of(cta("免费获取 API Key", "/signup", true)));
        addSection("cta", sort, "准备好了吗？", null, ctaPayload, null);
    }

    private void addSection(String key, int sort, String title, String subtitle,
                            Map<String, Object> payload, String bindSource) {
        SiteSection s = new SiteSection();
        s.setSectionKey(key);
        s.setLang(LANG_ZH);
        s.setEnabled(Boolean.TRUE);
        s.setSort(sort);
        s.setTitle(title);
        s.setSubtitle(subtitle);
        s.setPayload(payload);
        s.setBindSource(bindSource);
        siteSectionMapper.insert(s);
    }

    // -------------------------------------------------------------------- faq

    private void seedFaq() {
        addFaq(0, "怎么计费？", "按 token 实时计费，调用前预冻结额度防超支，响应头与账单回显本次花费与余额。");
        addFaq(1, "迁移要改多少代码？", "完全兼容 OpenAI SDK，只需把 base_url 指向 api.omniroute.ai/v1 并替换 API Key，通常只改两行。");
        addFaq(2, "支持哪些支付？", "Stripe（含 Wise/国际卡）、支付宝、微信、USDT 等多渠道充值。");
        addFaq(3, "模型挂了怎么办？", "内置负载均衡与故障转移，单一上游不可用时自动切换渠道，客户端无感。");
        addFaq(4, "能否切版本？", "可以。在 model 字段填入想要的版本即可，如 claude-opus-4-8 / claude-sonnet-4-6 / gpt-5 等。");
        addFaq(5, "数据是否安全？", "密钥只存哈希、全链路 TLS、支付回调验签、企业级四级数据隔离。");
    }

    private void addFaq(int sort, String question, String answer) {
        SiteFaq f = new SiteFaq();
        f.setLang(LANG_ZH);
        f.setQuestion(question);
        f.setAnswer(answer);
        f.setSort(sort);
        f.setEnabled(Boolean.TRUE);
        siteFaqMapper.insert(f);
    }

    // --------------------------------------------------------------- builders

    private static Map<String, Object> card(String icon, String title, String desc) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("icon", icon);
        m.put("title", title);
        m.put("desc", desc);
        return m;
    }

    private static Map<String, Object> step(String no, String title, String desc) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("no", no);
        m.put("title", title);
        m.put("desc", desc);
        return m;
    }

    private static Map<String, Object> cta(String text, String href, boolean primary) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("text", text);
        m.put("href", href);
        m.put("primary", primary);
        return m;
    }

    private static Map<String, Object> codeTab(String label, String language, String code) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("label", label);
        m.put("language", language);
        m.put("code", code);
        return m;
    }

    private static Map<String, Object> link(String text, String href) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("text", text);
        m.put("href", href);
        return m;
    }

    @SafeVarargs
    private static Map<String, Object> group(String title, Map<String, Object>... links) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("title", title);
        List<Map<String, Object>> list = new ArrayList<>();
        for (Map<String, Object> l : links) {
            list.add(l);
        }
        m.put("links", list);
        return m;
    }
}
