package com.aigateway.modules.payment.adapter;

import com.aigateway.common.crypto.AesUtil;
import com.aigateway.common.exception.BizException;
import com.aigateway.common.exception.ErrorCode;
import com.aigateway.modules.finance.entity.FinRechargeOrder;
import com.aigateway.modules.payment.entity.PayChannelConfig;
import com.stripe.exception.SignatureVerificationException;
import com.stripe.model.Event;
import com.stripe.model.checkout.Session;
import com.stripe.net.RequestOptions;
import com.stripe.net.Webhook;
import com.stripe.param.checkout.SessionCreateParams;
import com.stripe.param.checkout.SessionRetrieveParams;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.HashMap;
import java.util.Map;

/**
 * Functional Stripe adapter (design doc §10.2). Uses Stripe Checkout Sessions with
 * {@code payment_method_types=card}, which natively covers Wise / international cards.
 * Webhooks are verified with {@link Webhook#constructEvent} using the per-channel
 * webhook secret. Handles {@code checkout.session.completed} with payment_status=paid.
 *
 * <p>Secrets ({@code apiKey}, {@code webhookSecret}) are read from the channel's encrypted
 * {@code credentials} map; the webhook secret falls back to {@code ${STRIPE_WEBHOOK_SECRET}}.
 * Secrets are never logged.</p>
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class StripeAdapter implements PaymentAdapter {

    private final AesUtil aesUtil;

    @Value("${STRIPE_WEBHOOK_SECRET:}")
    private String fallbackWebhookSecret;

    @Value("${aigateway.pay.success-url:https://app.example.com/recharge/success}")
    private String successUrl;

    @Value("${aigateway.pay.cancel-url:https://app.example.com/recharge/cancel}")
    private String cancelUrl;

    @Override
    public String code() {
        return "stripe";
    }

    @Override
    public PrepayResult createOrder(FinRechargeOrder o, PayChannelConfig c) {
        String apiKey = cred(c, "apiKey");
        if (apiKey == null) {
            throw new BizException(ErrorCode.PAY_CHANNEL_DISABLED, "stripe api key not configured");
        }
        try {
            // amount in the smallest currency unit (cents).
            long unitAmount = o.getAmount().multiply(BigDecimal.valueOf(100))
                    .setScale(0, RoundingMode.HALF_UP).longValueExact();
            String currency = o.getCurrency() != null ? o.getCurrency().toLowerCase() : "usd";

            SessionCreateParams params = SessionCreateParams.builder()
                    .setMode(SessionCreateParams.Mode.PAYMENT)
                    .addPaymentMethodType(SessionCreateParams.PaymentMethodType.CARD)
                    .setSuccessUrl(successUrl + "?order_no=" + o.getOrderNo())
                    .setCancelUrl(cancelUrl + "?order_no=" + o.getOrderNo())
                    .putMetadata("order_no", o.getOrderNo())
                    .setClientReferenceId(o.getOrderNo())
                    .addLineItem(SessionCreateParams.LineItem.builder()
                            .setQuantity(1L)
                            .setPriceData(SessionCreateParams.LineItem.PriceData.builder()
                                    .setCurrency(currency)
                                    .setUnitAmount(unitAmount)
                                    .setProductData(SessionCreateParams.LineItem.PriceData.ProductData.builder()
                                            .setName("Account recharge " + o.getOrderNo())
                                            .build())
                                    .build())
                            .build())
                    .build();

            RequestOptions opts = RequestOptions.builder().setApiKey(apiKey).build();
            Session session = Session.create(params, opts);

            PrepayResult res = new PrepayResult();
            res.setPayUrl(session.getUrl());
            Map<String, Object> raw = new HashMap<>();
            raw.put("sessionId", session.getId());
            res.setRaw(raw);
            return res;
        } catch (Exception e) {
            log.error("stripe create order failed for {}: {}", o.getOrderNo(), e.getMessage());
            throw new BizException(ErrorCode.SYSTEM_ERROR, "stripe create order failed");
        }
    }

    @Override
    public CallbackResult handleCallback(String body, Map<String, String> headers, PayChannelConfig c) {
        String webhookSecret = cred(c, "webhookSecret");
        if (webhookSecret == null) {
            webhookSecret = fallbackWebhookSecret;
        }
        String sigHeader = header(headers, "Stripe-Signature");
        if (webhookSecret == null || webhookSecret.isBlank() || sigHeader == null) {
            throw new BizException(ErrorCode.CALLBACK_SIGN_INVALID, "missing stripe signature/secret");
        }
        Event event;
        try {
            event = Webhook.constructEvent(body, sigHeader, webhookSecret);
        } catch (SignatureVerificationException e) {
            throw new BizException(ErrorCode.CALLBACK_SIGN_INVALID, "stripe signature invalid");
        }

        CallbackResult res = new CallbackResult();
        if (!"checkout.session.completed".equals(event.getType())) {
            res.setSuccess(false);
            return res;
        }
        Object obj = event.getDataObjectDeserializer().getObject().orElse(null);
        if (!(obj instanceof Session session)) {
            res.setSuccess(false);
            return res;
        }
        boolean paid = "paid".equals(session.getPaymentStatus());
        res.setSuccess(paid);
        res.setOrderNo(session.getMetadata() != null
                ? session.getMetadata().get("order_no") : session.getClientReferenceId());
        res.setThirdTxnId(session.getPaymentIntent());
        if (session.getAmountTotal() != null) {
            res.setAmount(BigDecimal.valueOf(session.getAmountTotal())
                    .divide(BigDecimal.valueOf(100), 2, RoundingMode.HALF_UP));
        }
        if (session.getCurrency() != null) {
            res.setCurrency(session.getCurrency().toUpperCase());
        }
        return res;
    }

    @Override
    public OrderStatus query(String orderNo, PayChannelConfig c) {
        String apiKey = cred(c, "apiKey");
        if (apiKey == null) {
            return OrderStatus.PENDING;
        }
        try {
            // Look up the checkout session by client_reference_id via list, then inspect status.
            RequestOptions opts = RequestOptions.builder().setApiKey(apiKey).build();
            com.stripe.param.checkout.SessionListParams listParams =
                    com.stripe.param.checkout.SessionListParams.builder().setLimit(20L).build();
            for (Session s : Session.list(listParams, opts).getData()) {
                if (orderNo.equals(s.getClientReferenceId())
                        || (s.getMetadata() != null && orderNo.equals(s.getMetadata().get("order_no")))) {
                    Session full = Session.retrieve(s.getId(), SessionRetrieveParams.builder().build(), opts);
                    return "paid".equals(full.getPaymentStatus()) ? OrderStatus.PAID : OrderStatus.PENDING;
                }
            }
            return OrderStatus.PENDING;
        } catch (Exception e) {
            log.warn("stripe query failed for {}: {}", orderNo, e.getMessage());
            return OrderStatus.PENDING;
        }
    }

    /** Decrypt a named credential value from the channel config (never logged). */
    private String cred(PayChannelConfig c, String key) {
        if (c.getCredentials() == null) {
            return null;
        }
        Object v = c.getCredentials().get(key);
        if (v == null) {
            return null;
        }
        return aesUtil.decrypt(v.toString());
    }

    private String header(Map<String, String> headers, String name) {
        if (headers == null) {
            return null;
        }
        for (Map.Entry<String, String> e : headers.entrySet()) {
            if (e.getKey() != null && e.getKey().equalsIgnoreCase(name)) {
                return e.getValue();
            }
        }
        return null;
    }
}
