package com.aigateway.modules.user.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

/** Refresh-token exchange request. */
@Data
public class RefreshRequest {

    @NotBlank
    private String refreshToken;
}
