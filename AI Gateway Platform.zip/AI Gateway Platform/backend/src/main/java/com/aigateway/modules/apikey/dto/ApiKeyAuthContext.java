package com.aigateway.modules.apikey.dto;

import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

/**
 * Authenticated API-key context resolved by {@code ApiKeyAuthService}.
 * Consumed by the gateway module to enforce per-key limits, model allow-lists
 * and quotas. Cached in Redis under {@code RedisKeys.apiKeyAuth(hash)}.
 */
@Data
public class ApiKeyAuthContext implements Serializable {

    private Long apiKeyId;
    private Long companyId;
    private Long projectId;
    private List<String> allowedModels;
    private Integer rpmLimit;
    private Integer tpmLimit;
    private BigDecimal dailyQuota;
    private List<String> ipWhitelist;
    private Integer status;
}
