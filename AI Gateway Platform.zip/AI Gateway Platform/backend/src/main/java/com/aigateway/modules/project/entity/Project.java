package com.aigateway.modules.project.entity;

import com.aigateway.common.enums.CommonStatus;
import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableLogic;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.handlers.JacksonTypeHandler;
import lombok.Data;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.List;

/** Project entity (table {@code biz_project}). */
@Data
@TableName(value = "biz_project", autoResultMap = true)
public class Project {

    @TableId(type = IdType.AUTO)
    private Long id;

    private Long companyId;

    private String name;

    private String description;

    /** Monthly spend quota; 0 = unlimited. */
    private BigDecimal monthlyQuota;

    @TableField(typeHandler = JacksonTypeHandler.class)
    private List<String> allowedModels;

    private CommonStatus status;

    @TableLogic
    private Integer deleted;

    @TableField(fill = FieldFill.INSERT)
    private OffsetDateTime createdAt;

    @TableField(fill = FieldFill.INSERT_UPDATE)
    private OffsetDateTime updatedAt;
}
