package com.aigateway.modules.payment.service;

import java.util.Map;

/** Unified, idempotent, signature-verified payment callback handler (design doc §10.2 / §18). */
public interface PaymentCallbackHandler {

    /**
     * Handle an inbound webhook for a channel. Returns a short ack string for the provider.
     *
     * @param code    channel code from the path
     * @param body    raw request body (needed for signature verification)
     * @param headers request headers (signature header lives here)
     */
    String handle(String code, String body, Map<String, String> headers);
}
