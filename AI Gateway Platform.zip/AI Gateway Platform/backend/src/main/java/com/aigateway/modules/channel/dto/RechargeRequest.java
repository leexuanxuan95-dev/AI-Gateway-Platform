package com.aigateway.modules.channel.dto;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.math.BigDecimal;

/** Manual channel recharge payload. */
@Data
public class RechargeRequest {

    @NotNull
    @DecimalMin(value = "0.01", message = "amount must be at least 0.01")
    private BigDecimal amount;

    private String currency;

    private String remark;
}
