package com.aigateway.modules.notify.entity;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.aigateway.common.enums.NotifyStatus;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.time.OffsetDateTime;

/** A single delivered/attempted notification (table {@code notify_log}, design doc §13). */
@Data
@TableName(value = "notify_log", autoResultMap = true)
public class NotifyLog {

    @TableId(type = IdType.AUTO)
    private Long id;

    private Long companyId;

    /** email / sms / inmail / webhook. */
    private String channel;

    private String scene;

    private String target;

    private String content;

    /** 0 pending, 1 success, 2 fail. */
    private NotifyStatus status;

    private Integer retry;

    @TableField(fill = FieldFill.INSERT)
    private OffsetDateTime createdAt;
}
