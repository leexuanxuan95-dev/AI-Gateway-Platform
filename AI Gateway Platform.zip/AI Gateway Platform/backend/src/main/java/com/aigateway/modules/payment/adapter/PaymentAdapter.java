package com.aigateway.modules.payment.adapter;

import com.aigateway.modules.finance.entity.FinRechargeOrder;
import com.aigateway.modules.payment.entity.PayChannelConfig;

import java.util.Map;

/**
 * Pluggable payment channel adapter SPI (design doc §10.2). Each implementation is a
 * Spring bean discovered by {@link #code()}. Adapters MUST verify the webhook signature
 * inside {@link #handleCallback} and never trust raw callback amounts.
 */
public interface PaymentAdapter {

    /** Channel code this adapter handles (e.g. {@code stripe}). */
    String code();

    /** Create an order at the channel and return the prepay payload. */
    PrepayResult createOrder(FinRechargeOrder o, PayChannelConfig c);

    /**
     * Verify the signature of an inbound webhook and parse it into a normalized result.
     * Implementations must return {@code success=false} (or throw) on signature failure.
     */
    CallbackResult handleCallback(String body, Map<String, String> headers, PayChannelConfig c);

    /** Actively query the order status (used by the lost-callback poller). */
    OrderStatus query(String orderNo, PayChannelConfig c);
}
