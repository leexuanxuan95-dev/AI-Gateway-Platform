package com.aigateway.modules.model.controller;

import com.aigateway.common.api.PageResult;
import com.aigateway.common.api.R;
import com.aigateway.common.exception.BizException;
import com.aigateway.common.exception.ErrorCode;
import com.aigateway.common.security.UserContext;
import com.aigateway.modules.model.dto.ModelFamilyRequest;
import com.aigateway.modules.model.dto.ModelRouteRequest;
import com.aigateway.modules.model.dto.ModelVersionQuery;
import com.aigateway.modules.model.dto.ModelVersionRequest;
import com.aigateway.modules.model.entity.ModelChannelRoute;
import com.aigateway.modules.model.entity.ModelFamily;
import com.aigateway.modules.model.entity.ModelVersion;
import com.aigateway.modules.model.service.ModelCatalogService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * Model catalog endpoints. Catalog reads (families list, versions, routes) are open to any
 * authenticated user; all writes are restricted to the platform super-admin.
 */
@RestController
@RequestMapping("/api/model")
@RequiredArgsConstructor
public class ModelController {

    private final ModelCatalogService catalogService;

    // ---- families ----

    @GetMapping("/families")
    public R<List<ModelFamily>> families() {
        UserContext.require();
        return R.ok(catalogService.listFamilies());
    }

    @PostMapping("/families")
    public R<ModelFamily> createFamily(@RequestBody @Valid ModelFamilyRequest req) {
        requireSuperAdmin();
        return R.ok(catalogService.createFamily(req));
    }

    @PutMapping("/families/{id}")
    public R<ModelFamily> updateFamily(@PathVariable Long id, @RequestBody ModelFamilyRequest req) {
        requireSuperAdmin();
        return R.ok(catalogService.updateFamily(id, req));
    }

    @DeleteMapping("/families/{id}")
    public R<Void> deleteFamily(@PathVariable Long id) {
        requireSuperAdmin();
        catalogService.deleteFamily(id);
        return R.ok();
    }

    // ---- versions ----

    @GetMapping("/versions")
    public R<PageResult<ModelVersion>> versions(@ModelAttribute ModelVersionQuery query,
                                                @RequestParam(defaultValue = "1") long current,
                                                @RequestParam(defaultValue = "20") long size) {
        UserContext.require();
        return R.ok(catalogService.pageVersions(query, current, size));
    }

    @PostMapping("/versions")
    public R<ModelVersion> createVersion(@RequestBody @Valid ModelVersionRequest req) {
        requireSuperAdmin();
        return R.ok(catalogService.createVersion(req));
    }

    @PutMapping("/versions/{id}")
    public R<ModelVersion> updateVersion(@PathVariable Long id, @RequestBody ModelVersionRequest req) {
        requireSuperAdmin();
        return R.ok(catalogService.updateVersion(id, req));
    }

    @PostMapping("/versions/{id}/list")
    public R<ModelVersion> listVersion(@PathVariable Long id) {
        requireSuperAdmin();
        return R.ok(catalogService.listVersion(id));
    }

    @PostMapping("/versions/{id}/delist")
    public R<ModelVersion> delistVersion(@PathVariable Long id) {
        requireSuperAdmin();
        return R.ok(catalogService.delistVersion(id));
    }

    @DeleteMapping("/versions/{id}")
    public R<Void> deleteVersion(@PathVariable Long id) {
        requireSuperAdmin();
        catalogService.deleteVersion(id);
        return R.ok();
    }

    // ---- routes ----

    @GetMapping("/versions/{id}/routes")
    public R<List<ModelChannelRoute>> routes(@PathVariable Long id) {
        UserContext.require();
        return R.ok(catalogService.routesForVersion(id));
    }

    @PostMapping("/routes")
    public R<ModelChannelRoute> createRoute(@RequestBody @Valid ModelRouteRequest req) {
        requireSuperAdmin();
        return R.ok(catalogService.createRoute(req));
    }

    @PutMapping("/routes/{id}")
    public R<ModelChannelRoute> updateRoute(@PathVariable Long id, @RequestBody ModelRouteRequest req) {
        requireSuperAdmin();
        return R.ok(catalogService.updateRoute(id, req));
    }

    @DeleteMapping("/routes/{id}")
    public R<Void> deleteRoute(@PathVariable Long id) {
        requireSuperAdmin();
        catalogService.deleteRoute(id);
        return R.ok();
    }

    private void requireSuperAdmin() {
        if (!UserContext.require().isSuperAdmin()) {
            throw new BizException(ErrorCode.FORBIDDEN);
        }
    }
}
