package com.aigateway.common.enums;

import com.baomidou.mybatisplus.annotation.EnumValue;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;

/** Generic success/fail flag (login log, audit log). */
@Getter
public enum ResultStatus implements CodedEnum<Integer> {

    FAIL(0),
    SUCCESS(1);

    @EnumValue
    @JsonValue
    private final Integer code;

    ResultStatus(Integer code) {
        this.code = code;
    }

    @JsonCreator
    public static ResultStatus of(Integer code) {
        if (code == null) {
            return null;
        }
        for (ResultStatus v : values()) {
            if (v.code.equals(code)) {
                return v;
            }
        }
        return null;
    }
}
