package com.aigateway.modules.scheduler.dto;

import lombok.Data;

import java.time.OffsetDateTime;

/** Admin view of a managed scheduled job (status + next fire time). */
@Data
public class JobView {

    private String jobKey;
    private String jobName;
    private String cron;
    private Boolean enabled;
    private String description;
    private OffsetDateTime lastRunAt;
    private String lastStatus;
    private Long lastDurationMs;
    private String lastError;
    /** Whether a live trigger is currently armed. */
    private Boolean scheduled;
    private OffsetDateTime nextRunAt;
}
