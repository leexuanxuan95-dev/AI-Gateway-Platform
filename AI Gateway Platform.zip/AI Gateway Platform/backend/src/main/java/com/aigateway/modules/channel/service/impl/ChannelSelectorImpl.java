package com.aigateway.modules.channel.service.impl;

import com.aigateway.common.constant.RedisKeys;
import com.aigateway.common.crypto.AesUtil;
import com.aigateway.common.enums.ChannelHealth;
import com.aigateway.common.enums.CommonStatus;
import com.aigateway.common.exception.BizException;
import com.aigateway.common.exception.ErrorCode;
import com.aigateway.modules.channel.dto.ChannelPick;
import com.aigateway.modules.channel.entity.Channel;
import com.aigateway.modules.channel.entity.ChannelApiKey;
import com.aigateway.modules.channel.mapper.ChannelMapper;
import com.aigateway.modules.channel.service.ChannelApiKeyService;
import com.aigateway.modules.channel.service.ChannelSelector;
import com.aigateway.modules.model.entity.ModelChannelRoute;
import com.aigateway.modules.model.service.ModelRouteService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.Duration;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Default {@link ChannelSelector}. Resolves routes via {@link ModelRouteService}, filters
 * to healthy/enabled/off-cooldown channels with positive balance, and does priority-tiered
 * weighted-random selection. Failures trip a Redis-backed circuit breaker.
 */
@Slf4j
@Service
public class ChannelSelectorImpl implements ChannelSelector {

    private static final int FAIL_THRESHOLD = 3;
    private static final Duration COOLDOWN = Duration.ofSeconds(30);
    private static final Duration FAIL_TTL = Duration.ofSeconds(60);
    private static final String FAIL_PREFIX = "gw:ch:fail:";

    private final ModelRouteService modelRouteService;
    private final ChannelMapper channelMapper;
    private final RedisTemplate<String, Object> redisTemplate;
    private final AesUtil aesUtil;
    private final ChannelApiKeyService channelApiKeyService;

    @Autowired
    public ChannelSelectorImpl(ModelRouteService modelRouteService,
                               ChannelMapper channelMapper,
                               RedisTemplate<String, Object> redisTemplate,
                               AesUtil aesUtil,
                               ChannelApiKeyService channelApiKeyService) {
        this.modelRouteService = modelRouteService;
        this.channelMapper = channelMapper;
        this.redisTemplate = redisTemplate;
        this.aesUtil = aesUtil;
        this.channelApiKeyService = channelApiKeyService;
    }

    @Override
    public ChannelPick pick(String modelCode) {
        List<ModelChannelRoute> routes = modelRouteService.routesFor(modelCode);
        if (routes.isEmpty()) {
            throw new BizException(ErrorCode.ALL_CHANNELS_UNAVAILABLE);
        }

        // Build priority-tiered candidate list (routes already sorted priority asc, weight desc).
        Map<Integer, List<Candidate>> byPriority = new LinkedHashMap<>();
        for (ModelChannelRoute route : routes) {
            Channel ch = channelMapper.selectById(route.getChannelId());
            if (!isUsable(ch)) {
                continue;
            }
            int prio = route.getPriority() == null ? 0 : route.getPriority();
            byPriority.computeIfAbsent(prio, k -> new ArrayList<>()).add(new Candidate(route, ch));
        }

        // Lowest priority tier first; within tier, weighted random.
        for (Map.Entry<Integer, List<Candidate>> tier : byPriority.entrySet()) {
            Candidate chosen = weightedPick(tier.getValue());
            if (chosen != null) {
                return toPick(chosen);
            }
        }
        throw new BizException(ErrorCode.ALL_CHANNELS_UNAVAILABLE);
    }

    @Override
    public void reportSuccess(Long channelId, BigDecimal upstreamCost) {
        if (channelId == null) {
            return;
        }
        try {
            redisTemplate.delete(FAIL_PREFIX + channelId);
        } catch (Exception e) {
            log.debug("reportSuccess clear failed for {}: {}", channelId, e.getMessage());
        }
    }

    @Override
    public void reportFailure(Long channelId) {
        if (channelId == null) {
            return;
        }
        try {
            String key = FAIL_PREFIX + channelId;
            Long fails = redisTemplate.opsForValue().increment(key);
            redisTemplate.expire(key, FAIL_TTL);
            if (fails != null && fails >= FAIL_THRESHOLD) {
                Channel upd = new Channel();
                upd.setId(channelId);
                upd.setHealth(ChannelHealth.BROKEN);
                channelMapper.updateById(upd);
                redisTemplate.opsForValue().set(
                        RedisKeys.channelCooldown(channelId), "1", COOLDOWN);
                redisTemplate.delete(key);
                log.warn("channel {} tripped circuit breaker (>= {} failures)", channelId, FAIL_THRESHOLD);
            }
        } catch (Exception e) {
            log.debug("reportFailure failed for {}: {}", channelId, e.getMessage());
        }
    }

    /** Healthy, enabled, off-cooldown and positive balance. */
    private boolean isUsable(Channel ch) {
        if (ch == null) {
            return false;
        }
        if (ChannelHealth.HEALTHY != ch.getHealth()) {
            return false;
        }
        if (CommonStatus.ENABLED != ch.getStatus()) {
            return false;
        }
        if (estimatedBalance(ch).compareTo(BigDecimal.ZERO) <= 0) {
            return false;
        }
        try {
            if (Boolean.TRUE.equals(redisTemplate.hasKey(RedisKeys.channelCooldown(ch.getId())))) {
                return false;
            }
        } catch (Exception e) {
            log.debug("cooldown check failed for {}: {}", ch.getId(), e.getMessage());
        }
        // Usable only if the pool has at least one active key OR a legacy single key is configured.
        return channelApiKeyService.hasActiveKey(ch.getId()) || hasLegacyKey(ch);
    }

    /** Whether the channel carries a non-blank legacy {@code api_key} column. */
    private boolean hasLegacyKey(Channel ch) {
        return ch.getApiKey() != null && !ch.getApiKey().isBlank();
    }

    private BigDecimal estimatedBalance(Channel ch) {
        BigDecimal quota = ch.getQuota() == null ? BigDecimal.ZERO : ch.getQuota();
        BigDecimal used = ch.getUsedQuota() == null ? BigDecimal.ZERO : ch.getUsedQuota();
        return quota.subtract(used);
    }

    /** Weighted-random selection over candidates by channel weight (min 1). */
    private Candidate weightedPick(List<Candidate> candidates) {
        if (candidates.isEmpty()) {
            return null;
        }
        int total = 0;
        for (Candidate c : candidates) {
            total += Math.max(1, c.channel.getWeight() == null ? 1 : c.channel.getWeight());
        }
        int roll = ThreadLocalRandom.current().nextInt(total);
        int acc = 0;
        for (Candidate c : candidates) {
            acc += Math.max(1, c.channel.getWeight() == null ? 1 : c.channel.getWeight());
            if (roll < acc) {
                return c;
            }
        }
        return candidates.get(candidates.size() - 1);
    }

    /**
     * Resolve the decrypted upstream key for the chosen channel: prefer an active key from the
     * channel's key pool (sets {@code keyId}); fall back to the channel's legacy single
     * {@code api_key} column when the pool has no active key ({@code keyId=null}). Never logged.
     */
    private ChannelPick toPick(Candidate c) {
        ChannelPick pick = new ChannelPick();
        pick.setChannelId(c.channel.getId());
        pick.setProviderName(c.channel.getProviderName());
        pick.setUpstreamModel(c.route.getUpstreamModel());
        pick.setBaseUrl(c.channel.getBaseUrl());

        ChannelApiKey poolKey = channelApiKeyService.pickActive(c.channel.getId());
        if (poolKey != null) {
            pick.setKeyId(poolKey.getId());
            pick.setApiKey(aesUtil.decrypt(poolKey.getApiKey()));
        } else {
            pick.setKeyId(null);
            pick.setApiKey(aesUtil.decrypt(c.channel.getApiKey()));
        }
        return pick;
    }

    /** Route + its resolved channel. */
    private record Candidate(ModelChannelRoute route, Channel channel) {
    }
}
