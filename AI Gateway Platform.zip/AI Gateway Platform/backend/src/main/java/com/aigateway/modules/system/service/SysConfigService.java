package com.aigateway.modules.system.service;

import com.aigateway.modules.system.entity.SysConfig;

import java.math.BigDecimal;
import java.util.List;

/**
 * System config center (design doc §15.4). Provides Redis-cached get/set of dynamic
 * platform parameters plus typed accessors with defaults. Writes evict the cache.
 */
public interface SysConfigService {

    /** Raw config row, or null if absent. */
    SysConfig get(String key);

    /** All entries in a group (null group = all), ordered by key. */
    List<SysConfig> listByGroup(String group);

    /** Insert or update a config entry; evicts the Redis cache for the key. */
    SysConfig upsert(String key, Object value, String group, String remark, Long operatorUserId);

    /** Delete a config entry; evicts the Redis cache for the key. */
    void delete(String key);

    /** Typed string getter with default. */
    String getString(String key, String def);

    /** Typed boolean getter with default. */
    boolean getBool(String key, boolean def);

    /** Typed decimal getter with default. */
    BigDecimal getDecimal(String key, BigDecimal def);

    /** Typed long getter with default. */
    long getLong(String key, long def);
}
