package com.aigateway.modules.channel.controller;

import com.aigateway.common.api.PageResult;
import com.aigateway.common.api.R;
import com.aigateway.common.exception.BizException;
import com.aigateway.common.exception.ErrorCode;
import com.aigateway.common.security.UserContext;
import com.aigateway.modules.channel.dto.ChannelRequest;
import com.aigateway.modules.channel.dto.ChannelView;
import com.aigateway.modules.channel.dto.RechargeRequest;
import com.aigateway.modules.channel.dto.ReserveRequest;
import com.aigateway.modules.channel.entity.UpstreamRechargeLog;
import com.aigateway.modules.channel.entity.UpstreamReserve;
import com.aigateway.modules.channel.service.ChannelService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.math.BigDecimal;
import java.util.List;

/**
 * Platform/super-admin channel management. All endpoints require the super-admin role.
 * Api keys are encrypted on write and masked on read; plaintext is never returned.
 */
@RestController
@RequestMapping("/api/channel")
@RequiredArgsConstructor
public class ChannelController {

    private final ChannelService channelService;

    @PostMapping
    public R<ChannelView> create(@RequestBody @Valid ChannelRequest req) {
        requireSuperAdmin();
        return R.ok(channelService.create(req));
    }

    @GetMapping
    public R<PageResult<ChannelView>> page(@RequestParam(defaultValue = "1") long current,
                                           @RequestParam(defaultValue = "20") long size) {
        requireSuperAdmin();
        return R.ok(channelService.page(current, size));
    }

    @GetMapping("/{id}")
    public R<ChannelView> get(@PathVariable Long id) {
        requireSuperAdmin();
        return R.ok(channelService.get(id));
    }

    @PutMapping("/{id}")
    public R<ChannelView> update(@PathVariable Long id, @RequestBody ChannelRequest req) {
        requireSuperAdmin();
        return R.ok(channelService.update(id, req));
    }

    @DeleteMapping("/{id}")
    public R<Void> delete(@PathVariable Long id) {
        requireSuperAdmin();
        channelService.delete(id);
        return R.ok();
    }

    @PostMapping("/{id}/recharge")
    public R<ChannelView> recharge(@PathVariable Long id, @RequestBody @Valid RechargeRequest req) {
        requireSuperAdmin();
        return R.ok(channelService.recharge(id, req));
    }

    @GetMapping("/{id}/balance")
    public R<BigDecimal> balance(@PathVariable Long id) {
        requireSuperAdmin();
        return R.ok(channelService.balance(id));
    }

    @GetMapping("/{id}/reserve")
    public R<UpstreamReserve> getReserve(@PathVariable Long id) {
        requireSuperAdmin();
        return R.ok(channelService.getReserve(id));
    }

    @PutMapping("/{id}/reserve")
    public R<UpstreamReserve> updateReserve(@PathVariable Long id, @RequestBody ReserveRequest req) {
        requireSuperAdmin();
        return R.ok(channelService.updateReserve(id, req));
    }

    @GetMapping("/{id}/recharge-logs")
    public R<List<UpstreamRechargeLog>> rechargeLogs(@PathVariable Long id) {
        requireSuperAdmin();
        return R.ok(channelService.rechargeLogs(id));
    }

    private void requireSuperAdmin() {
        if (!UserContext.require().isSuperAdmin()) {
            throw new BizException(ErrorCode.FORBIDDEN);
        }
    }
}
