package com.aigateway.modules.payment.adapter;

import lombok.Data;

import java.math.BigDecimal;

/**
 * Normalized, signature-verified callback result. {@code success} is only true after
 * the adapter has verified the webhook signature and parsed a paid event.
 */
@Data
public class CallbackResult {

    private boolean success;

    private String orderNo;

    private String thirdTxnId;

    private BigDecimal amount;

    private String currency;
}
