package com.aigateway.modules.finance.service;

import com.aigateway.modules.finance.dto.ChargeResult;

/**
 * Pricing engine (design doc §10.4). Computes the customer charge from token
 * usage and the upstream cost, applying the resolved markup rule with a hard
 * minimum-margin floor. The gateway integrates against {@link #calc}.
 */
public interface PricingService {

    /**
     * Calculate cost and charge for a single request.
     *
     * @param modelCode        the model invoked
     * @param promptTokens     prompt tokens
     * @param completionTokens completion tokens
     * @param cachedTokens     cached (prompt-cache hit) tokens
     * @param companyId        the calling company (for company-scoped markup), may be null
     * @return the charge breakdown
     */
    ChargeResult calc(String modelCode, long promptTokens, long completionTokens,
                      long cachedTokens, Long companyId);

    /**
     * Calculate the customer charge from an already-computed upstream {@code cost}, applying the
     * SAME hard min-margin rule as {@link #calc}:
     * {@code charge = max(cost*(1+markupRate), cost*(1+minMargin)) + markupFixed}, never below cost.
     *
     * <p>Used for unit-based (non-token) endpoints (images / audio speech / transcriptions /
     * rerank) where the cost is derived from {@link com.aigateway.modules.model.entity.ModelVersion}
     * price fields x unit count rather than from token usage. The markup rule is resolved at the
     * global scope (and company scope when {@code companyId} is non-null) since no model code is
     * available here.</p>
     *
     * @param upstreamCost the computed upstream cost (must be &gt; 0)
     * @param companyId    the calling company (for company-scoped markup), may be null
     * @return the charge breakdown
     */
    ChargeResult calcByCost(java.math.BigDecimal upstreamCost, Long companyId);
}
