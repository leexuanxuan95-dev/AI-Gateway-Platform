package com.aigateway.modules.model.entity;

import com.aigateway.common.enums.ModelAvailability;
import com.aigateway.common.enums.ModelStatus;
import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.handlers.JacksonTypeHandler;
import lombok.Data;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.List;

/**
 * A concrete, customer-facing model version under a {@link ModelFamily}
 * (table {@code model_version}). Field names are part of the cross-module contract
 * (gateway + finance depend on them) and must not be renamed.
 *
 * <p>{@code priceInput/priceOutput/priceCached} are the customer prices (per 1M tokens);
 * {@code costInput/costOutput/costCached} are the upstream cost prices. A version with no
 * cost price is treated as not-yet-priced and is delisted by default.</p>
 */
@Data
@TableName(value = "model_version", autoResultMap = true)
public class ModelVersion {

    @TableId(type = IdType.AUTO)
    private Long id;

    private Long familyId;

    /** Unique public model code, e.g. {@code claude-opus-4-8}. */
    private String modelCode;

    private String displayName;

    private String tagline;

    @TableField(typeHandler = JacksonTypeHandler.class)
    private List<String> capabilities;

    private Integer contextWindow;

    private Integer maxOutput;

    /** Customer price per 1M input tokens. */
    private BigDecimal priceInput;

    /** Customer price per 1M output tokens. */
    private BigDecimal priceOutput;

    /** Customer price per 1M cached tokens. */
    private BigDecimal priceCached;

    /** Upstream cost per 1M input tokens. */
    private BigDecimal costInput;

    /** Upstream cost per 1M output tokens. */
    private BigDecimal costOutput;

    /** Upstream cost per 1M cached tokens. */
    private BigDecimal costCached;

    private String currency;

    /** 1 active, 2 maintenance, 3 disabled. */
    private ModelStatus status;

    /** available / maintenance / unavailable. */
    private ModelAvailability availability;

    private Integer sort;

    @TableField(fill = FieldFill.INSERT)
    private OffsetDateTime createdAt;

    @TableField(fill = FieldFill.INSERT_UPDATE)
    private OffsetDateTime updatedAt;
}
