package com.aigateway.modules.payment.adapter;

import com.aigateway.common.crypto.AesUtil;
import com.aigateway.modules.payment.entity.PayChannelConfig;

import java.util.Map;

/**
 * Shared base for the STUB payment adapters. Provides credential decryption and a
 * case-insensitive header lookup. Subclasses implement the channel-specific
 * create/verify/query shape with TODO markers for real SDK wiring.
 */
public abstract class AbstractStubAdapter implements PaymentAdapter {

    protected final AesUtil aesUtil;

    protected AbstractStubAdapter(AesUtil aesUtil) {
        this.aesUtil = aesUtil;
    }

    /** Decrypt a named credential value (never logged). */
    protected String cred(PayChannelConfig c, String key) {
        if (c == null || c.getCredentials() == null) {
            return null;
        }
        Object v = c.getCredentials().get(key);
        return v == null ? null : aesUtil.decrypt(v.toString());
    }

    protected String header(Map<String, String> headers, String name) {
        if (headers == null) {
            return null;
        }
        for (Map.Entry<String, String> e : headers.entrySet()) {
            if (e.getKey() != null && e.getKey().equalsIgnoreCase(name)) {
                return e.getValue();
            }
        }
        return null;
    }
}
