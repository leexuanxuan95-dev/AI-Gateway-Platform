package com.aigateway.modules.risk.consumer;

import com.aigateway.common.constant.KafkaTopics;
import lombok.extern.slf4j.Slf4j;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

/**
 * Consumes risk events (design doc §12). Risk events are emitted by the engine (e.g. a
 * token-spike trip) and by the gateway. This lean consumer records the event for the ops
 * dashboard; auto-mitigation (auto-blacklist/throttle) is left as a follow-up hook.
 */
@Slf4j
@Component
public class RiskEventConsumer {

    @KafkaListener(topics = KafkaTopics.RISK_EVENT, groupId = "ai-gateway-risk")
    public void onEvent(String payload) {
        // Best-effort: surface the anomaly. Persisting/auto-action is a future enhancement.
        log.warn("[risk-event] {}", payload);
    }
}
