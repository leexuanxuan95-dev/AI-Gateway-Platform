package com.aigateway.modules.payment.mapper;

import com.aigateway.modules.payment.entity.PayChannelConfig;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/** MyBatis-Plus mapper for {@link PayChannelConfig}. */
public interface PayChannelConfigMapper extends BaseMapper<PayChannelConfig> {
}
