package com.aigateway.modules.channel.dto;

import lombok.Data;

/**
 * A resolved upstream target for a single request, returned by
 * {@link com.aigateway.modules.channel.service.ChannelSelector#pick(String)}.
 * The {@code apiKey} here is DECRYPTED for immediate upstream use and must never be
 * logged or persisted.
 */
@Data
public class ChannelPick {

    private Long channelId;

    /** Id of the specific pool key used (null when falling back to the channel's legacy key). */
    private Long keyId;

    private String providerName;

    /** Provider-specific upstream model id to call. */
    private String upstreamModel;

    private String baseUrl;

    /** Decrypted upstream api key. Do not log. */
    private String apiKey;
}
