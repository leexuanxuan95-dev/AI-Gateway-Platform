package com.aigateway.modules.model.dto;

import com.aigateway.common.enums.CommonStatus;
import lombok.Data;

/** Create/update payload for a model family. */
@Data
public class ModelFamilyRequest {

    private String familyCode;
    private String familyName;
    private String icon;
    private Integer sort;
    private CommonStatus status;
}
