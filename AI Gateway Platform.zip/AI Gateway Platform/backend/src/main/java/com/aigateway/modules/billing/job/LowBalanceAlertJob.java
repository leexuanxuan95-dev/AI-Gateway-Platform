package com.aigateway.modules.billing.job;

import com.aigateway.common.constant.KafkaTopics;
import com.aigateway.modules.finance.entity.FinAccount;
import com.aigateway.modules.finance.mapper.FinAccountMapper;
import com.aigateway.modules.notify.dto.NotifyMessage;
import com.aigateway.modules.system.service.SysConfigService;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.aigateway.common.schedule.ManagedJob;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.Duration;
import java.util.List;

/**
 * Periodically scans company finance accounts and emits a low-balance notification
 * (design doc §11/§13) when {@code available_balance} drops below the configured threshold.
 * The threshold comes from {@code sys_config} ({@code billing.low_balance_threshold}); a
 * per-company Redis marker debounces alerts so we don't spam every cycle.
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class LowBalanceAlertJob implements ManagedJob {

    private static final String JOB_KEY = "low-balance-alert";
    private static final BigDecimal DEFAULT_THRESHOLD = new BigDecimal("10");
    private static final Duration ALERT_DEBOUNCE = Duration.ofHours(6);

    private final FinAccountMapper finAccountMapper;
    private final SysConfigService sysConfigService;
    private final KafkaTemplate<String, String> kafkaTemplate;
    private final StringRedisTemplate stringRedisTemplate;
    private final ObjectMapper objectMapper;

    @Override
    public String jobKey() {
        return JOB_KEY;
    }

    @Override
    public String defaultCron() {
        return "0 */10 * * * *";
    }

    @Override
    public String description() {
        return "Scan finance accounts and emit low-balance notifications every 10 minutes";
    }

    @Override
    public void execute() {
        BigDecimal threshold = sysConfigService.getDecimal("billing.low_balance_threshold", DEFAULT_THRESHOLD);
        try {
            List<FinAccount> low = finAccountMapper.selectList(
                    Wrappers.<FinAccount>lambdaQuery().le(FinAccount::getAvailableBalance, threshold));
            int alerted = 0;
            for (FinAccount acc : low) {
                if (shouldAlert(acc.getCompanyId())) {
                    emit(acc, threshold);
                    alerted++;
                }
            }
            if (alerted > 0) {
                log.info("[low-balance] alerted {} companies (threshold={})", alerted, threshold);
            }
        } catch (Exception e) {
            log.warn("low-balance scan failed: {}", e.getMessage());
        }
    }

    /** Debounce per company via a Redis marker with TTL. */
    private boolean shouldAlert(Long companyId) {
        if (companyId == null) {
            return false;
        }
        try {
            String key = "gw:alert:lowbal:" + companyId;
            Boolean set = stringRedisTemplate.opsForValue().setIfAbsent(key, "1", ALERT_DEBOUNCE);
            return Boolean.TRUE.equals(set);
        } catch (Exception e) {
            // fail-open: better to alert than to silently drop on a cache hiccup
            return true;
        }
    }

    private void emit(FinAccount acc, BigDecimal threshold) {
        try {
            NotifyMessage msg = new NotifyMessage();
            msg.setCompanyId(acc.getCompanyId());
            msg.setChannel("email");
            msg.setScene("low_balance");
            msg.setTarget("company:" + acc.getCompanyId());
            msg.setContent("Available balance " + acc.getAvailableBalance()
                    + " is at/below threshold " + threshold + ". Please recharge.");
            kafkaTemplate.send(KafkaTopics.NOTIFY, String.valueOf(acc.getCompanyId()),
                    objectMapper.writeValueAsString(msg));
        } catch (Exception e) {
            log.warn("emit low-balance notify failed for company {}: {}", acc.getCompanyId(), e.getMessage());
        }
    }
}
