package com.aigateway.modules.channel.entity;

import com.aigateway.common.enums.ChannelHealth;
import com.aigateway.common.enums.CommonStatus;
import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.math.BigDecimal;
import java.time.OffsetDateTime;

/**
 * Upstream channel (provider account / key pool slot), table {@code channel}.
 * The {@code apiKey} column stores the AES-encrypted upstream key; it is decrypted
 * only when calling upstream and is never logged or returned to clients.
 */
@Data
@TableName(value = "channel", autoResultMap = true)
public class Channel {

    @TableId(type = IdType.AUTO)
    private Long id;

    /** Provider name: openai / anthropic / gemini / deepseek / openrouter ... */
    private String providerName;

    private String channelName;

    /** Model family this channel primarily serves (optional). */
    private Long familyId;

    /** AES-256 encrypted upstream api key. NEVER store or return plaintext. */
    private String apiKey;

    private String baseUrl;

    private String orgId;

    /** Total recharged credit. */
    private BigDecimal quota;

    /** Accumulated upstream cost. */
    private BigDecimal usedQuota;

    private Integer weight;

    private Integer priority;

    /** 1 healthy, 0 broken. */
    private ChannelHealth health;

    /** Low-balance alert threshold. */
    private BigDecimal lowThreshold;

    /** 1 enabled, other = disabled. */
    private CommonStatus status;

    @TableField(fill = FieldFill.INSERT)
    private OffsetDateTime createdAt;

    @TableField(fill = FieldFill.INSERT_UPDATE)
    private OffsetDateTime updatedAt;
}
