package com.aigateway.modules.gateway.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/** Token usage extracted from (or estimated for) an upstream response. */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class TokenUsage {

    private long promptTokens;
    private long completionTokens;
    private long cachedTokens;

    public long total() {
        return promptTokens + completionTokens + cachedTokens;
    }
}
