package com.aigateway.modules.channel.entity;

import com.aigateway.common.enums.ChannelKeyStatus;
import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.time.OffsetDateTime;

/**
 * One upstream provider API key inside a channel's key pool (table {@code channel_api_key}).
 * A channel can hold many keys so dead/banned keys can be replenished without redeploy.
 * The {@code apiKey} column stores the AES-encrypted upstream key; it is decrypted only when
 * calling upstream and is never logged or returned to clients.
 */
@Data
@TableName(value = "channel_api_key", autoResultMap = true)
public class ChannelApiKey {

    @TableId(type = IdType.AUTO)
    private Long id;

    /** Owning channel id. */
    private Long channelId;

    /** Human-friendly label for this key (optional). */
    private String keyAlias;

    /** AES-256 encrypted upstream api key. NEVER store or return plaintext. */
    private String apiKey;

    /** 1 active, 2 banned, 3 disabled. */
    private ChannelKeyStatus status;

    /** Why the key was banned (set when status=2). */
    private String banReason;

    /** Weighted-random selection weight (min 1). */
    private Integer weight;

    /** Consecutive/observed failure count; bans the key once it crosses the threshold. */
    private Integer failCount;

    /** Total number of times this key was picked for an upstream call. */
    private Long usedCount;

    private OffsetDateTime lastUsedAt;

    private OffsetDateTime bannedAt;

    @TableField(fill = FieldFill.INSERT)
    private OffsetDateTime createdAt;
}
