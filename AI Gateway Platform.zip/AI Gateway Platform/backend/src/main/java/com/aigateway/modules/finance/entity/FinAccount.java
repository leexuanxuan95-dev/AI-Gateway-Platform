package com.aigateway.modules.finance.entity;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.Version;
import lombok.Data;

import java.math.BigDecimal;
import java.time.OffsetDateTime;

/** Company finance account (table {@code fin_account}, design doc §10). */
@Data
@TableName(value = "fin_account", autoResultMap = true)
public class FinAccount {

    @TableId(type = IdType.AUTO)
    private Long id;

    private Long companyId;

    private BigDecimal availableBalance;

    private BigDecimal freezeBalance;

    private BigDecimal totalRecharge;

    private BigDecimal totalConsume;

    private String currency;

    /** Optimistic-lock version. */
    @Version
    private Long version;

    @TableField(fill = FieldFill.INSERT_UPDATE)
    private OffsetDateTime updatedAt;
}
