package com.aigateway.modules.company.mapper;

import com.aigateway.modules.company.entity.CompanyInvite;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/** MyBatis-Plus mapper for {@link CompanyInvite}. */
public interface CompanyInviteMapper extends BaseMapper<CompanyInvite> {
}
