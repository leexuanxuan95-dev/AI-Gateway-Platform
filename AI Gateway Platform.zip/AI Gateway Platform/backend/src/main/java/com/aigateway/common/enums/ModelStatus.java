package com.aigateway.common.enums;

import com.baomidou.mybatisplus.annotation.EnumValue;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;

/** model_version.status. */
@Getter
public enum ModelStatus implements CodedEnum<Integer> {

    ACTIVE(1),
    MAINTENANCE(2),
    DISABLED(3);

    @EnumValue
    @JsonValue
    private final Integer code;

    ModelStatus(Integer code) {
        this.code = code;
    }

    @JsonCreator
    public static ModelStatus of(Integer code) {
        if (code == null) {
            return null;
        }
        for (ModelStatus v : values()) {
            if (v.code.equals(code)) {
                return v;
            }
        }
        return null;
    }
}
