package com.aigateway.modules.finance.entity;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.aigateway.common.enums.RechargeStatus;
import com.baomidou.mybatisplus.extension.handlers.JacksonTypeHandler;
import lombok.Data;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.Map;

/** Recharge order (table {@code fin_recharge_order}, design doc §10). */
@Data
@TableName(value = "fin_recharge_order", autoResultMap = true)
public class FinRechargeOrder {

    @TableId(type = IdType.AUTO)
    private Long id;

    private String orderNo;

    private Long companyId;

    private Long userId;

    private BigDecimal amount;

    private String currency;

    /** stripe/alipay/wechat/usdt_trc20/usdt_erc20/wise. */
    private String payChannel;

    /** card/wallet/crypto/bank. */
    private String payMethod;

    /** 0 pending / 1 paid / 2 cancelled / 3 expired / 4 refunded. */
    private RechargeStatus status;

    private String thirdTxnId;

    private OffsetDateTime paidAt;

    private OffsetDateTime expireAt;

    @TableField(typeHandler = JacksonTypeHandler.class)
    private Map<String, Object> rawCallback;

    @TableField(fill = FieldFill.INSERT)
    private OffsetDateTime createdAt;
}
