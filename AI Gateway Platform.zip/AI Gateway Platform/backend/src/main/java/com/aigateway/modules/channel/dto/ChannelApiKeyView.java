package com.aigateway.modules.channel.dto;

import com.aigateway.common.enums.ChannelKeyStatus;
import lombok.Data;

import java.time.OffsetDateTime;

/**
 * Channel pool-key projection for responses. The full/decrypted key is NEVER returned;
 * only a masked hint (e.g. {@code sk-abc***xyz}) is exposed.
 */
@Data
public class ChannelApiKeyView {

    private Long id;
    private Long channelId;
    private String keyAlias;
    /** Masked key hint, e.g. {@code sk-abc***xyz}. Never the plaintext. */
    private String keyMasked;
    /** 1 active, 2 banned, 3 disabled. */
    private ChannelKeyStatus status;
    private String banReason;
    private Integer weight;
    private Integer failCount;
    private Long usedCount;
    private OffsetDateTime lastUsedAt;
    private OffsetDateTime bannedAt;
    private OffsetDateTime createdAt;
}
