package com.aigateway.common.security;

import java.util.Map;
import java.util.Set;

/**
 * Static role &rarr; permission-point mapping per design doc §2.2 permission matrix.
 * Company-scoped roles only; the platform super-admin bypasses checks entirely.
 *
 * <p>Permission point naming: {@code <domain>:<action>}.</p>
 */
public final class RolePermissions {

    private RolePermissions() {
    }

    // ---- permission points ----
    public static final String COMPANY_MEMBER_MANAGE = "company:member:manage";
    public static final String APIKEY_MANAGE = "apikey:manage";
    public static final String APIKEY_READ = "apikey:read";
    public static final String RECHARGE = "finance:recharge";
    public static final String WITHDRAW_APPLY = "finance:withdraw";
    public static final String BILLING_READ = "billing:read";
    public static final String BILLING_READ_SELF = "billing:read:self";
    public static final String PROJECT_MANAGE = "project:manage";
    public static final String PROJECT_READ = "project:read";
    public static final String MODEL_SELECT = "model:select";
    public static final String CALL_API = "api:call";
    public static final String COMPANY_SETTINGS = "company:settings";
    /** Platform scheduled-job management — granted to no company role, so only the super-admin
     *  (who bypasses permission checks) may use it. */
    public static final String SCHED_MANAGE = "platform:schedule:manage";

    private static final Set<String> OWNER = Set.of(
            COMPANY_MEMBER_MANAGE, APIKEY_MANAGE, APIKEY_READ, RECHARGE, WITHDRAW_APPLY,
            BILLING_READ, PROJECT_MANAGE, PROJECT_READ, MODEL_SELECT, CALL_API, COMPANY_SETTINGS);

    private static final Set<String> ADMIN = Set.of(
            COMPANY_MEMBER_MANAGE, APIKEY_MANAGE, APIKEY_READ, RECHARGE,
            BILLING_READ, PROJECT_MANAGE, PROJECT_READ, MODEL_SELECT, CALL_API, COMPANY_SETTINGS);

    private static final Set<String> DEVELOPER = Set.of(
            APIKEY_MANAGE, APIKEY_READ, PROJECT_READ, MODEL_SELECT, CALL_API, BILLING_READ_SELF);

    private static final Set<String> VIEWER = Set.of(
            APIKEY_READ, PROJECT_READ, BILLING_READ);

    private static final Map<String, Set<String>> BY_ROLE = Map.of(
            "OWNER", OWNER,
            "ADMIN", ADMIN,
            "DEVELOPER", DEVELOPER,
            "VIEWER", VIEWER);

    public static Set<String> forRole(String role) {
        if (role == null) {
            return Set.of();
        }
        return BY_ROLE.getOrDefault(role.toUpperCase(), Set.of());
    }
}
