package com.aigateway.modules.gateway.controller;

import com.aigateway.modules.gateway.service.GatewayProxyService;
import com.aigateway.modules.gateway.service.GatewayRequestSupport;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

/**
 * OpenAI-compatible {@code POST /v1/embeddings} (design doc §20). Billed from
 * {@code usage.prompt_tokens} in the upstream response.
 */
@RestController
@RequiredArgsConstructor
public class EmbeddingsController {

    private static final String PATH = "/v1/embeddings";

    private final GatewayProxyService proxy;
    private final GatewayRequestSupport support;

    @PostMapping(PATH)
    public String embeddings(@RequestBody Map<String, Object> body,
                             HttpServletRequest req,
                             HttpServletResponse resp) {
        String model = support.resolveModel(body.get("model"));
        Long projectId = support.resolveProjectId(req);
        long estPrompt = proxy.estimatePromptTokens(body);
        return proxy.proxyAndBill(PATH, body, model, projectId, estPrompt, 0, resp);
    }
}
