package com.aigateway.modules.payment.dto;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.math.BigDecimal;

/** Recharge create request (design doc §10.2). */
@Data
public class CreatePayRequest {

    /** Payment channel code (stripe/alipay/...). */
    @NotBlank
    private String channel;

    @NotNull
    @DecimalMin(value = "0.01", message = "amount must be at least 0.01")
    private BigDecimal amount;

    @NotBlank
    private String currency;

    /** card/wallet/crypto/bank. */
    private String payMethod;
}
