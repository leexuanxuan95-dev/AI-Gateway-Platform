package com.aigateway.modules.risk.controller;

import com.aigateway.common.api.R;
import com.aigateway.common.exception.BizException;
import com.aigateway.common.exception.ErrorCode;
import com.aigateway.common.security.UserContext;
import com.aigateway.modules.risk.dto.BlacklistRequest;
import com.aigateway.modules.risk.entity.RiskBlacklist;
import com.aigateway.modules.risk.entity.RiskRule;
import com.aigateway.modules.risk.service.RiskService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * Risk control admin surface (design doc §12). Super-admin only: manage detection rules
 * and the ip/country/user blacklist that the gateway filter enforces.
 */
@RestController
@RequestMapping("/api/risk")
@RequiredArgsConstructor
public class RiskController {

    private final RiskService riskService;

    // ---- rules ----

    /** List all risk detection rules. */
    @GetMapping("/rules")
    public R<List<RiskRule>> listRules() {
        requireSuperAdmin();
        return R.ok(riskService.listRules());
    }

    /** Create or update a risk detection rule. */
    @PostMapping("/rules")
    public R<RiskRule> saveRule(@RequestBody RiskRule rule) {
        requireSuperAdmin();
        return R.ok(riskService.saveRule(rule));
    }

    /** Delete a risk detection rule by id. */
    @DeleteMapping("/rules/{id}")
    public R<Void> deleteRule(@PathVariable Long id) {
        requireSuperAdmin();
        riskService.deleteRule(id);
        return R.ok();
    }

    // ---- blacklist ----

    /** List blacklist entries, optionally filtered by type (ip / country / user). */
    @GetMapping("/blacklist")
    public R<List<RiskBlacklist>> listBlacklist(@RequestParam(required = false) String type) {
        requireSuperAdmin();
        return R.ok(riskService.listBlacklist(type));
    }

    /** Add a blacklist entry from the request payload. */
    @PostMapping("/blacklist")
    public R<RiskBlacklist> addBlacklist(@RequestBody @Valid BlacklistRequest req) {
        requireSuperAdmin();
        RiskBlacklist entry = new RiskBlacklist();
        entry.setType(req.getType());
        entry.setValue(req.getValue());
        entry.setReason(req.getReason());
        entry.setExpireAt(req.getExpireAt());
        return R.ok(riskService.addBlacklist(entry));
    }

    /** Remove a blacklist entry by id. */
    @DeleteMapping("/blacklist/{id}")
    public R<Void> removeBlacklist(@PathVariable Long id) {
        requireSuperAdmin();
        riskService.removeBlacklist(id);
        return R.ok();
    }

    private void requireSuperAdmin() {
        if (!UserContext.require().isSuperAdmin()) {
            throw new BizException(ErrorCode.FORBIDDEN);
        }
    }
}
