package com.aigateway.modules.risk.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.aigateway.common.enums.CommonStatus;
import com.baomidou.mybatisplus.extension.handlers.JacksonTypeHandler;
import lombok.Data;

import java.util.Map;

/**
 * Risk detection rule (table {@code risk_rule}, design doc §12). The {@code threshold}
 * JSONB holds rule-specific parameters (e.g. {@code {"tokens":1000000,"windowSec":60}}).
 */
@Data
@TableName(value = "risk_rule", autoResultMap = true)
public class RiskRule {

    @TableId(type = IdType.AUTO)
    private Long id;

    /** token_spike / high_freq / proxy_ip. */
    private String ruleType;

    @TableField(typeHandler = JacksonTypeHandler.class)
    private Map<String, Object> threshold;

    /** alert / throttle / ban. */
    private String action;

    /** 1 enabled, 0 disabled. */
    private CommonStatus status;
}
