package com.aigateway.modules.site.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

/** Result of generating a preview: an opaque token and the relative preview URL. */
@Data
@AllArgsConstructor
public class PreviewResp {

    private String previewToken;

    private String url;
}
