package com.aigateway.modules.site.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

/**
 * A single FAQ entry for the landing page (table {@code site_faq}, OmniRoute doc §4.2).
 * Kept in its own table for easy add / sort / enable.
 */
@Data
@TableName(value = "site_faq", autoResultMap = true)
public class SiteFaq {

    @TableId(type = IdType.AUTO)
    private Long id;

    /** Content language: {@code zh} / {@code en}. */
    private String lang;

    private String question;

    private String answer;

    private Integer sort;

    private Boolean enabled;
}
