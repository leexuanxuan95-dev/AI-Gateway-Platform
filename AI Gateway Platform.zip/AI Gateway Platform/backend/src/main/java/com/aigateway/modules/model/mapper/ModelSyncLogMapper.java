package com.aigateway.modules.model.mapper;

import com.aigateway.modules.model.entity.ModelSyncLog;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/** MyBatis-Plus mapper for {@link ModelSyncLog}. */
public interface ModelSyncLogMapper extends BaseMapper<ModelSyncLog> {
}
