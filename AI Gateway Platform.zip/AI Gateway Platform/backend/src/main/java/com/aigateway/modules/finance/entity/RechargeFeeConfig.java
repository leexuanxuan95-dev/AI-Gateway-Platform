package com.aigateway.modules.finance.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.math.BigDecimal;

/** Recharge fee configuration (table {@code recharge_fee_config}, design doc §10.4). */
@Data
@TableName(value = "recharge_fee_config", autoResultMap = true)
public class RechargeFeeConfig {

    @TableId(type = IdType.AUTO)
    private Long id;

    /** global / plan / company. */
    private String scope;

    private String scopeRef;

    private BigDecimal feeRate;

    private Boolean enabled;
}
