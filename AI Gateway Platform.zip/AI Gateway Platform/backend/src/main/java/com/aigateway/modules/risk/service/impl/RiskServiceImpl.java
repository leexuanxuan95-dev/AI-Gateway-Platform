package com.aigateway.modules.risk.service.impl;

import com.aigateway.common.constant.KafkaTopics;
import com.aigateway.common.enums.CommonStatus;
import com.aigateway.modules.risk.entity.RiskBlacklist;
import com.aigateway.modules.risk.entity.RiskRule;
import com.aigateway.modules.risk.mapper.RiskBlacklistMapper;
import com.aigateway.modules.risk.mapper.RiskRuleMapper;
import com.aigateway.modules.risk.service.GeoIpService;
import com.aigateway.modules.risk.service.RiskService;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.time.OffsetDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Default {@link RiskService}. Blacklist lookups hit the DB (small table, indexed on
 * type+value) and honor {@code expireAt}; rate-limit and token-spike state lives in Redis
 * as short-TTL fixed-window counters. All Redis paths fail open so a cache outage never
 * blocks legitimate traffic.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class RiskServiceImpl implements RiskService {

    private static final String TOKEN_WINDOW_PREFIX = "gw:risk:tok:";
    /** Default token-spike threshold per company per minute when no rule configured. */
    private static final long DEFAULT_TOKEN_SPIKE = 5_000_000L;
    private static final Duration SPIKE_WINDOW = Duration.ofMinutes(1);

    /** Per-key high-frequency window counter prefix. */
    private static final String FREQ_PREFIX = "gw:risk:freq:";
    /** Per-key temporary RPM throttle override prefix (set by a throttle action). */
    private static final String THROTTLE_PREFIX = "gw:risk:throttle:";
    private static final int DEFAULT_HIGH_FREQ = 600;
    private static final int DEFAULT_FREQ_WINDOW_SEC = 60;
    private static final int DEFAULT_THROTTLE_RPM = 10;
    private static final int DEFAULT_THROTTLE_SEC = 300;
    private static final int DEFAULT_BAN_SEC = 3600;
    /** Fixed initial capacity for the 4-entry token-spike event map (size/0.75 + 1). */
    private static final int SPIKE_MSG_CAPACITY = 6;
    /** Fixed initial capacity for the 7-entry notify message map (size/0.75 + 1). */
    private static final int NOTIFY_MSG_CAPACITY = 10;

    private final RiskBlacklistMapper riskBlacklistMapper;
    private final RiskRuleMapper riskRuleMapper;
    private final StringRedisTemplate stringRedisTemplate;
    private final KafkaTemplate<String, String> kafkaTemplate;
    private final ObjectMapper objectMapper;
    private final GeoIpService geoIpService;

    @Override
    public boolean isBlocked(String ip, String country, Long companyId) {
        if (ip != null && !ip.isBlank() && matches("ip", ip)) {
            return true;
        }
        if (country != null && !country.isBlank() && matches("country", country)) {
            return true;
        }
        return companyId != null && matches("user", String.valueOf(companyId));
    }

    /** True if an active (non-expired) blacklist row exists for the dimension/value. */
    private boolean matches(String type, String value) {
        List<RiskBlacklist> rows = riskBlacklistMapper.selectList(
                Wrappers.<RiskBlacklist>lambdaQuery()
                        .eq(RiskBlacklist::getType, type)
                        .eq(RiskBlacklist::getValue, value));
        OffsetDateTime now = OffsetDateTime.now();
        for (RiskBlacklist r : rows) {
            if (r.getExpireAt() == null || r.getExpireAt().isAfter(now)) {
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean allow(String dimension, String value, int limit, int windowSeconds) {
        if (value == null || value.isBlank() || limit <= 0) {
            return true;
        }
        String key = "gw:risk:rl:" + dimension + ":" + value;
        try {
            Long count = stringRedisTemplate.opsForValue().increment(key);
            if (count != null && count == 1L) {
                stringRedisTemplate.expire(key, Duration.ofSeconds(windowSeconds));
            }
            return count == null || count <= limit;
        } catch (Exception e) {
            log.warn("risk rate-limit check failed for {}:{} - {}", dimension, value, e.getMessage());
            return true;
        }
    }

    @Override
    public boolean recordTokensAndCheckSpike(Long companyId, long tokens) {
        if (companyId == null || tokens <= 0) {
            return false;
        }
        long threshold = resolveTokenSpikeThreshold();
        String key = TOKEN_WINDOW_PREFIX + companyId;
        try {
            Long total = stringRedisTemplate.opsForValue().increment(key, tokens);
            if (total != null && total == tokens) {
                stringRedisTemplate.expire(key, SPIKE_WINDOW);
            }
            if (total != null && total > threshold) {
                emitSpike(companyId, total, threshold);
                return true;
            }
        } catch (Exception e) {
            log.warn("token-spike check failed for company {}: {}", companyId, e.getMessage());
        }
        return false;
    }

    private long resolveTokenSpikeThreshold() {
        try {
            RiskRule rule = riskRuleMapper.selectOne(Wrappers.<RiskRule>lambdaQuery()
                    .eq(RiskRule::getRuleType, "token_spike")
                    .eq(RiskRule::getStatus, CommonStatus.ENABLED)
                    .last("limit 1"));
            if (rule != null && rule.getThreshold() != null) {
                Object t = rule.getThreshold().get("tokens");
                if (t != null) {
                    return Long.parseLong(String.valueOf(t));
                }
            }
        } catch (Exception e) {
            log.debug("resolve token-spike threshold failed: {}", e.getMessage());
        }
        return DEFAULT_TOKEN_SPIKE;
    }

    private void emitSpike(Long companyId, long total, long threshold) {
        try {
            Map<String, Object> msg = new HashMap<>(SPIKE_MSG_CAPACITY);
            msg.put("type", "token_spike");
            msg.put("companyId", companyId);
            msg.put("windowTokens", total);
            msg.put("threshold", threshold);
            kafkaTemplate.send(KafkaTopics.RISK_EVENT, String.valueOf(companyId),
                    objectMapper.writeValueAsString(msg));
            log.warn("token-spike detected company={} window={} threshold={}", companyId, total, threshold);
        } catch (Exception e) {
            log.warn("emit risk event failed: {}", e.getMessage());
        }
    }

    @Override
    public String resolveCountry(String ip) {
        try {
            String c = geoIpService.countryOf(ip);
            return c == null ? GeoIpService.UNKNOWN : c;
        } catch (Exception e) {
            log.debug("country resolve failed for {}: {}", ip, e.getMessage());
            return GeoIpService.UNKNOWN;
        }
    }

    @Override
    public int effectiveRpm(Long apiKeyId, int configuredRpm) {
        if (apiKeyId == null) {
            return configuredRpm;
        }
        try {
            String v = stringRedisTemplate.opsForValue().get(THROTTLE_PREFIX + apiKeyId);
            if (v != null) {
                int throttled = Integer.parseInt(v.trim());
                // honor whichever is stricter, but never below 0
                return Math.max(0, Math.min(configuredRpm, throttled));
            }
        } catch (Exception e) {
            log.debug("effectiveRpm read failed for key {}: {}", apiKeyId, e.getMessage());
        }
        return configuredRpm;
    }

    @Override
    public void evaluateAfterCall(Long companyId, Long apiKeyId, String ip, String country, long tokens) {
        List<RiskRule> rules;
        try {
            rules = riskRuleMapper.selectList(Wrappers.<RiskRule>lambdaQuery()
                    .eq(RiskRule::getStatus, CommonStatus.ENABLED));
        } catch (Exception e) {
            log.debug("risk rule load failed: {}", e.getMessage());
            return;
        }
        if (rules == null || rules.isEmpty()) {
            return;
        }
        for (RiskRule rule : rules) {
            try {
                if (matchesRule(rule, companyId, apiKeyId, ip, country, tokens)) {
                    applyAction(rule, companyId, apiKeyId, ip);
                }
            } catch (Exception e) {
                log.debug("risk rule eval failed (rule {}): {}", rule.getId(), e.getMessage());
            }
        }
    }

    /** Cheap, defensive per-rule predicate. Unknown rule types never match. */
    private boolean matchesRule(RiskRule rule, Long companyId, Long apiKeyId,
                                String ip, String country, long tokens) {
        String type = rule.getRuleType();
        if (type == null) {
            return false;
        }
        Map<String, Object> th = rule.getThreshold();
        switch (type) {
            case "token_spike":
                long tokenLimit = readLong(th, "tokens", DEFAULT_TOKEN_SPIKE);
                return tokens > 0 && tokens >= tokenLimit;
            case "high_freq": {
                if (apiKeyId == null) {
                    return false;
                }
                int limit = (int) readLong(th, "count", DEFAULT_HIGH_FREQ);
                int window = (int) readLong(th, "windowSec", DEFAULT_FREQ_WINDOW_SEC);
                long count = incrWindow(FREQ_PREFIX + apiKeyId, window);
                return count > limit;
            }
            case "proxy_ip":
            case "datacenter_ip":
                // Heuristic: an unknown / unresolved country on a public IP is treated as a
                // proxy/datacenter signal. A real provider flag would refine this.
                return ip != null && !ip.isBlank()
                        && (country == null || country.isBlank() || GeoIpService.UNKNOWN.equals(country));
            default:
                return false;
        }
    }

    /** Apply alert / throttle / ban for a tripped rule. */
    private void applyAction(RiskRule rule, Long companyId, Long apiKeyId, String ip) {
        String action = rule.getAction() == null ? "alert" : rule.getAction();
        switch (action) {
            case "throttle":
                throttleKey(apiKeyId, rule);
                notify("risk.throttle", rule, companyId, apiKeyId, ip);
                break;
            case "ban":
                ban(companyId, ip, rule);
                notify("risk.ban", rule, companyId, apiKeyId, ip);
                break;
            case "alert":
            default:
                notify("risk.alert", rule, companyId, apiKeyId, ip);
                break;
        }
    }

    /** Temporarily tighten a key's RPM by writing a throttle override read by the gateway filter. */
    private void throttleKey(Long apiKeyId, RiskRule rule) {
        if (apiKeyId == null) {
            return;
        }
        int rpm = (int) readLong(rule.getThreshold(), "throttleRpm", DEFAULT_THROTTLE_RPM);
        int sec = (int) readLong(rule.getThreshold(), "throttleSec", DEFAULT_THROTTLE_SEC);
        try {
            stringRedisTemplate.opsForValue().set(THROTTLE_PREFIX + apiKeyId,
                    String.valueOf(rpm), Duration.ofSeconds(sec));
            log.warn("risk throttle applied key={} rpm={} ttl={}s", apiKeyId, rpm, sec);
        } catch (Exception e) {
            log.debug("throttle write failed for key {}: {}", apiKeyId, e.getMessage());
        }
    }

    /** Insert an expiring blacklist row for the offending ip and/or company (user). */
    private void ban(Long companyId, String ip, RiskRule rule) {
        int sec = (int) readLong(rule.getThreshold(), "banSec", DEFAULT_BAN_SEC);
        OffsetDateTime expire = OffsetDateTime.now().plusSeconds(sec);
        String reason = "auto-ban: rule " + rule.getRuleType();
        if (ip != null && !ip.isBlank()) {
            insertBlacklist("ip", ip, reason, expire);
        }
        if (companyId != null) {
            insertBlacklist("user", String.valueOf(companyId), reason, expire);
        }
    }

    private void insertBlacklist(String type, String value, String reason, OffsetDateTime expire) {
        try {
            RiskBlacklist row = new RiskBlacklist();
            row.setType(type);
            row.setValue(value);
            row.setReason(reason);
            row.setExpireAt(expire);
            riskBlacklistMapper.insert(row);
            log.warn("risk auto-ban inserted type={} value={} expire={}", type, value, expire);
        } catch (Exception e) {
            log.debug("auto-ban insert failed type={} value={}: {}", type, value, e.getMessage());
        }
    }

    /** Emit a NOTIFY message for the ops/notification pipeline. */
    private void notify(String event, RiskRule rule, Long companyId, Long apiKeyId, String ip) {
        try {
            Map<String, Object> msg = new HashMap<>(NOTIFY_MSG_CAPACITY);
            msg.put("type", event);
            msg.put("ruleId", rule.getId());
            msg.put("ruleType", rule.getRuleType());
            msg.put("action", rule.getAction());
            msg.put("companyId", companyId);
            msg.put("apiKeyId", apiKeyId);
            msg.put("ip", ip);
            String json = objectMapper.writeValueAsString(msg);
            kafkaTemplate.send(KafkaTopics.NOTIFY, String.valueOf(companyId), json);
        } catch (Exception e) {
            log.debug("risk notify emit failed: {}", e.getMessage());
        }
    }

    /** Fixed-window INCR helper that returns the post-increment count (1 on first hit). */
    private long incrWindow(String key, int windowSeconds) {
        Long count = stringRedisTemplate.opsForValue().increment(key);
        if (count != null && count == 1L) {
            stringRedisTemplate.expire(key, Duration.ofSeconds(Math.max(1, windowSeconds)));
        }
        return count == null ? 0L : count;
    }

    private long readLong(Map<String, Object> map, String field, long def) {
        if (map == null) {
            return def;
        }
        Object v = map.get(field);
        if (v == null) {
            return def;
        }
        try {
            return Long.parseLong(String.valueOf(v).trim());
        } catch (NumberFormatException e) {
            return def;
        }
    }

    @Override
    public List<RiskRule> listRules() {
        return riskRuleMapper.selectList(Wrappers.<RiskRule>lambdaQuery().orderByDesc(RiskRule::getId));
    }

    @Override
    public RiskRule saveRule(RiskRule rule) {
        if (rule.getId() == null) {
            riskRuleMapper.insert(rule);
        } else {
            riskRuleMapper.updateById(rule);
        }
        return riskRuleMapper.selectById(rule.getId());
    }

    @Override
    public void deleteRule(Long id) {
        riskRuleMapper.deleteById(id);
    }

    @Override
    public List<RiskBlacklist> listBlacklist(String type) {
        return riskBlacklistMapper.selectList(Wrappers.<RiskBlacklist>lambdaQuery()
                .eq(type != null && !type.isBlank(), RiskBlacklist::getType, type)
                .orderByDesc(RiskBlacklist::getId));
    }

    @Override
    public RiskBlacklist addBlacklist(RiskBlacklist entry) {
        riskBlacklistMapper.insert(entry);
        return riskBlacklistMapper.selectById(entry.getId());
    }

    @Override
    public void removeBlacklist(Long id) {
        riskBlacklistMapper.deleteById(id);
    }
}
