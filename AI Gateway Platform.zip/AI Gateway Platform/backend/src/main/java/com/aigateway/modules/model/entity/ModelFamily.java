package com.aigateway.modules.model.entity;

import com.aigateway.common.enums.CommonStatus;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

/** Model family (table {@code model_family}), e.g. claude / gpt / gemini. */
@Data
@TableName(value = "model_family", autoResultMap = true)
public class ModelFamily {

    @TableId(type = IdType.AUTO)
    private Long id;

    /** Unique family code: claude / gpt / gemini ... */
    private String familyCode;

    private String familyName;

    private String icon;

    private Integer sort;

    /** 1 active. */
    private CommonStatus status;
}
