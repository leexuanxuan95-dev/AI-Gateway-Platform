package com.aigateway.modules.project.controller;

import com.aigateway.common.api.PageResult;
import com.aigateway.common.api.R;
import com.aigateway.common.security.RequirePerm;
import com.aigateway.common.security.RolePermissions;
import com.aigateway.modules.project.dto.ProjectRequest;
import com.aigateway.modules.project.entity.Project;
import com.aigateway.modules.project.service.ProjectService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/** Company-scoped project CRUD endpoints. */
@RestController
@RequestMapping("/api/project")
@RequiredArgsConstructor
public class ProjectController {

    private final ProjectService projectService;

    @PostMapping
    @RequirePerm(RolePermissions.PROJECT_MANAGE)
    public R<Project> create(@RequestBody @Valid ProjectRequest req) {
        return R.ok(projectService.create(req));
    }

    @GetMapping
    @RequirePerm(RolePermissions.PROJECT_READ)
    public R<PageResult<Project>> page(@RequestParam(defaultValue = "1") long current,
                                       @RequestParam(defaultValue = "20") long size) {
        return R.ok(projectService.page(current, size));
    }

    @GetMapping("/{id}")
    @RequirePerm(RolePermissions.PROJECT_READ)
    public R<Project> get(@PathVariable Long id) {
        return R.ok(projectService.get(id));
    }

    @PutMapping("/{id}")
    @RequirePerm(RolePermissions.PROJECT_MANAGE)
    public R<Project> update(@PathVariable Long id, @RequestBody ProjectRequest req) {
        return R.ok(projectService.update(id, req));
    }

    @DeleteMapping("/{id}")
    @RequirePerm(RolePermissions.PROJECT_MANAGE)
    public R<Void> delete(@PathVariable Long id) {
        projectService.delete(id);
        return R.ok();
    }
}
