package com.aigateway.modules.payment.service;

import com.aigateway.modules.payment.dto.ChannelOption;
import com.aigateway.modules.payment.entity.PayChannelConfig;

import java.math.BigDecimal;
import java.util.List;

/** Payment channel config center (design doc §10.2.1). */
public interface PayChannelConfigService {

    /** List all channel configs with secrets masked (super-admin). */
    List<PayChannelConfig> listMasked();

    /** Create a config (encrypts credential values, generates callback_url). */
    PayChannelConfig create(PayChannelConfig cfg, Long operatorId);

    /** Update a config (re-encrypts any plaintext credential values). */
    PayChannelConfig update(Long id, PayChannelConfig cfg, Long operatorId);

    /** Enable/disable a channel. */
    PayChannelConfig setEnabled(Long id, boolean enabled, Long operatorId);

    /** Load a config (decrypted credentials) by code, using the Redis cache. */
    PayChannelConfig getByCode(String code);

    /** Public: enabled channels matching the amount/currency filter. */
    List<ChannelOption> publicChannels(BigDecimal amount, String currency);
}
