package com.aigateway.modules.notify.consumer;

import com.aigateway.common.constant.KafkaTopics;
import com.aigateway.modules.notify.dto.NotifyMessage;
import com.aigateway.modules.notify.service.NotifyService;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

/**
 * Consumes notification messages off {@code KafkaTopics.NOTIFY} (design doc §13) and
 * dispatches them through {@link NotifyService}. Malformed payloads are logged and skipped
 * so a poison message never stalls the partition.
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class NotifyConsumer {

    private final NotifyService notifyService;
    private final ObjectMapper objectMapper;

    /** Deserialize a notify payload and dispatch it; malformed messages are logged and skipped. */
    @KafkaListener(topics = KafkaTopics.NOTIFY, groupId = "ai-gateway-notify")
    public void onMessage(String payload) {
        try {
            NotifyMessage msg = objectMapper.readValue(payload, NotifyMessage.class);
            notifyService.dispatch(msg);
        } catch (Exception e) {
            log.warn("notify consume failed, skipping: {}", e.getMessage());
        }
    }
}
