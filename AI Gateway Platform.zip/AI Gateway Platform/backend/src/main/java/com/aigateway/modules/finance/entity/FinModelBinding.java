package com.aigateway.modules.finance.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.aigateway.common.enums.CommonStatus;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.math.BigDecimal;

/** Per-model balance allocation for a company (table {@code fin_model_binding}). */
@Data
@TableName(value = "fin_model_binding", autoResultMap = true)
public class FinModelBinding {

    @TableId(type = IdType.AUTO)
    private Long id;

    private Long companyId;

    private String modelCode;

    private BigDecimal allocated;

    private BigDecimal used;

    /** 1 active / 0 disabled. */
    private CommonStatus status;
}
