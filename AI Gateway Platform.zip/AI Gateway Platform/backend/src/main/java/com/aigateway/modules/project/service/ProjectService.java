package com.aigateway.modules.project.service;

import com.aigateway.common.api.PageResult;
import com.aigateway.modules.project.dto.ProjectRequest;
import com.aigateway.modules.project.entity.Project;

/** Company-scoped project CRUD. */
public interface ProjectService {

    Project create(ProjectRequest req);

    PageResult<Project> page(long current, long size);

    Project get(Long id);

    Project update(Long id, ProjectRequest req);

    /** Soft delete. */
    void delete(Long id);
}
