package com.aigateway.modules.system.entity;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.handlers.JacksonTypeHandler;
import lombok.Data;

import java.time.OffsetDateTime;

/**
 * Dynamic system configuration entry (table {@code sys_config}, design doc §15.4).
 * Backs the config center for dynamic params (markup defaults, alert thresholds,
 * job switches, ...). The {@code configValue} is stored as JSONB so it can hold a
 * raw scalar (string/number/bool) or a structured object.
 */
@Data
@TableName(value = "sys_config", autoResultMap = true)
public class SysConfig {

    /** Primary key is the natural config key (not auto). */
    @TableId(value = "config_key", type = IdType.INPUT)
    private String configKey;

    @TableField(typeHandler = JacksonTypeHandler.class)
    private Object configValue;

    /** Logical group: pay/model/risk/markup/notify/system. */
    private String groupName;

    private String remark;

    private Long updatedBy;

    @TableField(fill = FieldFill.INSERT_UPDATE)
    private OffsetDateTime updatedAt;
}
