package com.aigateway.common.security;

import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.http.MediaType;
import org.springframework.lang.NonNull;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.time.Duration;
import java.util.Map;

/**
 * Coarse IP-based throttle for the public, unauthenticated auth surface
 * ({@code /api/auth/**}) to blunt credential stuffing / brute-force / enumeration
 * (design doc §18 risk control). Fixed window: max N requests per IP per window.
 * Account-level lockout is enforced separately in the auth service.
 */
@Slf4j
public class AuthRateLimitFilter extends OncePerRequestFilter {

    private static final int MAX_PER_WINDOW = 30;
    private static final Duration WINDOW = Duration.ofMinutes(1);
    /** HTTP 429 Too Many Requests. */
    private static final int HTTP_TOO_MANY_REQUESTS = 429;
    /** Business error code for throttled requests. */
    private static final int CODE_TOO_MANY_REQUESTS = 3005;

    private final StringRedisTemplate redis;
    private final ObjectMapper om = new ObjectMapper();

    public AuthRateLimitFilter(StringRedisTemplate redis) {
        this.redis = redis;
    }

    @Override
    protected boolean shouldNotFilter(@NonNull HttpServletRequest request) {
        return !request.getRequestURI().startsWith("/api/auth/");
    }

    @Override
    protected void doFilterInternal(@NonNull HttpServletRequest request,
                                    @NonNull HttpServletResponse response,
                                    @NonNull FilterChain chain) throws ServletException, IOException {
        String ip = clientIp(request);
        String key = "gw:rl:auth:" + ip;
        try {
            Long count = redis.opsForValue().increment(key);
            if (count != null && count == 1L) {
                redis.expire(key, WINDOW);
            }
            if (count != null && count > MAX_PER_WINDOW) {
                response.setStatus(HTTP_TOO_MANY_REQUESTS);
                response.setContentType(MediaType.APPLICATION_JSON_VALUE);
                response.setHeader("Retry-After", String.valueOf(WINDOW.getSeconds()));
                om.writeValue(response.getOutputStream(),
                        Map.of("code", CODE_TOO_MANY_REQUESTS, "msg", "too many requests, slow down"));
                return;
            }
        } catch (Exception e) {
            // fail-open on Redis hiccup so a cache outage doesn't lock everyone out
            log.warn("auth rate limit check failed: {}", e.getMessage());
        }
        chain.doFilter(request, response);
    }

    /** Resolve the real client IP behind a proxy/LB, taking only the first XFF hop. */
    public static String clientIp(HttpServletRequest req) {
        String xff = req.getHeader("X-Forwarded-For");
        if (xff != null && !xff.isBlank()) {
            return xff.split(",")[0].trim();
        }
        String real = req.getHeader("X-Real-IP");
        return (real != null && !real.isBlank()) ? real : req.getRemoteAddr();
    }
}
