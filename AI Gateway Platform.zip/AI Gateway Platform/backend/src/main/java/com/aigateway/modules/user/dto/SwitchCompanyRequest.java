package com.aigateway.modules.user.dto;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

/** Switch the active company context request. */
@Data
public class SwitchCompanyRequest {

    @NotNull
    private Long companyId;
}
