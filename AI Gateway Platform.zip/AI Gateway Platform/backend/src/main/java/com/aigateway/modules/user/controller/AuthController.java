package com.aigateway.modules.user.controller;

import com.aigateway.common.api.R;
import com.aigateway.modules.user.dto.GoogleLoginRequest;
import com.aigateway.modules.user.dto.InviteRegisterRequest;
import com.aigateway.modules.user.dto.LoginRequest;
import com.aigateway.modules.user.dto.LoginResponse;
import com.aigateway.modules.user.dto.RefreshRequest;
import com.aigateway.modules.user.dto.RegisterRequest;
import com.aigateway.modules.user.dto.SendCodeRequest;
import com.aigateway.modules.user.entity.SysUser;
import com.aigateway.modules.user.service.AuthService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

/** Public authentication endpoints (permitted under {@code /api/auth/**}). */
@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
public class AuthController {

    private final AuthService authService;

    @PostMapping("/register")
    public R<Map<String, Object>> register(@RequestBody @Valid RegisterRequest req,
                                           HttpServletRequest http) {
        SysUser u = authService.register(req, http);
        return R.ok(Map.of("id", u.getId(), "uid", u.getUid()));
    }

    @PostMapping("/send-code")
    public R<Void> sendCode(@RequestBody @Valid SendCodeRequest req) {
        authService.sendCode(req);
        return R.ok();
    }

    @PostMapping("/login")
    public R<LoginResponse> login(@RequestBody @Valid LoginRequest req, HttpServletRequest http) {
        return R.ok(authService.login(req, http));
    }

    /** Google OAuth login: verify the Google ID token, find-or-create the user, issue tokens. */
    @PostMapping("/google")
    public R<LoginResponse> google(@RequestBody @Valid GoogleLoginRequest req, HttpServletRequest http) {
        return R.ok(authService.googleLogin(req, http));
    }

    /** Register (or attach an existing user) via a company invite token. */
    @PostMapping("/register-invite")
    public R<LoginResponse> registerInvite(@RequestBody @Valid InviteRegisterRequest req,
                                           HttpServletRequest http) {
        return R.ok(authService.registerByInvite(req, http));
    }

    @PostMapping("/refresh")
    public R<Map<String, Object>> refresh(@RequestBody @Valid RefreshRequest req) {
        return R.ok(Map.of("accessToken", authService.refresh(req.getRefreshToken())));
    }

    @PostMapping("/logout")
    public R<Void> logout(@RequestBody RefreshRequest req) {
        authService.logout(req.getRefreshToken());
        return R.ok();
    }
}
