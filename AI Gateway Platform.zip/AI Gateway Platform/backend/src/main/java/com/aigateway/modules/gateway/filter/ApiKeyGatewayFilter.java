package com.aigateway.modules.gateway.filter;

import com.aigateway.common.constant.RedisKeys;
import com.aigateway.common.exception.BizException;
import com.aigateway.common.exception.ErrorCode;
import com.aigateway.common.security.AuthRateLimitFilter;
import com.aigateway.common.web.RequestIdFilter;
import com.aigateway.modules.apikey.dto.ApiKeyAuthContext;
import com.aigateway.modules.apikey.service.ApiKeyAuthService;
import com.aigateway.modules.gateway.context.GatewayContext;
import com.aigateway.modules.gateway.util.GatewayErrorWriter;
import com.aigateway.modules.risk.service.RiskService;
import com.aigateway.modules.system.service.SysConfigService;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;
import org.springframework.core.annotation.Order;
import org.springframework.data.redis.core.script.DefaultRedisScript;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.lang.NonNull;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.time.Duration;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Collections;
import java.util.concurrent.CompletableFuture;

/**
 * Authenticates and rate-limits the OpenAI-compatible {@code /v1/*} surface (design doc
 * §1.2/§12). For each request it: extracts the {@code Authorization: Bearer sk-...} key,
 * resolves it via {@link ApiKeyAuthService}, checks the risk blacklist, enforces the RPM
 * token bucket and a daily request quota, then binds a {@link GatewayContext} for downstream
 * handlers. All errors are written as OpenAI-shaped JSON (filters bypass the controller advice).
 *
 * <p>Raw keys and prompt bodies are never logged.</p>
 */
@Slf4j
@Order(10)
@Component
public class ApiKeyGatewayFilter extends OncePerRequestFilter {

    private static final DateTimeFormatter DAY = DateTimeFormatter.ofPattern("yyyyMMdd");
    private static final String BEARER = "Bearer ";
    private static final int DIM_WINDOW_SEC = 60;
    private static final int DEFAULT_COMPANY_DIM_LIMIT = 6000;
    private static final int DEFAULT_IP_DIM_LIMIT = 1200;
    /** Fallback RPM limit when a key has none configured. */
    private static final int DEFAULT_RPM_LIMIT = 60;
    /** Daily request/token counter TTL. */
    private static final Duration DAILY_COUNTER_TTL = Duration.ofDays(2);

    private final ApiKeyAuthService apiKeyAuthService;
    private final RiskService riskService;
    private final SysConfigService sysConfigService;
    private final StringRedisTemplate stringRedisTemplate;
    private final DefaultRedisScript<Long> tokenBucketScript;

    public ApiKeyGatewayFilter(ApiKeyAuthService apiKeyAuthService,
                               RiskService riskService,
                               SysConfigService sysConfigService,
                               StringRedisTemplate stringRedisTemplate,
                               DefaultRedisScript<Long> tokenBucketScript) {
        this.apiKeyAuthService = apiKeyAuthService;
        this.riskService = riskService;
        this.sysConfigService = sysConfigService;
        this.stringRedisTemplate = stringRedisTemplate;
        this.tokenBucketScript = tokenBucketScript;
    }

    @Override
    protected boolean shouldNotFilter(@NonNull HttpServletRequest request) {
        return !request.getRequestURI().startsWith("/v1/");
    }

    @Override
    protected void doFilterInternal(@NonNull HttpServletRequest request,
                                    @NonNull HttpServletResponse response,
                                    @NonNull FilterChain chain) throws ServletException, IOException {
        // 1) extract bearer key
        String header = request.getHeader("Authorization");
        if (header == null || !header.startsWith(BEARER)) {
            GatewayErrorWriter.write(response, ErrorCode.INVALID_API_KEY, "missing bearer api key");
            return;
        }
        String rawKey = header.substring(BEARER.length()).trim();
        if (!rawKey.startsWith("sk-")) {
            GatewayErrorWriter.write(response, ErrorCode.INVALID_API_KEY, "invalid api key format");
            return;
        }

        String clientIp = AuthRateLimitFilter.clientIp(request);

        // 2) authenticate (maps BizException -> OpenAI error)
        ApiKeyAuthContext auth;
        try {
            auth = apiKeyAuthService.authenticate(rawKey, clientIp);
        } catch (BizException e) {
            GatewayErrorWriter.write(response, e.getErrorCode(), e.getMessage());
            return;
        } catch (Exception e) {
            log.warn("api key auth error: {}", e.getMessage());
            GatewayErrorWriter.write(response, ErrorCode.INVALID_API_KEY, "authentication failed");
            return;
        }

        // 3) risk blacklist (ip / country / user). Country is resolved via GeoIP (header override
        //    honored first); all geo/risk lookups fail open so a legitimate call is never broken.
        String country = request.getHeader("CF-IPCountry");
        if (country == null || country.isBlank()) {
            country = safeResolveCountry(clientIp);
        }
        boolean blocked;
        try {
            blocked = riskService.isBlocked(clientIp, country, auth.getCompanyId());
        } catch (Exception e) {
            log.warn("risk blacklist check failed (fail-open): {}", e.getMessage());
            blocked = false;
        }
        if (blocked) {
            GatewayErrorWriter.write(response, ErrorCode.FORBIDDEN, "request blocked by risk policy");
            return;
        }

        // 4) multi-dimension throttle (§12.1): company-level and IP-level fixed-window limits.
        if (!multiDimAllow(auth.getCompanyId(), clientIp)) {
            response.setHeader("Retry-After", "1");
            GatewayErrorWriter.write(response, ErrorCode.RATE_LIMITED, "dimension rate limit exceeded");
            return;
        }

        // 5) RPM token bucket, honoring any temporary risk throttle override.
        int configuredRpm = auth.getRpmLimit() == null ? DEFAULT_RPM_LIMIT : auth.getRpmLimit();
        int rpm = safeEffectiveRpm(auth.getApiKeyId(), configuredRpm);
        if (rpm > 0 && !allowRpm(auth.getApiKeyId(), rpm)) {
            response.setHeader("Retry-After", "1");
            response.setHeader("X-RateLimit-Limit", String.valueOf(rpm));
            response.setHeader("X-RateLimit-Remaining", "0");
            response.setHeader("X-RateLimit-Reset", String.valueOf(nextWindowEpoch()));
            GatewayErrorWriter.write(response, ErrorCode.RATE_LIMITED, "rpm limit exceeded");
            return;
        }

        // 6) daily TOKEN quota pre-check: block if today's accumulated tokens already exceed the
        //    key's dailyQuota. Actual tokens are accumulated post-call by the proxy. Fails open.
        if (dailyTokenQuotaExceeded(auth)) {
            GatewayErrorWriter.write(response, ErrorCode.QUOTA_EXCEEDED, "daily token quota exceeded");
            return;
        }

        // 7) daily request quota counter (informational counter; per-request cost is enforced by balance freeze)
        incrDailyRequests(auth.getApiKeyId());

        // 8) bind context + proceed
        GatewayContext.Holder holder = new GatewayContext.Holder();
        holder.setAuth(auth);
        holder.setRequestId(MDC.get(RequestIdFilter.MDC_KEY));
        holder.setClientIp(clientIp);
        holder.setCountry(country);
        holder.setUserAgent(request.getHeader("User-Agent"));
        holder.setRateLimitLimit(rpm);
        holder.setRateLimitRemaining(rpm);
        holder.setRateLimitResetEpoch(nextWindowEpoch());
        GatewayContext.set(holder);

        touchAsync(auth.getApiKeyId());
        try {
            chain.doFilter(request, response);
        } finally {
            GatewayContext.clear();
        }
    }

    /** Resolve country defensively; never throws (fail-open to UNKNOWN). */
    private String safeResolveCountry(String ip) {
        try {
            return riskService.resolveCountry(ip);
        } catch (Exception e) {
            log.debug("country resolve failed (fail-open): {}", e.getMessage());
            return null;
        }
    }

    /** Apply any temporary risk throttle override defensively. */
    private int safeEffectiveRpm(Long apiKeyId, int configuredRpm) {
        try {
            return riskService.effectiveRpm(apiKeyId, configuredRpm);
        } catch (Exception e) {
            log.debug("effectiveRpm failed (fail-open): {}", e.getMessage());
            return configuredRpm;
        }
    }

    /**
     * Company-level total throttle + IP-level throttle (§12.1). Both are coarse fixed-window
     * back-stops above per-key RPM; limits/windows come from {@code sys_config} with sane defaults.
     * Fails open (RiskService.allow itself fails open on Redis errors).
     */
    private boolean multiDimAllow(Long companyId, String ip) {
        try {
            boolean companyOk = companyId == null || riskService.allow("company",
                    String.valueOf(companyId), companyDimLimit(), DIM_WINDOW_SEC);
            boolean ipOk = ip == null || ip.isBlank() || riskService.allow("ip",
                    ip, ipDimLimit(), DIM_WINDOW_SEC);
            return companyOk && ipOk;
        } catch (Exception e) {
            log.debug("multi-dim throttle failed (fail-open): {}", e.getMessage());
            return true;
        }
    }

    private int companyDimLimit() {
        try {
            return (int) sysConfigService.getLong("risk.ratelimit.company.perMin", DEFAULT_COMPANY_DIM_LIMIT);
        } catch (Exception e) {
            return DEFAULT_COMPANY_DIM_LIMIT;
        }
    }

    private int ipDimLimit() {
        try {
            return (int) sysConfigService.getLong("risk.ratelimit.ip.perMin", DEFAULT_IP_DIM_LIMIT);
        } catch (Exception e) {
            return DEFAULT_IP_DIM_LIMIT;
        }
    }

    /** Epoch seconds at the start of the next minute window (for X-RateLimit-Reset). */
    private static long nextWindowEpoch() {
        long now = System.currentTimeMillis() / 1000L;
        return now - (now % 60) + 60;
    }

    /** Token-bucket RPM check via the shared Lua script. Fails open on Redis error. */
    private boolean allowRpm(Long apiKeyId, int rpm) {
        try {
            double rate = rpm / 60.0;
            Long ok = stringRedisTemplate.execute(tokenBucketScript,
                    Collections.singletonList(RedisKeys.rpm(apiKeyId)),
                    String.valueOf(rate), String.valueOf(rpm),
                    String.valueOf(System.currentTimeMillis() / 1000.0), "1");
            return ok != null && ok == 1L;
        } catch (Exception e) {
            log.warn("rpm bucket check failed for key {}: {}", apiKeyId, e.getMessage());
            return true;
        }
    }

    /**
     * Pre-check: today's accumulated tokens already over the key's dailyQuota? Read-only, no
     * increment (the proxy accumulates actual tokens post-call). Fails open on Redis error.
     */
    private boolean dailyTokenQuotaExceeded(ApiKeyAuthContext auth) {
        java.math.BigDecimal quota = auth.getDailyQuota();
        if (quota == null || quota.signum() <= 0) {
            return false;
        }
        try {
            String key = RedisKeys.dailyTokens(auth.getApiKeyId(), LocalDate.now().format(DAY));
            String v = stringRedisTemplate.opsForValue().get(key);
            if (v == null || v.isBlank()) {
                return false;
            }
            return new java.math.BigDecimal(v.trim()).compareTo(quota) >= 0;
        } catch (Exception e) {
            log.debug("daily token quota pre-check failed for key {} (fail-open): {}",
                    auth.getApiKeyId(), e.getMessage());
            return false;
        }
    }

    private void incrDailyRequests(Long apiKeyId) {
        try {
            String key = RedisKeys.dailyReq(apiKeyId, LocalDate.now().format(DAY));
            Long c = stringRedisTemplate.opsForValue().increment(key);
            if (c != null && c == 1L) {
                stringRedisTemplate.expire(key, DAILY_COUNTER_TTL);
            }
        } catch (Exception e) {
            log.debug("daily request counter failed for key {}: {}", apiKeyId, e.getMessage());
        }
    }

    /** Best-effort, off the request thread; the service itself swallows failures. */
    private void touchAsync(Long apiKeyId) {
        CompletableFuture.runAsync(() -> {
            try {
                apiKeyAuthService.touchLastUsed(apiKeyId);
            } catch (Exception e) {
                log.debug("touchLastUsed failed for key {}: {}", apiKeyId, e.getMessage());
            }
        });
    }
}
