package com.aigateway.common.enums;

import com.baomidou.mybatisplus.annotation.EnumValue;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;

/** channel.health circuit-breaker state. */
@Getter
public enum ChannelHealth implements CodedEnum<Integer> {

    BROKEN(0),
    HEALTHY(1);

    @EnumValue
    @JsonValue
    private final Integer code;

    ChannelHealth(Integer code) {
        this.code = code;
    }

    @JsonCreator
    public static ChannelHealth of(Integer code) {
        if (code == null) {
            return null;
        }
        for (ChannelHealth v : values()) {
            if (v.code.equals(code)) {
                return v;
            }
        }
        return null;
    }
}
