package com.aigateway.modules.company.entity;

import com.aigateway.common.enums.CommonStatus;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.time.OffsetDateTime;

/** Company membership entity (table {@code biz_company_member}). */
@Data
@TableName("biz_company_member")
public class CompanyMember {

    @TableId(type = IdType.AUTO)
    private Long id;

    private Long companyId;

    private Long userId;

    /** OWNER / ADMIN / DEVELOPER / VIEWER. */
    private String role;

    private CommonStatus status;

    private Long invitedBy;

    /** Populated by the DB default ({@code now()}) on insert. */
    private OffsetDateTime joinedAt;
}
