package com.aigateway.modules.finance.job;

import com.aigateway.common.schedule.ManagedJob;
import com.aigateway.modules.finance.service.FinanceService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.Map;

/** Daily platform profit summary log (design doc §10.4). */
@Slf4j
@Component
@RequiredArgsConstructor
public class ProfitReportJob implements ManagedJob {

    private static final String JOB_KEY = "profit-report";

    private final FinanceService financeService;

    @Override
    public String jobKey() {
        return JOB_KEY;
    }

    @Override
    public String defaultCron() {
        return "0 0 3 * * *";
    }

    @Override
    public String description() {
        return "Daily platform profit summary log";
    }

    @Override
    public void execute() {
        Map<String, Object> s = financeService.profitSummary();
        log.info("[profit-report] revenue={} cost={} profit={}",
                s.get("totalRevenue"), s.get("totalCost"), s.get("totalProfit"));
    }
}
