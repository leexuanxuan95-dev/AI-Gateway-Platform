package com.aigateway.modules.gateway.controller;

import com.aigateway.common.exception.BizException;
import com.aigateway.common.exception.ErrorCode;
import com.aigateway.common.util.UploadValidator;
import com.aigateway.modules.gateway.service.GatewayProxyService;
import com.aigateway.modules.gateway.service.GatewayRequestSupport;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.Map;

/**
 * Audio endpoints (design doc §20.4): {@code POST /v1/audio/speech} (TTS, JSON in / audio bytes
 * out, billed per input character) and {@code POST /v1/audio/transcriptions} (multipart passthrough,
 * billed per audio second with a per-call floor when the duration is unknown). Both bill via the
 * model's unit cost through the standard min-margin markup.
 */
@RestController
@RequiredArgsConstructor
public class AudioController {

    private static final String SPEECH_PATH = "/v1/audio/speech";
    private static final String TRANSCRIBE_PATH = "/v1/audio/transcriptions";

    private final GatewayProxyService proxy;
    private final GatewayRequestSupport support;

    @PostMapping(SPEECH_PATH)
    public String speech(@RequestBody Map<String, Object> body,
                         HttpServletRequest req,
                         HttpServletResponse resp) {
        String model = support.resolveModel(body.get("model"));
        Long projectId = support.resolveProjectId(req);
        // TTS is billed per input character.
        long chars = inputChars(body);
        return proxy.proxyUnitAndBill(SPEECH_PATH, body, model, projectId, "char", chars, resp);
    }

    @PostMapping(value = TRANSCRIBE_PATH, consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public String transcribe(@RequestParam("model") String modelParam,
                             @RequestParam("file") MultipartFile file,
                             HttpServletRequest req,
                             HttpServletResponse resp) {
        // Anti-malicious-upload: enforce size ceiling, audio extension allow-list and a
        // traversal-free filename before we buffer the bytes or forward them upstream.
        UploadValidator.validateAudioFile(file);
        String model = support.resolveModel(modelParam);
        Long projectId = support.resolveProjectId(req);
        // Rebuild a minimal multipart body for upstream (model + file part) so LiteLLM receives
        // a well-formed request regardless of how the original parts were ordered/buffered.
        byte[] body;
        String boundary = "----aigw" + System.nanoTime();
        try {
            body = buildMultipart(boundary, model, file);
        } catch (IOException e) {
            throw new BizException(ErrorCode.PARAM_ERROR, "unreadable upload");
        }
        MediaType ct = MediaType.parseMediaType(MediaType.MULTIPART_FORM_DATA_VALUE + "; boundary=" + boundary);
        // Audio duration is not known from the upload here -> bill the per-call floor (proxy applies it).
        return proxy.proxyTranscriptionAndBill(TRANSCRIBE_PATH, body, ct, model, projectId, -1, resp);
    }

    /** Count characters of the TTS {@code input} field (per-character billing). */
    private long inputChars(Map<String, Object> body) {
        Object input = body.get("input");
        if (input instanceof String s) {
            return Math.max(1, s.length());
        }
        return 1;
    }

    /** Assemble a {@code multipart/form-data} body with the model field and the audio file part. */
    private byte[] buildMultipart(String boundary, String model, MultipartFile file) throws IOException {
        java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream();
        String dash = "--";
        String crlf = "\r\n";
        String filename = file.getOriginalFilename() == null ? "audio" : file.getOriginalFilename();
        String fileCt = file.getContentType() == null ? "application/octet-stream" : file.getContentType();

        out.write((dash + boundary + crlf).getBytes(java.nio.charset.StandardCharsets.UTF_8));
        out.write(("Content-Disposition: form-data; name=\"model\"" + crlf + crlf + model + crlf)
                .getBytes(java.nio.charset.StandardCharsets.UTF_8));
        out.write((dash + boundary + crlf).getBytes(java.nio.charset.StandardCharsets.UTF_8));
        out.write(("Content-Disposition: form-data; name=\"file\"; filename=\"" + filename + "\"" + crlf
                + "Content-Type: " + fileCt + crlf + crlf)
                .getBytes(java.nio.charset.StandardCharsets.UTF_8));
        out.write(file.getBytes());
        out.write(crlf.getBytes(java.nio.charset.StandardCharsets.UTF_8));
        out.write((dash + boundary + dash + crlf).getBytes(java.nio.charset.StandardCharsets.UTF_8));
        return out.toByteArray();
    }
}
