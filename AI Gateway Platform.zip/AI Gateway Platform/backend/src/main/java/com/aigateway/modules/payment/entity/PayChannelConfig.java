package com.aigateway.modules.payment.entity;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.handlers.JacksonTypeHandler;
import lombok.Data;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.Map;

/**
 * Payment channel configuration (table {@code pay_channel_config}, design doc §10.2.1).
 * {@code credentials} holds AES-encrypted secret values (per-value ciphertext).
 */
@Data
@TableName(value = "pay_channel_config", autoResultMap = true)
public class PayChannelConfig {

    @TableId(type = IdType.AUTO)
    private Long id;

    private String channelCode;

    private String displayName;

    private String icon;

    private Boolean enabled;

    /** production / sandbox. */
    private String envMode;

    /** AES-encrypted secret values keyed by name (e.g. apiKey, webhookSecret). */
    @TableField(typeHandler = JacksonTypeHandler.class)
    private Map<String, Object> credentials;

    /** Supported currencies, e.g. ["USD","EUR"]. */
    @TableField(typeHandler = JacksonTypeHandler.class)
    private List<String> currencies;

    private BigDecimal feeRate;

    private BigDecimal feeFixed;

    private BigDecimal minAmount;

    private BigDecimal maxAmount;

    /** auto / fixed. */
    private String exchangeMode;

    private BigDecimal fixedRate;

    /** webhook / poll. */
    private String confirmType;

    /** Required confirmations for crypto channels. */
    private Integer confirmBlocks;

    private String callbackUrl;

    private Integer sort;

    private String remark;

    private Long updatedBy;

    @TableField(fill = FieldFill.INSERT_UPDATE)
    private OffsetDateTime updatedAt;
}
