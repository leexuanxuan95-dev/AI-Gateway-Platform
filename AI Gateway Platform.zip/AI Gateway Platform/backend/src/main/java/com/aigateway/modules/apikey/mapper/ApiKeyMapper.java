package com.aigateway.modules.apikey.mapper;

import com.aigateway.modules.apikey.entity.ApiKey;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/** MyBatis-Plus mapper for {@link ApiKey}. */
public interface ApiKeyMapper extends BaseMapper<ApiKey> {
}
