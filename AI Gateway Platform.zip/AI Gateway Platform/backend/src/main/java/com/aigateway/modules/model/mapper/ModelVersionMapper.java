package com.aigateway.modules.model.mapper;

import com.aigateway.modules.model.entity.ModelVersion;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/** MyBatis-Plus mapper for {@link ModelVersion}. */
public interface ModelVersionMapper extends BaseMapper<ModelVersion> {
}
