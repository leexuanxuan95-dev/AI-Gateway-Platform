package com.aigateway.modules.user.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

/** Google OAuth login request carrying the Google-issued ID token (JWT). */
@Data
public class GoogleLoginRequest {

    @NotBlank
    private String idToken;
}
