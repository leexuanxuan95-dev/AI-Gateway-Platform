package com.aigateway.modules.site.service;

import com.aigateway.modules.site.dto.PreviewResp;
import com.aigateway.modules.site.dto.SiteFaqReq;
import com.aigateway.modules.site.dto.SiteSectionReq;
import com.aigateway.modules.site.dto.SiteSettingReq;
import com.aigateway.modules.site.entity.SiteFaq;
import com.aigateway.modules.site.entity.SitePublish;
import com.aigateway.modules.site.entity.SiteSection;
import com.aigateway.modules.site.entity.SiteSetting;

import java.util.List;
import java.util.Map;

/**
 * OmniRoute landing CMS service (OmniRoute doc §4). Manages draft content
 * (settings / sections / FAQ), preview snapshots, and publish / rollback.
 */
public interface SiteCmsService {

    /** Build the structured DRAFT content object (settings + sections + faq) for a language. */
    Map<String, Object> getDraft(String lang);

    /** Upsert the site-level setting (brand / SEO / theme / footer) for a language. */
    SiteSetting upsertSetting(String lang, SiteSettingReq req, Long operatorUserId);

    /** Upsert a section by key + language. */
    SiteSection upsertSection(String sectionKey, String lang, SiteSectionReq req);

    /** Create a FAQ entry. */
    SiteFaq createFaq(SiteFaqReq req);

    /** Update an existing FAQ entry. */
    SiteFaq updateFaq(Long id, SiteFaqReq req);

    /** Delete a FAQ entry. */
    void deleteFaq(Long id);

    /** Build a preview snapshot from the current draft, store under a token, return token + url. */
    PreviewResp createPreview(String lang);

    /** Read a stored preview snapshot by token, or null if expired / unknown. */
    Map<String, Object> getPreview(String token);

    /**
     * Assemble the full resolved snapshot from the current draft (embedding bind_source
     * data), persist a published row, supersede previous ones, evict the landing cache.
     */
    Map<String, Object> publish(String lang, Long operatorUserId);

    /** List publish history for a language (newest first). */
    List<SitePublish> publishHistory(String lang);

    /** Re-publish a historical snapshot by id (inserts a new published row), evict cache. */
    Map<String, Object> rollback(Long publishId, Long operatorUserId);

    /**
     * The latest published landing snapshot for a language (Redis-cached, OmniRoute §4.4).
     * Falls back to {@code zh}, then to assembling from the draft if nothing is published.
     */
    Map<String, Object> getLanding(String lang);
}
