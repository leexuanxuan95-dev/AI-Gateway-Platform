package com.aigateway.modules.finance.service;

import java.math.BigDecimal;

/**
 * Cross-currency conversion for settlement / recharge (design doc §15.5). Reads the
 * safety-factor-adjusted FX rates cached in Redis ({@code gw:fx:rates}, hash ccy-&gt;rate,
 * base USD) that {@code ExchangeRateJob} refreshes hourly, with a {@code sys_config}
 * ({@code fx.rates}) fallback. Rates express "units of CCY per 1 USD".
 */
public interface ExchangeRateService {

    /** Convert {@code amount} in {@code ccy} to USD. Falls back to 1.0 (and warns) if unknown. */
    BigDecimal toUsd(BigDecimal amount, String ccy);

    /** Convert {@code amount} from {@code from} currency to {@code to} currency. */
    BigDecimal convert(BigDecimal amount, String from, String to);

    /** Raw adjusted rate (units of {@code ccy} per 1 USD), or null if unknown. */
    BigDecimal rateOf(String ccy);
}
