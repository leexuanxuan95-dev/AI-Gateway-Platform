package com.aigateway.modules.site.mapper;

import com.aigateway.modules.site.entity.SitePublish;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/** MyBatis-Plus mapper for {@link SitePublish}. */
public interface SitePublishMapper extends BaseMapper<SitePublish> {
}
