package com.aigateway.common.security;

import lombok.RequiredArgsConstructor;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

import java.time.Duration;

/**
 * Account-level brute-force lockout (design doc §18). After
 * {@link #MAX_FAILURES} consecutive failed logins for an identity (email/mobile),
 * the account is temporarily locked for {@link #LOCK_MINUTES}. A successful login
 * clears the counter. Complements the IP-based {@link AuthRateLimitFilter}.
 */
@Service
@RequiredArgsConstructor
public class LoginAttemptService {

    public static final int MAX_FAILURES = 5;
    public static final long LOCK_MINUTES = 15;

    private final StringRedisTemplate redis;

    private String key(String identity) {
        return "gw:login:fail:" + identity;
    }

    public boolean isLocked(String identity) {
        String v = redis.opsForValue().get(key(identity));
        return v != null && Integer.parseInt(v) >= MAX_FAILURES;
    }

    /** Record a failed attempt; returns remaining attempts before lockout. */
    public int recordFailure(String identity) {
        String k = key(identity);
        Long c = redis.opsForValue().increment(k);
        if (c != null && c == 1L) {
            redis.expire(k, Duration.ofMinutes(LOCK_MINUTES));
        }
        long used = c == null ? 0 : c;
        return (int) Math.max(0, MAX_FAILURES - used);
    }

    public void clear(String identity) {
        redis.delete(key(identity));
    }
}
