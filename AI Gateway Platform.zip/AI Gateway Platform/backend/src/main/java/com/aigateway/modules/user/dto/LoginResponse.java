package com.aigateway.modules.user.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/** Successful login / token bundle. */
@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class LoginResponse {

    private String accessToken;

    private String refreshToken;

    private UserInfo user;

    /**
     * Set when a force-2FA policy applies and the user has not yet enrolled. When true the
     * client must complete {@code /api/user/totp/setup} + {@code /api/user/totp/enable}
     * before the issued access token grants full access (design doc §3 security center).
     */
    private Boolean require2faSetup;

    /** Convenience factory for the normal (no 2FA-setup) path. */
    public static LoginResponse of(String accessToken, String refreshToken, UserInfo user) {
        return new LoginResponse(accessToken, refreshToken, user, null);
    }
}
