package com.aigateway.modules.channel.service;

import com.aigateway.common.api.PageResult;
import com.aigateway.modules.channel.dto.ChannelRequest;
import com.aigateway.modules.channel.dto.ChannelView;
import com.aigateway.modules.channel.dto.RechargeRequest;
import com.aigateway.modules.channel.dto.ReserveRequest;
import com.aigateway.modules.channel.entity.Channel;
import com.aigateway.modules.channel.entity.UpstreamRechargeLog;
import com.aigateway.modules.channel.entity.UpstreamReserve;

import java.math.BigDecimal;
import java.util.List;

/** Channel management (super-admin) plus the shared {@link #estimatedBalance} helper. */
public interface ChannelService {

    ChannelView create(ChannelRequest req);

    PageResult<ChannelView> page(long current, long size);

    ChannelView get(Long id);

    ChannelView update(Long id, ChannelRequest req);

    void delete(Long id);

    /** Manual recharge: quota += amount; writes an audit log with the current operator. */
    ChannelView recharge(Long id, RechargeRequest req);

    /** Remaining balance = quota - usedQuota. */
    BigDecimal balance(Long id);

    UpstreamReserve getReserve(Long id);

    UpstreamReserve updateReserve(Long id, ReserveRequest req);

    List<UpstreamRechargeLog> rechargeLogs(Long id);

    /** Estimated balance for a channel entity = quota - usedQuota. */
    BigDecimal estimatedBalance(Channel ch);
}
