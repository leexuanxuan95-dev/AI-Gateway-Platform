package com.aigateway.modules.user.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

/** Email + password login request, with optional TOTP code for 2FA users. */
@Data
public class LoginRequest {

    @NotBlank
    @Email
    private String email;

    @NotBlank
    private String password;

    /** TOTP 6-digit code; required only if the account has 2FA enabled. */
    private String totpCode;
}
