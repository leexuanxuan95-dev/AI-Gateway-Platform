package com.aigateway.modules.billing.service;

import com.aigateway.common.api.PageResult;
import com.aigateway.modules.billing.dto.BillQuery;
import com.aigateway.modules.billing.entity.BillToken;
import com.aigateway.modules.billing.entity.CallLog;

import java.io.Writer;
import java.util.Map;

/**
 * Read/aggregate side of the billing module (design doc §11). All queries are scoped to a
 * company (null companyId = platform-wide, super-admin only).
 */
public interface BillingQueryService {

    /** Paged token bills, filtered by date/model/project, newest first. */
    PageResult<BillToken> pageBills(Long companyId, BillQuery q);

    /** Paged call logs, filtered by date/model, newest first. */
    PageResult<CallLog> pageCallLogs(Long companyId, BillQuery q);

    /** Stream token bills as CSV to the given writer (bounded by the query window). */
    void exportBillsCsv(Long companyId, BillQuery q, Writer out);

    /** Consumption summary: today / yesterday / month / total charge, cost, tokens, requests. */
    Map<String, Object> summary(Long companyId);
}
