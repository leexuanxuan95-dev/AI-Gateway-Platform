package com.aigateway.modules.user.dto;

import lombok.Data;

/**
 * Carries the caller's current refresh token so session listing can flag the current device
 * and "revoke all other" can keep the caller signed in (design doc §3.3). Optional: when
 * absent, every other session is treated as revocable and none is flagged current.
 */
@Data
public class SessionActionRequest {

    private String refreshToken;
}
