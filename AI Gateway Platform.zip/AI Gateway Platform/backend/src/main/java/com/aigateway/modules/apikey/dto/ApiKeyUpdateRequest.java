package com.aigateway.modules.apikey.dto;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.PositiveOrZero;
import jakarta.validation.constraints.Size;
import lombok.Data;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.List;

/** Request body for updating an API key's limits/metadata. */
@Data
public class ApiKeyUpdateRequest {

    @Size(max = 100)
    private String keyName;

    private List<String> allowedModels;

    @PositiveOrZero
    private Integer rpmLimit;

    @PositiveOrZero
    private Integer tpmLimit;

    @DecimalMin(value = "0.0", message = "dailyQuota must not be negative")
    private BigDecimal dailyQuota;

    private List<String> ipWhitelist;

    private OffsetDateTime expireAt;
}
