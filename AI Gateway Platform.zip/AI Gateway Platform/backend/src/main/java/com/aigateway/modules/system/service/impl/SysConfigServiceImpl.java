package com.aigateway.modules.system.service.impl;

import com.aigateway.common.constant.RedisKeys;
import com.aigateway.modules.system.entity.SysConfig;
import com.aigateway.modules.system.mapper.SysConfigMapper;
import com.aigateway.modules.system.service.SysConfigService;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.Duration;
import java.util.List;

/**
 * Default {@link SysConfigService}. Single entries are cached in Redis under
 * {@code RedisKeys.sysConfig(key)} with a short TTL; writes evict the entry so the
 * next read repopulates from the database. Cache faults fail open to the DB.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class SysConfigServiceImpl implements SysConfigService {

    /** Redis cache TTL for a single config entry. */
    private static final Duration TTL = Duration.ofMinutes(10);

    private final SysConfigMapper sysConfigMapper;
    private final RedisTemplate<String, Object> redisTemplate;

    @Override
    public SysConfig get(String key) {
        if (key == null) {
            return null;
        }
        String cacheKey = RedisKeys.sysConfig(key);
        try {
            Object cached = redisTemplate.opsForValue().get(cacheKey);
            if (cached instanceof SysConfig sc) {
                return sc;
            }
        } catch (Exception e) {
            log.debug("sysConfig cache read failed for {}: {}", key, e.getMessage());
        }
        SysConfig db = sysConfigMapper.selectById(key);
        if (db != null) {
            try {
                redisTemplate.opsForValue().set(cacheKey, db, TTL);
            } catch (Exception e) {
                log.debug("sysConfig cache write failed for {}: {}", key, e.getMessage());
            }
        }
        return db;
    }

    @Override
    public List<SysConfig> listByGroup(String group) {
        return sysConfigMapper.selectList(Wrappers.<SysConfig>lambdaQuery()
                .eq(group != null && !group.isBlank(), SysConfig::getGroupName, group)
                .orderByAsc(SysConfig::getConfigKey));
    }

    @Override
    public SysConfig upsert(String key, Object value, String group, String remark, Long operatorUserId) {
        SysConfig existing = sysConfigMapper.selectById(key);
        SysConfig row = new SysConfig();
        row.setConfigKey(key);
        row.setConfigValue(value);
        row.setGroupName(group);
        row.setRemark(remark);
        row.setUpdatedBy(operatorUserId);
        if (existing == null) {
            sysConfigMapper.insert(row);
        } else {
            sysConfigMapper.updateById(row);
        }
        evict(key);
        return sysConfigMapper.selectById(key);
    }

    @Override
    public void delete(String key) {
        sysConfigMapper.deleteById(key);
        evict(key);
    }

    @Override
    public String getString(String key, String def) {
        SysConfig sc = get(key);
        Object v = sc == null ? null : sc.getConfigValue();
        return v == null ? def : String.valueOf(v);
    }

    @Override
    public boolean getBool(String key, boolean def) {
        String s = getString(key, null);
        if (s == null) {
            return def;
        }
        return "true".equalsIgnoreCase(s) || "1".equals(s);
    }

    @Override
    public BigDecimal getDecimal(String key, BigDecimal def) {
        String s = getString(key, null);
        if (s == null) {
            return def;
        }
        try {
            return new BigDecimal(s.trim());
        } catch (NumberFormatException e) {
            return def;
        }
    }

    @Override
    public long getLong(String key, long def) {
        String s = getString(key, null);
        if (s == null) {
            return def;
        }
        try {
            return Long.parseLong(s.trim());
        } catch (NumberFormatException e) {
            return def;
        }
    }

    private void evict(String key) {
        try {
            redisTemplate.delete(RedisKeys.sysConfig(key));
        } catch (Exception e) {
            log.debug("sysConfig cache evict failed for {}: {}", key, e.getMessage());
        }
    }
}
