package com.aigateway.modules.apikey.service;

import com.aigateway.common.api.PageResult;
import com.aigateway.modules.apikey.dto.ApiKeyCreateRequest;
import com.aigateway.modules.apikey.dto.ApiKeyCreateResponse;
import com.aigateway.modules.apikey.dto.ApiKeyUpdateRequest;
import com.aigateway.modules.apikey.dto.ApiKeyView;

/** Console-facing API key management (company-scoped CRUD). */
public interface ApiKeyService {

    ApiKeyCreateResponse create(ApiKeyCreateRequest req);

    PageResult<ApiKeyView> page(long current, long size);

    ApiKeyView update(Long id, ApiKeyUpdateRequest req);

    void disable(Long id);

    void enable(Long id);

    /** Soft delete (status = 3). */
    void delete(Long id);
}
