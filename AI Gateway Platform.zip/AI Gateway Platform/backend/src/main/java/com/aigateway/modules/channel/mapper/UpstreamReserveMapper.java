package com.aigateway.modules.channel.mapper;

import com.aigateway.modules.channel.entity.UpstreamReserve;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/** MyBatis-Plus mapper for {@link UpstreamReserve}. */
public interface UpstreamReserveMapper extends BaseMapper<UpstreamReserve> {
}
