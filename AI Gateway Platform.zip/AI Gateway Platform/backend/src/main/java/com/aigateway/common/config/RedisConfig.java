package com.aigateway.common.config;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.jsontype.impl.LaissezFaireSubTypeValidator;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.script.DefaultRedisScript;
import org.springframework.data.redis.serializer.GenericJackson2JsonRedisSerializer;
import org.springframework.data.redis.serializer.StringRedisSerializer;

/** Redis serialization setup and shared Lua scripts (rate limiting). */
@Configuration
public class RedisConfig {

    @Bean
    public RedisTemplate<String, Object> redisTemplate(RedisConnectionFactory factory) {
        RedisTemplate<String, Object> template = new RedisTemplate<>();
        template.setConnectionFactory(factory);

        ObjectMapper om = new ObjectMapper();
        // support Java 8 date/time (OffsetDateTime on cached entities)
        om.registerModule(new com.fasterxml.jackson.datatype.jsr310.JavaTimeModule());
        om.disable(com.fasterxml.jackson.databind.SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
        om.setVisibility(PropertyAccessor.ALL, JsonAutoDetect.Visibility.ANY);
        om.activateDefaultTyping(LaissezFaireSubTypeValidator.instance,
                ObjectMapper.DefaultTyping.NON_FINAL);
        GenericJackson2JsonRedisSerializer json = new GenericJackson2JsonRedisSerializer(om);
        StringRedisSerializer str = new StringRedisSerializer();

        template.setKeySerializer(str);
        template.setHashKeySerializer(str);
        template.setValueSerializer(json);
        template.setHashValueSerializer(json);
        template.afterPropertiesSet();
        return template;
    }

    /** Token-bucket rate limiter Lua script (design doc §12.1), returns 1 if allowed. */
    @Bean
    public DefaultRedisScript<Long> tokenBucketScript() {
        DefaultRedisScript<Long> script = new DefaultRedisScript<>();
        script.setScriptText(
                "local key=KEYS[1]; local rate=tonumber(ARGV[1]); local cap=tonumber(ARGV[2])\n" +
                "local now=tonumber(ARGV[3]); local req=tonumber(ARGV[4])\n" +
                "local b=redis.call('HMGET',key,'tokens','ts')\n" +
                "local tokens=tonumber(b[1]) or cap; local ts=tonumber(b[2]) or now\n" +
                "tokens=math.min(cap, tokens+(now-ts)*rate)\n" +
                "local ok=0; if tokens>=req then tokens=tokens-req; ok=1 end\n" +
                "redis.call('HMSET',key,'tokens',tokens,'ts',now); redis.call('EXPIRE',key,3600)\n" +
                "return ok");
        script.setResultType(Long.class);
        return script;
    }
}
