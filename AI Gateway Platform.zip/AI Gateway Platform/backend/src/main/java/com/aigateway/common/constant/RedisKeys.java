package com.aigateway.common.constant;

/** Centralized Redis key builders to avoid magic strings across modules. */
public final class RedisKeys {

    private RedisKeys() {
    }

    /** API key auth cache (hash of sk-xxx -> ApiKeyAuth json). TTL applied. */
    public static String apiKeyAuth(String hash) {
        return "gw:apikey:" + hash;
    }

    /** SMS / email verification code. */
    public static String captcha(String scene, String target) {
        return "gw:captcha:" + scene + ":" + target;
    }

    /** Refresh token store (opaque -> userId). */
    public static String refreshToken(String token) {
        return "gw:refresh:" + token;
    }

    /** RPM token bucket per api key. */
    public static String rpm(Long apiKeyId) {
        return "gw:rl:rpm:" + apiKeyId;
    }

    /** TPM token bucket per api key. */
    public static String tpm(Long apiKeyId) {
        return "gw:rl:tpm:" + apiKeyId;
    }

    /** Daily request counter per api key (yyyymmdd). */
    public static String dailyReq(Long apiKeyId, String day) {
        return "gw:daily:req:" + apiKeyId + ":" + day;
    }

    /** Daily token counter per api key. */
    public static String dailyTokens(Long apiKeyId, String day) {
        return "gw:daily:tok:" + apiKeyId + ":" + day;
    }

    /** Cached permission set per user+company. */
    public static String userPerms(Long userId, Long companyId) {
        return "gw:perms:" + userId + ":" + companyId;
    }

    /** Cached pay channel config. */
    public static String payChannel(String code) {
        return "gw:pay:cfg:" + code;
    }

    /** Cached system config entry. */
    public static String sysConfig(String key) {
        return "gw:sys:cfg:" + key;
    }

    /** Channel cooldown marker (circuit breaker). */
    public static String channelCooldown(Long channelId) {
        return "gw:ch:cd:" + channelId;
    }
}
