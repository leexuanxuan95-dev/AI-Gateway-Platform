package com.aigateway.modules.notify.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

/** Notification template per scene (table {@code notify_template}, design doc §13). */
@Data
@TableName(value = "notify_template", autoResultMap = true)
public class NotifyTemplate {

    @TableId(type = IdType.AUTO)
    private Long id;

    /** Unique scene key, e.g. {@code low_balance}. */
    private String scene;

    /** email / sms / inmail / webhook. */
    private String channel;

    private String title;

    /** Body with {@code {placeholder}} tokens. */
    private String content;

    private Boolean enabled;
}
