package com.aigateway.modules.company.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

/** Company verification document submission (object-store keys). */
@Data
public class AuthSubmitRequest {

    @NotBlank
    private String businessLicense;

    @NotBlank
    private String legalIdFront;
}
