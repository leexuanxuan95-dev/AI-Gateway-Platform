package com.aigateway.modules.gateway.controller;

import com.aigateway.modules.gateway.service.GatewayProxyService;
import com.aigateway.modules.gateway.service.GatewayRequestSupport;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.method.annotation.StreamingResponseBody;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * OpenAI-compatible {@code POST /v1/chat/completions} (design doc §20). Validates the model
 * against the key's allow-list, freezes an estimate, proxies to LiteLLM, then settles from the
 * actual usage. Honors {@code stream:true} (SSE passthrough) and the {@code X-Project-Id} header.
 */
@RestController
@RequiredArgsConstructor
public class ChatCompletionsController {

    private static final String PATH = "/v1/chat/completions";

    private final GatewayProxyService proxy;
    private final GatewayRequestSupport support;

    @PostMapping(PATH)
    public Object chat(@RequestBody Map<String, Object> body,
                       HttpServletRequest req,
                       HttpServletResponse resp) {
        String model = support.resolveModel(body.get("model"));
        support.assertWithinLimits(body);
        Long projectId = support.resolveProjectId(req);
        long estPrompt = proxy.estimatePromptTokens(body);
        long estOutput = proxy.estimateOutputTokens(body);

        boolean stream = Boolean.TRUE.equals(body.get("stream"));
        if (stream) {
            // ensure upstream returns usage in the final chunk so we can settle on actuals
            ensureIncludeUsage(body);
            StreamingResponseBody srb = proxy.proxyStream(PATH, body, model, projectId, estPrompt, estOutput);
            return ResponseEntity.ok()
                    .contentType(MediaType.TEXT_EVENT_STREAM)
                    .header("X-Request-Id", currentRequestIdHeader(resp))
                    .body(srb);
        }
        return proxy.proxyAndBill(PATH, body, model, projectId, estPrompt, estOutput, resp);
    }

    @SuppressWarnings("unchecked")
    private void ensureIncludeUsage(Map<String, Object> body) {
        Object so = body.get("stream_options");
        Map<String, Object> opts = (so instanceof Map) ? (Map<String, Object>) so : new LinkedHashMap<>();
        opts.put("include_usage", true);
        body.put("stream_options", opts);
    }

    private String currentRequestIdHeader(HttpServletResponse resp) {
        String rid = resp.getHeader("X-Request-Id");
        return rid == null ? "" : rid;
    }
}
