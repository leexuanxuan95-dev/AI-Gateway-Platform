package com.aigateway.modules.finance.job;

import com.aigateway.modules.finance.service.impl.ExchangeRateServiceImpl;
import com.aigateway.modules.system.service.SysConfigService;
import com.fasterxml.jackson.databind.JsonNode;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import com.aigateway.common.schedule.ManagedJob;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Duration;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Hourly FX rate refresh (design doc §15.5). Fetches USD-base rates from a config-driven HTTP
 * API ({@code sys_config} key {@code fx.endpoint}, e.g. an open exchange-rates JSON endpoint
 * returning {@code {"rates": {"EUR": 0.92, ...}}}), multiplies every rate by the configured
 * safety factor ({@code aigateway.pricing.exchange-safety-factor}, e.g. 1.03) so cross-currency
 * settlement/recharge is conservative, then caches the adjusted rates in Redis (hash
 * {@code gw:fx:rates}) and persists them to {@code sys_config} ({@code fx.rates}) for durability.
 *
 * <p>Defensive: on any API/parse failure the last good rates in Redis/sys_config are kept
 * untouched (we never overwrite with a partial/empty set).</p>
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class ExchangeRateJob implements ManagedJob {

    private static final String JOB_KEY = "exchange-rate";
    private static final int SCALE = 8;
    private static final long HTTP_TIMEOUT_SECONDS = 15;

    private final SysConfigService sysConfigService;
    private final StringRedisTemplate stringRedisTemplate;
    private final WebClient.Builder webClientBuilder;

    @Value("${aigateway.pricing.exchange-safety-factor:1.03}")
    private BigDecimal safetyFactor;

    @Override
    public String jobKey() {
        return JOB_KEY;
    }

    @Override
    public String defaultCron() {
        return "0 0 * * * ?";
    }

    @Override
    public String description() {
        return "Hourly FX rate refresh from configured endpoint";
    }

    @Override
    public void execute() {
        String endpoint = sysConfigService.getString("fx.endpoint", null);
        if (endpoint == null || endpoint.isBlank()) {
            log.warn("[fx] fx.endpoint not configured; skipping FX refresh (keeping last good rates)");
            return;
        }
        try {
            JsonNode body = webClientBuilder.build().get()
                    .uri(endpoint)
                    .retrieve()
                    .bodyToMono(JsonNode.class)
                    .block(Duration.ofSeconds(HTTP_TIMEOUT_SECONDS));
            if (body == null) {
                log.warn("[fx] empty FX response from {}; keeping last good rates", endpoint);
                return;
            }
            // Accept either {"rates": {...}} or a flat {ccy: rate} object.
            JsonNode rates = body.has("rates") ? body.get("rates") : body;
            if (rates == null || !rates.isObject()) {
                log.warn("[fx] unexpected FX payload shape from {}; keeping last good rates", endpoint);
                return;
            }

            Map<String, String> adjusted = new LinkedHashMap<>();
            rates.fields().forEachRemaining(e -> {
                JsonNode val = e.getValue();
                boolean usable = val != null
                        && (val.isNumber() || (val.isTextual() && !val.asText().isBlank()));
                if (!usable) {
                    return;
                }
                try {
                    BigDecimal raw = new BigDecimal(val.asText());
                    if (raw.signum() <= 0) {
                        return;
                    }
                    BigDecimal adj = raw.multiply(safetyFactor).setScale(SCALE, RoundingMode.HALF_UP);
                    adjusted.put(e.getKey().toUpperCase(), adj.toPlainString());
                } catch (NumberFormatException ignore) {
                    // skip malformed entry
                }
            });
            // USD base is parity.
            adjusted.put("USD", BigDecimal.ONE.setScale(SCALE, RoundingMode.HALF_UP).toPlainString());

            if (adjusted.size() <= 1) {
                log.warn("[fx] no usable rates parsed from {}; keeping last good rates", endpoint);
                return;
            }

            // Cache hot (Redis hash) + persist durable (sys_config). Replace atomically-ish.
            stringRedisTemplate.delete(ExchangeRateServiceImpl.REDIS_KEY);
            stringRedisTemplate.opsForHash().putAll(ExchangeRateServiceImpl.REDIS_KEY, adjusted);

            sysConfigService.upsert(ExchangeRateServiceImpl.CONFIG_KEY, adjusted, "system",
                    "FX rates (USD base, safety-adjusted x" + safetyFactor + ")", null);

            log.info("[fx] refreshed {} rates (safety x{}) from {}", adjusted.size(), safetyFactor, endpoint);
        } catch (Exception e) {
            log.warn("[fx] refresh failed (keeping last good rates): {}", e.getMessage());
        }
    }
}
