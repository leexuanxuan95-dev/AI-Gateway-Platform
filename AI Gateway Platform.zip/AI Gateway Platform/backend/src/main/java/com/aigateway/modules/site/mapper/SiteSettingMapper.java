package com.aigateway.modules.site.mapper;

import com.aigateway.modules.site.entity.SiteSetting;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/** MyBatis-Plus mapper for {@link SiteSetting}. */
public interface SiteSettingMapper extends BaseMapper<SiteSetting> {
}
