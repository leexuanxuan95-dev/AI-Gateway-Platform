package com.aigateway.modules.user.service;

import com.aigateway.common.enums.UserStatus;
import com.aigateway.common.util.IdGen;
import com.aigateway.modules.user.entity.SysUser;
import com.aigateway.modules.user.mapper.SysUserMapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.core.annotation.Order;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.time.OffsetDateTime;

/**
 * Bootstraps the initial platform super-admin on first start (design doc §2/§14): production
 * has no factory-default account, so without this there is no way to create the FIRST super-admin
 * (registration always yields a non-admin user). Idempotent: if any super-admin already exists,
 * it does nothing.
 *
 * <p>Credentials come from {@code aigateway.admin.email} / {@code aigateway.admin.password}
 * (env {@code ADMIN_EMAIL} / {@code ADMIN_PASSWORD}). If the password is blank a strong random one
 * is generated and logged ONCE — change it immediately on first login.</p>
 */
@Slf4j
@Order(50)
@Component
@RequiredArgsConstructor
public class InitialAdminSeeder implements ApplicationRunner {

    private final SysUserMapper userMapper;
    private final PasswordEncoder passwordEncoder;

    @Value("${aigateway.admin.email:admin@aigateway.local}")
    private String adminEmail;

    @Value("${aigateway.admin.password:}")
    private String adminPassword;

    @Override
    public void run(ApplicationArguments args) {
        try {
            Long admins = userMapper.selectCount(
                    Wrappers.<SysUser>lambdaQuery().eq(SysUser::getSuperAdmin, true));
            if (admins != null && admins > 0) {
                return;
            }
            // also avoid clashing with an existing (non-admin) account on the same email
            SysUser existing = userMapper.selectOne(
                    Wrappers.<SysUser>lambdaQuery().eq(SysUser::getEmail, adminEmail));
            if (existing != null) {
                log.warn("[admin-seed] no super-admin exists but email {} is taken; "
                        + "promote it manually or set a different ADMIN_EMAIL", adminEmail);
                return;
            }

            String password = adminPassword;
            boolean generated = false;
            if (password == null || password.isBlank()) {
                password = "Adm-" + IdGen.requestId().substring(4, 18);
                generated = true;
            }

            SysUser admin = new SysUser();
            admin.setUid(IdGen.uid());
            admin.setEmail(adminEmail);
            admin.setNickname("Super Admin");
            admin.setPassword(passwordEncoder.encode(password));
            admin.setSuperAdmin(true);
            admin.setTotpEnabled(false);
            admin.setStatus(UserStatus.NORMAL);
            admin.setRegisterTime(OffsetDateTime.now());
            userMapper.insert(admin);

            if (generated) {
                log.warn("=================================================================");
                log.warn("[admin-seed] initial super-admin created: {} / {}", adminEmail, password);
                log.warn("[admin-seed] CHANGE THIS PASSWORD IMMEDIATELY (set ADMIN_PASSWORD in prod)");
                log.warn("=================================================================");
            } else {
                log.warn("[admin-seed] initial super-admin created: {} (password from ADMIN_PASSWORD)", adminEmail);
            }
        } catch (Exception e) {
            log.error("[admin-seed] failed to seed initial super-admin: {}", e.getMessage());
        }
    }
}
