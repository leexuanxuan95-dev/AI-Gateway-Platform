package com.aigateway.modules.finance.dto;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.math.BigDecimal;

/** Request to allocate balance to a model binding (design doc §10). */
@Data
public class ModelBindingRequest {

    @NotBlank
    private String modelCode;

    /** Amount to allocate to this model (added to existing allocation). */
    @NotNull
    @DecimalMin(value = "0.01", message = "amount must be at least 0.01")
    private BigDecimal amount;
}
