package com.aigateway.modules.finance.dto;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

/** Super-admin withdraw audit decision. */
@Data
public class WithdrawAuditRequest {

    /** true = approve (and pay), false = reject (and unfreeze). */
    @NotNull
    private Boolean approve;

    private String remark;
}
