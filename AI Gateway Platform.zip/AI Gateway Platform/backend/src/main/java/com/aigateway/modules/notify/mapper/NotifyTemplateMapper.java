package com.aigateway.modules.notify.mapper;

import com.aigateway.modules.notify.entity.NotifyTemplate;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/** MyBatis-Plus mapper for {@link NotifyTemplate}. */
public interface NotifyTemplateMapper extends BaseMapper<NotifyTemplate> {
}
