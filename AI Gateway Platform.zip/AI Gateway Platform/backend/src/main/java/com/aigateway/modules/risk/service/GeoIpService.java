package com.aigateway.modules.risk.service;

/**
 * GeoIP country resolution (design doc §12.2). Resolves a client IP to an ISO country code via a
 * config-driven HTTP geo API ({@code risk.geoip.*} in {@code sys_config}), Redis-cached for 24h.
 * Always fails open: any error (no config, timeout, parse failure, private IP) yields
 * {@link #UNKNOWN} so a legitimate call is never blocked by the geo lookup itself.
 */
public interface GeoIpService {

    String UNKNOWN = "UNKNOWN";

    /** Resolve {@code ip} to an upper-case ISO country code, or {@link #UNKNOWN} on any failure. */
    String countryOf(String ip);
}
