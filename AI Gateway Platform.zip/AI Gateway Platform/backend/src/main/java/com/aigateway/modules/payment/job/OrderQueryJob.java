package com.aigateway.modules.payment.job;

import com.aigateway.common.enums.RechargeStatus;
import com.aigateway.modules.finance.entity.FinRechargeOrder;
import com.aigateway.modules.finance.mapper.FinRechargeOrderMapper;
import com.aigateway.modules.payment.adapter.OrderStatus;
import com.aigateway.modules.payment.adapter.PaymentAdapter;
import com.aigateway.modules.payment.adapter.PaymentAdapterRegistry;
import com.aigateway.modules.payment.entity.PayChannelConfig;
import com.aigateway.modules.payment.service.PayChannelConfigService;
import com.aigateway.modules.payment.service.RechargeSettleService;
import com.aigateway.common.schedule.ManagedJob;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.time.OffsetDateTime;
import java.util.List;

/**
 * Polls pending recharge orders and actively queries the channel to recover from lost
 * webhooks (design doc §10.2). Runs every 60s. Expires stale orders.
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class OrderQueryJob implements ManagedJob {

    private static final String JOB_KEY = "pay-order-query";

    private final FinRechargeOrderMapper rechargeOrderMapper;
    private final PayChannelConfigService channelConfigService;
    private final PaymentAdapterRegistry adapterRegistry;
    private final RechargeSettleService rechargeSettleService;

    @Override
    public String jobKey() {
        return JOB_KEY;
    }

    @Override
    public String defaultCron() {
        return "0 * * * * *";
    }

    @Override
    public String description() {
        return "Poll pending recharge orders and recover from lost webhooks every minute";
    }

    @Override
    public void execute() {
        List<FinRechargeOrder> pending = rechargeOrderMapper.selectList(
                Wrappers.<FinRechargeOrder>lambdaQuery()
                        .eq(FinRechargeOrder::getStatus, RechargeStatus.PENDING)
                        .orderByAsc(FinRechargeOrder::getId)
                        .last("limit 200"));
        OffsetDateTime now = OffsetDateTime.now();
        for (FinRechargeOrder o : pending) {
            try {
                if (o.getExpireAt() != null && o.getExpireAt().isBefore(now)) {
                    expire(o);
                    continue;
                }
                PayChannelConfig cfg = channelConfigService.getByCode(o.getPayChannel());
                PaymentAdapter adapter = adapterRegistry.require(o.getPayChannel());
                OrderStatus st = adapter.query(o.getOrderNo(), cfg);
                if (st == OrderStatus.PAID) {
                    var cb = new com.aigateway.modules.payment.adapter.CallbackResult();
                    cb.setSuccess(true);
                    cb.setOrderNo(o.getOrderNo());
                    cb.setAmount(o.getAmount());
                    cb.setCurrency(o.getCurrency());
                    rechargeSettleService.creditPaidOrder(o, cb, null);
                    log.info("recovered paid order {} via poll", o.getOrderNo());
                } else if (st == OrderStatus.FAILED) {
                    rechargeOrderMapper.update(failed(), Wrappers.<FinRechargeOrder>lambdaUpdate()
                            .eq(FinRechargeOrder::getId, o.getId())
                            .eq(FinRechargeOrder::getStatus, RechargeStatus.PENDING));
                }
            } catch (Exception e) {
                log.warn("poll order {} failed: {}", o.getOrderNo(), e.getMessage());
            }
        }
    }

    private void expire(FinRechargeOrder o) {
        FinRechargeOrder upd = new FinRechargeOrder();
        upd.setStatus(RechargeStatus.EXPIRED);
        rechargeOrderMapper.update(upd, Wrappers.<FinRechargeOrder>lambdaUpdate()
                .eq(FinRechargeOrder::getId, o.getId())
                .eq(FinRechargeOrder::getStatus, RechargeStatus.PENDING));
    }

    private FinRechargeOrder failed() {
        FinRechargeOrder f = new FinRechargeOrder();
        f.setStatus(RechargeStatus.CANCELLED);
        return f;
    }
}
