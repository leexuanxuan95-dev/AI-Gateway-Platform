package com.aigateway.modules.billing.job;

import com.aigateway.common.schedule.ManagedJob;
import com.aigateway.modules.billing.mapper.BillingStatMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

/**
 * Pre-creates monthly partitions for the partitioned billing tables (design doc §11).
 * Runs the same {@code CREATE TABLE ... PARTITION OF} DDL as {@code init.sql} for the next
 * three months so inserts never hit a missing partition. Idempotent ({@code IF NOT EXISTS}).
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class PartitionCreateJob implements ManagedJob {

    private static final String JOB_KEY = "partition-create";

    private static final DateTimeFormatter SUFFIX = DateTimeFormatter.ofPattern("yyyyMM");
    private static final DateTimeFormatter DATE = DateTimeFormatter.ISO_LOCAL_DATE;

    /** Number of upcoming months (beyond the current one) to pre-provision partitions for. */
    private static final int MONTHS_AHEAD = 3;

    private final BillingStatMapper billingStatMapper;

    @Override
    public String jobKey() {
        return JOB_KEY;
    }

    @Override
    public String defaultCron() {
        return "0 0 1 25 * ?";
    }

    @Override
    public String description() {
        return "Pre-create monthly partitions for partitioned billing tables";
    }

    /** Also run once at startup so a fresh deploy has current partitions. */
    @Override
    public boolean runOnStartup() {
        return true;
    }

    @Override
    public void execute() {
        ensure();
    }

    private void ensure() {
        LocalDate firstOfMonth = LocalDate.now().withDayOfMonth(1);
        for (int m = 0; m <= MONTHS_AHEAD; m++) {
            LocalDate start = firstOfMonth.plusMonths(m);
            LocalDate end = start.plusMonths(1);
            String suffix = start.format(SUFFIX);
            try {
                billingStatMapper.createBillTokenPartition(suffix, start.format(DATE), end.format(DATE));
                billingStatMapper.createCallLogPartition(suffix, start.format(DATE), end.format(DATE));
            } catch (Exception e) {
                log.warn("partition create for {} failed: {}", suffix, e.getMessage());
            }
        }
        log.info("[partition-create] ensured partitions through {} months ahead", MONTHS_AHEAD);
    }
}
