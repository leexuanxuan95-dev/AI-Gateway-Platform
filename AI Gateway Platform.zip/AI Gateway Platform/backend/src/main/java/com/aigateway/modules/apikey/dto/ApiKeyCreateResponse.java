package com.aigateway.modules.apikey.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * Response returned exactly once on key creation. {@code rawKey} is the only time
 * the plaintext secret is ever exposed; it is not persisted in plaintext.
 */
@Data
@AllArgsConstructor
public class ApiKeyCreateResponse {

    /** The plaintext {@code sk-...} key — shown once, store it now. */
    private String rawKey;

    /** Safe metadata view of the created key. */
    private ApiKeyView key;
}
