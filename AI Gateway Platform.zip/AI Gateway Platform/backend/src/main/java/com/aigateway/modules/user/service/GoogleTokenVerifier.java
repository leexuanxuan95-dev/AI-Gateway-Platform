package com.aigateway.modules.user.service;

import com.aigateway.common.exception.BizException;
import com.aigateway.common.exception.ErrorCode;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.reactive.function.client.WebClient;

import java.time.Duration;
import java.util.Set;

/**
 * Verifies Google OAuth ID tokens (design doc §3 third-party login). Calls Google's
 * {@code tokeninfo} endpoint, which validates the JWT signature, then we additionally check
 * {@code aud} (against the configured client id, when set), {@code iss} and {@code exp}.
 *
 * <p>The expected audience comes from {@code aigateway.oauth.google.client-id}; when blank
 * (e.g. dev) the {@code aud} check is skipped but signature/iss/exp are still enforced.
 */
@Slf4j
@Component
public class GoogleTokenVerifier {

    private static final String TOKENINFO_URL = "https://oauth2.googleapis.com/tokeninfo?id_token=";
    private static final Set<String> VALID_ISS =
            Set.of("accounts.google.com", "https://accounts.google.com");
    /** Timeout for the blocking tokeninfo call. */
    private static final Duration TOKENINFO_TIMEOUT = Duration.ofSeconds(10);
    /** Milliseconds per second, for converting the {@code exp} epoch-seconds claim. */
    private static final long MILLIS_PER_SECOND = 1000L;

    private final WebClient webClient;
    private final ObjectMapper objectMapper;
    private final String expectedClientId;

    public GoogleTokenVerifier(WebClient.Builder webClientBuilder,
                               ObjectMapper objectMapper,
                               @Value("${aigateway.oauth.google.client-id:}") String expectedClientId) {
        this.webClient = webClientBuilder.build();
        this.objectMapper = objectMapper;
        this.expectedClientId = expectedClientId;
    }

    /** Verify the token and return the validated claims, or throw {@link BizException} UNAUTHORIZED. */
    public GoogleClaims verify(String idToken) {
        if (!StringUtils.hasText(idToken)) {
            throw new BizException(ErrorCode.UNAUTHORIZED, "missing google id token");
        }
        String body;
        try {
            body = webClient.get()
                    .uri(TOKENINFO_URL + idToken)
                    .retrieve()
                    .bodyToMono(String.class)
                    .block(TOKENINFO_TIMEOUT);
        } catch (Exception e) {
            log.warn("google tokeninfo call failed: {}", e.getMessage());
            throw new BizException(ErrorCode.UNAUTHORIZED, "google token verification failed");
        }
        if (!StringUtils.hasText(body)) {
            throw new BizException(ErrorCode.UNAUTHORIZED, "google token verification failed");
        }

        JsonNode node;
        try {
            node = objectMapper.readTree(body);
        } catch (Exception e) {
            throw new BizException(ErrorCode.UNAUTHORIZED, "google token unparsable");
        }
        // tokeninfo returns an "error"/"error_description" field for invalid/expired tokens
        if (node.hasNonNull("error") || node.hasNonNull("error_description")) {
            throw new BizException(ErrorCode.UNAUTHORIZED, "invalid google token");
        }

        String iss = text(node, "iss");
        if (iss == null || !VALID_ISS.contains(iss)) {
            throw new BizException(ErrorCode.UNAUTHORIZED, "invalid google issuer");
        }

        String aud = text(node, "aud");
        if (StringUtils.hasText(expectedClientId) && !expectedClientId.equals(aud)) {
            throw new BizException(ErrorCode.UNAUTHORIZED, "google audience mismatch");
        }

        long exp = node.path("exp").asLong(0L); // seconds since epoch
        if (exp <= 0L || exp * MILLIS_PER_SECOND <= System.currentTimeMillis()) {
            throw new BizException(ErrorCode.UNAUTHORIZED, "google token expired");
        }

        String sub = text(node, "sub");
        if (!StringUtils.hasText(sub)) {
            throw new BizException(ErrorCode.UNAUTHORIZED, "google token missing subject");
        }

        GoogleClaims claims = new GoogleClaims();
        claims.setSub(sub);
        claims.setEmail(text(node, "email"));
        claims.setEmailVerified("true".equalsIgnoreCase(text(node, "email_verified")));
        claims.setName(text(node, "name"));
        claims.setPicture(text(node, "picture"));
        return claims;
    }

    private static String text(JsonNode node, String field) {
        JsonNode v = node.get(field);
        return v == null || v.isNull() ? null : v.asText();
    }

    /** Validated subset of Google ID-token claims. */
    @Data
    public static class GoogleClaims {
        private String sub;
        private String email;
        private boolean emailVerified;
        private String name;
        private String picture;
    }
}
