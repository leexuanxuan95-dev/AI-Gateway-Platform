package com.aigateway.modules.user.service;

import com.aigateway.common.api.PageResult;
import com.aigateway.modules.user.dto.ChangeContactRequest;
import com.aigateway.modules.user.dto.ChangePasswordRequest;
import com.aigateway.modules.user.dto.ProfileUpdateRequest;
import com.aigateway.modules.user.dto.SessionView;
import com.aigateway.modules.user.dto.TotpSetupResponse;
import com.aigateway.modules.user.dto.UserInfo;
import com.aigateway.modules.user.entity.LoginLog;
import com.aigateway.modules.user.entity.SysUser;

import java.util.List;

/** User profile, password and 2FA management for the current user. */
public interface UserService {

    /** Current profile + memberships. */
    UserInfo me();

    /** Assemble a {@link UserInfo} including the companies list for the given active context. */
    UserInfo buildUserInfo(SysUser user, Long activeCompanyId, String activeRole);

    void updateProfile(ProfileUpdateRequest req);

    void changePassword(ChangePasswordRequest req);

    /**
     * Change the bound email/mobile after step-up re-verification (design doc §3.3): a valid
     * current password OR a fresh verification code sent to the new target.
     */
    void changeContact(ChangeContactRequest req);

    /** List the current user's active sessions/devices; {@code currentRefreshToken} flags the caller. */
    List<SessionView> listSessions(String currentRefreshToken);

    /** Revoke a single session by its refresh-token id. */
    void revokeSession(String tokenId);

    /** Revoke every session except the caller's ({@code currentRefreshToken}); null kicks all. */
    void revokeOtherSessions(String currentRefreshToken);

    /** Generate a new TOTP secret (encrypted+stored, not yet enabled) and return enrollment data. */
    TotpSetupResponse totpSetup();

    /** Verify a code against the pending secret and enable 2FA. */
    void totpEnable(String code);

    /**
     * Disable 2FA. Step-up re-verification (design doc §3.3): requires a valid current TOTP
     * {@code code} AND, when the account has a password set, a matching current {@code password}.
     */
    void totpDisable(String code, String password);

    /** Paged login logs for the current user. */
    PageResult<LoginLog> loginLogs(long current, long size);
}
