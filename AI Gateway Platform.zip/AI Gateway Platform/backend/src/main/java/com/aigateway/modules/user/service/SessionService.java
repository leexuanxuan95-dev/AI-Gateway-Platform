package com.aigateway.modules.user.service;

import com.aigateway.modules.user.dto.SessionView;

import java.util.List;

/**
 * Per-user active session / device registry backed by Redis (design doc §3.3).
 *
 * <p>Each issued refresh token is registered as a session under a per-user hash
 * ({@code gw:sessions:{userId}} -> tokenId -> metadata). This lets the user list their
 * active devices and remotely revoke individual sessions or kick everyone else. The
 * opaque refresh token itself remains stored separately ({@code gw:refresh:{token}} ->
 * userId) by the auth service; revoking a session deletes both entries so the refresh
 * token can no longer mint access tokens.
 */
public interface SessionService {

    /** Register a newly-issued refresh token as an active session for the user. */
    void register(Long userId, String tokenId, String ip, String userAgent);

    /** Remove a session from the registry (does not touch the refresh-token entry). */
    void deregister(Long userId, String tokenId);

    /** List active sessions; {@code currentTokenId} (nullable) is flagged as {@code current}. */
    List<SessionView> list(Long userId, String currentTokenId);

    /** Revoke a single session: removes it from the registry AND invalidates its refresh token. */
    void revoke(Long userId, String tokenId);

    /** Revoke every session except {@code keepTokenId} (nullable to kick all). */
    void revokeAllExcept(Long userId, String keepTokenId);

    /** True if this ip/userAgent has not been seen in the user's recent sessions (new device). */
    boolean isNewDevice(Long userId, String ip, String userAgent);
}
