package com.aigateway.common.web;

import com.aigateway.common.exception.BizException;
import com.aigateway.common.exception.ErrorCode;

import java.net.InetAddress;
import java.net.URI;
import java.net.UnknownHostException;
import java.util.Locale;

/**
 * SSRF guard for tenant-supplied outbound URLs.
 *
 * <p>{@link #assertSafe(String)} accepts only {@code http}/{@code https} URLs whose host
 * resolves exclusively to publicly routable addresses. It rejects loopback, link-local,
 * site-local (RFC 1918 private), wildcard/any-local and multicast addresses, as well as the
 * cloud instance-metadata address {@code 169.254.169.254}. This stops a tenant from coaxing
 * the platform into making requests to internal services or the metadata endpoint.</p>
 *
 * <p><b>Trust model:</b> this validator is intended for <em>tenant-controlled</em> URLs only
 * &mdash; chiefly the customer-configured notify <b>webhook</b> target. Platform-admin
 * (super-admin only) configured URLs such as upstream provider base URLs, geo-IP / FX /
 * email-provider endpoints are considered trusted and are deliberately <em>not</em> routed
 * through this check.</p>
 */
public final class SafeUrlValidator {

    /** Cloud instance metadata service address (AWS/GCP/Azure/etc.). */
    private static final String METADATA_IP = "169.254.169.254";

    private SafeUrlValidator() {
    }

    /**
     * Validate that {@code url} is an http/https URL pointing at a public address.
     *
     * @throws BizException with {@link ErrorCode#PARAM_ERROR} if the URL is malformed,
     *                       uses a non-http(s) scheme, cannot be resolved, or resolves to a
     *                       private/loopback/link-local/wildcard/multicast/metadata address.
     */
    public static void assertSafe(String url) {
        if (url == null || url.isBlank()) {
            throw new BizException(ErrorCode.PARAM_ERROR, "url is blank");
        }
        URI uri;
        try {
            uri = new URI(url.trim());
        } catch (Exception e) {
            throw new BizException(ErrorCode.PARAM_ERROR, "malformed url");
        }
        String scheme = uri.getScheme();
        if (scheme == null
                || !("http".equalsIgnoreCase(scheme) || "https".equalsIgnoreCase(scheme))) {
            throw new BizException(ErrorCode.PARAM_ERROR, "only http/https urls are allowed");
        }
        String host = uri.getHost();
        if (host == null || host.isBlank()) {
            throw new BizException(ErrorCode.PARAM_ERROR, "url has no host");
        }
        // Defensive: reject obvious metadata host before DNS as well.
        String normalizedHost = host.toLowerCase(Locale.ROOT);
        if (METADATA_IP.equals(normalizedHost)) {
            throw new BizException(ErrorCode.PARAM_ERROR, "url targets a blocked address");
        }

        InetAddress[] addresses;
        try {
            addresses = InetAddress.getAllByName(host);
        } catch (UnknownHostException e) {
            throw new BizException(ErrorCode.PARAM_ERROR, "url host cannot be resolved");
        }
        if (addresses == null || addresses.length == 0) {
            throw new BizException(ErrorCode.PARAM_ERROR, "url host cannot be resolved");
        }
        for (InetAddress addr : addresses) {
            if (isBlocked(addr)) {
                throw new BizException(ErrorCode.PARAM_ERROR, "url targets a non-public address");
            }
        }
    }

    /** True if the address is one we must never let tenant URLs reach. */
    private static boolean isBlocked(InetAddress addr) {
        if (addr == null) {
            return true;
        }
        if (METADATA_IP.equals(addr.getHostAddress())) {
            return true;
        }
        return addr.isLoopbackAddress()
                || addr.isSiteLocalAddress()
                || addr.isLinkLocalAddress()
                || addr.isAnyLocalAddress()
                || addr.isMulticastAddress();
    }
}
