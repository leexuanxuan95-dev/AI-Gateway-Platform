package com.aigateway.modules.payment.mapper;

import com.aigateway.modules.payment.entity.PayReconcile;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/** MyBatis-Plus mapper for {@link PayReconcile}. */
public interface PayReconcileMapper extends BaseMapper<PayReconcile> {
}
