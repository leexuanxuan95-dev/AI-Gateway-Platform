package com.aigateway.modules.model.entity;

import com.aigateway.common.enums.CommonStatus;
import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.time.OffsetDateTime;

/**
 * One LiteLLM deployment registered for a single upstream key (table {@code litellm_deployment}).
 * Each ACTIVE {@link com.aigateway.modules.channel.entity.ChannelApiKey} of a channel becomes its
 * own LiteLLM deployment of every enabled model on that channel, so LiteLLM can load-balance and
 * fail over across the channel's keys. The row is removed (and the LiteLLM model deleted) when the
 * key is banned/disabled/deleted.
 */
@Data
@TableName(value = "litellm_deployment", autoResultMap = true)
public class LitellmDeployment {

    @TableId(type = IdType.AUTO)
    private Long id;

    /** Owning channel id. */
    private Long channelId;

    /** {@link com.aigateway.modules.channel.entity.ChannelApiKey#getId()} this deployment serves. */
    private Long keyId;

    /** Public model code, e.g. {@code claude-opus-4-8} ({@code model_name} in LiteLLM). */
    private String modelCode;

    /** Upstream model id called on the channel (provider-specific). */
    private String upstreamModel;

    /** The {@code model_id} returned by LiteLLM {@code POST /model/new}; used to delete it later. */
    private String litellmModelId;

    /** 1 active. */
    private CommonStatus status;

    @TableField(fill = FieldFill.INSERT)
    private OffsetDateTime createdAt;

    @TableField(fill = FieldFill.INSERT_UPDATE)
    private OffsetDateTime updatedAt;
}
