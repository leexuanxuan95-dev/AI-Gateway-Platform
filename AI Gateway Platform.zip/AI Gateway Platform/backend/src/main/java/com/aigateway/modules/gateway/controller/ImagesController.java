package com.aigateway.modules.gateway.controller;

import com.aigateway.modules.gateway.service.GatewayProxyService;
import com.aigateway.modules.gateway.service.GatewayRequestSupport;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

/**
 * {@code POST /v1/images/generations} (design doc §20.4). Image responses carry no token usage, so
 * this bills per image (n) via {@link GatewayProxyService#proxyUnitAndBill} using the model's
 * per-image cost, applying the standard min-margin markup. A quality multiplier (hd = 2x) and a
 * size multiplier scale the per-image unit.
 */
@RestController
@RequiredArgsConstructor
public class ImagesController {

    private static final String PATH = "/v1/images/generations";

    private final GatewayProxyService proxy;
    private final GatewayRequestSupport support;

    @PostMapping(PATH)
    public String images(@RequestBody Map<String, Object> body,
                         HttpServletRequest req,
                         HttpServletResponse resp) {
        String model = support.resolveModel(body.get("model"));
        Long projectId = support.resolveProjectId(req);
        long units = imageUnits(body);
        return proxy.proxyUnitAndBill(PATH, body, model, projectId, "image", units, resp);
    }

    /** Billable image units = n * quality-multiplier * size-multiplier (min 1). */
    private long imageUnits(Map<String, Object> body) {
        long n = 1;
        Object nObj = body.get("n");
        if (nObj instanceof Number num) {
            n = Math.max(1, num.longValue());
        }
        long mult = 1;
        Object quality = body.get("quality");
        if (quality != null && "hd".equalsIgnoreCase(String.valueOf(quality))) {
            mult *= 2;
        }
        Object size = body.get("size");
        if (size != null) {
            String s = String.valueOf(size);
            // larger canvases cost more upstream; coarse 2x for >= 1024 dimension
            if (s.contains("1792") || s.contains("2048")) {
                mult *= 2;
            }
        }
        return Math.max(1, n * mult);
    }
}
