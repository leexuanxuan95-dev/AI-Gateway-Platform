package com.aigateway.modules.company.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

/** Create a member invitation. */
@Data
public class InviteRequest {

    /** Target role: ADMIN / DEVELOPER / VIEWER. */
    @NotBlank
    private String role;

    /** Optional invitee email. */
    private String email;
}
