package com.aigateway.modules.site.controller;

import com.aigateway.common.api.R;
import com.aigateway.common.exception.BizException;
import com.aigateway.common.exception.ErrorCode;
import com.aigateway.modules.site.service.SiteCmsService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

/**
 * Public OmniRoute landing content API (OmniRoute doc §4.3). Read-only, strongly
 * cached (Redis, ~5min). Both paths are permit-all in {@code SecurityConfig}:
 * {@code /api/site/landing} (already permitted) and {@code /api/site/preview/**}.
 */
@RestController
@RequestMapping("/api/site")
@RequiredArgsConstructor
public class SiteLandingController {

    private final SiteCmsService siteCmsService;

    /** Latest published landing snapshot for a language; falls back to draft on a fresh install. */
    @GetMapping("/landing")
    public R<Map<String, Object>> landing(@RequestParam(defaultValue = "zh") String lang) {
        return R.ok(siteCmsService.getLanding(lang));
    }

    /** Read a preview snapshot by token (used by the back-office preview link). */
    @GetMapping("/preview/{token}")
    public R<Map<String, Object>> preview(@PathVariable String token) {
        Map<String, Object> snapshot = siteCmsService.getPreview(token);
        if (snapshot == null) {
            throw new BizException(ErrorCode.NOT_FOUND, "preview expired or not found");
        }
        return R.ok(snapshot);
    }
}
