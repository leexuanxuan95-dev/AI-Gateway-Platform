package com.aigateway.modules.risk.mapper;

import com.aigateway.modules.risk.entity.RiskBlacklist;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/** MyBatis-Plus mapper for {@link RiskBlacklist}. */
public interface RiskBlacklistMapper extends BaseMapper<RiskBlacklist> {
}
