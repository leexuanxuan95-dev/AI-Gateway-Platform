package com.aigateway.modules.channel.mapper;

import com.aigateway.modules.channel.entity.Channel;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/** MyBatis-Plus mapper for {@link Channel}. */
public interface ChannelMapper extends BaseMapper<Channel> {
}
