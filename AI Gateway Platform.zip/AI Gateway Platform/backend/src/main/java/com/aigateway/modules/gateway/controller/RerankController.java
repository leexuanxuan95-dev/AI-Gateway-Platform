package com.aigateway.modules.gateway.controller;

import com.aigateway.modules.gateway.service.GatewayProxyService;
import com.aigateway.modules.gateway.service.GatewayRequestSupport;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

/**
 * {@code POST /v1/rerank} (design doc §20.4). Billed per query+document unit (1 query x N documents)
 * via the model's per-unit cost through the standard min-margin markup.
 */
@RestController
@RequiredArgsConstructor
public class RerankController {

    private static final String PATH = "/v1/rerank";

    private final GatewayProxyService proxy;
    private final GatewayRequestSupport support;

    @PostMapping(PATH)
    public String rerank(@RequestBody Map<String, Object> body,
                         HttpServletRequest req,
                         HttpServletResponse resp) {
        String model = support.resolveModel(body.get("model"));
        Long projectId = support.resolveProjectId(req);
        long units = rerankUnits(body);
        return proxy.proxyUnitAndBill(PATH, body, model, projectId, "query", units, resp);
    }

    /** Billable units = number of documents (one query reranks N docs); min 1. */
    private long rerankUnits(Map<String, Object> body) {
        Object docs = body.get("documents");
        if (docs instanceof List<?> list) {
            return Math.max(1, list.size());
        }
        return 1;
    }
}
