package com.aigateway.modules.payment.adapter;

import com.aigateway.common.crypto.AesUtil;
import com.aigateway.common.exception.BizException;
import com.aigateway.common.exception.ErrorCode;
import com.aigateway.modules.finance.entity.FinRechargeOrder;
import com.aigateway.modules.payment.entity.PayChannelConfig;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

/**
 * Functional Alipay adapter (design doc §10.2) implemented WITHOUT the Alipay SDK, using only
 * {@code java.security} RSA2 (SHA256withRSA) signing/verification and {@link WebClient}.
 *
 * <ul>
 *   <li>{@code createOrder}: builds an {@code alipay.trade.page.pay} request, signs the sorted
 *       parameter string with RSA2 and returns the gateway redirect URL as
 *       {@link PrepayResult#setPayUrl}.</li>
 *   <li>{@code handleCallback}: parses the async-notify form params, verifies the RSA2 signature
 *       against the Alipay public key (excluding {@code sign}/{@code sign_type}, sorted), and
 *       requires {@code trade_status=TRADE_SUCCESS}.</li>
 *   <li>{@code query}: issues a signed {@code alipay.trade.query} GET.</li>
 * </ul>
 *
 * <p>Credentials (all AES-encrypted at rest, never logged): {@code appId},
 * {@code privateKey} (merchant RSA private key, PKCS8 base64), {@code alipayPublicKey}
 * (Alipay RSA public key, X.509 base64). The gateway host follows {@code env_mode}:
 * production = {@code https://openapi.alipay.com/gateway.do}, sandbox =
 * {@code https://openapi.alipaydev.com/gateway.do}.</p>
 */
@Slf4j
@Component
public class AlipayAdapter extends AbstractStubAdapter {

    private static final String PROD_GATEWAY = "https://openapi.alipay.com/gateway.do";
    private static final String SANDBOX_GATEWAY = "https://openapi.alipaydev.com/gateway.do";
    private static final DateTimeFormatter TS_FMT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    private final WebClient webClient;
    private final ObjectMapper objectMapper = new ObjectMapper();

    @Value("${aigateway.pay.alipay.notify-url:https://app.example.com/api/pay/callback/alipay}")
    private String notifyUrl;

    @Value("${aigateway.pay.alipay.return-url:https://app.example.com/recharge/success}")
    private String returnUrl;

    public AlipayAdapter(AesUtil aesUtil, WebClient.Builder webClientBuilder) {
        super(aesUtil);
        this.webClient = webClientBuilder.build();
    }

    @Override
    public String code() {
        return "alipay";
    }

    private String gateway(PayChannelConfig c) {
        return "sandbox".equalsIgnoreCase(c.getEnvMode()) ? SANDBOX_GATEWAY : PROD_GATEWAY;
    }

    @Override
    public PrepayResult createOrder(FinRechargeOrder o, PayChannelConfig c) {
        String appId = cred(c, "appId");
        String privateKey = cred(c, "privateKey");
        if (appId == null || privateKey == null) {
            throw new BizException(ErrorCode.PAY_CHANNEL_DISABLED, "alipay not configured");
        }
        try {
            String amount = o.getAmount().setScale(2, RoundingMode.HALF_UP).toPlainString();
            Map<String, String> biz = new HashMap<>();
            biz.put("out_trade_no", o.getOrderNo());
            biz.put("total_amount", amount);
            biz.put("subject", "Account recharge " + o.getOrderNo());
            biz.put("product_code", "FAST_INSTANT_TRADE_PAY");
            String bizContent = objectMapper.writeValueAsString(biz);

            TreeMap<String, String> params = baseParams(appId, "alipay.trade.page.pay");
            params.put("notify_url", notifyUrl);
            params.put("return_url", returnUrl);
            params.put("biz_content", bizContent);

            String sign = rsa2Sign(buildSignContent(params), privateKey);
            params.put("sign", sign);

            String query = buildQuery(params);
            PrepayResult r = new PrepayResult();
            r.setPayUrl(gateway(c) + "?" + query);
            return r;
        } catch (BizException e) {
            throw e;
        } catch (Exception e) {
            log.error("alipay create order failed for {}: {}", o.getOrderNo(), e.getMessage());
            throw new BizException(ErrorCode.SYSTEM_ERROR, "alipay create order failed");
        }
    }

    @Override
    public CallbackResult handleCallback(String body, Map<String, String> headers, PayChannelConfig c) {
        CallbackResult r = new CallbackResult();
        r.setSuccess(false);
        try {
            Map<String, String> params = parseForm(body);
            String sign = params.get("sign");
            String signType = params.get("sign_type");
            if (sign == null) {
                return r;
            }
            String alipayPublicKey = cred(c, "alipayPublicKey");
            if (alipayPublicKey == null) {
                log.warn("alipay public key not configured; refusing callback");
                return r;
            }
            // Build the to-verify content: exclude sign + sign_type, sort, do NOT url-encode values.
            TreeMap<String, String> toVerify = new TreeMap<>();
            for (Map.Entry<String, String> e : params.entrySet()) {
                if (!"sign".equals(e.getKey()) && !"sign_type".equals(e.getKey()) && e.getValue() != null) {
                    toVerify.put(e.getKey(), e.getValue());
                }
            }
            boolean ok = rsa2Verify(buildSignContent(toVerify), sign, alipayPublicKey);
            if (!ok) {
                log.warn("alipay callback signature invalid");
                return r;
            }
            if (signType != null && !"RSA2".equalsIgnoreCase(signType)) {
                log.warn("alipay callback unexpected sign_type");
                return r;
            }
            String tradeStatus = params.get("trade_status");
            if (!"TRADE_SUCCESS".equals(tradeStatus) && !"TRADE_FINISHED".equals(tradeStatus)) {
                return r;
            }
            r.setOrderNo(params.get("out_trade_no"));
            r.setThirdTxnId(params.get("trade_no"));
            String total = params.get("total_amount");
            if (total != null) {
                r.setAmount(new BigDecimal(total));
            }
            // Alipay settles in CNY by default; echo configured currency if present.
            r.setCurrency("CNY");
            r.setSuccess(true);
            return r;
        } catch (Exception e) {
            log.warn("alipay callback handling failed: {}", e.getMessage());
            r.setSuccess(false);
            return r;
        }
    }

    @Override
    public OrderStatus query(String orderNo, PayChannelConfig c) {
        String appId = cred(c, "appId");
        String privateKey = cred(c, "privateKey");
        String alipayPublicKey = cred(c, "alipayPublicKey");
        if (appId == null || privateKey == null) {
            return OrderStatus.PENDING;
        }
        try {
            Map<String, String> biz = new HashMap<>();
            biz.put("out_trade_no", orderNo);
            String bizContent = objectMapper.writeValueAsString(biz);

            TreeMap<String, String> params = baseParams(appId, "alipay.trade.query");
            params.put("biz_content", bizContent);
            String sign = rsa2Sign(buildSignContent(params), privateKey);
            params.put("sign", sign);

            String url = gateway(c) + "?" + buildQuery(params);
            String resp = webClient.get().uri(url)
                    .retrieve().bodyToMono(String.class)
                    .block(java.time.Duration.ofSeconds(15));
            if (resp == null) {
                return OrderStatus.PENDING;
            }
            var root = objectMapper.readTree(resp);
            var node = root.path("alipay_trade_query_response");
            // Optionally verify response sign with alipayPublicKey if present.
            if (alipayPublicKey != null && root.hasNonNull("sign")) {
                // Best-effort: response signing verification is left to gateway TLS here.
                log.debug("alipay query response sign present");
            }
            String tradeStatus = node.path("trade_status").asText("");
            if ("TRADE_SUCCESS".equals(tradeStatus) || "TRADE_FINISHED".equals(tradeStatus)) {
                return OrderStatus.PAID;
            }
            if ("TRADE_CLOSED".equals(tradeStatus)) {
                return OrderStatus.FAILED;
            }
            return OrderStatus.PENDING;
        } catch (Exception e) {
            log.warn("alipay query failed for {}: {}", orderNo, e.getMessage());
            return OrderStatus.PENDING;
        }
    }

    // ---------- helpers ----------

    private TreeMap<String, String> baseParams(String appId, String method) {
        TreeMap<String, String> p = new TreeMap<>();
        p.put("app_id", appId);
        p.put("method", method);
        p.put("format", "JSON");
        p.put("charset", "utf-8");
        p.put("sign_type", "RSA2");
        p.put("timestamp", LocalDateTime.now().format(TS_FMT));
        p.put("version", "1.0");
        return p;
    }

    /** Build the canonical "k=v&k=v" content (sorted, raw values) used for RSA2 signing/verify. */
    private String buildSignContent(TreeMap<String, String> params) {
        StringBuilder sb = new StringBuilder();
        for (Map.Entry<String, String> e : params.entrySet()) {
            if (e.getValue() == null || e.getValue().isEmpty()) {
                continue;
            }
            if (sb.length() > 0) {
                sb.append('&');
            }
            sb.append(e.getKey()).append('=').append(e.getValue());
        }
        return sb.toString();
    }

    /** Build a url-encoded query string from signed params. */
    private String buildQuery(TreeMap<String, String> params) {
        StringBuilder sb = new StringBuilder();
        for (Map.Entry<String, String> e : params.entrySet()) {
            if (e.getValue() == null) {
                continue;
            }
            if (sb.length() > 0) {
                sb.append('&');
            }
            sb.append(e.getKey()).append('=')
                    .append(URLEncoder.encode(e.getValue(), StandardCharsets.UTF_8));
        }
        return sb.toString();
    }

    private Map<String, String> parseForm(String body) {
        Map<String, String> map = new HashMap<>();
        if (body == null || body.isBlank()) {
            return map;
        }
        for (String pair : body.split("&")) {
            int idx = pair.indexOf('=');
            if (idx < 0) {
                continue;
            }
            String k = URLDecoder.decode(pair.substring(0, idx), StandardCharsets.UTF_8);
            String v = URLDecoder.decode(pair.substring(idx + 1), StandardCharsets.UTF_8);
            map.put(k, v);
        }
        return map;
    }

    private String rsa2Sign(String content, String privateKeyB64) throws Exception {
        byte[] keyBytes = Base64.getDecoder().decode(normalizePem(privateKeyB64));
        PrivateKey priv = KeyFactory.getInstance("RSA")
                .generatePrivate(new PKCS8EncodedKeySpec(keyBytes));
        Signature sig = Signature.getInstance("SHA256withRSA");
        sig.initSign(priv);
        sig.update(content.getBytes(StandardCharsets.UTF_8));
        return Base64.getEncoder().encodeToString(sig.sign());
    }

    private boolean rsa2Verify(String content, String signB64, String publicKeyB64) {
        try {
            byte[] keyBytes = Base64.getDecoder().decode(normalizePem(publicKeyB64));
            PublicKey pub = KeyFactory.getInstance("RSA")
                    .generatePublic(new X509EncodedKeySpec(keyBytes));
            Signature sig = Signature.getInstance("SHA256withRSA");
            sig.initVerify(pub);
            sig.update(content.getBytes(StandardCharsets.UTF_8));
            return sig.verify(Base64.getDecoder().decode(signB64));
        } catch (Exception e) {
            log.warn("alipay rsa2 verify error: {}", e.getMessage());
            return false;
        }
    }

    /** Strip PEM headers/whitespace so a raw base64 key body remains. */
    private String normalizePem(String key) {
        return key.replaceAll("-----BEGIN [^-]+-----", "")
                .replaceAll("-----END [^-]+-----", "")
                .replaceAll("\\s", "");
    }
}
