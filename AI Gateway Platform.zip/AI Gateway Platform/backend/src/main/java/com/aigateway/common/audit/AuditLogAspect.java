package com.aigateway.common.audit;

import com.aigateway.common.security.AuthRateLimitFilter;
import com.aigateway.common.security.LoginUser;
import com.aigateway.common.security.UserContext;
import com.aigateway.common.web.RequestIdFilter;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.slf4j.MDC;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import java.time.OffsetDateTime;

/**
 * Persists an audit record for every {@link AuditLog}-annotated method, capturing the
 * acting user, company, request id, client ip, outcome and latency. Writes are async so
 * they never slow the request; failures to audit are logged but never propagated.
 */
@Slf4j
@Aspect
@Component
@RequiredArgsConstructor
public class AuditLogAspect {

    /** Max stored length of a captured error message. */
    private static final int ERROR_MSG_MAX_LEN = 500;

    private final com.aigateway.common.audit.mapper.SysAuditLogMapper auditMapper;

    @Around("@annotation(auditLog)")
    public Object around(ProceedingJoinPoint pjp, AuditLog auditLog) throws Throwable {
        long start = System.currentTimeMillis();
        SysAuditLog record = new SysAuditLog();
        record.setAction(auditLog.value());
        record.setModule(auditLog.module());
        record.setMethod(((MethodSignature) pjp.getSignature()).getMethod().getName());
        record.setRequestId(MDC.get(RequestIdFilter.MDC_KEY));
        record.setCreatedAt(OffsetDateTime.now());
        LoginUser u = UserContext.get();
        if (u != null) {
            record.setUserId(u.getUserId());
            record.setCompanyId(u.getCompanyId());
        }
        HttpServletRequest req = currentRequest();
        if (req != null) {
            record.setUri(req.getRequestURI());
            record.setIp(AuthRateLimitFilter.clientIp(req));
        }
        try {
            Object result = pjp.proceed();
            record.setStatus(1);
            return result;
        } catch (Throwable t) {
            record.setStatus(0);
            record.setErrorMsg(truncate(t.getMessage()));
            throw t;
        } finally {
            record.setCostMs(System.currentTimeMillis() - start);
            save(record);
        }
    }

    @Async
    void save(SysAuditLog record) {
        try {
            auditMapper.insert(record);
        } catch (Exception e) {
            log.warn("audit log persist failed: {}", e.getMessage());
        }
    }

    private HttpServletRequest currentRequest() {
        var attrs = RequestContextHolder.getRequestAttributes();
        return attrs instanceof ServletRequestAttributes sra ? sra.getRequest() : null;
    }

    private String truncate(String s) {
        if (s == null) {
            return null;
        }
        return s.length() > ERROR_MSG_MAX_LEN ? s.substring(0, ERROR_MSG_MAX_LEN) : s;
    }
}
