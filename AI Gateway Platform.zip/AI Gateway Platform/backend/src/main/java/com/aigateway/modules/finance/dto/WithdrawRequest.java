package com.aigateway.modules.finance.dto;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Map;

/** Withdraw application request (design doc §10). */
@Data
public class WithdrawRequest {

    @NotNull
    @DecimalMin(value = "0.01", message = "amount must be at least 0.01")
    private BigDecimal amount;

    /** wise/bank/usdt. */
    @NotBlank
    private String channel;

    /** Beneficiary account details (encrypted at rest before persist). */
    @NotNull
    private Map<String, Object> accountInfo;
}
