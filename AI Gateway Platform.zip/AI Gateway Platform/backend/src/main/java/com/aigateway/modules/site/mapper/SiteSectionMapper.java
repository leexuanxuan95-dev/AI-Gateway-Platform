package com.aigateway.modules.site.mapper;

import com.aigateway.modules.site.entity.SiteSection;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/** MyBatis-Plus mapper for {@link SiteSection}. */
public interface SiteSectionMapper extends BaseMapper<SiteSection> {
}
