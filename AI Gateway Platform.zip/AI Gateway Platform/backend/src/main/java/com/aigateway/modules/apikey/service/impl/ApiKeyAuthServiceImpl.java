package com.aigateway.modules.apikey.service.impl;

import cn.hutool.crypto.SecureUtil;
import com.aigateway.common.constant.RedisKeys;
import com.aigateway.common.enums.ApiKeyStatus;
import com.aigateway.common.exception.BizException;
import com.aigateway.common.exception.ErrorCode;
import com.aigateway.modules.apikey.dto.ApiKeyAuthContext;
import com.aigateway.modules.apikey.entity.ApiKey;
import com.aigateway.modules.apikey.mapper.ApiKeyMapper;
import com.aigateway.modules.apikey.service.ApiKeyAuthService;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.time.OffsetDateTime;
import java.util.List;

/**
 * Default {@link ApiKeyAuthService} implementation. Resolves keys via a short-lived
 * Redis cache backed by {@code biz_api_key}, then enforces status, expiry and IP
 * whitelist rules.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class ApiKeyAuthServiceImpl implements ApiKeyAuthService {

    private static final Duration CACHE_TTL = Duration.ofSeconds(300);

    private final ApiKeyMapper apiKeyMapper;
    private final RedisTemplate<String, Object> redisTemplate;

    @Override
    public ApiKeyAuthContext authenticate(String rawKey, String clientIp) {
        if (rawKey == null || rawKey.isBlank()) {
            throw new BizException(ErrorCode.INVALID_API_KEY);
        }
        String hash = sha256(rawKey);
        String cacheKey = RedisKeys.apiKeyAuth(hash);

        ApiKeyAuthContext ctx = readCache(cacheKey);
        if (ctx == null) {
            LambdaQueryWrapper<ApiKey> qw = Wrappers.<ApiKey>lambdaQuery()
                    .eq(ApiKey::getKeyHash, hash);
            ApiKey key = apiKeyMapper.selectOne(qw);
            if (key == null) {
                throw new BizException(ErrorCode.INVALID_API_KEY);
            }
            ctx = toContext(key);
            redisTemplate.opsForValue().set(cacheKey, ctx, CACHE_TTL);
        }

        // status check (deleted/disabled keys behave as invalid)
        if (ApiKeyStatus.ACTIVE != ApiKeyStatus.of(ctx.getStatus())) {
            throw new BizException(ErrorCode.INVALID_API_KEY);
        }
        // IP whitelist enforcement
        List<String> wl = ctx.getIpWhitelist();
        if (wl != null && !wl.isEmpty()) {
            if (clientIp == null || !wl.contains(clientIp)) {
                throw new BizException(ErrorCode.IP_NOT_ALLOWED);
            }
        }
        return ctx;
    }

    @Override
    @Async
    public void touchLastUsed(Long apiKeyId) {
        if (apiKeyId == null) {
            return;
        }
        try {
            ApiKey upd = new ApiKey();
            upd.setId(apiKeyId);
            upd.setLastUsedAt(OffsetDateTime.now());
            apiKeyMapper.updateById(upd);
        } catch (Exception e) {
            log.debug("touchLastUsed failed for {}: {}", apiKeyId, e.getMessage());
        }
    }

    private ApiKeyAuthContext readCache(String cacheKey) {
        Object cached = redisTemplate.opsForValue().get(cacheKey);
        if (cached instanceof ApiKeyAuthContext c) {
            return c;
        }
        return null;
    }

    /**
     * Map an entity to the gateway context, validating expiry at DB-read time.
     * Because {@link ApiKeyAuthContext} carries no expiry field, expiry is enforced
     * when the key is loaded from the database; cached contexts (TTL ~300s) inherit
     * that decision until the cache entry lapses.
     */
    private ApiKeyAuthContext toContext(ApiKey key) {
        if (key.getExpireAt() != null && key.getExpireAt().isBefore(OffsetDateTime.now())) {
            throw new BizException(ErrorCode.KEY_EXPIRED);
        }
        ApiKeyAuthContext ctx = new ApiKeyAuthContext();
        ctx.setApiKeyId(key.getId());
        ctx.setCompanyId(key.getCompanyId());
        ctx.setProjectId(key.getProjectId());
        ctx.setAllowedModels(key.getAllowedModels());
        ctx.setRpmLimit(key.getRpmLimit());
        ctx.setTpmLimit(key.getTpmLimit());
        ctx.setDailyQuota(key.getDailyQuota());
        ctx.setIpWhitelist(key.getIpWhitelist());
        ctx.setStatus(key.getStatus() != null ? key.getStatus().getCode() : null);
        return ctx;
    }

    /** SHA-256 hex digest of the raw key. */
    public static String sha256(String raw) {
        return SecureUtil.sha256(raw);
    }
}
