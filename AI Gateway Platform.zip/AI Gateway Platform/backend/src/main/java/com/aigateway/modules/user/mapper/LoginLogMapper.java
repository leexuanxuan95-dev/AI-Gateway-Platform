package com.aigateway.modules.user.mapper;

import com.aigateway.modules.user.entity.LoginLog;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/** MyBatis-Plus mapper for {@link LoginLog}. */
public interface LoginLogMapper extends BaseMapper<LoginLog> {
}
