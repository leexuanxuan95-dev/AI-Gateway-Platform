package com.aigateway.modules.billing.mapper;

import com.aigateway.modules.billing.entity.CallLog;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;

/**
 * Mapper for {@link CallLog} (partitioned table). Paged reads use the inherited
 * {@code BaseMapper}; the explicit insert sets {@code created_at = now()} so the row lands
 * in the correct partition.
 */
public interface CallLogMapper extends BaseMapper<CallLog> {

    /** Insert a call-log row into the partitioned table (created_at = now()). */
    @Insert("INSERT INTO call_log (request_id, api_key_id, company_id, model_code, channel_id, ip, " +
            "user_agent, http_status, biz_status, response_time, is_stream, created_at) " +
            "VALUES (#{requestId}, #{apiKeyId}, #{companyId}, #{modelCode}, #{channelId}, #{ip}, " +
            "#{userAgent}, #{httpStatus}, #{bizStatus}, #{responseTime}, #{isStream}, now())")
    int insertLog(@Param("requestId") String requestId,
                  @Param("apiKeyId") Long apiKeyId,
                  @Param("companyId") Long companyId,
                  @Param("modelCode") String modelCode,
                  @Param("channelId") Long channelId,
                  @Param("ip") String ip,
                  @Param("userAgent") String userAgent,
                  @Param("httpStatus") Integer httpStatus,
                  @Param("bizStatus") String bizStatus,
                  @Param("responseTime") Integer responseTime,
                  @Param("isStream") Boolean isStream);
}
