package com.aigateway.modules.notify.sender;

import com.aigateway.modules.notify.dto.NotifyMessage;
import com.aigateway.modules.system.service.SysConfigService;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;

import java.time.Duration;
import java.util.HashMap;
import java.util.Map;

/**
 * Real SMS sender (design doc §13): delivers via a config-driven SMS gateway HTTP API
 * (Twilio/SNS-style REST) using {@link WebClient}. Config from {@code sys_config}
 * (group {@code notify}):
 * <ul>
 *   <li>{@code notify.sms.endpoint} - full POST URL</li>
 *   <li>{@code notify.sms.apiKey}   - bearer token</li>
 *   <li>{@code notify.sms.from}     - sender id / number (optional)</li>
 * </ul>
 * If unconfigured a warning is logged and the message is marked pending (no throw) via
 * {@link NotifyPendingException}. On HTTP failure it throws so the dispatcher records
 * status=fail and retries. The api key is never logged.
 */
@Slf4j
@Component
public class SmsSender implements NotifySender {

    /** Outbound HTTP call timeout, in seconds. */
    private static final int SEND_TIMEOUT_SECONDS = 15;

    private final WebClient webClient;
    private final ObjectMapper objectMapper;
    private final SysConfigService sysConfigService;

    public SmsSender(WebClient.Builder webClientBuilder,
                     ObjectMapper objectMapper,
                     SysConfigService sysConfigService) {
        this.webClient = webClientBuilder.build();
        this.objectMapper = objectMapper;
        this.sysConfigService = sysConfigService;
    }

    @Override
    public String channel() {
        return "sms";
    }

    @Override
    public void send(NotifyMessage msg) {
        String endpoint = sysConfigService.getString("notify.sms.endpoint", null);
        String apiKey = sysConfigService.getString("notify.sms.apiKey", null);
        String from = sysConfigService.getString("notify.sms.from", null);
        if (isBlank(endpoint) || isBlank(apiKey)) {
            log.warn("[notify:sms] not configured (notify.sms.endpoint/apiKey); "
                    + "marking pending for target={} scene={}", msg.getTarget(), msg.getScene());
            throw new NotifyPendingException("sms provider not configured");
        }
        String to = msg.getTarget();
        if (isBlank(to)) {
            throw new IllegalArgumentException("sms target is blank");
        }

        Map<String, Object> body = new HashMap<>();
        body.put("to", to);
        if (!isBlank(from)) {
            body.put("from", from);
        }
        body.put("text", msg.getContent() != null ? msg.getContent() : "");
        if (msg.getParams() != null && !msg.getParams().isEmpty()) {
            body.put("params", msg.getParams());
        }
        String json;
        try {
            json = objectMapper.writeValueAsString(body);
        } catch (Exception e) {
            throw new IllegalStateException("serialize sms payload failed", e);
        }

        webClient.post()
                .uri(endpoint)
                .header("Authorization", "Bearer " + apiKey)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .retrieve()
                .toBodilessEntity()
                .block(Duration.ofSeconds(SEND_TIMEOUT_SECONDS));
        log.info("[notify:sms] sent -> {} scene={}", to, msg.getScene());
    }

    private boolean isBlank(String s) {
        return s == null || s.isBlank();
    }
}
