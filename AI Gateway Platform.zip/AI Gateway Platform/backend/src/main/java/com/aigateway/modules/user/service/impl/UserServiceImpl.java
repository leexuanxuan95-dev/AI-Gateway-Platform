package com.aigateway.modules.user.service.impl;

import com.aigateway.common.api.PageResult;
import com.aigateway.common.constant.RedisKeys;
import com.aigateway.common.crypto.AesUtil;
import com.aigateway.common.exception.BizException;
import com.aigateway.common.exception.ErrorCode;
import com.aigateway.common.security.TokenEpochService;
import com.aigateway.common.security.UserContext;
import com.aigateway.common.util.UploadValidator;
import com.aigateway.modules.company.entity.Company;
import com.aigateway.modules.company.entity.CompanyMember;
import com.aigateway.modules.company.mapper.CompanyMapper;
import com.aigateway.modules.company.mapper.CompanyMemberMapper;
import com.aigateway.modules.user.dto.ChangeContactRequest;
import com.aigateway.modules.user.dto.ChangePasswordRequest;
import com.aigateway.modules.user.dto.CompanyBrief;
import com.aigateway.modules.user.dto.ProfileUpdateRequest;
import com.aigateway.modules.user.dto.SessionView;
import com.aigateway.modules.user.dto.TotpSetupResponse;
import com.aigateway.modules.user.dto.UserInfo;
import com.aigateway.modules.user.entity.LoginLog;
import com.aigateway.modules.user.entity.SysUser;
import com.aigateway.modules.user.mapper.LoginLogMapper;
import com.aigateway.modules.user.mapper.SysUserMapper;
import com.aigateway.modules.user.service.SessionService;
import com.aigateway.modules.user.service.TotpService;
import com.aigateway.modules.user.service.UserService;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import lombok.RequiredArgsConstructor;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/** Default {@link UserService}. */
@Service
@RequiredArgsConstructor
public class UserServiceImpl implements UserService {

    private final SysUserMapper userMapper;
    private final LoginLogMapper loginLogMapper;
    private final CompanyMemberMapper memberMapper;
    private final CompanyMapper companyMapper;
    private final PasswordEncoder passwordEncoder;
    private final TotpService totpService;
    private final AesUtil aesUtil;
    private final SessionService sessionService;
    private final TokenEpochService tokenEpochService;
    private final RedisTemplate<String, Object> redisTemplate;

    @Override
    public UserInfo me() {
        SysUser u = currentUser();
        return buildUserInfo(u, UserContext.require().getCompanyId(),
                UserContext.require().getCompanyRole());
    }

    @Override
    public UserInfo buildUserInfo(SysUser user, Long activeCompanyId, String activeRole) {
        UserInfo info = UserInfo.from(user);
        info.setCompanyId(activeCompanyId);
        info.setCompanyRole(activeRole);
        info.setCompanies(listCompanies(user.getId()));
        return info;
    }

    @Override
    public void updateProfile(ProfileUpdateRequest req) {
        // Avatar is optional and may be either an http(s) URL (e.g. an OAuth profile picture) or
        // an object-store key. Reject neither-shaped values to block traversal / injection payloads.
        if (StringUtils.hasText(req.getAvatar()) && !isHttpUrl(req.getAvatar())) {
            UploadValidator.validateObjectKey("avatar", req.getAvatar());
        }
        SysUser upd = new SysUser();
        upd.setId(UserContext.userId());
        upd.setNickname(req.getNickname());
        upd.setAvatar(req.getAvatar());
        userMapper.updateById(upd);
    }

    @Override
    public void changePassword(ChangePasswordRequest req) {
        SysUser u = currentUser();
        if (!StringUtils.hasText(u.getPassword())
                || !passwordEncoder.matches(req.getOldPassword(), u.getPassword())) {
            throw new BizException(ErrorCode.INVALID_CREDENTIALS);
        }
        SysUser upd = new SysUser();
        upd.setId(u.getId());
        upd.setPassword(passwordEncoder.encode(req.getNewPassword()));
        userMapper.updateById(upd);
        // A password change must invalidate every previously-issued access token (design doc §18).
        tokenEpochService.bump(u.getId());
    }

    @Override
    public void changeContact(ChangeContactRequest req) {
        boolean byEmail = StringUtils.hasText(req.getEmail());
        boolean byMobile = StringUtils.hasText(req.getMobile());
        if (byEmail == byMobile) {
            throw new BizException(ErrorCode.PARAM_ERROR, "provide exactly one of email or mobile");
        }
        SysUser u = currentUser();

        // §3.3 step-up: require a valid current password OR a fresh code sent to the new target
        boolean verified = false;
        if (StringUtils.hasText(req.getPassword())
                && StringUtils.hasText(u.getPassword())
                && passwordEncoder.matches(req.getPassword(), u.getPassword())) {
            verified = true;
        } else if (StringUtils.hasText(req.getCode())) {
            String scene = byEmail ? "change_email" : "change_mobile";
            String target = byEmail ? req.getEmail() : req.getMobile();
            Object stored = redisTemplate.opsForValue().get(RedisKeys.captcha(scene, target));
            if (stored != null && String.valueOf(stored).equals(req.getCode())) {
                redisTemplate.delete(RedisKeys.captcha(scene, target));
                verified = true;
            }
        }
        if (!verified) {
            throw new BizException(ErrorCode.CAPTCHA_INVALID, "step-up verification required");
        }

        // uniqueness check against other users
        if (byEmail) {
            if (userMapper.selectCount(Wrappers.<SysUser>lambdaQuery()
                    .eq(SysUser::getEmail, req.getEmail())
                    .ne(SysUser::getId, u.getId())) > 0) {
                throw new BizException(ErrorCode.EMAIL_EXISTS);
            }
        } else if (userMapper.selectCount(Wrappers.<SysUser>lambdaQuery()
                .eq(SysUser::getMobile, req.getMobile())
                .ne(SysUser::getId, u.getId())) > 0) {
            throw new BizException(ErrorCode.MOBILE_EXISTS);
        }

        SysUser upd = new SysUser();
        upd.setId(u.getId());
        if (byEmail) {
            upd.setEmail(req.getEmail());
        } else {
            upd.setMobile(req.getMobile());
        }
        userMapper.updateById(upd);
    }

    @Override
    public List<SessionView> listSessions(String currentRefreshToken) {
        return sessionService.list(UserContext.userId(), currentRefreshToken);
    }

    @Override
    public void revokeSession(String tokenId) {
        sessionService.revoke(UserContext.userId(), tokenId);
    }

    @Override
    public void revokeOtherSessions(String currentRefreshToken) {
        Long userId = UserContext.userId();
        sessionService.revokeAllExcept(userId, currentRefreshToken);
        // Deleting the other refresh tokens only stops them minting NEW access tokens; their
        // already-issued access tokens stay valid until expiry. Bump the epoch to kill those
        // immediately. The caller keeps their refresh token and transparently re-mints an
        // epoch-current access token on the next refresh.
        tokenEpochService.bump(userId);
    }

    @Override
    public TotpSetupResponse totpSetup() {
        SysUser u = currentUser();
        String secret = totpService.generateSecret();
        // store encrypted but keep totp_enabled = false until verified
        SysUser upd = new SysUser();
        upd.setId(u.getId());
        upd.setTotpSecret(aesUtil.encrypt(secret));
        userMapper.updateById(upd);
        String label = StringUtils.hasText(u.getEmail()) ? u.getEmail() : u.getUid();
        return new TotpSetupResponse(secret, totpService.otpauthUrl(label, secret));
    }

    @Override
    public void totpEnable(String code) {
        SysUser u = currentUser();
        String secret = aesUtil.decrypt(u.getTotpSecret());
        if (!StringUtils.hasText(secret) || !totpService.verify(secret, code)) {
            throw new BizException(ErrorCode.TOTP_INVALID);
        }
        SysUser upd = new SysUser();
        upd.setId(u.getId());
        upd.setTotpEnabled(true);
        userMapper.updateById(upd);
    }

    @Override
    public void totpDisable(String code, String password) {
        SysUser u = currentUser();
        if (!Boolean.TRUE.equals(u.getTotpEnabled())) {
            return;
        }
        // §3.3 step-up: if the account has a password, re-verify it in addition to the TOTP code
        if (StringUtils.hasText(u.getPassword())
                && (!StringUtils.hasText(password) || !passwordEncoder.matches(password, u.getPassword()))) {
            throw new BizException(ErrorCode.INVALID_CREDENTIALS, "current password required to disable 2FA");
        }
        String secret = aesUtil.decrypt(u.getTotpSecret());
        if (!StringUtils.hasText(secret) || !totpService.verify(secret, code)) {
            throw new BizException(ErrorCode.TOTP_INVALID);
        }
        SysUser upd = new SysUser();
        upd.setId(u.getId());
        upd.setTotpEnabled(false);
        upd.setTotpSecret(null);
        userMapper.updateById(upd);
        // Disabling 2FA is a security-sensitive downgrade: revoke all existing sessions so a
        // session opened before the change cannot ride on the weaker posture (design doc §18).
        tokenEpochService.bump(u.getId());
    }

    @Override
    public PageResult<LoginLog> loginLogs(long current, long size) {
        IPage<LoginLog> p = loginLogMapper.selectPage(new Page<>(current, size),
                Wrappers.<LoginLog>lambdaQuery()
                        .eq(LoginLog::getUserId, UserContext.userId())
                        .orderByDesc(LoginLog::getId));
        return PageResult.of(p);
    }

    // ---- helpers ----

    /** True if the value is a syntactically valid http/https URL. */
    private boolean isHttpUrl(String value) {
        String lower = value.toLowerCase(java.util.Locale.ROOT);
        return lower.startsWith("http://") || lower.startsWith("https://");
    }

    private SysUser currentUser() {
        SysUser u = userMapper.selectById(UserContext.userId());
        if (u == null) {
            throw new BizException(ErrorCode.USER_NOT_FOUND);
        }
        return u;
    }

    private List<CompanyBrief> listCompanies(Long userId) {
        List<CompanyMember> members = memberMapper.selectList(Wrappers.<CompanyMember>lambdaQuery()
                .eq(CompanyMember::getUserId, userId));
        if (members.isEmpty()) {
            return new ArrayList<>();
        }
        List<Long> ids = members.stream().map(CompanyMember::getCompanyId).collect(Collectors.toList());
        Map<Long, String> names = new HashMap<>();
        for (Company c : companyMapper.selectBatchIds(ids)) {
            names.put(c.getId(), c.getCompanyName());
        }
        return members.stream()
                .map(m -> new CompanyBrief(m.getCompanyId(), names.get(m.getCompanyId()), m.getRole()))
                .collect(Collectors.toList());
    }
}
