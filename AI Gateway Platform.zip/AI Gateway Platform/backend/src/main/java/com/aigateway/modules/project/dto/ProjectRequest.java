package com.aigateway.modules.project.dto;

import com.aigateway.common.enums.CommonStatus;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

import java.math.BigDecimal;
import java.util.List;

/** Create/update request for a project. */
@Data
public class ProjectRequest {

    @NotBlank
    private String name;

    private String description;

    private BigDecimal monthlyQuota;

    private List<String> allowedModels;

    private CommonStatus status;
}
