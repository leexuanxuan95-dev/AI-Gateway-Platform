package com.aigateway.modules.payment.service.impl;

import com.aigateway.common.constant.RedisKeys;
import com.aigateway.common.crypto.AesUtil;
import com.aigateway.common.exception.BizException;
import com.aigateway.common.exception.ErrorCode;
import com.aigateway.modules.payment.dto.ChannelOption;
import com.aigateway.modules.payment.entity.PayChannelConfig;
import com.aigateway.modules.payment.mapper.PayChannelConfigMapper;
import com.aigateway.modules.payment.service.PayChannelConfigService;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import lombok.RequiredArgsConstructor;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

/**
 * Default {@link PayChannelConfigService}. Secrets are AES-encrypted before persist
 * and masked on read. The decrypted config is cached in Redis and evicted on change.
 */
@Service
@RequiredArgsConstructor
public class PayChannelConfigServiceImpl implements PayChannelConfigService {

    private static final String MASK = "******";
    private static final long CACHE_TTL_MIN = 30;

    private final PayChannelConfigMapper mapper;
    private final AesUtil aesUtil;
    private final RedisTemplate<String, Object> redisTemplate;

    @Override
    public List<PayChannelConfig> listMasked() {
        List<PayChannelConfig> list = mapper.selectList(
                Wrappers.<PayChannelConfig>lambdaQuery().orderByAsc(PayChannelConfig::getSort));
        list.forEach(this::maskCredentials);
        return list;
    }

    @Override
    public PayChannelConfig create(PayChannelConfig cfg, Long operatorId) {
        cfg.setId(null);
        cfg.setUpdatedBy(operatorId);
        encryptCredentials(cfg, null);
        cfg.setCallbackUrl("/api/pay/callback/" + cfg.getChannelCode());
        mapper.insert(cfg);
        evict(cfg.getChannelCode());
        return maskCredentials(cfg);
    }

    @Override
    public PayChannelConfig update(Long id, PayChannelConfig cfg, Long operatorId) {
        PayChannelConfig existing = mapper.selectById(id);
        if (existing == null) {
            throw new BizException(ErrorCode.NOT_FOUND);
        }
        cfg.setId(id);
        cfg.setChannelCode(existing.getChannelCode());
        cfg.setUpdatedBy(operatorId);
        encryptCredentials(cfg, existing);
        cfg.setCallbackUrl("/api/pay/callback/" + existing.getChannelCode());
        mapper.updateById(cfg);
        evict(existing.getChannelCode());
        return maskCredentials(mapper.selectById(id));
    }

    @Override
    public PayChannelConfig setEnabled(Long id, boolean enabled, Long operatorId) {
        PayChannelConfig existing = mapper.selectById(id);
        if (existing == null) {
            throw new BizException(ErrorCode.NOT_FOUND);
        }
        PayChannelConfig upd = new PayChannelConfig();
        upd.setId(id);
        upd.setEnabled(enabled);
        upd.setUpdatedBy(operatorId);
        mapper.updateById(upd);
        evict(existing.getChannelCode());
        return maskCredentials(mapper.selectById(id));
    }

    @Override
    public PayChannelConfig getByCode(String code) {
        String key = RedisKeys.payChannel(code);
        Object cached = redisTemplate.opsForValue().get(key);
        if (cached instanceof PayChannelConfig pc) {
            return pc;
        }
        PayChannelConfig cfg = mapper.selectOne(
                Wrappers.<PayChannelConfig>lambdaQuery().eq(PayChannelConfig::getChannelCode, code).last("limit 1"));
        if (cfg == null) {
            throw new BizException(ErrorCode.PAY_CHANNEL_DISABLED, "unknown channel " + code);
        }
        // Cache with credentials kept encrypted; adapters decrypt per use.
        redisTemplate.opsForValue().set(key, cfg, CACHE_TTL_MIN, TimeUnit.MINUTES);
        return cfg;
    }

    @Override
    public List<ChannelOption> publicChannels(BigDecimal amount, String currency) {
        List<PayChannelConfig> list = mapper.selectList(
                Wrappers.<PayChannelConfig>lambdaQuery()
                        .eq(PayChannelConfig::getEnabled, true)
                        .orderByAsc(PayChannelConfig::getSort));
        List<ChannelOption> out = new ArrayList<>();
        for (PayChannelConfig c : list) {
            if (amount != null) {
                if (c.getMinAmount() != null && c.getMinAmount().signum() > 0
                        && amount.compareTo(c.getMinAmount()) < 0) {
                    continue;
                }
                if (c.getMaxAmount() != null && c.getMaxAmount().signum() > 0
                        && amount.compareTo(c.getMaxAmount()) > 0) {
                    continue;
                }
            }
            if (currency != null && c.getCurrencies() != null && !c.getCurrencies().isEmpty()
                    && !c.getCurrencies().contains(currency)) {
                continue;
            }
            ChannelOption o = new ChannelOption();
            o.setCode(c.getChannelCode());
            o.setName(c.getDisplayName());
            o.setIcon(c.getIcon());
            o.setFee(c.getFeeRate());
            o.setMin(c.getMinAmount());
            o.setMax(c.getMaxAmount());
            o.setConfirmBlocks(c.getConfirmBlocks());
            out.add(o);
        }
        return out;
    }

    /** Encrypt plaintext credential values; preserve already-masked values from {@code existing}. */
    private void encryptCredentials(PayChannelConfig cfg, PayChannelConfig existing) {
        if (cfg.getCredentials() == null) {
            return;
        }
        Map<String, Object> existingCreds = existing != null ? existing.getCredentials() : null;
        Map<String, Object> enc = new HashMap<>();
        for (Map.Entry<String, Object> e : cfg.getCredentials().entrySet()) {
            Object v = e.getValue();
            if (v == null) {
                continue;
            }
            String s = v.toString();
            if (MASK.equals(s) && existingCreds != null && existingCreds.get(e.getKey()) != null) {
                // unchanged masked value -> keep the existing ciphertext
                enc.put(e.getKey(), existingCreds.get(e.getKey()));
            } else {
                enc.put(e.getKey(), aesUtil.encrypt(s));
            }
        }
        cfg.setCredentials(enc);
    }

    /** Replace credential values with a mask for safe display. */
    private PayChannelConfig maskCredentials(PayChannelConfig cfg) {
        if (cfg != null && cfg.getCredentials() != null) {
            Map<String, Object> masked = new HashMap<>();
            for (String k : cfg.getCredentials().keySet()) {
                masked.put(k, MASK);
            }
            cfg.setCredentials(masked);
        }
        return cfg;
    }

    private void evict(String code) {
        redisTemplate.delete(RedisKeys.payChannel(code));
    }
}
