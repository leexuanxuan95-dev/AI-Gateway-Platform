package com.aigateway.modules.notify.mapper;

import com.aigateway.modules.notify.entity.NotifyLog;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/** MyBatis-Plus mapper for {@link NotifyLog}. */
public interface NotifyLogMapper extends BaseMapper<NotifyLog> {
}
