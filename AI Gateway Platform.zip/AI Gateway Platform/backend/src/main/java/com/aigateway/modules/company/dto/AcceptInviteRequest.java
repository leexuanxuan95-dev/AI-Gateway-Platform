package com.aigateway.modules.company.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

/** Accept a pending invitation by token. */
@Data
public class AcceptInviteRequest {

    @NotBlank
    private String inviteToken;
}
