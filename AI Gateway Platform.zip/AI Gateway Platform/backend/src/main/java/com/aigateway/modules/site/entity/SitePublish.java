package com.aigateway.modules.site.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.aigateway.common.enums.SitePublishStatus;
import com.baomidou.mybatisplus.extension.handlers.JacksonTypeHandler;
import lombok.Data;

import java.time.OffsetDateTime;
import java.util.Map;

/**
 * A publish snapshot of the full landing content (table {@code site_publish},
 * OmniRoute doc §4.2). Supports version history and rollback.
 */
@Data
@TableName(value = "site_publish", autoResultMap = true)
public class SitePublish {

    @TableId(type = IdType.AUTO)
    private Long id;

    /** Content language: {@code zh} / {@code en}. */
    private String lang;

    /** {@code 1} published / {@code 0} draft/superseded (history kept). */
    private SitePublishStatus status;

    /** Full-site content snapshot (resolved bind_source embedded at publish time). */
    @TableField(typeHandler = JacksonTypeHandler.class)
    private Map<String, Object> snapshot;

    private Long publishedBy;

    /** Set explicitly on insert (DB also defaults to now()). */
    private OffsetDateTime publishedAt;
}
