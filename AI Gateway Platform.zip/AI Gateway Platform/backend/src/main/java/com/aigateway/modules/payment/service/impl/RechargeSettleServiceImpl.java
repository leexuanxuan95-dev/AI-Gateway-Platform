package com.aigateway.modules.payment.service.impl;

import com.aigateway.common.constant.KafkaTopics;
import com.aigateway.common.enums.RechargeStatus;
import com.aigateway.modules.finance.entity.FinRechargeOrder;
import com.aigateway.modules.finance.entity.RechargeFeeConfig;
import com.aigateway.modules.finance.mapper.FinRechargeOrderMapper;
import com.aigateway.modules.finance.service.FinanceService;
import com.aigateway.modules.payment.adapter.CallbackResult;
import com.aigateway.modules.payment.service.RechargeSettleService;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.OffsetDateTime;
import java.util.HashMap;
import java.util.Map;

/** Default {@link RechargeSettleService}. */
@Slf4j
@Service
@RequiredArgsConstructor
public class RechargeSettleServiceImpl implements RechargeSettleService {

    private final FinRechargeOrderMapper rechargeOrderMapper;
    private final FinanceService financeService;
    private final KafkaTemplate<String, String> kafkaTemplate;
    private final ObjectMapper objectMapper;

    @Override
    @Transactional
    public boolean creditPaidOrder(FinRechargeOrder order, CallbackResult cb, String rawBody) {
        // DB-level idempotency: conditional update status 0 -> 1; if 0 rows, someone beat us.
        FinRechargeOrder upd = new FinRechargeOrder();
        upd.setStatus(RechargeStatus.PAID);
        upd.setThirdTxnId(cb.getThirdTxnId());
        upd.setPaidAt(OffsetDateTime.now());
        upd.setRawCallback(parseRaw(rawBody));
        int changed = rechargeOrderMapper.update(upd,
                Wrappers.<FinRechargeOrder>lambdaUpdate()
                        .eq(FinRechargeOrder::getId, order.getId())
                        .eq(FinRechargeOrder::getStatus, RechargeStatus.PENDING));
        if (changed == 0) {
            return false; // already paid -> idempotent no-op
        }

        // Credit the account + apply recharge fee within the same transaction.
        RechargeFeeConfig fee = financeService.resolveRechargeFee(order.getCompanyId());
        financeService.creditRecharge(order.getCompanyId(), order.getAmount(), order.getOrderNo(), fee);

        emitNotify(order);
        return true;
    }

    private void emitNotify(FinRechargeOrder order) {
        try {
            Map<String, Object> msg = new HashMap<>();
            msg.put("scene", "recharge_success");
            msg.put("companyId", order.getCompanyId());
            msg.put("orderNo", order.getOrderNo());
            msg.put("amount", order.getAmount());
            msg.put("currency", order.getCurrency());
            kafkaTemplate.send(KafkaTopics.NOTIFY, order.getOrderNo(), objectMapper.writeValueAsString(msg));
        } catch (Exception e) {
            log.warn("emit recharge notify failed for {}: {}", order.getOrderNo(), e.getMessage());
        }
    }

    @SuppressWarnings("unchecked")
    private Map<String, Object> parseRaw(String rawBody) {
        if (rawBody == null) {
            return null;
        }
        try {
            return objectMapper.readValue(rawBody, new TypeReference<Map<String, Object>>() {
            });
        } catch (Exception e) {
            Map<String, Object> m = new HashMap<>();
            m.put("raw", rawBody);
            return m;
        }
    }
}
