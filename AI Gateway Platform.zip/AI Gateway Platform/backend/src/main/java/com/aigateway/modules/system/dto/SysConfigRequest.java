package com.aigateway.modules.system.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

/** Upsert payload for a system config entry. */
@Data
public class SysConfigRequest {

    @NotBlank
    private String configKey;

    /** Raw value (scalar or object); stored as JSONB. */
    private Object configValue;

    /** pay/model/risk/markup/notify/system. */
    private String groupName;

    private String remark;
}
