package com.aigateway.common.security;

import jakarta.servlet.FilterChain;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Unit tests for {@link GlobalRateLimitFilter}: under the per-IP cap the request passes; over the
 * cap it is rejected with HTTP 429 and the chain is not invoked. {@link StringRedisTemplate} and
 * its {@link ValueOperations} are mocked.
 */
@ExtendWith(MockitoExtension.class)
@DisplayName("GlobalRateLimitFilter - per-IP flood backstop")
class GlobalRateLimitFilterTest {

    private static final int HTTP_TOO_MANY_REQUESTS = 429;
    /** Mirrors GlobalRateLimitFilter#MAX_PER_WINDOW. */
    private static final long CAP = 600L;

    @Mock
    private StringRedisTemplate redis;
    @Mock
    private ValueOperations<String, String> valueOps;

    private GlobalRateLimitFilter filter;

    @BeforeEach
    void setUp() {
        lenient().when(redis.opsForValue()).thenReturn(valueOps);
        filter = new GlobalRateLimitFilter(redis);
    }

    private MockHttpServletRequest request() {
        MockHttpServletRequest req = new MockHttpServletRequest("GET", "/api/user/me");
        req.setRemoteAddr("198.51.100.10");
        return req;
    }

    @Test
    @DisplayName("allows a request under the cap")
    void allowsUnderCap() throws Exception {
        when(valueOps.increment(anyString())).thenReturn(5L);
        FilterChain chain = mock(FilterChain.class);
        MockHttpServletRequest req = request();
        MockHttpServletResponse resp = new MockHttpServletResponse();

        filter.doFilter(req, resp, chain);

        assertThat(resp.getStatus()).isEqualTo(200);
        verify(chain, times(1)).doFilter(req, resp);
    }

    @Test
    @DisplayName("returns 429 once the cap is exceeded")
    void blocksOverCap() throws Exception {
        when(valueOps.increment(anyString())).thenReturn(CAP + 1);
        FilterChain chain = mock(FilterChain.class);
        MockHttpServletResponse resp = new MockHttpServletResponse();

        filter.doFilter(request(), resp, chain);

        assertThat(resp.getStatus()).isEqualTo(HTTP_TOO_MANY_REQUESTS);
        verify(chain, never()).doFilter(any(), any());
    }
}
