package com.aigateway.it;

import com.aigateway.modules.finance.dto.ChargeResult;
import com.aigateway.modules.finance.dto.SettleCmd;
import com.aigateway.modules.finance.entity.FinAccount;
import com.aigateway.modules.finance.mapper.FinAccountMapper;
import com.aigateway.modules.finance.service.BillingService;
import com.aigateway.modules.finance.service.PricingService;
import com.aigateway.modules.model.entity.ModelVersion;
import com.aigateway.modules.model.mapper.ModelVersionMapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.condition.EnabledIf;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.testcontainers.containers.GenericContainer;
import org.testcontainers.containers.PostgreSQLContainer;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;
import org.testcontainers.utility.DockerImageName;

import java.math.BigDecimal;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicLong;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Testcontainers-backed integration test that boots the full Spring context against a real
 * PostgreSQL 16 + Redis 7 data layer. These exercise the actual JDBC/JSONB coercion and the
 * MyBatis-Plus optimistic-locker interceptor end to end — the two areas that pure unit mocks
 * could not catch (the JSONB-cast bug and the {@code @Version} optimistic-lock bug).
 *
 * <p>Tests are intentionally NOT {@code @Transactional}: writes commit so the optimistic-lock
 * version CAS and the partitioned {@code bill_token} insert are exercised for real. Every test
 * uses unique ids so they stay independent.</p>
 */
@SpringBootTest
@Testcontainers
@EnabledIf("dockerAvailable")
class DataLayerIntegrationTest {

    /**
     * Only run when a usable Docker environment is reachable, so the default {@code mvn test}
     * stays green on hosts without Docker (or with an incompatible Docker API). Evaluated before
     * the Testcontainers extension starts any container.
     */
    static boolean dockerAvailable() {
        try {
            return org.testcontainers.DockerClientFactory.instance().isDockerAvailable();
        } catch (Throwable t) {
            return false;
        }
    }

    @Container
    static final PostgreSQLContainer<?> POSTGRES = new PostgreSQLContainer<>(DockerImageName.parse("postgres:16"))
            .withDatabaseName("ai_gateway")
            .withUsername("gw")
            .withPassword("gw")
            // init.sql is self-contained: CREATE TABLE IF NOT EXISTS + seeds + partition DO block.
            .withInitScript("db-init.sql");

    @Container
    static final GenericContainer<?> REDIS = new GenericContainer<>(DockerImageName.parse("redis:7"))
            .withExposedPorts(6379);

    /** Counter to keep company ids unique across test methods within a single run. */
    private static final AtomicLong COMPANY_SEQ = new AtomicLong(900000L);

    @DynamicPropertySource
    static void props(DynamicPropertyRegistry registry) {
        // CRITICAL: stringtype=unspecified lets PostgreSQL coerce String-bound JSON into JSONB
        // columns. Without it, the capabilities insert fails with a "column is of type jsonb but
        // expression is of type character varying" error. This is the regression being guarded.
        registry.add("spring.datasource.url", () -> POSTGRES.getJdbcUrl() + "?stringtype=unspecified");
        registry.add("spring.datasource.username", POSTGRES::getUsername);
        registry.add("spring.datasource.password", POSTGRES::getPassword);
        registry.add("spring.datasource.driver-class-name", () -> "org.postgresql.Driver");

        registry.add("spring.data.redis.host", REDIS::getHost);
        registry.add("spring.data.redis.port", () -> REDIS.getMappedPort(6379));
        registry.add("spring.data.redis.password", () -> "");

        // No Kafka broker in the test environment: don't start listeners. The app wraps producer
        // sends in try/catch, so an unreachable broker won't fail a test.
        registry.add("spring.kafka.listener.auto-startup", () -> "false");
        registry.add("spring.kafka.bootstrap-servers", () -> "localhost:9092");
    }

    @Autowired
    private ModelVersionMapper modelVersionMapper;

    @Autowired
    private FinAccountMapper finAccountMapper;

    @Autowired
    private BillingService billingService;

    @Autowired
    private PricingService pricingService;

    @Autowired
    private JdbcTemplate jdbcTemplate;

    // ------------------------------------------------------------------------------------------
    // 1) JSONB round-trip — proves the String->jsonb coercion via stringtype=unspecified.
    // ------------------------------------------------------------------------------------------
    @Test
    void jsonbRoundTrip() {
        String code = "it-model-" + UUID.randomUUID();
        ModelVersion mv = new ModelVersion();
        mv.setFamilyId(1L);
        mv.setModelCode(code);
        mv.setDisplayName("IT Model");
        mv.setCapabilities(List.of("chat", "vision", "stream"));
        mv.setAvailability(com.aigateway.common.enums.ModelAvailability.AVAILABLE);
        mv.setStatus(com.aigateway.common.enums.ModelStatus.ACTIVE);
        mv.setCostInput(new BigDecimal("1.000000"));
        mv.setCostOutput(new BigDecimal("2.000000"));
        mv.setCurrency("USD");

        // This INSERT would fail without ?stringtype=unspecified (JSONB column, String binding).
        int inserted = modelVersionMapper.insert(mv);
        assertThat(inserted).isEqualTo(1);
        assertThat(mv.getId()).isNotNull();

        ModelVersion reloaded = modelVersionMapper.selectById(mv.getId());
        assertThat(reloaded).isNotNull();
        assertThat(reloaded.getCapabilities())
                .as("JSONB capabilities must survive the round-trip")
                .containsExactly("chat", "vision", "stream");
        assertThat(reloaded.getModelCode()).isEqualTo(code);
    }

    // ------------------------------------------------------------------------------------------
    // 2) freeze + settle — proves the @Version OptimisticLockerInnerInterceptor is wired and the
    //    balance transitions are correct against the real DB.
    // ------------------------------------------------------------------------------------------
    @Test
    void freezeAndSettle() {
        long companyId = COMPANY_SEQ.getAndIncrement();

        FinAccount acc = new FinAccount();
        acc.setCompanyId(companyId);
        acc.setAvailableBalance(new BigDecimal("100"));
        acc.setFreezeBalance(BigDecimal.ZERO);
        acc.setTotalRecharge(BigDecimal.ZERO);
        acc.setTotalConsume(BigDecimal.ZERO);
        acc.setCurrency("USD");
        acc.setVersion(0L);
        assertThat(finAccountMapper.insert(acc)).isEqualTo(1);

        // freeze 10: available 100 -> 90, freeze 0 -> 10. Without the optimistic-lock interceptor
        // updateById would fail with the MyBatis-Plus MP_OPTLOCK / version-column error.
        billingService.freeze(companyId, new BigDecimal("10"));

        FinAccount afterFreeze = loadAccount(companyId);
        assertThat(afterFreeze.getAvailableBalance()).isEqualByComparingTo("90");
        assertThat(afterFreeze.getFreezeBalance()).isEqualByComparingTo("10");

        // settle: release frozen 10 (freeze 10 -> 0, available 90 -> 100) then deduct charge 6
        // (available 100 -> 96).
        String requestId = "it-req-" + UUID.randomUUID();
        SettleCmd cmd = new SettleCmd();
        cmd.setCompanyId(companyId);
        cmd.setChannelId(null); // skip channel/upstream writes; no channel row seeded
        cmd.setModelCode("it-settle-model");
        cmd.setRequestId(requestId);
        cmd.setPromptTokens(1000L);
        cmd.setCompletionTokens(500L);
        cmd.setCachedTokens(0L);
        cmd.setCharge(new BigDecimal("6"));
        cmd.setCost(new BigDecimal("4"));
        cmd.setFrozen(new BigDecimal("10"));

        billingService.settle(cmd);

        FinAccount afterSettle = loadAccount(companyId);
        assertThat(afterSettle.getFreezeBalance())
                .as("frozen estimate released back")
                .isEqualByComparingTo("0");
        assertThat(afterSettle.getAvailableBalance())
                .as("release frozen 10 then deduct actual charge 6 => 96")
                .isEqualByComparingTo("96");
        assertThat(afterSettle.getTotalConsume()).isEqualByComparingTo("6");

        Integer billRows = jdbcTemplate.queryForObject(
                "SELECT count(*) FROM bill_token WHERE request_id = ?", Integer.class, requestId);
        assertThat(billRows).as("a bill_token row must be written for the settled request").isEqualTo(1);
    }

    // ------------------------------------------------------------------------------------------
    // 3) pricing min-margin — proves the pricing engine resolves the seeded global markup rule
    //    (0.30 rate / 0.10 min-margin) from the real DB.
    // ------------------------------------------------------------------------------------------
    @Test
    void pricingMinMargin() {
        long companyId = COMPANY_SEQ.getAndIncrement();
        String code = "it-priced-" + UUID.randomUUID();

        ModelVersion mv = new ModelVersion();
        mv.setFamilyId(1L);
        mv.setModelCode(code);
        mv.setDisplayName("IT Priced");
        mv.setCapabilities(List.of("chat"));
        mv.setAvailability(com.aigateway.common.enums.ModelAvailability.AVAILABLE);
        mv.setStatus(com.aigateway.common.enums.ModelStatus.ACTIVE);
        mv.setCostInput(new BigDecimal("1.000000"));   // per 1M input tokens
        mv.setCostOutput(new BigDecimal("2.000000"));  // per 1M output tokens
        mv.setCurrency("USD");
        assertThat(modelVersionMapper.insert(mv)).isEqualTo(1);

        // cost = 1000/1e6*1 + 1000/1e6*2 + 0 = 0.001 + 0.002 = 0.003
        // global rule markupRate=0.30, minMargin=0.10, markupFixed=0
        //   => charge = max(cost*1.30, cost*1.10) = cost*1.30 = 0.0039
        ChargeResult res = pricingService.calc(code, 1000L, 1000L, 0L, companyId);

        BigDecimal expectedCost = new BigDecimal("0.003000");
        BigDecimal expectedCharge = expectedCost.multiply(new BigDecimal("1.30"));

        assertThat(res.getCost()).isEqualByComparingTo(expectedCost);
        assertThat(res.getCharge())
                .as("charge must never be below cost")
                .isGreaterThanOrEqualTo(res.getCost());
        assertThat(res.getCharge())
                .as("charge == cost * (1 + 0.30) under the seeded global markup")
                .isEqualByComparingTo(expectedCharge);
        assertThat(res.getMarkupRate()).isEqualByComparingTo("0.30");
        assertThat(res.getMinMargin()).isEqualByComparingTo("0.10");
    }

    private FinAccount loadAccount(long companyId) {
        return finAccountMapper.selectOne(
                Wrappers.<FinAccount>lambdaQuery().eq(FinAccount::getCompanyId, companyId));
    }
}
