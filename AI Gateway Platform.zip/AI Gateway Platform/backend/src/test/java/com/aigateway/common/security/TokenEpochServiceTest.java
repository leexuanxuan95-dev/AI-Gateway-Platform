package com.aigateway.common.security;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.data.redis.core.ValueOperations;

import java.util.HashMap;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.when;

/**
 * Unit tests for {@link TokenEpochService}: a {@code bump} advances the per-user epoch so
 * {@code current} reads a higher value, and Redis faults fail open (epoch reads as 0).
 * Backed by an in-memory map standing in for Redis.
 */
@ExtendWith(MockitoExtension.class)
@DisplayName("TokenEpochService - revoke-all epoch")
class TokenEpochServiceTest {

    private static final Long USER_ID = 4242L;

    @Mock
    private StringRedisTemplate redis;
    @Mock
    private ValueOperations<String, String> valueOps;

    private TokenEpochService service;

    @BeforeEach
    void setUp() {
        lenient().when(redis.opsForValue()).thenReturn(valueOps);
        service = new TokenEpochService(redis);
    }

    @Test
    @DisplayName("current reflects a higher value after bump")
    void bumpThenCurrentIncreases() {
        Map<String, String> store = new HashMap<>();
        doAnswer(inv -> store.put(inv.getArgument(0), inv.getArgument(1)))
                .when(valueOps).set(anyString(), anyString());
        when(valueOps.get(anyString())).thenAnswer(inv -> store.get(inv.getArgument(0)));

        long before = service.current(USER_ID);
        service.bump(USER_ID);
        long after = service.current(USER_ID);

        assertThat(before).isZero();
        assertThat(after).isGreaterThan(before);
    }

    @Test
    @DisplayName("fail-open: current returns 0 when Redis throws")
    void currentFailsOpenOnRedisError() {
        when(valueOps.get(anyString())).thenThrow(new RuntimeException("redis down"));

        assertThat(service.current(USER_ID)).isZero();
    }

    @Test
    @DisplayName("bump swallows Redis faults (no exception propagates)")
    void bumpSwallowsRedisError() {
        doThrow(new RuntimeException("redis down")).when(valueOps).set(anyString(), anyString());

        // must not throw
        service.bump(USER_ID);
    }
}
