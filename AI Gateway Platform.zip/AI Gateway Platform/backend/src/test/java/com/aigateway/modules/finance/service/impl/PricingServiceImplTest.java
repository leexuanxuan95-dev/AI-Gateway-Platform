package com.aigateway.modules.finance.service.impl;

import com.aigateway.common.exception.BizException;
import com.aigateway.common.exception.ErrorCode;
import com.aigateway.modules.finance.dto.ChargeResult;
import com.aigateway.modules.finance.entity.PricingMarkup;
import com.aigateway.modules.finance.mapper.PricingMarkupMapper;
import com.aigateway.modules.model.entity.ModelVersion;
import com.aigateway.modules.model.service.ModelRouteService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Collections;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

/**
 * Unit tests for {@link PricingServiceImpl} verifying the HARD min-margin pricing rule
 * (design doc §10.4-D): {@code charge = max(cost*(1+markupRate), cost*(1+minMargin)) + markupFixed},
 * and the never-below-cost / PRICE_NOT_SET guarantees.
 *
 * <p>All collaborators ({@link ModelRouteService}, {@link PricingMarkupMapper}) are mocked.</p>
 */
@ExtendWith(MockitoExtension.class)
@DisplayName("PricingServiceImpl - min-margin pricing rule (§10.4)")
class PricingServiceImplTest {

    private static final String MODEL_CODE = "claude-opus-4-8";
    private static final Long COMPANY_ID = 100L;
    private static final Long FAMILY_ID = 7L;
    private static final int SCALE = 6;

    /** Defaults injected via @Value in production; set here via reflection. */
    private static final BigDecimal DEFAULT_MARKUP_RATE = new BigDecimal("0.30");
    private static final BigDecimal DEFAULT_MIN_MARGIN = new BigDecimal("0.10");

    @Mock
    private PricingMarkupMapper pricingMarkupMapper;

    @Mock
    private ModelRouteService modelRouteService;

    @InjectMocks
    private PricingServiceImpl pricingService;

    @BeforeEach
    void setUp() {
        ReflectionTestUtils.setField(pricingService, "defaultMarkupRate", DEFAULT_MARKUP_RATE);
        ReflectionTestUtils.setField(pricingService, "defaultMinMargin", DEFAULT_MIN_MARGIN);
    }

    /** Build a model version with the given per-million cost fields. */
    private ModelVersion modelWithCost(String costInput, String costOutput, String costCached) {
        ModelVersion mv = new ModelVersion();
        mv.setModelCode(MODEL_CODE);
        mv.setFamilyId(FAMILY_ID);
        mv.setCostInput(costInput == null ? null : new BigDecimal(costInput));
        mv.setCostOutput(costOutput == null ? null : new BigDecimal(costOutput));
        mv.setCostCached(costCached == null ? null : new BigDecimal(costCached));
        return mv;
    }

    private PricingMarkup rule(String scope, String scopeRef,
                               String markupRate, String minMargin, String markupFixed) {
        PricingMarkup r = new PricingMarkup();
        r.setScope(scope);
        r.setScopeRef(scopeRef);
        r.setEnabled(true);
        r.setMarkupRate(markupRate == null ? null : new BigDecimal(markupRate));
        r.setMinMargin(minMargin == null ? null : new BigDecimal(minMargin));
        r.setMarkupFixed(markupFixed == null ? null : new BigDecimal(markupFixed));
        return r;
    }

    private BigDecimal scaled(String v) {
        return new BigDecimal(v).setScale(SCALE, RoundingMode.HALF_UP);
    }

    @Test
    @DisplayName("calc: charge uses markupRate when markupRate > minMargin")
    void calc_markupRateWins_whenRateAboveMargin() {
        // cost = 1_000_000/1e6 * 10 = 10.000000
        when(modelRouteService.getByCode(MODEL_CODE))
                .thenReturn(modelWithCost("10", "0", "0"));
        // explicit company rule: rate 0.50, margin 0.10 -> rate wins
        when(pricingMarkupMapper.selectList(any()))
                .thenReturn(List.of(rule("company", COMPANY_ID.toString(), "0.50", "0.10", "0")));

        ChargeResult res = pricingService.calc(MODEL_CODE, 1_000_000L, 0L, 0L, COMPANY_ID);

        // charge = max(10*1.50, 10*1.10) = 15.000000
        assertThat(res.getCost()).isEqualByComparingTo(scaled("10"));
        assertThat(res.getCharge()).isEqualByComparingTo(scaled("15"));
        assertThat(res.getMarkupRate()).isEqualByComparingTo("0.50");
        assertThat(res.getMinMargin()).isEqualByComparingTo("0.10");
        assertThat(res.getCharge()).isGreaterThan(res.getCost());
    }

    @Test
    @DisplayName("calc: HARD min-margin wins when markupRate < minMargin")
    void calc_minMarginWins_whenRateBelowMargin() {
        when(modelRouteService.getByCode(MODEL_CODE))
                .thenReturn(modelWithCost("0", "20", "0"));
        // rate 0.02 < margin 0.25 -> margin must win
        when(pricingMarkupMapper.selectList(any()))
                .thenReturn(List.of(rule("company", COMPANY_ID.toString(), "0.02", "0.25", "0")));

        // cost = 2_000_000/1e6 * 20 = 40.000000 (output tokens only)
        ChargeResult res = pricingService.calc(MODEL_CODE, 0L, 2_000_000L, 0L, COMPANY_ID);

        // charge = max(40*1.02=40.80, 40*1.25=50.00) = 50.000000
        assertThat(res.getCost()).isEqualByComparingTo(scaled("40"));
        assertThat(res.getCharge()).isEqualByComparingTo(scaled("50"));
    }

    @Test
    @DisplayName("calc: markupFixed is added on top of the max(rate, margin) component")
    void calc_addsMarkupFixed() {
        when(modelRouteService.getByCode(MODEL_CODE))
                .thenReturn(modelWithCost("10", "0", "0"));
        when(pricingMarkupMapper.selectList(any()))
                .thenReturn(List.of(rule("company", COMPANY_ID.toString(), "0.30", "0.10", "2.5")));

        // cost = 10.000000 ; charge = max(13,11) + 2.5 = 15.500000
        ChargeResult res = pricingService.calc(MODEL_CODE, 1_000_000L, 0L, 0L, COMPANY_ID);

        assertThat(res.getCharge()).isEqualByComparingTo(scaled("15.5"));
    }

    @Test
    @DisplayName("calc: combines input + output + cached costs across multiple token counts")
    void calc_combinesAllTokenComponents() {
        when(modelRouteService.getByCode(MODEL_CODE))
                .thenReturn(modelWithCost("3", "15", "0.30"));
        when(pricingMarkupMapper.selectList(any()))
                .thenReturn(List.of(rule("global", null, "0.20", "0.10", "0")));

        // cost = 500_000/1e6*3 + 200_000/1e6*15 + 1_000_000/1e6*0.30
        //      = 1.5 + 3.0 + 0.30 = 4.800000
        ChargeResult res = pricingService.calc(MODEL_CODE, 500_000L, 200_000L, 1_000_000L, COMPANY_ID);

        assertThat(res.getCost()).isEqualByComparingTo(scaled("4.8"));
        // charge = max(4.8*1.20=5.76, 4.8*1.10=5.28) = 5.760000
        assertThat(res.getCharge()).isEqualByComparingTo(scaled("5.76"));
        assertThat(res.getCharge()).isGreaterThanOrEqualTo(res.getCost());
    }

    @Test
    @DisplayName("calc: falls back to default markup/min-margin when no rule matches")
    void calc_fallsBackToDefaults_whenNoRules() {
        when(modelRouteService.getByCode(MODEL_CODE))
                .thenReturn(modelWithCost("10", "0", "0"));
        // empty rule list -> resolveMarkup returns null -> applyMarkup uses defaults
        when(pricingMarkupMapper.selectList(any()))
                .thenReturn(Collections.emptyList());

        ChargeResult res = pricingService.calc(MODEL_CODE, 1_000_000L, 0L, 0L, COMPANY_ID);

        // charge = max(10*1.30=13, 10*1.10=11) = 13.000000 using defaults
        assertThat(res.getCharge()).isEqualByComparingTo(scaled("13"));
        assertThat(res.getMarkupRate()).isEqualByComparingTo(DEFAULT_MARKUP_RATE);
        assertThat(res.getMinMargin()).isEqualByComparingTo(DEFAULT_MIN_MARGIN);
    }

    @Test
    @DisplayName("calc: charge is never below cost (default min-margin floor still applies)")
    void calc_chargeNeverBelowCost() {
        when(modelRouteService.getByCode(MODEL_CODE))
                .thenReturn(modelWithCost("12.5", "0", "0"));
        when(pricingMarkupMapper.selectList(any()))
                .thenReturn(Collections.emptyList());

        ChargeResult res = pricingService.calc(MODEL_CODE, 1_000_000L, 0L, 0L, COMPANY_ID);

        assertThat(res.getCharge()).isGreaterThanOrEqualTo(res.getCost());
    }

    @Test
    @DisplayName("calc: throws PRICE_NOT_SET when all cost fields are null/zero")
    void calc_throwsPriceNotSet_whenCostUnset() {
        when(modelRouteService.getByCode(MODEL_CODE))
                .thenReturn(modelWithCost(null, null, null));

        assertThatThrownBy(() -> pricingService.calc(MODEL_CODE, 1_000L, 1_000L, 0L, COMPANY_ID))
                .isInstanceOf(BizException.class)
                .extracting("errorCode")
                .isEqualTo(ErrorCode.PRICE_NOT_SET);
    }

    @Test
    @DisplayName("calc: throws PRICE_NOT_SET when costs are set but resolved cost is zero (no billed tokens)")
    void calc_throwsPriceNotSet_whenResolvedCostZero() {
        when(modelRouteService.getByCode(MODEL_CODE))
                .thenReturn(modelWithCost("10", "10", "10"));

        // All token counts zero -> cost resolves to zero -> PRICE_NOT_SET.
        assertThatThrownBy(() -> pricingService.calc(MODEL_CODE, 0L, 0L, 0L, COMPANY_ID))
                .isInstanceOf(BizException.class)
                .extracting("errorCode")
                .isEqualTo(ErrorCode.PRICE_NOT_SET);
    }

    @Test
    @DisplayName("calc: throws MODEL_NOT_FOUND when model version is missing")
    void calc_throwsModelNotFound_whenMissing() {
        when(modelRouteService.getByCode(MODEL_CODE)).thenReturn(null);

        assertThatThrownBy(() -> pricingService.calc(MODEL_CODE, 1L, 1L, 0L, COMPANY_ID))
                .isInstanceOf(BizException.class)
                .extracting("errorCode")
                .isEqualTo(ErrorCode.MODEL_NOT_FOUND);
    }

    @Test
    @DisplayName("calcByCost: applies markup over the upstream cost and never charges below cost")
    void calcByCost_appliesMarkup() {
        when(pricingMarkupMapper.selectList(any()))
                .thenReturn(List.of(rule("global", null, "0.40", "0.10", "0")));

        ChargeResult res = pricingService.calcByCost(new BigDecimal("100"), COMPANY_ID);

        // charge = max(100*1.40=140, 100*1.10=110) = 140.000000
        assertThat(res.getCost()).isEqualByComparingTo(scaled("100"));
        assertThat(res.getCharge()).isEqualByComparingTo(scaled("140"));
        assertThat(res.getCharge()).isGreaterThan(res.getCost());
    }

    @Test
    @DisplayName("calcByCost: HARD min-margin wins when markupRate < minMargin")
    void calcByCost_minMarginWins() {
        when(pricingMarkupMapper.selectList(any()))
                .thenReturn(List.of(rule("company", COMPANY_ID.toString(), "0.01", "0.20", "0")));

        ChargeResult res = pricingService.calcByCost(new BigDecimal("50"), COMPANY_ID);

        // charge = max(50*1.01=50.50, 50*1.20=60.00) = 60.000000
        assertThat(res.getCharge()).isEqualByComparingTo(scaled("60"));
    }

    @Test
    @DisplayName("calcByCost: throws PRICE_NOT_SET when upstream cost is null")
    void calcByCost_throwsWhenNull() {
        assertThatThrownBy(() -> pricingService.calcByCost(null, COMPANY_ID))
                .isInstanceOf(BizException.class)
                .extracting("errorCode")
                .isEqualTo(ErrorCode.PRICE_NOT_SET);
    }

    @Test
    @DisplayName("calcByCost: throws PRICE_NOT_SET when upstream cost is zero or negative")
    void calcByCost_throwsWhenNonPositive() {
        assertThatThrownBy(() -> pricingService.calcByCost(BigDecimal.ZERO, COMPANY_ID))
                .isInstanceOf(BizException.class)
                .extracting("errorCode")
                .isEqualTo(ErrorCode.PRICE_NOT_SET);
    }
}
