package com.aigateway.common.security;

import jakarta.servlet.FilterChain;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;

import jakarta.servlet.ServletException;
import java.io.IOException;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

/**
 * Unit tests for {@link WafFilter}: malicious request lines are blocked with HTTP 403 and the
 * chain is short-circuited, while a clean request passes through. Uses Spring's
 * {@link MockHttpServletRequest}/{@link MockHttpServletResponse} and a mocked {@link FilterChain}.
 */
@DisplayName("WafFilter - attack-signature blocking")
class WafFilterTest {

    private static final int HTTP_FORBIDDEN = 403;

    private final WafFilter filter = new WafFilter();

    private MockHttpServletResponse runFilter(MockHttpServletRequest req, FilterChain chain)
            throws ServletException, IOException {
        MockHttpServletResponse resp = new MockHttpServletResponse();
        filter.doFilter(req, resp, chain);
        return resp;
    }

    private MockHttpServletRequest get(String uri, String query) {
        MockHttpServletRequest req = new MockHttpServletRequest("GET", uri);
        req.setQueryString(query);
        req.setRemoteAddr("203.0.113.7");
        return req;
    }

    @Test
    @DisplayName("blocks SQL injection in the query string")
    void blocksSqlInjection() throws Exception {
        FilterChain chain = mock(FilterChain.class);

        MockHttpServletResponse resp = runFilter(get("/api/x", "q=1 union select password from users"), chain);

        assertThat(resp.getStatus()).isEqualTo(HTTP_FORBIDDEN);
        verify(chain, never()).doFilter(org.mockito.ArgumentMatchers.any(), org.mockito.ArgumentMatchers.any());
    }

    @Test
    @DisplayName("blocks reflected XSS payloads")
    void blocksXss() throws Exception {
        FilterChain chain = mock(FilterChain.class);

        MockHttpServletResponse resp = runFilter(get("/api/x", "name=<script>alert(1)</script>"), chain);

        assertThat(resp.getStatus()).isEqualTo(HTTP_FORBIDDEN);
        verify(chain, never()).doFilter(org.mockito.ArgumentMatchers.any(), org.mockito.ArgumentMatchers.any());
    }

    @Test
    @DisplayName("blocks plain path traversal")
    void blocksPathTraversal() throws Exception {
        FilterChain chain = mock(FilterChain.class);

        MockHttpServletResponse resp = runFilter(get("/api/file", "p=../../etc/passwd"), chain);

        assertThat(resp.getStatus()).isEqualTo(HTTP_FORBIDDEN);
        verify(chain, never()).doFilter(org.mockito.ArgumentMatchers.any(), org.mockito.ArgumentMatchers.any());
    }

    @Test
    @DisplayName("blocks URL-encoded path traversal (double-decode evasion)")
    void blocksEncodedPathTraversal() throws Exception {
        FilterChain chain = mock(FilterChain.class);

        MockHttpServletResponse resp = runFilter(get("/api/file", "p=%2e%2e%2fetc"), chain);

        assertThat(resp.getStatus()).isEqualTo(HTTP_FORBIDDEN);
        verify(chain, never()).doFilter(org.mockito.ArgumentMatchers.any(), org.mockito.ArgumentMatchers.any());
    }

    @Test
    @DisplayName("blocks known scanner user-agents")
    void blocksScannerUserAgent() throws Exception {
        FilterChain chain = mock(FilterChain.class);
        MockHttpServletRequest req = get("/api/x", null);
        req.addHeader("User-Agent", "sqlmap/1.7");

        MockHttpServletResponse resp = runFilter(req, chain);

        assertThat(resp.getStatus()).isEqualTo(HTTP_FORBIDDEN);
        verify(chain, never()).doFilter(org.mockito.ArgumentMatchers.any(), org.mockito.ArgumentMatchers.any());
    }

    @Test
    @DisplayName("lets a clean request through to the chain")
    void allowsCleanRequest() throws Exception {
        FilterChain chain = mock(FilterChain.class);
        MockHttpServletRequest req = get("/api/user/me", "page=1&size=20");
        req.addHeader("User-Agent", "Mozilla/5.0 (Macintosh)");

        MockHttpServletResponse resp = runFilter(req, chain);

        assertThat(resp.getStatus()).isEqualTo(200);
        verify(chain, times(1)).doFilter(req, resp);
    }
}
