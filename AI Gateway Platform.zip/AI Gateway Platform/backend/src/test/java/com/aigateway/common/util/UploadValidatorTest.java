package com.aigateway.common.util;

import com.aigateway.common.exception.BizException;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.mock.web.MockMultipartFile;

import static org.assertj.core.api.Assertions.assertThatCode;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

/**
 * Unit tests for {@link UploadValidator}: object-key hardening (traversal / charset / extension),
 * document file validation (size / content-type / extension) and audio file validation.
 */
@DisplayName("UploadValidator - anti-malicious-upload checks")
class UploadValidatorTest {

    // ---- object keys ----

    @Test
    @DisplayName("accepts a sane object key with an allowed extension")
    void acceptsSaneKey() {
        assertThatCode(() -> UploadValidator.validateObjectKey("doc", "company/123/license.pdf"))
                .doesNotThrowAnyException();
    }

    @Test
    @DisplayName("rejects path traversal in an object key")
    void rejectsTraversalKey() {
        assertThatThrownBy(() -> UploadValidator.validateObjectKey("doc", "../../etc/passwd.png"))
                .isInstanceOf(BizException.class);
    }

    @Test
    @DisplayName("rejects an absolute object key")
    void rejectsAbsoluteKey() {
        assertThatThrownBy(() -> UploadValidator.validateObjectKey("doc", "/etc/shadow.png"))
                .isInstanceOf(BizException.class);
    }

    @Test
    @DisplayName("rejects illegal characters in an object key")
    void rejectsIllegalCharsKey() {
        assertThatThrownBy(() -> UploadValidator.validateObjectKey("doc", "a b;rm -rf.png"))
                .isInstanceOf(BizException.class);
    }

    @Test
    @DisplayName("rejects a disallowed extension on an object key")
    void rejectsBadExtensionKey() {
        assertThatThrownBy(() -> UploadValidator.validateObjectKey("doc", "evil/upload.exe"))
                .isInstanceOf(BizException.class);
    }

    @Test
    @DisplayName("rejects a blank object key")
    void rejectsBlankKey() {
        assertThatThrownBy(() -> UploadValidator.validateObjectKey("doc", "  "))
                .isInstanceOf(BizException.class);
    }

    // ---- document files ----

    @Test
    @DisplayName("accepts a well-formed image upload")
    void acceptsImageFile() {
        MockMultipartFile f = new MockMultipartFile(
                "file", "license.png", "image/png", new byte[]{1, 2, 3});
        assertThatCode(() -> UploadValidator.validateFile(f)).doesNotThrowAnyException();
    }

    @Test
    @DisplayName("rejects a disallowed content-type")
    void rejectsBadContentType() {
        MockMultipartFile f = new MockMultipartFile(
                "file", "x.png", "application/x-msdownload", new byte[]{1});
        assertThatThrownBy(() -> UploadValidator.validateFile(f)).isInstanceOf(BizException.class);
    }

    @Test
    @DisplayName("rejects an oversized upload")
    void rejectsOversized() {
        byte[] big = new byte[(int) UploadValidator.MAX_FILE_BYTES + 1];
        MockMultipartFile f = new MockMultipartFile("file", "x.pdf", "application/pdf", big);
        assertThatThrownBy(() -> UploadValidator.validateFile(f)).isInstanceOf(BizException.class);
    }

    @Test
    @DisplayName("rejects an empty upload")
    void rejectsEmpty() {
        MockMultipartFile f = new MockMultipartFile("file", "x.pdf", "application/pdf", new byte[0]);
        assertThatThrownBy(() -> UploadValidator.validateFile(f)).isInstanceOf(BizException.class);
    }

    // ---- audio files ----

    @Test
    @DisplayName("accepts an allowed audio format")
    void acceptsAudioFile() {
        MockMultipartFile f = new MockMultipartFile(
                "file", "speech.mp3", "audio/mpeg", new byte[]{1, 2, 3});
        assertThatCode(() -> UploadValidator.validateAudioFile(f)).doesNotThrowAnyException();
    }

    @Test
    @DisplayName("rejects a disallowed audio extension")
    void rejectsBadAudioExtension() {
        MockMultipartFile f = new MockMultipartFile(
                "file", "speech.exe", "audio/mpeg", new byte[]{1, 2, 3});
        assertThatThrownBy(() -> UploadValidator.validateAudioFile(f)).isInstanceOf(BizException.class);
    }

    @Test
    @DisplayName("rejects traversal in an audio filename")
    void rejectsAudioTraversal() {
        MockMultipartFile f = new MockMultipartFile(
                "file", "../../x.mp3", "audio/mpeg", new byte[]{1, 2, 3});
        assertThatThrownBy(() -> UploadValidator.validateAudioFile(f)).isInstanceOf(BizException.class);
    }
}
