package com.aigateway.modules.user.service.impl;

import com.aigateway.common.exception.BizException;
import com.aigateway.common.exception.ErrorCode;
import com.aigateway.modules.user.dto.SendCodeRequest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ValueOperations;

import java.time.Duration;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.when;

/**
 * Verifies the anti-bombing cooldown in {@link AuthServiceImpl#sendCode}: when the per-target
 * cooldown key already exists ({@code setIfAbsent} returns {@code false}), a second request
 * within the window is rejected with {@link ErrorCode#RATE_LIMITED}. {@link RedisTemplate} and
 * its {@link ValueOperations} are mocked; all other collaborators are unused Mockito stubs.
 */
@ExtendWith(MockitoExtension.class)
@DisplayName("AuthServiceImpl.sendCode - cooldown throttle")
class SendCodeThrottleTest {

    @Mock
    private RedisTemplate<String, Object> redisTemplate;
    @Mock
    private ValueOperations<String, Object> valueOps;

    @InjectMocks
    private AuthServiceImpl authService;

    @BeforeEach
    void setUp() {
        lenient().when(redisTemplate.opsForValue()).thenReturn(valueOps);
    }

    @Test
    @DisplayName("second call within the cooldown is rejected with RATE_LIMITED")
    void cooldownActive_throwsRateLimited() {
        // cooldown key already present -> setIfAbsent returns false
        when(valueOps.setIfAbsent(anyString(), eq("1"), any(Duration.class))).thenReturn(false);
        SendCodeRequest req = new SendCodeRequest();
        req.setScene("register");
        req.setTarget("user@example.com");

        assertThatThrownBy(() -> authService.sendCode(req))
                .isInstanceOf(BizException.class)
                .extracting(e -> ((BizException) e).getErrorCode())
                .isEqualTo(ErrorCode.RATE_LIMITED);
    }

    @Test
    @DisplayName("first call within the window passes the cooldown gate")
    void cooldownFresh_passesGate() {
        // fresh cooldown key acquired
        when(valueOps.setIfAbsent(anyString(), eq("1"), any(Duration.class))).thenReturn(true);
        // daily counter under the cap
        when(valueOps.increment(anyString())).thenReturn(1L);
        SendCodeRequest req = new SendCodeRequest();
        req.setScene("register");
        req.setTarget("user@example.com");

        // should reach code generation/storage without throwing
        authService.sendCode(req);

        assertThat(req.getTarget()).isEqualTo("user@example.com");
    }
}
