package com.aigateway.modules.payment.service.impl;

import com.aigateway.common.enums.RechargeStatus;
import com.aigateway.modules.finance.entity.FinRechargeOrder;
import com.aigateway.modules.finance.entity.RechargeFeeConfig;
import com.aigateway.modules.finance.mapper.FinRechargeOrderMapper;
import com.aigateway.modules.finance.service.FinanceService;
import com.aigateway.modules.payment.adapter.CallbackResult;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.kafka.core.KafkaTemplate;

import java.math.BigDecimal;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Unit tests for {@link RechargeSettleServiceImpl#creditPaidOrder} — DB-level idempotency.
 * The order is only credited when the conditional update (status 0 -&gt; 1) actually changes a row.
 */
@ExtendWith(MockitoExtension.class)
@DisplayName("RechargeSettleServiceImpl - credit idempotency")
class RechargeSettleServiceImplTest {

    private static final Long COMPANY_ID = 100L;
    private static final String ORDER_NO = "RO-2026-0001";

    @Mock
    private FinRechargeOrderMapper rechargeOrderMapper;
    @Mock
    private FinanceService financeService;
    @Mock
    private KafkaTemplate<String, String> kafkaTemplate;
    @Mock
    private ObjectMapper objectMapper;

    @InjectMocks
    private RechargeSettleServiceImpl service;

    private FinRechargeOrder pendingOrder() {
        FinRechargeOrder o = new FinRechargeOrder();
        o.setId(1L);
        o.setOrderNo(ORDER_NO);
        o.setCompanyId(COMPANY_ID);
        o.setAmount(new BigDecimal("50.00"));
        o.setCurrency("USD");
        o.setStatus(RechargeStatus.PENDING);
        return o;
    }

    private CallbackResult callback() {
        CallbackResult cb = new CallbackResult();
        cb.setSuccess(true);
        cb.setOrderNo(ORDER_NO);
        cb.setThirdTxnId("txn-abc");
        cb.setAmount(new BigDecimal("50.00"));
        cb.setCurrency("USD");
        return cb;
    }

    @Test
    @DisplayName("credits the account exactly once when the conditional update changes a row")
    void creditPaidOrder_creditsWhenStatusFlips() throws Exception {
        when(rechargeOrderMapper.update(any(), any())).thenReturn(1);
        RechargeFeeConfig fee = new RechargeFeeConfig();
        when(financeService.resolveRechargeFee(COMPANY_ID)).thenReturn(fee);
        lenient().when(objectMapper.writeValueAsString(any())).thenReturn("{}");

        boolean credited = service.creditPaidOrder(pendingOrder(), callback(), "{\"x\":1}");

        assertThat(credited).isTrue();
        verify(financeService, times(1))
                .creditRecharge(COMPANY_ID, new BigDecimal("50.00"), ORDER_NO, fee);
    }

    @Test
    @DisplayName("is idempotent: when the conditional update changes 0 rows it does not credit again")
    void creditPaidOrder_idempotentWhenAlreadyPaid() {
        // Another worker already flipped the status -> conditional update affects 0 rows.
        when(rechargeOrderMapper.update(any(), any())).thenReturn(0);

        boolean credited = service.creditPaidOrder(pendingOrder(), callback(), "{\"x\":1}");

        assertThat(credited).isFalse();
        verify(financeService, never()).creditRecharge(any(), any(), anyString(), any());
        verify(financeService, never()).resolveRechargeFee(any());
        verify(kafkaTemplate, never()).send(any(), anyString(), anyString());
    }
}
