package com.aigateway.modules.apikey.service.impl;

import cn.hutool.crypto.SecureUtil;
import com.aigateway.common.enums.ApiKeyStatus;
import com.aigateway.common.exception.BizException;
import com.aigateway.common.exception.ErrorCode;
import com.aigateway.modules.apikey.dto.ApiKeyAuthContext;
import com.aigateway.modules.apikey.entity.ApiKey;
import com.aigateway.modules.apikey.mapper.ApiKeyMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ValueOperations;

import java.time.OffsetDateTime;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Unit tests for {@link ApiKeyAuthServiceImpl#authenticate(String, String)} covering the
 * security-critical authentication path: hash lookup, status, expiry and IP whitelist.
 * The mapper + Redis are mocked; every test exercises the cache-miss branch.
 */
@ExtendWith(MockitoExtension.class)
@DisplayName("ApiKeyAuthServiceImpl - authenticate")
class ApiKeyAuthServiceImplTest {

    private static final String RAW_KEY = "sk-test-1234567890";
    private static final String CLIENT_IP = "203.0.113.7";

    @Mock
    private ApiKeyMapper apiKeyMapper;
    @Mock
    private RedisTemplate<String, Object> redisTemplate;
    @Mock
    private ValueOperations<String, Object> valueOperations;

    @InjectMocks
    private ApiKeyAuthServiceImpl service;

    @BeforeEach
    void setUp() {
        // Cache-miss path: opsForValue().get(..) -> null, opsForValue().set(..) is a no-op.
        lenient().when(redisTemplate.opsForValue()).thenReturn(valueOperations);
        lenient().when(valueOperations.get(anyString())).thenReturn(null);
    }

    private ApiKey activeKey() {
        ApiKey key = new ApiKey();
        key.setId(42L);
        key.setCompanyId(100L);
        key.setProjectId(5L);
        key.setKeyHash(SecureUtil.sha256(RAW_KEY));
        key.setStatus(ApiKeyStatus.ACTIVE);
        key.setAllowedModels(List.of("claude-opus-4-8"));
        key.setRpmLimit(60);
        key.setTpmLimit(10_000);
        return key;
    }

    @Test
    @DisplayName("returns a populated context on a valid key (cache miss -> DB load -> cache set)")
    void authenticate_success() {
        when(apiKeyMapper.selectOne(any())).thenReturn(activeKey());

        ApiKeyAuthContext ctx = service.authenticate(RAW_KEY, CLIENT_IP);

        assertThat(ctx).isNotNull();
        assertThat(ctx.getApiKeyId()).isEqualTo(42L);
        assertThat(ctx.getCompanyId()).isEqualTo(100L);
        assertThat(ctx.getProjectId()).isEqualTo(5L);
        assertThat(ctx.getStatus()).isEqualTo(ApiKeyStatus.ACTIVE.getCode());
        assertThat(ctx.getAllowedModels()).containsExactly("claude-opus-4-8");
        // resolved context is written back to the cache
        verify(valueOperations).set(anyString(), any(ApiKeyAuthContext.class), any());
    }

    @Test
    @DisplayName("throws INVALID_API_KEY when raw key is null/blank")
    void authenticate_throwsOnBlankKey() {
        assertThatThrownBy(() -> service.authenticate("  ", CLIENT_IP))
                .isInstanceOf(BizException.class)
                .extracting("errorCode")
                .isEqualTo(ErrorCode.INVALID_API_KEY);
    }

    @Test
    @DisplayName("throws INVALID_API_KEY when no key matches the hash")
    void authenticate_throwsWhenKeyMissing() {
        when(apiKeyMapper.selectOne(any())).thenReturn(null);

        assertThatThrownBy(() -> service.authenticate(RAW_KEY, CLIENT_IP))
                .isInstanceOf(BizException.class)
                .extracting("errorCode")
                .isEqualTo(ErrorCode.INVALID_API_KEY);
    }

    @Test
    @DisplayName("throws INVALID_API_KEY when the key is disabled")
    void authenticate_throwsWhenDisabled() {
        ApiKey key = activeKey();
        key.setStatus(ApiKeyStatus.DISABLED);
        when(apiKeyMapper.selectOne(any())).thenReturn(key);

        assertThatThrownBy(() -> service.authenticate(RAW_KEY, CLIENT_IP))
                .isInstanceOf(BizException.class)
                .extracting("errorCode")
                .isEqualTo(ErrorCode.INVALID_API_KEY);
    }

    @Test
    @DisplayName("throws KEY_EXPIRED when the key is past its expiry")
    void authenticate_throwsWhenExpired() {
        ApiKey key = activeKey();
        key.setExpireAt(OffsetDateTime.now().minusDays(1));
        when(apiKeyMapper.selectOne(any())).thenReturn(key);

        assertThatThrownBy(() -> service.authenticate(RAW_KEY, CLIENT_IP))
                .isInstanceOf(BizException.class)
                .extracting("errorCode")
                .isEqualTo(ErrorCode.KEY_EXPIRED);
    }

    @Test
    @DisplayName("succeeds when expiry is in the future")
    void authenticate_succeedsWhenNotExpired() {
        ApiKey key = activeKey();
        key.setExpireAt(OffsetDateTime.now().plusDays(1));
        when(apiKeyMapper.selectOne(any())).thenReturn(key);

        ApiKeyAuthContext ctx = service.authenticate(RAW_KEY, CLIENT_IP);

        assertThat(ctx.getApiKeyId()).isEqualTo(42L);
    }

    @Test
    @DisplayName("throws IP_NOT_ALLOWED when client IP is not in a non-empty whitelist")
    void authenticate_throwsWhenIpNotWhitelisted() {
        ApiKey key = activeKey();
        key.setIpWhitelist(List.of("198.51.100.1"));
        when(apiKeyMapper.selectOne(any())).thenReturn(key);

        assertThatThrownBy(() -> service.authenticate(RAW_KEY, CLIENT_IP))
                .isInstanceOf(BizException.class)
                .extracting("errorCode")
                .isEqualTo(ErrorCode.IP_NOT_ALLOWED);
    }

    @Test
    @DisplayName("throws IP_NOT_ALLOWED when whitelist set but client IP is null")
    void authenticate_throwsWhenIpNull() {
        ApiKey key = activeKey();
        key.setIpWhitelist(List.of("198.51.100.1"));
        when(apiKeyMapper.selectOne(any())).thenReturn(key);

        assertThatThrownBy(() -> service.authenticate(RAW_KEY, null))
                .isInstanceOf(BizException.class)
                .extracting("errorCode")
                .isEqualTo(ErrorCode.IP_NOT_ALLOWED);
    }

    @Test
    @DisplayName("succeeds when the client IP is present in the whitelist")
    void authenticate_succeedsWhenIpWhitelisted() {
        ApiKey key = activeKey();
        key.setIpWhitelist(List.of(CLIENT_IP, "198.51.100.1"));
        when(apiKeyMapper.selectOne(any())).thenReturn(key);

        ApiKeyAuthContext ctx = service.authenticate(RAW_KEY, CLIENT_IP);

        assertThat(ctx.getApiKeyId()).isEqualTo(42L);
    }
}
