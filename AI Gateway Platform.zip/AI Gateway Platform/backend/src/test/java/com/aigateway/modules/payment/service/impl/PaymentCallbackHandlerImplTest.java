package com.aigateway.modules.payment.service.impl;

import com.aigateway.common.enums.RechargeStatus;
import com.aigateway.modules.finance.entity.FinRechargeOrder;
import com.aigateway.modules.finance.mapper.FinRechargeOrderMapper;
import com.aigateway.modules.payment.adapter.CallbackResult;
import com.aigateway.modules.payment.adapter.PaymentAdapter;
import com.aigateway.modules.payment.adapter.PaymentAdapterRegistry;
import com.aigateway.modules.payment.entity.PayChannelConfig;
import com.aigateway.modules.payment.service.PayChannelConfigService;
import com.aigateway.modules.payment.service.RechargeSettleService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ValueOperations;

import java.math.BigDecimal;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Unit tests for {@link PaymentCallbackHandlerImpl#handle} security/idempotency paths.
 * Focuses on: a signature-failed callback never credits, and an already-paid order is
 * idempotent (no double credit). All collaborators are mocked.
 */
@ExtendWith(MockitoExtension.class)
@DisplayName("PaymentCallbackHandlerImpl - callback security/idempotency")
class PaymentCallbackHandlerImplTest {

    private static final String CODE = "stripe";
    private static final String ORDER_NO = "RO-2026-0001";
    private static final String BODY = "{\"raw\":true}";

    @Mock
    private PaymentAdapterRegistry adapterRegistry;
    @Mock
    private PayChannelConfigService channelConfigService;
    @Mock
    private FinRechargeOrderMapper rechargeOrderMapper;
    @Mock
    private RechargeSettleService rechargeSettleService;
    @Mock
    private RedisTemplate<String, Object> redisTemplate;
    @Mock
    private ValueOperations<String, Object> valueOperations;
    @Mock
    private PaymentAdapter adapter;

    @InjectMocks
    private PaymentCallbackHandlerImpl handler;

    @BeforeEach
    void setUp() {
        lenient().when(channelConfigService.getByCode(CODE)).thenReturn(new PayChannelConfig());
        lenient().when(adapterRegistry.require(CODE)).thenReturn(adapter);
        lenient().when(redisTemplate.opsForValue()).thenReturn(valueOperations);
    }

    private CallbackResult successCallback() {
        CallbackResult cb = new CallbackResult();
        cb.setSuccess(true);
        cb.setOrderNo(ORDER_NO);
        cb.setAmount(new BigDecimal("50.00"));
        cb.setCurrency("USD");
        return cb;
    }

    private FinRechargeOrder order(RechargeStatus status) {
        FinRechargeOrder o = new FinRechargeOrder();
        o.setId(1L);
        o.setOrderNo(ORDER_NO);
        o.setAmount(new BigDecimal("50.00"));
        o.setCurrency("USD");
        o.setStatus(status);
        return o;
    }

    @Test
    @DisplayName("signature-failed callback (success=false) is ignored and never credits")
    void handle_signatureFailed_doesNotCredit() {
        CallbackResult bad = new CallbackResult();
        bad.setSuccess(false);
        when(adapter.handleCallback(eq(BODY), any(), any())).thenReturn(bad);

        String result = handler.handle(CODE, BODY, Map.of());

        assertThat(result).isEqualTo("ignored");
        verify(rechargeSettleService, never()).creditPaidOrder(any(), any(), anyString());
        verify(rechargeOrderMapper, never()).selectOne(any());
    }

    @Test
    @DisplayName("null callback result is ignored and never credits")
    void handle_nullCallback_doesNotCredit() {
        when(adapter.handleCallback(eq(BODY), any(), any())).thenReturn(null);

        String result = handler.handle(CODE, BODY, Map.of());

        assertThat(result).isEqualTo("ignored");
        verify(rechargeSettleService, never()).creditPaidOrder(any(), any(), anyString());
    }

    @Test
    @DisplayName("already-paid order (status=1) acks success without crediting again")
    void handle_alreadyPaid_isIdempotent() {
        when(adapter.handleCallback(eq(BODY), any(), any())).thenReturn(successCallback());
        when(valueOperations.setIfAbsent(anyString(), any(), anyLong(), any())).thenReturn(true);
        when(rechargeOrderMapper.selectOne(any())).thenReturn(order(RechargeStatus.PAID));

        String result = handler.handle(CODE, BODY, Map.of());

        assertThat(result).isEqualTo("success");
        verify(rechargeSettleService, never()).creditPaidOrder(any(), any(), anyString());
        // lock is always released
        verify(redisTemplate).delete(anyString());
    }

    @Test
    @DisplayName("concurrent retry that cannot acquire the lock returns processing without crediting")
    void handle_lockNotAcquired_returnsProcessing() {
        when(adapter.handleCallback(eq(BODY), any(), any())).thenReturn(successCallback());
        when(valueOperations.setIfAbsent(anyString(), any(), anyLong(), any())).thenReturn(false);

        String result = handler.handle(CODE, BODY, Map.of());

        assertThat(result).isEqualTo("processing");
        verify(rechargeSettleService, never()).creditPaidOrder(any(), any(), anyString());
        verify(rechargeOrderMapper, never()).selectOne(any());
    }

    @Test
    @DisplayName("pending order with a verified successful callback is credited once")
    void handle_pendingOrder_credits() {
        when(adapter.handleCallback(eq(BODY), any(), any())).thenReturn(successCallback());
        when(valueOperations.setIfAbsent(anyString(), any(), anyLong(), any())).thenReturn(true);
        when(rechargeOrderMapper.selectOne(any())).thenReturn(order(RechargeStatus.PENDING));
        when(rechargeSettleService.creditPaidOrder(any(), any(), anyString())).thenReturn(true);

        String result = handler.handle(CODE, BODY, Map.of());

        assertThat(result).isEqualTo("success");
        verify(rechargeSettleService).creditPaidOrder(any(), any(), eq(BODY));
        verify(redisTemplate).delete(anyString());
    }
}
