package com.aigateway.common.crypto;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.Base64;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Unit tests for {@link AesUtil} (AES-256-GCM). Verifies round-trip integrity, IV randomness
 * (two ciphertexts of the same plaintext differ) and null handling.
 */
@DisplayName("AesUtil - AES-256-GCM round trip")
class AesUtilTest {

    /** A deterministic 32-byte key encoded as base64 (test only). */
    private static final String TEST_KEY_BASE64 =
            Base64.getEncoder().encodeToString("0123456789abcdef0123456789abcdef".getBytes());

    private AesUtil aesUtil;

    @BeforeEach
    void setUp() {
        aesUtil = new AesUtil(TEST_KEY_BASE64);
    }

    @Test
    @DisplayName("encrypt then decrypt returns the original plaintext")
    void encryptDecrypt_roundTrips() {
        String plain = "sk-upstream-secret-credential-009";

        String cipher = aesUtil.encrypt(plain);
        String decrypted = aesUtil.decrypt(cipher);

        assertThat(cipher).isNotNull().isNotEqualTo(plain);
        assertThat(decrypted).isEqualTo(plain);
    }

    @Test
    @DisplayName("two encryptions of the same plaintext differ (random IV)")
    void encrypt_producesDifferentCiphertextsPerCall() {
        String plain = "same-plaintext";

        String c1 = aesUtil.encrypt(plain);
        String c2 = aesUtil.encrypt(plain);

        assertThat(c1).isNotEqualTo(c2);
        // both still decrypt back to the original
        assertThat(aesUtil.decrypt(c1)).isEqualTo(plain);
        assertThat(aesUtil.decrypt(c2)).isEqualTo(plain);
    }

    @Test
    @DisplayName("encrypt(null) returns null")
    void encrypt_nullReturnsNull() {
        assertThat(aesUtil.encrypt(null)).isNull();
    }

    @Test
    @DisplayName("decrypt(null) returns null")
    void decrypt_nullReturnsNull() {
        assertThat(aesUtil.decrypt(null)).isNull();
    }

    @Test
    @DisplayName("empty string survives the round trip")
    void encryptDecrypt_emptyString() {
        String cipher = aesUtil.encrypt("");
        assertThat(aesUtil.decrypt(cipher)).isEmpty();
    }

    @Test
    @DisplayName("constructor rejects a key that is not 32 bytes")
    void constructor_rejectsWrongKeyLength() {
        String shortKey = Base64.getEncoder().encodeToString("too-short".getBytes());
        org.assertj.core.api.Assertions.assertThatThrownBy(() -> new AesUtil(shortKey))
                .isInstanceOf(IllegalStateException.class);
    }
}
