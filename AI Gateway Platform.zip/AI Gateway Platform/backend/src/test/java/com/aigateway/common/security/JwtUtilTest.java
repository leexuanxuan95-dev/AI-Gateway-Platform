package com.aigateway.common.security;

import io.jsonwebtoken.Claims;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

/**
 * Unit tests for {@link JwtUtil} access-token issue/parse round trip.
 */
@DisplayName("JwtUtil - issue/parse access token")
class JwtUtilTest {

    /** HMAC-SHA key material must be at least 256 bits; use a comfortably long test secret. */
    private static final String SECRET =
            "test-secret-test-secret-test-secret-test-secret-0123456789-abcdef";
    private static final long TTL_SECONDS = 3600L;
    private static final Long USER_ID = 777L;
    private static final String UID = "u-777";

    private JwtUtil jwtUtil;

    @BeforeEach
    void setUp() {
        jwtUtil = new JwtUtil(SECRET, TTL_SECONDS);
    }

    @Test
    @DisplayName("issued token parses back to the same subject, uid and extra claims")
    void issueThenParse_roundTrips() {
        String token = jwtUtil.issueAccessToken(USER_ID, UID,
                Map.of("companyId", 100, "role", "OWNER"));

        Claims claims = jwtUtil.parse(token);

        assertThat(claims.getSubject()).isEqualTo(String.valueOf(USER_ID));
        assertThat(claims.get("uid", String.class)).isEqualTo(UID);
        assertThat(claims.get("role", String.class)).isEqualTo("OWNER");
        assertThat(claims.get("companyId", Integer.class)).isEqualTo(100);
    }

    @Test
    @DisplayName("token carries issuedAt and a future expiration")
    void issuedToken_hasExpiryInFuture() {
        String token = jwtUtil.issueAccessToken(USER_ID, UID, Map.of());

        Claims claims = jwtUtil.parse(token);

        assertThat(claims.getIssuedAt()).isNotNull();
        assertThat(claims.getExpiration()).isNotNull();
        assertThat(claims.getExpiration()).isAfter(claims.getIssuedAt());
    }

    @Test
    @DisplayName("parsing a token signed with a different secret fails")
    void parse_failsForTokenFromDifferentSecret() {
        JwtUtil other = new JwtUtil(
                "another-secret-another-secret-another-secret-0123456789-xyz", TTL_SECONDS);
        String foreignToken = other.issueAccessToken(USER_ID, UID, Map.of());

        assertThatThrownBy(() -> jwtUtil.parse(foreignToken))
                .isInstanceOf(io.jsonwebtoken.JwtException.class);
    }
}
