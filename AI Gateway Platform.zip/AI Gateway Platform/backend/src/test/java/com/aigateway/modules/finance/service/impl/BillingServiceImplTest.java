package com.aigateway.modules.finance.service.impl;

import com.aigateway.common.exception.BizException;
import com.aigateway.common.exception.ErrorCode;
import com.aigateway.modules.finance.dto.SettleCmd;
import com.aigateway.modules.finance.entity.FinAccount;
import com.aigateway.modules.finance.entity.FinModelBinding;
import com.aigateway.modules.finance.entity.PlatformProfitAccount;
import com.aigateway.modules.finance.mapper.FinAccountMapper;
import com.aigateway.modules.finance.mapper.FinModelBindingMapper;
import com.aigateway.modules.finance.mapper.FinTransactionMapper;
import com.aigateway.modules.finance.mapper.PlatformProfitAccountMapper;
import com.aigateway.modules.finance.mapper.ProfitLedgerMapper;
import com.aigateway.modules.finance.mapper.SettlementMapper;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.kafka.core.KafkaTemplate;

import java.math.BigDecimal;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Unit tests for {@link BillingServiceImpl} freeze/settle balance flow (design doc §10.4-E / §11.1).
 * All mappers and the Kafka template are mocked; assertions focus on the account mutations and
 * the observable downstream mapper interactions.
 */
@ExtendWith(MockitoExtension.class)
@DisplayName("BillingServiceImpl - freeze/settle balance flow")
class BillingServiceImplTest {

    private static final Long COMPANY_ID = 100L;
    private static final Long CHANNEL_ID = 9L;
    private static final String MODEL_CODE = "claude-opus-4-8";
    private static final String REQUEST_ID = "req-123";

    @Mock
    private FinAccountMapper finAccountMapper;
    @Mock
    private FinTransactionMapper finTransactionMapper;
    @Mock
    private FinModelBindingMapper finModelBindingMapper;
    @Mock
    private PlatformProfitAccountMapper platformProfitAccountMapper;
    @Mock
    private ProfitLedgerMapper profitLedgerMapper;
    @Mock
    private SettlementMapper settlementMapper;
    @Mock
    private KafkaTemplate<String, String> kafkaTemplate;
    @Mock
    private ObjectMapper objectMapper;

    @InjectMocks
    private BillingServiceImpl billingService;

    private FinAccount account(String available, String freeze) {
        FinAccount acc = new FinAccount();
        acc.setId(1L);
        acc.setCompanyId(COMPANY_ID);
        acc.setAvailableBalance(new BigDecimal(available));
        acc.setFreezeBalance(new BigDecimal(freeze));
        acc.setTotalConsume(BigDecimal.ZERO);
        acc.setVersion(0L);
        return acc;
    }

    private SettleCmd settleCmd(String charge, String cost, String frozen) {
        SettleCmd cmd = new SettleCmd();
        cmd.setCompanyId(COMPANY_ID);
        cmd.setChannelId(CHANNEL_ID);
        cmd.setModelCode(MODEL_CODE);
        cmd.setRequestId(REQUEST_ID);
        cmd.setProjectId(5L);
        cmd.setApiKeyId(3L);
        cmd.setPromptTokens(10L);
        cmd.setCompletionTokens(20L);
        cmd.setCachedTokens(0L);
        cmd.setCharge(new BigDecimal(charge));
        cmd.setCost(new BigDecimal(cost));
        cmd.setFrozen(new BigDecimal(frozen));
        return cmd;
    }

    // ---------------- freeze ----------------

    @Test
    @DisplayName("freeze: moves estimate from available to freeze and updates the account")
    void freeze_movesAvailableToFreeze() {
        FinAccount acc = account("100", "0");
        when(finAccountMapper.selectOne(any())).thenReturn(acc);
        when(finAccountMapper.updateById(any(FinAccount.class))).thenReturn(1);

        BigDecimal frozen = billingService.freeze(COMPANY_ID, new BigDecimal("30"));

        assertThat(frozen).isEqualByComparingTo("30");

        ArgumentCaptor<FinAccount> captor = ArgumentCaptor.forClass(FinAccount.class);
        verify(finAccountMapper).updateById(captor.capture());
        FinAccount saved = captor.getValue();
        assertThat(saved.getAvailableBalance()).isEqualByComparingTo("70");
        assertThat(saved.getFreezeBalance()).isEqualByComparingTo("30");
    }

    @Test
    @DisplayName("freeze: throws INSUFFICIENT_BALANCE when available < estimate")
    void freeze_throwsWhenInsufficient() {
        when(finAccountMapper.selectOne(any())).thenReturn(account("10", "0"));

        assertThatThrownBy(() -> billingService.freeze(COMPANY_ID, new BigDecimal("30")))
                .isInstanceOf(BizException.class)
                .extracting("errorCode")
                .isEqualTo(ErrorCode.INSUFFICIENT_BALANCE);

        verify(finAccountMapper, never()).updateById(any());
    }

    @Test
    @DisplayName("freeze: non-positive estimate is a no-op returning zero")
    void freeze_zeroEstimateIsNoop() {
        BigDecimal frozen = billingService.freeze(COMPANY_ID, BigDecimal.ZERO);

        assertThat(frozen).isEqualByComparingTo(BigDecimal.ZERO);
        verify(finAccountMapper, never()).selectOne(any());
        verify(finAccountMapper, never()).updateById(any());
    }

    // ---------------- settle ----------------

    @Test
    @DisplayName("settle: releases frozen estimate, deducts charge, accumulates total consume")
    void settle_releasesFrozenAndDeductsCharge() {
        // available starts at 70 (30 frozen). frozen=30, charge=20.
        FinAccount acc = account("70", "30");
        when(finAccountMapper.selectOne(any())).thenReturn(acc);
        when(finAccountMapper.updateById(any(FinAccount.class))).thenReturn(1);
        when(finModelBindingMapper.selectOne(any())).thenReturn(null);
        when(platformProfitAccountMapper.selectById(1)).thenReturn(profitAccount());

        billingService.settle(settleCmd("20", "12", "30"));

        ArgumentCaptor<FinAccount> captor = ArgumentCaptor.forClass(FinAccount.class);
        verify(finAccountMapper).updateById(captor.capture());
        FinAccount saved = captor.getValue();
        // freeze: 30 - 30 = 0 ; available: 70 + 30 - 20 = 80 ; totalConsume: 0 + 20 = 20
        assertThat(saved.getFreezeBalance()).isEqualByComparingTo("0");
        assertThat(saved.getAvailableBalance()).isEqualByComparingTo("80");
        assertThat(saved.getTotalConsume()).isEqualByComparingTo("20");
    }

    @Test
    @DisplayName("settle: writes consume transaction, profit ledger and bill-token record")
    void settle_writesLedgerRecords() {
        when(finAccountMapper.selectOne(any())).thenReturn(account("70", "30"));
        when(finAccountMapper.updateById(any(FinAccount.class))).thenReturn(1);
        when(finModelBindingMapper.selectOne(any())).thenReturn(null);
        when(platformProfitAccountMapper.selectById(1)).thenReturn(profitAccount());

        billingService.settle(settleCmd("20", "12", "30"));

        verify(finTransactionMapper).insert(any());
        verify(profitLedgerMapper).insert(any());
        // bill_token written with the customer charge + upstream cost.
        long expectedTotal = 10L + 20L + 0L;
        verify(settlementMapper).insertBillToken(
                eq(REQUEST_ID), eq(COMPANY_ID), eq(5L), eq(3L), eq(MODEL_CODE), eq(CHANNEL_ID),
                eq(10L), eq(20L), eq(0L), eq(expectedTotal),
                any(BigDecimal.class), any(BigDecimal.class));
    }

    @Test
    @DisplayName("settle: updates channel used_quota and upstream_reserve with the cost")
    void settle_updatesChannelAndUpstreamReserve() {
        when(finAccountMapper.selectOne(any())).thenReturn(account("70", "30"));
        when(finAccountMapper.updateById(any(FinAccount.class))).thenReturn(1);
        when(finModelBindingMapper.selectOne(any())).thenReturn(null);
        when(platformProfitAccountMapper.selectById(1)).thenReturn(profitAccount());

        billingService.settle(settleCmd("20", "12", "30"));

        ArgumentCaptor<BigDecimal> costCaptor = ArgumentCaptor.forClass(BigDecimal.class);
        verify(settlementMapper).addChannelUsedQuota(eq(CHANNEL_ID), costCaptor.capture());
        verify(settlementMapper).addUpstreamReserve(eq(CHANNEL_ID), any(BigDecimal.class));
        assertThat(costCaptor.getValue()).isEqualByComparingTo("12");
    }

    @Test
    @DisplayName("settle: bumps platform profit account by revenue/cost/profit")
    void settle_bumpsProfitAccount() {
        when(finAccountMapper.selectOne(any())).thenReturn(account("70", "30"));
        when(finAccountMapper.updateById(any(FinAccount.class))).thenReturn(1);
        when(finModelBindingMapper.selectOne(any())).thenReturn(null);
        PlatformProfitAccount p = profitAccount();
        when(platformProfitAccountMapper.selectById(1)).thenReturn(p);

        billingService.settle(settleCmd("20", "12", "30"));

        ArgumentCaptor<PlatformProfitAccount> captor = ArgumentCaptor.forClass(PlatformProfitAccount.class);
        verify(platformProfitAccountMapper).updateById(captor.capture());
        PlatformProfitAccount saved = captor.getValue();
        assertThat(saved.getTotalRevenue()).isEqualByComparingTo("20");
        assertThat(saved.getTotalCost()).isEqualByComparingTo("12");
        assertThat(saved.getTotalProfit()).isEqualByComparingTo("8");
    }

    @Test
    @DisplayName("settle: deducts model-binding allocated/used when a binding exists")
    void settle_updatesModelBinding() {
        when(finAccountMapper.selectOne(any())).thenReturn(account("70", "30"));
        when(finAccountMapper.updateById(any(FinAccount.class))).thenReturn(1);
        FinModelBinding binding = new FinModelBinding();
        binding.setId(2L);
        binding.setCompanyId(COMPANY_ID);
        binding.setModelCode(MODEL_CODE);
        binding.setAllocated(new BigDecimal("100"));
        binding.setUsed(new BigDecimal("5"));
        when(finModelBindingMapper.selectOne(any())).thenReturn(binding);
        when(platformProfitAccountMapper.selectById(1)).thenReturn(profitAccount());

        billingService.settle(settleCmd("20", "12", "30"));

        ArgumentCaptor<FinModelBinding> captor = ArgumentCaptor.forClass(FinModelBinding.class);
        verify(finModelBindingMapper).updateById(captor.capture());
        FinModelBinding saved = captor.getValue();
        // used: 5 + 20 = 25 ; allocated: 100 - 20 = 80
        assertThat(saved.getUsed()).isEqualByComparingTo("25");
        assertThat(saved.getAllocated()).isEqualByComparingTo("80");
    }

    @Test
    @DisplayName("settle: emits a low-margin Kafka message when margin < 5%")
    void settle_emitsKafka_whenLowMargin() throws Exception {
        when(finAccountMapper.selectOne(any())).thenReturn(account("1000", "30"));
        when(finAccountMapper.updateById(any(FinAccount.class))).thenReturn(1);
        when(finModelBindingMapper.selectOne(any())).thenReturn(null);
        when(platformProfitAccountMapper.selectById(1)).thenReturn(profitAccount());
        when(objectMapper.writeValueAsString(any())).thenReturn("{}");

        // charge=100, cost=98 -> profit=2 -> margin=0.02 < 0.05
        billingService.settle(settleCmd("100", "98", "30"));

        verify(kafkaTemplate).send(any(), eq(REQUEST_ID), any());
    }

    @Test
    @DisplayName("settle: does NOT emit Kafka when margin is healthy")
    void settle_noKafka_whenHealthyMargin() {
        when(finAccountMapper.selectOne(any())).thenReturn(account("1000", "30"));
        when(finAccountMapper.updateById(any(FinAccount.class))).thenReturn(1);
        when(finModelBindingMapper.selectOne(any())).thenReturn(null);
        when(platformProfitAccountMapper.selectById(1)).thenReturn(profitAccount());

        // charge=100, cost=50 -> margin 0.50 > 0.05
        billingService.settle(settleCmd("100", "50", "30"));

        verify(kafkaTemplate, never()).send(any(), any(), any());
    }

    @Test
    @DisplayName("settle: skips channel accounting when channelId is null")
    void settle_skipsChannel_whenNoChannel() {
        when(finAccountMapper.selectOne(any())).thenReturn(account("70", "30"));
        when(finAccountMapper.updateById(any(FinAccount.class))).thenReturn(1);
        when(finModelBindingMapper.selectOne(any())).thenReturn(null);
        when(platformProfitAccountMapper.selectById(1)).thenReturn(profitAccount());

        SettleCmd cmd = settleCmd("20", "12", "30");
        cmd.setChannelId(null);
        billingService.settle(cmd);

        verify(settlementMapper, never()).addChannelUsedQuota(any(), any());
        verify(settlementMapper, never()).addUpstreamReserve(any(), any());
        // bill_token is still written.
        verify(settlementMapper, times(1)).insertBillToken(
                any(), any(), any(), any(), any(), any(),
                org.mockito.ArgumentMatchers.anyLong(),
                org.mockito.ArgumentMatchers.anyLong(),
                org.mockito.ArgumentMatchers.anyLong(),
                org.mockito.ArgumentMatchers.anyLong(),
                any(), any());
    }

    private PlatformProfitAccount profitAccount() {
        PlatformProfitAccount p = new PlatformProfitAccount();
        p.setId(1);
        p.setTotalRevenue(BigDecimal.ZERO);
        p.setTotalCost(BigDecimal.ZERO);
        p.setTotalProfit(BigDecimal.ZERO);
        return p;
    }
}
