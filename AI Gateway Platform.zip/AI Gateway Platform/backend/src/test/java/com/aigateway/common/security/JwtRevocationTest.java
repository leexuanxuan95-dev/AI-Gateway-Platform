package com.aigateway.common.security;

import jakarta.servlet.FilterChain;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.security.core.context.SecurityContextHolder;

import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Revoke-all integration at the filter level: a real {@link JwtUtil}-minted token whose embedded
 * {@code epoch} is older than {@link TokenEpochService#current(Long)} must be rejected by
 * {@link JwtAuthFilter} (no authentication populated), while a token whose epoch is current is
 * accepted. {@link TokenEpochService} is mocked. The chain always proceeds (the filter never
 * blocks; it simply leaves the request unauthenticated for downstream authorization to reject).
 */
@ExtendWith(MockitoExtension.class)
@DisplayName("JwtAuthFilter - revoke-all epoch enforcement")
class JwtRevocationTest {

    private static final String SECRET =
            "test-secret-test-secret-test-secret-test-secret-0123456789-abcdef";
    private static final long TTL_SECONDS = 3600L;
    private static final Long USER_ID = 901L;
    private static final String UID = "u-901";

    @Mock
    private TokenEpochService tokenEpochService;

    private JwtUtil jwtUtil;
    private JwtAuthFilter filter;

    @BeforeEach
    void setUp() {
        jwtUtil = new JwtUtil(SECRET, TTL_SECONDS);
        filter = new JwtAuthFilter(jwtUtil, tokenEpochService);
        SecurityContextHolder.clearContext();
    }

    @AfterEach
    void tearDown() {
        SecurityContextHolder.clearContext();
    }

    private MockHttpServletResponse runWithToken(String token) throws Exception {
        MockHttpServletRequest req = new MockHttpServletRequest("GET", "/api/user/me");
        req.addHeader("Authorization", "Bearer " + token);
        MockHttpServletResponse resp = new MockHttpServletResponse();
        FilterChain chain = org.mockito.Mockito.mock(FilterChain.class);
        filter.doFilter(req, resp, chain);
        // the filter is non-blocking: it always forwards the request
        verify(chain, times(1)).doFilter(req, resp);
        return resp;
    }

    @Test
    @DisplayName("token minted at epoch 0 is rejected once the user's epoch advances")
    void staleEpochToken_isRejected() throws Exception {
        String token = jwtUtil.issueAccessToken(USER_ID, UID, Map.of("epoch", 0L));
        when(tokenEpochService.current(eq(USER_ID))).thenReturn(System.currentTimeMillis());

        runWithToken(token);

        // revoked: no authentication is populated in the security context
        assertThat(SecurityContextHolder.getContext().getAuthentication()).isNull();
    }

    @Test
    @DisplayName("token whose epoch matches the user's current epoch is accepted")
    void currentEpochToken_isAccepted() throws Exception {
        long epoch = System.currentTimeMillis();
        String token = jwtUtil.issueAccessToken(USER_ID, UID, Map.of("epoch", epoch));
        when(tokenEpochService.current(eq(USER_ID))).thenReturn(epoch);

        runWithToken(token);

        assertThat(SecurityContextHolder.getContext().getAuthentication()).isNotNull();
        assertThat(SecurityContextHolder.getContext().getAuthentication().getPrincipal())
                .isInstanceOf(LoginUser.class);
    }
}
