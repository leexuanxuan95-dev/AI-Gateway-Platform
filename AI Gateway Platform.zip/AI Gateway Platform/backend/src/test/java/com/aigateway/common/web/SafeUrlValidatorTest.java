package com.aigateway.common.web;

import com.aigateway.common.exception.BizException;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThatCode;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

/**
 * Unit tests for {@link SafeUrlValidator} SSRF guard. Internal / metadata / non-http targets
 * must be rejected; a normal public https URL must pass.
 */
@DisplayName("SafeUrlValidator - SSRF guard")
class SafeUrlValidatorTest {

    @Test
    @DisplayName("rejects the cloud instance-metadata address")
    void rejectsMetadataAddress() {
        assertThatThrownBy(() -> SafeUrlValidator.assertSafe("http://169.254.169.254/latest/meta-data/"))
                .isInstanceOf(BizException.class);
    }

    @Test
    @DisplayName("rejects loopback hostnames")
    void rejectsLoopback() {
        assertThatThrownBy(() -> SafeUrlValidator.assertSafe("http://localhost/admin"))
                .isInstanceOf(BizException.class);
    }

    @Test
    @DisplayName("rejects RFC1918 private addresses")
    void rejectsPrivateAddress() {
        assertThatThrownBy(() -> SafeUrlValidator.assertSafe("http://10.0.0.1/internal"))
                .isInstanceOf(BizException.class);
    }

    @Test
    @DisplayName("rejects non-http(s) schemes (file://)")
    void rejectsFileScheme() {
        assertThatThrownBy(() -> SafeUrlValidator.assertSafe("file:///etc/passwd"))
                .isInstanceOf(BizException.class);
    }

    @Test
    @DisplayName("rejects other non-http schemes (gopher://)")
    void rejectsNonHttpScheme() {
        assertThatThrownBy(() -> SafeUrlValidator.assertSafe("gopher://example.com/"))
                .isInstanceOf(BizException.class);
    }

    @Test
    @DisplayName("rejects blank input")
    void rejectsBlank() {
        assertThatThrownBy(() -> SafeUrlValidator.assertSafe("  "))
                .isInstanceOf(BizException.class);
    }

    @Test
    @DisplayName("allows a normal public https URL")
    void allowsPublicHttps() {
        // 1.1.1.1 is a stable, publicly-routable address; no DNS lookup needed for an IP literal.
        assertThatCode(() -> SafeUrlValidator.assertSafe("https://1.1.1.1/webhook"))
                .doesNotThrowAnyException();
    }
}
