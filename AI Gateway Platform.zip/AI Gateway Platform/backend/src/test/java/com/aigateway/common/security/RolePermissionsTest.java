package com.aigateway.common.security;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.Set;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Unit tests for {@link RolePermissions} role-to-permission matrix (design doc §2.2).
 */
@DisplayName("RolePermissions - role to permission matrix")
class RolePermissionsTest {

    @Test
    @DisplayName("OWNER has the full company permission set including withdraw and settings")
    void owner_hasAllPoints() {
        Set<String> perms = RolePermissions.forRole("OWNER");

        assertThat(perms).contains(
                RolePermissions.COMPANY_MEMBER_MANAGE,
                RolePermissions.APIKEY_MANAGE,
                RolePermissions.APIKEY_READ,
                RolePermissions.RECHARGE,
                RolePermissions.WITHDRAW_APPLY,
                RolePermissions.BILLING_READ,
                RolePermissions.PROJECT_MANAGE,
                RolePermissions.PROJECT_READ,
                RolePermissions.MODEL_SELECT,
                RolePermissions.CALL_API,
                RolePermissions.COMPANY_SETTINGS);
    }

    @Test
    @DisplayName("ADMIN matches OWNER except it cannot apply for withdrawals")
    void admin_lacksWithdraw() {
        Set<String> perms = RolePermissions.forRole("ADMIN");

        assertThat(perms).contains(
                RolePermissions.COMPANY_MEMBER_MANAGE,
                RolePermissions.RECHARGE,
                RolePermissions.COMPANY_SETTINGS);
        assertThat(perms).doesNotContain(RolePermissions.WITHDRAW_APPLY);
    }

    @Test
    @DisplayName("DEVELOPER manages keys/projects-read/model/call but only self-billing")
    void developer_hasExpectedPoints() {
        Set<String> perms = RolePermissions.forRole("DEVELOPER");

        assertThat(perms).containsExactlyInAnyOrder(
                RolePermissions.APIKEY_MANAGE,
                RolePermissions.APIKEY_READ,
                RolePermissions.PROJECT_READ,
                RolePermissions.MODEL_SELECT,
                RolePermissions.CALL_API,
                RolePermissions.BILLING_READ_SELF);
        assertThat(perms).doesNotContain(
                RolePermissions.RECHARGE,
                RolePermissions.COMPANY_SETTINGS,
                RolePermissions.PROJECT_MANAGE);
    }

    @Test
    @DisplayName("VIEWER is read-only")
    void viewer_isReadOnly() {
        Set<String> perms = RolePermissions.forRole("VIEWER");

        assertThat(perms).containsExactlyInAnyOrder(
                RolePermissions.APIKEY_READ,
                RolePermissions.PROJECT_READ,
                RolePermissions.BILLING_READ);
        assertThat(perms).doesNotContain(
                RolePermissions.APIKEY_MANAGE,
                RolePermissions.CALL_API,
                RolePermissions.MODEL_SELECT);
    }

    @Test
    @DisplayName("role lookup is case-insensitive")
    void roleLookup_isCaseInsensitive() {
        assertThat(RolePermissions.forRole("owner"))
                .isEqualTo(RolePermissions.forRole("OWNER"));
    }

    @Test
    @DisplayName("unknown role maps to an empty set")
    void unknownRole_returnsEmpty() {
        assertThat(RolePermissions.forRole("SUPERHERO")).isEmpty();
    }

    @Test
    @DisplayName("null role maps to an empty set")
    void nullRole_returnsEmpty() {
        assertThat(RolePermissions.forRole(null)).isEmpty();
    }
}
