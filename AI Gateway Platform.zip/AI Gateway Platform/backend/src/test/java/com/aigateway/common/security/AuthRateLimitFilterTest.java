package com.aigateway.common.security;

import jakarta.servlet.FilterChain;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Unit tests for {@link AuthRateLimitFilter}: the public auth surface is throttled per IP. Under
 * the cap the request proceeds; over the cap it is rejected with HTTP 429.
 */
@ExtendWith(MockitoExtension.class)
@DisplayName("AuthRateLimitFilter - auth-surface throttle")
class AuthRateLimitFilterTest {

    private static final int HTTP_TOO_MANY_REQUESTS = 429;
    /** Mirrors AuthRateLimitFilter#MAX_PER_WINDOW. */
    private static final long CAP = 30L;

    @Mock
    private StringRedisTemplate redis;
    @Mock
    private ValueOperations<String, String> valueOps;

    private AuthRateLimitFilter filter;

    @BeforeEach
    void setUp() {
        lenient().when(redis.opsForValue()).thenReturn(valueOps);
        filter = new AuthRateLimitFilter(redis);
    }

    private MockHttpServletRequest authRequest() {
        MockHttpServletRequest req = new MockHttpServletRequest("POST", "/api/auth/login");
        req.setRemoteAddr("198.51.100.20");
        return req;
    }

    @Test
    @DisplayName("allows a request under the cap")
    void allowsUnderCap() throws Exception {
        when(valueOps.increment(anyString())).thenReturn(3L);
        FilterChain chain = mock(FilterChain.class);
        MockHttpServletRequest req = authRequest();
        MockHttpServletResponse resp = new MockHttpServletResponse();

        filter.doFilter(req, resp, chain);

        assertThat(resp.getStatus()).isEqualTo(200);
        verify(chain, times(1)).doFilter(req, resp);
    }

    @Test
    @DisplayName("returns 429 once the cap is exceeded")
    void blocksOverCap() throws Exception {
        when(valueOps.increment(anyString())).thenReturn(CAP + 1);
        FilterChain chain = mock(FilterChain.class);
        MockHttpServletResponse resp = new MockHttpServletResponse();

        filter.doFilter(authRequest(), resp, chain);

        assertThat(resp.getStatus()).isEqualTo(HTTP_TOO_MANY_REQUESTS);
        verify(chain, never()).doFilter(any(), any());
    }
}
