package com.aigateway.common.security;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.data.redis.core.ValueOperations;

import java.time.Duration;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Unit tests for {@link LoginAttemptService} brute-force lockout (design doc §18).
 * {@link StringRedisTemplate} and its {@link ValueOperations} are mocked.
 */
@ExtendWith(MockitoExtension.class)
@DisplayName("LoginAttemptService - brute-force lockout")
class LoginAttemptServiceTest {

    private static final String IDENTITY = "user@example.com";
    private static final String EXPECTED_KEY = "gw:login:fail:" + IDENTITY;

    @Mock
    private StringRedisTemplate redis;
    @Mock
    private ValueOperations<String, String> valueOperations;

    @InjectMocks
    private LoginAttemptService service;

    @BeforeEach
    void setUp() {
        lenient().when(redis.opsForValue()).thenReturn(valueOperations);
    }

    @Test
    @DisplayName("isLocked is true once the counter reaches MAX_FAILURES")
    void isLocked_trueAtMaxFailures() {
        when(valueOperations.get(EXPECTED_KEY))
                .thenReturn(String.valueOf(LoginAttemptService.MAX_FAILURES));

        assertThat(service.isLocked(IDENTITY)).isTrue();
    }

    @Test
    @DisplayName("isLocked is false below MAX_FAILURES")
    void isLocked_falseBelowThreshold() {
        when(valueOperations.get(EXPECTED_KEY))
                .thenReturn(String.valueOf(LoginAttemptService.MAX_FAILURES - 1));

        assertThat(service.isLocked(IDENTITY)).isFalse();
    }

    @Test
    @DisplayName("isLocked is false when no counter exists")
    void isLocked_falseWhenNoCounter() {
        when(valueOperations.get(EXPECTED_KEY)).thenReturn(null);

        assertThat(service.isLocked(IDENTITY)).isFalse();
    }

    @Test
    @DisplayName("first failure sets the lock TTL and returns MAX_FAILURES-1 remaining")
    void recordFailure_firstSetsTtl() {
        when(valueOperations.increment(EXPECTED_KEY)).thenReturn(1L);

        int remaining = service.recordFailure(IDENTITY);

        assertThat(remaining).isEqualTo(LoginAttemptService.MAX_FAILURES - 1);
        verify(redis).expire(eq(EXPECTED_KEY), eq(Duration.ofMinutes(LoginAttemptService.LOCK_MINUTES)));
    }

    @Test
    @DisplayName("subsequent failures do not reset the TTL and decrement remaining attempts")
    void recordFailure_subsequentNoTtlReset() {
        when(valueOperations.increment(EXPECTED_KEY)).thenReturn(3L);

        int remaining = service.recordFailure(IDENTITY);

        assertThat(remaining).isEqualTo(LoginAttemptService.MAX_FAILURES - 3);
        verify(redis, org.mockito.Mockito.never()).expire(anyString(), any());
    }

    @Test
    @DisplayName("remaining attempts never goes negative once locked out")
    void recordFailure_remainingClampedAtZero() {
        when(valueOperations.increment(EXPECTED_KEY))
                .thenReturn((long) (LoginAttemptService.MAX_FAILURES + 2));

        int remaining = service.recordFailure(IDENTITY);

        assertThat(remaining).isZero();
    }

    @Test
    @DisplayName("clear deletes the failure counter")
    void clear_deletesCounter() {
        service.clear(IDENTITY);

        verify(redis).delete(EXPECTED_KEY);
    }
}
