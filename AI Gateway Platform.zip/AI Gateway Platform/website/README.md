# OmniRoute 官网 (Public Marketing Website)

The public, data-driven landing site for **OmniRoute**. The entire page renders
from a single Landing CMS document — `GET /api/site/landing?lang=zh` — so all
content, colors, copy, pricing and FAQ are editable in the admin backend and go
live without a code change or redeploy (design doc §4).

Built with **Vue 3 + TypeScript + Vite**. Separate from the admin console in
`../frontend/`.

## Quick start

```bash
cd website
npm install
npm run dev          # http://localhost:5174
```

In dev, Vite proxies `/api` → `http://localhost:8080` (the backend). Override the
target:

```bash
VITE_BACKEND_ORIGIN=http://localhost:9000 npm run dev
```

If the API is unreachable, the site **renders standalone** from baked-in default
content (`src/defaults.ts`, zh + en) and shows a small "using default content"
notice. This means you can develop the marketing site with no backend running.

Other scripts:

```bash
npm run build        # vue-tsc type-check + vite build -> dist/
npm run preview      # serve the production build locally
npm run type-check   # types only
```

## How it consumes the CMS

- `src/api/landing.ts` — typed `getLanding(lang)` calling `GET /api/site/landing`.
- `src/types.ts` — `Landing / Section / Theme / …` interfaces matching the API.
- `src/App.vue` — fetches the document, applies `theme` tokens as CSS variables
  (`src/theme.ts`), sets `<title>` / meta / OG from `seo` (`src/seo.ts`), then
  renders **NavBar → ordered sections → FAQ → CTA → Footer**.
- `src/components/SectionRenderer.vue` — maps `section.key` → a component.
  Sections render in `sort` order; `enabled:false` sections are skipped; unknown
  keys render nothing.

Each section is its own component consuming its `payload`:

| key | component | payload |
|---|---|---|
| hero | `HeroSection` (+ `RoutingConsole`) | subtitle, ctas[], badges[], showConsole |
| providers | `ProvidersSection` | items[] |
| features | `FeaturesSection` | cards[{icon,title,desc}] |
| how | `HowSection` | steps[{no,title,desc}] |
| code | `CodeSection` | tabs[{lang,code}], domainVar |
| models | `ModelsSection` | families[{family,versions[{code,name,tagline,available}]}] |
| pricing | `PricingSection` | highlight, plans[{name,price,…,highlight}] |
| security | `SecuritySection` | cards[{icon,title,desc}] |
| cta | `CtaSection` | title, subtitle, button{text,href} |

FAQ (`faq[]`) and footer (`footer{}`) come from top-level fields, not a section.

## Signature Hero animation

`RoutingConsole.vue` (design doc §5): an API request fans out to model chips and
an amber "routed / 已路由" highlight cycles between them — pure CSS/SVG, no canvas
loop. It honors `prefers-reduced-motion` (cycling disabled, static routed state)
and is toggled by `payload.showConsole` on the hero section.

## i18n

`vue-i18n` provides UI-chrome strings (nav, buttons, labels) in zh + en. Page
*content* comes from the CMS per `lang`. The nav language switch calls
`getLanding(lang)` again and re-applies theme/SEO. Default fallback content is
provided in both languages.

## Theme tokens

Brand: dark teal bg `#0B1719`, amber `#F6B53C` (primary), mint `#57E3BE`
(accent), text `#E8F1EF`, border `#21454B`. `theme.ts` writes these to CSS
custom properties (`--bg`, `--amber`, `--mint`, `--text`, `--border`, `--font`,
`--radius`) consumed by `styles.css`. Fonts: Space Grotesk (headings), Noto Sans
SC (zh body), IBM Plex Mono (code).

## SEO & accessibility

- Title / description / keywords / OG tags set from `seo` at runtime (`seo.ts`)
  and pre-filled in `index.html`.
- `public/robots.txt` ships; **`sitemap.xml` is a production build step** (see
  below).
- Semantic landmarks, skip link, keyboard-focus styles, contrast against the
  dark palette, reduced-motion support, responsive desktop/tablet/mobile.

## Production: SSR / prerender / SSG (design doc §6 "SSR/预渲染")

`npm run build` produces a client-rendered SPA. For first-paint SEO (crawlers
seeing real HTML) and LCP < 2.5s, add a prerender/SSG step before going live:

1. **Recommended — `vite-ssg`** (least change): install `vite-ssg`, switch
   `main.ts` to `export const createApp = ViteSSG(App, …)`, and build with
   `vite-ssg build`. It crawls `/` (and `/en`) and emits static HTML with the
   landing content + meta baked in. Generate `sitemap.xml` from the routes in
   the same step.
2. **Alternative — Nuxt** if you later want file-based routing/SSR.
3. **Alternative — a prerender plugin** (`vite-plugin-prerender`-style) that
   renders the built SPA with a headless browser at build time.

At build time the prerenderer should fetch the published landing JSON so the
static HTML reflects current CMS content; re-run/redeploy (or trigger a build)
on publish. Serve `dist/` + the landing JSON via **CDN with active
invalidation** on publish (design doc §4.4).

## Docker

Multi-stage build → nginx serving `dist/`, proxying `/api` to `backend:8080`,
with gzip, long-cache for hashed assets, no-cache `index.html`, and security
headers (CSP/X-Frame-Options/etc.).

```bash
docker build -t omniroute-website .
docker run -p 8081:80 omniroute-website
```
