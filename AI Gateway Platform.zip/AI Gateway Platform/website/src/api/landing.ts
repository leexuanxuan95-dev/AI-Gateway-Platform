import axios from 'axios'
import type { Landing, Lang } from '@/types'

// Base path for the public Landing CMS API. In dev, Vite proxies /api -> backend.
const API_BASE = import.meta.env.VITE_API_BASE || ''

const http = axios.create({
  baseURL: API_BASE,
  timeout: 8000,
  headers: { Accept: 'application/json' },
})

/**
 * Fetch the published landing content for a language.
 * The whole page renders from this single document (design doc §4.3).
 * Throws on network/HTTP error so callers can fall back to baked-in defaults.
 */
export async function getLanding(lang: Lang = 'zh'): Promise<Landing> {
  const { data } = await http.get<Landing>('/api/site/landing', {
    params: { lang },
  })
  return data
}
