// Baked-in DEFAULT landing content (design doc §3) used when the CMS API is
// unreachable, so the site renders standalone. Mirrors the Landing JSON shape.
import type { Landing, Lang } from '@/types'

const THEME = {
  bg: '#0B1719',
  amber: '#F6B53C',
  mint: '#57E3BE',
  text: '#E8F1EF',
  border: '#21454B',
  font: "'Space Grotesk', 'Noto Sans SC', system-ui, sans-serif",
  radius: '14px',
}

const CURL = `curl https://api.omniroute.ai/v1/chat/completions \\
  -H "Authorization: Bearer $OMNIROUTE_KEY" \\
  -H "Content-Type: application/json" \\
  -d '{
    "model": "claude-opus-4-8",
    "messages": [{"role":"user","content":"Hello"}]
  }'`

const PY = `from openai import OpenAI

client = OpenAI(
    api_key="$OMNIROUTE_KEY",
    base_url="https://api.omniroute.ai/v1",   # 改这一行
)

resp = client.chat.completions.create(
    model="claude-opus-4-8",                   # 改这一行：换版本即换模型
    messages=[{"role": "user", "content": "Hello"}],
)
print(resp.choices[0].message.content)`

const NODE = `import OpenAI from "openai";

const client = new OpenAI({
  apiKey: process.env.OMNIROUTE_KEY,
  baseURL: "https://api.omniroute.ai/v1", // 改这一行
});

const resp = await client.chat.completions.create({
  model: "claude-opus-4-8",                // 改这一行：换版本即换模型
  messages: [{ role: "user", content: "Hello" }],
});
console.log(resp.choices[0].message.content);`

const zh: Landing = {
  brand: {
    name: 'OmniRoute',
    logo: '',
    domain: 'omniroute.ai',
    copyright: '© 2026 OmniRoute',
    icp: '',
  },
  seo: {
    title: 'OmniRoute — 一个 Key，接入所有大模型',
    description:
      'GPT-5、Claude Opus 4.8、Gemini、Grok、DeepSeek…… 一个 Key 调用所有大模型，统一计费、智能故障转移，完全兼容 OpenAI SDK，迁移只改两行。',
    keywords: 'AI Gateway,LLM API,OpenAI 兼容,Claude,GPT-5,模型路由,统一计费,故障转移',
    ogImage: '',
  },
  theme: THEME,
  sections: [
    {
      key: 'hero',
      enabled: true,
      sort: 1,
      title: '一个 Key，接入所有大模型。',
      payload: {
        subtitle:
          'GPT-5、Claude Opus 4.8、Gemini、Grok、DeepSeek…… 在 model 字段一填即换版本。统一计费、统一额度、智能故障转移。完全兼容 OpenAI SDK，迁移只改两行。',
        ctas: [
          { text: '免费获取 API Key', href: '/signup' },
          { text: '看如何接入', href: '#how' },
        ],
        badges: ['9+ 供应商接入', '数十个模型版本', '多渠道充值（含 Wise 卡）'],
        showConsole: true,
      },
    },
    {
      key: 'providers',
      enabled: true,
      sort: 2,
      title: '已接入主流供应商',
      payload: {
        items: [
          'OpenAI',
          'Anthropic',
          'Google Gemini',
          'xAI Grok',
          'DeepSeek',
          'Mistral',
          'Cohere',
          'OpenRouter',
          'Azure OpenAI',
        ],
      },
    },
    {
      key: 'features',
      enabled: true,
      sort: 3,
      title: '核心能力',
      subtitle: '一个网关，解决多模型接入的所有麻烦。',
      payload: {
        cards: [
          { icon: 'hub', title: '全模型聚合', desc: '9+ 供应商一个入口，屏蔽协议差异。' },
          { icon: 'swap', title: '版本自由切换', desc: '像选 Opus 4.8 / Sonnet 4.6 / Haiku 4.5 一样填 model。' },
          { icon: 'meter', title: '统一计费与额度', desc: '按 token 实时计费，预冻结防超支，响应回显花费与余额。' },
          { icon: 'shield-bolt', title: '负载均衡 + 故障转移', desc: '一家挂了自动切，客户端无感。' },
          { icon: 'building', title: '企业多租户 + 风控', desc: '四级隔离、RBAC、限流、黑名单、异常监控。' },
          { icon: 'card', title: '多渠道充值', desc: 'Stripe（含 Wise/国际卡）、支付宝、微信、USDT。' },
        ],
      },
    },
    {
      key: 'how',
      enabled: true,
      sort: 4,
      title: '四步接入',
      subtitle: '几分钟从注册到发出第一个请求。',
      payload: {
        steps: [
          { no: '01', title: '创建 API Key', desc: '注册后在控制台一键生成密钥。' },
          { no: '02', title: '指向 base_url', desc: '把 base_url 指向 api.omniroute.ai/v1。' },
          { no: '03', title: '选版本调用', desc: '在 model 字段填想用的版本，直接调用。' },
          { no: '04', title: '充值看账单', desc: '后台多渠道充值，实时查看花费与额度。' },
        ],
      },
    },
    {
      key: 'code',
      enabled: true,
      sort: 5,
      title: 'Drop-in 替换，迁移只改两行',
      subtitle: '保留你现有的 OpenAI SDK，改 base_url 与 model 即可。',
      payload: {
        domainVar: 'api.omniroute.ai/v1',
        tabs: [
          { lang: 'cURL', code: CURL },
          { lang: 'Python', code: PY },
          { lang: 'Node', code: NODE },
        ],
      },
    },
    {
      key: 'models',
      enabled: true,
      sort: 6,
      title: '支持模型',
      subtitle: '上游上新自动同步，无需改代码。',
      bind_source: 'model_version',
      payload: {
        families: [
          {
            family: 'Claude',
            versions: [
              { code: 'claude-opus-4-8', name: 'Opus 4.8', tagline: '最强推理', available: true },
              { code: 'claude-sonnet-4-6', name: 'Sonnet 4.6', tagline: '均衡高效', available: true },
              { code: 'claude-haiku-4-5', name: 'Haiku 4.5', tagline: '极速轻量', available: true },
            ],
          },
          {
            family: 'GPT',
            versions: [
              { code: 'gpt-5', name: 'GPT-5', tagline: '旗舰通用', available: true },
              { code: 'gpt-4o', name: 'GPT-4o', tagline: '多模态', available: true },
            ],
          },
          {
            family: 'Gemini',
            versions: [
              { code: 'gemini-2.5-pro', name: '2.5 Pro', tagline: '长上下文', available: true },
              { code: 'gemini-2.5-flash', name: '2.5 Flash', tagline: '高性价比', available: true },
            ],
          },
          {
            family: 'Grok',
            versions: [{ code: 'grok-3', name: 'Grok 3', tagline: '实时联网', available: true }],
          },
          {
            family: 'DeepSeek',
            versions: [
              { code: 'deepseek-v3', name: 'V3', tagline: '强性能', available: true },
              { code: 'deepseek-r1', name: 'R1', tagline: '深度推理', available: true },
            ],
          },
          {
            family: '更多',
            versions: [
              { code: 'mistral-*', name: 'Mistral', tagline: '全量', available: true },
              { code: 'cohere-*', name: 'Cohere', tagline: '全量', available: true },
              { code: 'openrouter-*', name: 'OpenRouter', tagline: '全量', available: true },
            ],
          },
        ],
      },
    },
    {
      key: 'pricing',
      enabled: true,
      sort: 7,
      title: '价格',
      subtitle: '按需选择，随时升级。',
      bind_source: 'plan',
      payload: {
        highlight: 'pro',
        plans: [
          {
            name: '基础版',
            price: 0,
            currency: '$',
            period: '/月',
            features: ['全模型访问', '社区支持', '按量计费', '基础限流'],
            cta: { text: '免费开始', href: '/signup' },
          },
          {
            name: '专业版',
            price: 49,
            currency: '$',
            period: '/月',
            features: ['更高限流', '故障转移优先级', '邮件支持', '用量分析'],
            cta: { text: '升级专业版', href: '/signup?plan=pro' },
            highlight: true,
          },
          {
            name: '企业版',
            price: 299,
            currency: '$',
            period: '/月',
            features: ['多租户隔离', 'RBAC + 风控', '专属额度池', '优先支持'],
            cta: { text: '选择企业版', href: '/signup?plan=enterprise' },
          },
          {
            name: '旗舰版',
            price: '议价',
            currency: '',
            period: '',
            features: ['私有部署可选', 'SLA 保障', '专属客户经理', '定制集成'],
            cta: { text: '联系销售', href: '/contact' },
          },
        ],
      },
    },
    {
      key: 'security',
      enabled: true,
      sort: 8,
      title: '安全与合规',
      subtitle: '为生产环境而生。',
      payload: {
        cards: [
          { icon: 'key', title: '密钥只存哈希', desc: 'API Key 不落明文，仅存不可逆哈希。' },
          { icon: 'lock', title: '全链路 TLS + 回调验签', desc: '传输全程加密，支付回调严格验签。' },
          { icon: 'partition', title: '企业级数据隔离', desc: '四级隔离，租户数据互不可见。' },
          { icon: 'freeze', title: '预冻结防超支', desc: '请求前冻结额度，杜绝超额扣费。' },
        ],
      },
    },
    {
      key: 'cta',
      enabled: true,
      sort: 9,
      payload: {
        title: '现在就拿到你的 API Key',
        subtitle: '免费开始，几分钟接入所有大模型。',
        button: { text: '免费获取 API Key', href: '/signup' },
      },
    },
  ],
  faq: [
    { q: '怎么计费？', a: '按 token 实时计费，请求前预冻结额度防止超支，响应中回显本次花费与剩余余额。' },
    { q: '迁移要改多少代码？', a: '完全兼容 OpenAI SDK，通常只改两行：base_url 指向 api.omniroute.ai/v1，model 填目标版本。' },
    { q: '支持哪些支付方式？', a: 'Stripe（含 Wise / 国际卡）、支付宝、微信、USDT，多渠道充值。' },
    { q: '某个模型挂了怎么办？', a: '内置负载均衡与故障转移，单一供应商异常时自动切换到可用渠道，客户端无感。' },
    { q: '能否随时切换版本？', a: '可以。在 model 字段填不同版本即可切换，无需改动其他代码。' },
    { q: '我的数据是否安全？', a: '密钥只存哈希、全链路 TLS、回调验签、企业级数据隔离，满足生产环境安全要求。' },
  ],
  footer: {
    groups: [
      {
        title: '产品',
        links: [
          { text: '核心能力', href: '#features' },
          { text: '支持模型', href: '#models' },
          { text: '价格', href: '#pricing' },
        ],
      },
      {
        title: '开发者',
        links: [
          { text: '快速开始', href: '#how' },
          { text: 'API 文档', href: 'https://docs.omniroute.ai' },
          { text: '状态页', href: 'https://status.omniroute.ai' },
        ],
      },
      {
        title: '公司',
        links: [
          { text: '关于我们', href: '/about' },
          { text: '联系销售', href: '/contact' },
          { text: '隐私政策', href: '/privacy' },
        ],
      },
    ],
    copyright: '© 2026 OmniRoute',
    icp: '',
  },
}

// Translate the zh "change this line" hints to en for the code samples.
// Order matters: replace the longer phrase first so its prefix isn't consumed.
function enComments(src: string): string {
  return src
    .replace(/改这一行：换版本即换模型/g, 'change this line: swap model = swap provider')
    .replace(/改这一行/g, 'change this line')
}
const enPy = enComments(PY)
const enNode = enComments(NODE)

const en: Landing = {
  brand: { ...zh.brand },
  seo: {
    title: 'OmniRoute — One Key, Every Model',
    description:
      'GPT-5, Claude Opus 4.8, Gemini, Grok, DeepSeek… one key for every model. Unified billing, smart failover, fully OpenAI-SDK compatible. Migrate by changing two lines.',
    keywords: 'AI Gateway,LLM API,OpenAI compatible,Claude,GPT-5,model routing,unified billing,failover',
    ogImage: '',
  },
  theme: THEME,
  sections: [
    {
      key: 'hero',
      enabled: true,
      sort: 1,
      title: 'One Key. Every Model.',
      payload: {
        subtitle:
          'GPT-5, Claude Opus 4.8, Gemini, Grok, DeepSeek… switch versions by changing one field. Unified billing, unified quota, smart failover. Fully OpenAI-SDK compatible — migrate in two lines.',
        ctas: [
          { text: 'Get a free API Key', href: '/signup' },
          { text: 'See how it works', href: '#how' },
        ],
        badges: ['9+ providers', 'Dozens of model versions', 'Multi-channel top-up (incl. Wise)'],
        showConsole: true,
      },
    },
    {
      key: 'providers',
      enabled: true,
      sort: 2,
      title: 'Integrated providers',
      payload: { items: [...(zh.sections[1].payload as { items: string[] }).items] },
    },
    {
      key: 'features',
      enabled: true,
      sort: 3,
      title: 'Core capabilities',
      subtitle: 'One gateway that removes the pain of multi-model integration.',
      payload: {
        cards: [
          { icon: 'hub', title: 'Aggregate every model', desc: '9+ providers behind one endpoint; protocol differences hidden.' },
          { icon: 'swap', title: 'Switch versions freely', desc: 'Pick Opus 4.8 / Sonnet 4.6 / Haiku 4.5 by setting model.' },
          { icon: 'meter', title: 'Unified billing & quota', desc: 'Real-time per-token billing, pre-freeze against overspend, cost echoed in responses.' },
          { icon: 'shield-bolt', title: 'Load balancing + failover', desc: 'If one provider fails, traffic reroutes automatically — clients never notice.' },
          { icon: 'building', title: 'Multi-tenant + risk control', desc: 'Four-level isolation, RBAC, rate limits, blocklists, anomaly monitoring.' },
          { icon: 'card', title: 'Multi-channel top-up', desc: 'Stripe (incl. Wise / intl. cards), Alipay, WeChat, USDT.' },
        ],
      },
    },
    {
      key: 'how',
      enabled: true,
      sort: 4,
      title: 'Integrate in four steps',
      subtitle: 'From sign-up to your first request in minutes.',
      payload: {
        steps: [
          { no: '01', title: 'Create an API Key', desc: 'Generate a key from the console after signing up.' },
          { no: '02', title: 'Point base_url', desc: 'Set base_url to api.omniroute.ai/v1.' },
          { no: '03', title: 'Call a version', desc: 'Put the version you want in the model field and call.' },
          { no: '04', title: 'Top up & track', desc: 'Top up via multiple channels and watch spend in real time.' },
        ],
      },
    },
    {
      key: 'code',
      enabled: true,
      sort: 5,
      title: 'Drop-in replacement — two lines to migrate',
      subtitle: 'Keep your existing OpenAI SDK; change base_url and model.',
      payload: {
        domainVar: 'api.omniroute.ai/v1',
        tabs: [
          { lang: 'cURL', code: CURL },
          { lang: 'Python', code: enPy },
          { lang: 'Node', code: enNode },
        ],
      },
    },
    {
      key: 'models',
      enabled: true,
      sort: 6,
      title: 'Supported models',
      subtitle: 'New upstream models sync automatically — no code changes.',
      bind_source: 'model_version',
      payload: { families: JSON.parse(JSON.stringify((zh.sections[5].payload as { families: unknown }).families)) },
    },
    {
      key: 'pricing',
      enabled: true,
      sort: 7,
      title: 'Pricing',
      subtitle: 'Pick what you need, upgrade anytime.',
      bind_source: 'plan',
      payload: {
        highlight: 'pro',
        plans: [
          { name: 'Basic', price: 0, currency: '$', period: '/mo', features: ['All models', 'Community support', 'Pay-as-you-go', 'Basic rate limits'], cta: { text: 'Start free', href: '/signup' } },
          { name: 'Pro', price: 49, currency: '$', period: '/mo', features: ['Higher rate limits', 'Failover priority', 'Email support', 'Usage analytics'], cta: { text: 'Go Pro', href: '/signup?plan=pro' }, highlight: true },
          { name: 'Enterprise', price: 299, currency: '$', period: '/mo', features: ['Tenant isolation', 'RBAC + risk control', 'Dedicated quota pool', 'Priority support'], cta: { text: 'Choose Enterprise', href: '/signup?plan=enterprise' } },
          { name: 'Custom', price: 'Contact', currency: '', period: '', features: ['Self-host option', 'SLA guarantees', 'Dedicated CSM', 'Custom integrations'], cta: { text: 'Contact sales', href: '/contact' } },
        ],
      },
    },
    {
      key: 'security',
      enabled: true,
      sort: 8,
      title: 'Security & compliance',
      subtitle: 'Built for production.',
      payload: {
        cards: [
          { icon: 'key', title: 'Keys stored as hashes', desc: 'API keys are never stored in plaintext — only irreversible hashes.' },
          { icon: 'lock', title: 'End-to-end TLS + signed callbacks', desc: 'All traffic encrypted; payment callbacks strictly verified.' },
          { icon: 'partition', title: 'Enterprise data isolation', desc: 'Four-level isolation keeps tenant data fully separated.' },
          { icon: 'freeze', title: 'Pre-freeze against overspend', desc: 'Quota is frozen before the request, preventing overcharges.' },
        ],
      },
    },
    {
      key: 'cta',
      enabled: true,
      sort: 9,
      payload: {
        title: 'Get your API Key now',
        subtitle: 'Start free and reach every model in minutes.',
        button: { text: 'Get a free API Key', href: '/signup' },
      },
    },
  ],
  faq: [
    { q: 'How does billing work?', a: 'Real-time per-token billing. Quota is pre-frozen before each request to prevent overspend, and the cost and remaining balance are echoed in the response.' },
    { q: 'How much code do I change to migrate?', a: 'Fully OpenAI-SDK compatible — usually two lines: point base_url to api.omniroute.ai/v1 and set model to your target version.' },
    { q: 'Which payment methods are supported?', a: 'Stripe (incl. Wise / international cards), Alipay, WeChat, and USDT.' },
    { q: 'What if a model goes down?', a: 'Built-in load balancing and failover automatically reroute to a healthy channel when a provider fails — transparent to your client.' },
    { q: 'Can I switch versions anytime?', a: 'Yes. Just set a different version in the model field; no other code changes needed.' },
    { q: 'Is my data safe?', a: 'Hashed keys, end-to-end TLS, signed callbacks and enterprise data isolation meet production security requirements.' },
  ],
  footer: {
    groups: [
      { title: 'Product', links: [{ text: 'Features', href: '#features' }, { text: 'Models', href: '#models' }, { text: 'Pricing', href: '#pricing' }] },
      { title: 'Developers', links: [{ text: 'Quickstart', href: '#how' }, { text: 'API Docs', href: 'https://docs.omniroute.ai' }, { text: 'Status', href: 'https://status.omniroute.ai' }] },
      { title: 'Company', links: [{ text: 'About', href: '/about' }, { text: 'Contact sales', href: '/contact' }, { text: 'Privacy', href: '/privacy' }] },
    ],
    copyright: '© 2026 OmniRoute',
    icp: '',
  },
}

export function defaultLanding(lang: Lang): Landing {
  return lang === 'en' ? en : zh
}
