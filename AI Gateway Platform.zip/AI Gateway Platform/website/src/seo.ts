import type { Seo, Brand } from '@/types'

// Sets document <title> and meta tags from the CMS `seo` block at runtime.
// For production SEO, an SSG/prerender step bakes these into the static HTML
// (see README "Production"). This keeps the SPA correct for client navigation.

function setMeta(selector: string, attr: 'name' | 'property', key: string, content: string): void {
  if (!content) return
  let el = document.head.querySelector<HTMLMetaElement>(selector)
  if (!el) {
    el = document.createElement('meta')
    el.setAttribute(attr, key)
    document.head.appendChild(el)
  }
  el.setAttribute('content', content)
}

export function applySeo(seo: Seo | undefined, brand?: Brand): void {
  if (!seo) return
  if (seo.title) document.title = seo.title
  setMeta('meta[name="description"]', 'name', 'description', seo.description || '')
  setMeta('meta[name="keywords"]', 'name', 'keywords', seo.keywords || '')

  setMeta('meta[property="og:title"]', 'property', 'og:title', seo.title || '')
  setMeta('meta[property="og:description"]', 'property', 'og:description', seo.description || '')
  setMeta('meta[property="og:image"]', 'property', 'og:image', seo.ogImage || '')
  setMeta('meta[property="og:type"]', 'property', 'og:type', 'website')
  if (brand?.domain) {
    setMeta('meta[property="og:url"]', 'property', 'og:url', `https://${brand.domain}/`)
  }
  setMeta('meta[name="twitter:card"]', 'name', 'twitter:card', 'summary_large_image')
}

export function setHtmlLang(lang: string): void {
  document.documentElement.setAttribute('lang', lang)
}
