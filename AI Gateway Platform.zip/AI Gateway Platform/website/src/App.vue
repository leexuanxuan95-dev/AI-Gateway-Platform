<script setup lang="ts">
import { computed, onMounted, ref } from 'vue'
import { useI18n } from 'vue-i18n'
import type { Landing, Lang, Section, HeroPayload } from '@/types'
import { getLanding } from '@/api/landing'
import { defaultLanding } from '@/defaults'
import { applyTheme } from '@/theme'
import { applySeo, setHtmlLang } from '@/seo'

import NavBar from '@/components/NavBar.vue'
import SectionRenderer from '@/components/SectionRenderer.vue'
import FaqSection from '@/components/FaqSection.vue'
import CtaSection from '@/components/CtaSection.vue'
import SiteFooter from '@/components/SiteFooter.vue'

const { locale, t } = useI18n()

const data = ref<Landing | null>(null)
const usingDefault = ref(false)
const loading = ref(true)

// Sections ordered by `sort`, skipping disabled ones. FAQ + CTA + Footer are
// handled separately so FAQ can sit before the final CTA per the doc IA.
const orderedSections = computed<Section[]>(() => {
  if (!data.value) return []
  return [...data.value.sections]
    .filter((s) => s.enabled !== false)
    .sort((a, b) => (a.sort ?? 0) - (b.sort ?? 0))
})

// Everything except the trailing CTA (rendered after FAQ).
const mainSections = computed(() => orderedSections.value.filter((s) => s.key !== 'cta'))
const ctaSection = computed(() => orderedSections.value.find((s) => s.key === 'cta') || null)

const heroCtas = computed(() => {
  const hero = orderedSections.value.find((s) => s.key === 'hero')
  return ((hero?.payload || {}) as HeroPayload).ctas ?? []
})
const primaryCta = computed(() => heroCtas.value[0])

function applyDocument(d: Landing, lang: Lang): void {
  applyTheme(d.theme)
  applySeo(d.seo, d.brand)
  setHtmlLang(lang)
}

async function load(lang: Lang): Promise<void> {
  loading.value = true
  locale.value = lang
  try {
    const d = await getLanding(lang)
    // Guard against a malformed/empty payload — fall back to defaults.
    if (!d || !Array.isArray(d.sections) || d.sections.length === 0) {
      throw new Error('empty landing payload')
    }
    data.value = d
    usingDefault.value = false
    applyDocument(d, lang)
  } catch {
    const d = defaultLanding(lang)
    data.value = d
    usingDefault.value = true
    applyDocument(d, lang)
  } finally {
    loading.value = false
  }
}

function onSwitchLang(lang: Lang): void {
  void load(lang)
}

onMounted(() => {
  // Initial language: ?lang=, then <html lang>, default zh.
  const param = new URLSearchParams(window.location.search).get('lang')
  const htmlLang = document.documentElement.getAttribute('lang')
  const initial: Lang = param === 'en' || htmlLang === 'en' ? 'en' : 'zh'
  void load(initial)
})
</script>

<template>
  <a class="skip-link" href="#main">Skip to content</a>

  <template v-if="data">
    <NavBar :brand="data.brand" :primary-cta="primaryCta" @switch-lang="onSwitchLang" />

    <p v-if="usingDefault" class="offline" role="status">{{ t('common.offline') }}</p>

    <main id="main">
      <SectionRenderer v-for="s in mainSections" :key="s.key" :section="s" />

      <FaqSection :items="data.faq" :title="'FAQ'" />

      <CtaSection v-if="ctaSection" :section="ctaSection" />
    </main>

    <SiteFooter :footer="data.footer" :brand="data.brand" />
  </template>

  <div v-else class="boot" aria-live="polite">{{ t('common.loading') }}</div>
</template>

<style scoped>
.boot {
  min-height: 60vh;
  display: grid;
  place-items: center;
  color: var(--text-muted);
}
.offline {
  margin: 0;
  text-align: center;
  font-size: 0.82rem;
  color: var(--text-muted);
  background: color-mix(in srgb, var(--amber) 10%, transparent);
  border-bottom: 1px solid color-mix(in srgb, var(--amber) 30%, transparent);
  padding: 6px 12px;
}
</style>
