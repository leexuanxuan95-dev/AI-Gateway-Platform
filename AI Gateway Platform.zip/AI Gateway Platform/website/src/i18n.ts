import { createI18n } from 'vue-i18n'

// UI chrome strings (nav, buttons, labels). Page *content* comes from the CMS
// payload per `lang`; i18n covers the surrounding shell so it stays localized
// even when falling back to baked-in defaults.
const messages = {
  zh: {
    nav: {
      features: '能力',
      how: '接入',
      models: '模型',
      pricing: '价格',
      faq: 'FAQ',
      cta: '免费获取 API Key',
      menu: '菜单',
    },
    code: { copy: '复制', copied: '已复制', changeTwoLines: '改两行' },
    models: { available: '可用', soon: '即将上线' },
    pricing: { recommended: '推荐' },
    common: { loading: '加载中…', offline: '正在使用默认内容（无法连接内容服务）。' },
    lang: { switch: '语言', zh: '中文', en: 'English' },
    console: { request: '请求', routed: '已路由', latency: '延迟' },
  },
  en: {
    nav: {
      features: 'Features',
      how: 'How',
      models: 'Models',
      pricing: 'Pricing',
      faq: 'FAQ',
      cta: 'Get a free API Key',
      menu: 'Menu',
    },
    code: { copy: 'Copy', copied: 'Copied', changeTwoLines: 'two lines' },
    models: { available: 'Available', soon: 'Coming soon' },
    pricing: { recommended: 'Recommended' },
    common: { loading: 'Loading…', offline: 'Showing default content (content service unreachable).' },
    lang: { switch: 'Language', zh: '中文', en: 'English' },
    console: { request: 'request', routed: 'routed', latency: 'latency' },
  },
}

export const i18n = createI18n({
  legacy: false,
  locale: 'zh',
  fallbackLocale: 'en',
  messages,
})
