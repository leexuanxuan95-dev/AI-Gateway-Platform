<script setup lang="ts">
import { computed } from 'vue'
import type { Section, ProvidersPayload } from '@/types'

const props = defineProps<{ section: Section }>()
const items = computed(() => ((props.section.payload || {}) as ProvidersPayload).items ?? [])
</script>

<template>
  <section v-if="items.length" id="providers" class="providers">
    <div class="container">
      <p class="providers__label">{{ section.title }}</p>
      <ul class="providers__list">
        <li v-for="name in items" :key="name" class="providers__item mono">{{ name }}</li>
      </ul>
    </div>
  </section>
</template>

<style scoped>
.providers {
  padding: 36px 0;
  border-top: 1px solid color-mix(in srgb, var(--border) 60%, transparent);
}
.providers__label {
  text-align: center;
  color: var(--text-muted);
  font-size: 0.82rem;
  letter-spacing: 0.08em;
  text-transform: uppercase;
  margin-bottom: 18px;
}
.providers__list {
  list-style: none;
  margin: 0;
  padding: 0;
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
  gap: 12px 14px;
}
.providers__item {
  border: 1px solid var(--border);
  border-radius: 999px;
  padding: 7px 16px;
  font-size: 0.85rem;
  color: var(--text);
  opacity: 0.85;
  transition: border-color 0.2s ease, opacity 0.2s ease;
}
.providers__item:hover {
  border-color: var(--mint);
  opacity: 1;
}
</style>
