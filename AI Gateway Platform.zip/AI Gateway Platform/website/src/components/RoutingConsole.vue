<script setup lang="ts">
// Signature Hero animation (design doc §5): an API request fans out to model
// chips; an amber "routed" highlight cycles between chips. Pure CSS/SVG, light.
// Honors prefers-reduced-motion (no cycling, static "routed" state).
import { onMounted, onBeforeUnmount, ref } from 'vue'
import { useI18n } from 'vue-i18n'

const { t } = useI18n()

const chips = [
  'claude-opus-4-8',
  'gpt-5',
  'gemini-2.5-pro',
  'grok-3',
  'deepseek-r1',
]

const active = ref(0)
let timer: number | undefined
const reduced =
  typeof window !== 'undefined' &&
  window.matchMedia &&
  window.matchMedia('(prefers-reduced-motion: reduce)').matches

onMounted(() => {
  if (reduced) {
    active.value = 0
    return
  }
  timer = window.setInterval(() => {
    active.value = (active.value + 1) % chips.length
  }, 1800)
})

onBeforeUnmount(() => {
  if (timer) window.clearInterval(timer)
})
</script>

<template>
  <div class="console" role="img" :aria-label="t('console.routed') + ': ' + chips[active]">
    <div class="console__bar">
      <span class="dot dot--r" /><span class="dot dot--a" /><span class="dot dot--m" />
      <span class="console__title mono">POST /v1/chat/completions</span>
    </div>

    <div class="console__body">
      <div class="console__req mono">
        <span class="kv"><span class="k">model</span>: <span class="v">"{{ chips[active] }}"</span></span>
        <span class="badge">{{ t('console.routed') }}</span>
      </div>

      <!-- fan-out lines -->
      <svg class="console__svg" viewBox="0 0 320 140" preserveAspectRatio="none" aria-hidden="true">
        <line
          v-for="(c, i) in chips"
          :key="i"
          x1="20"
          y1="70"
          x2="300"
          :y2="14 + i * 28"
          :class="['wire', { 'wire--on': i === active }]"
        />
        <circle cx="20" cy="70" r="5" class="origin" />
      </svg>

      <ul class="chips">
        <li v-for="(c, i) in chips" :key="c" :class="['chip', { 'chip--on': i === active }]">
          <span class="chip__dot" />
          <span class="mono chip__code">{{ c }}</span>
        </li>
      </ul>
    </div>
  </div>
</template>

<style scoped>
.console {
  background: color-mix(in srgb, var(--bg) 72%, #000 28%);
  border: 1px solid var(--border);
  border-radius: var(--radius);
  overflow: hidden;
  box-shadow: 0 24px 60px -30px rgba(0, 0, 0, 0.7);
}
.console__bar {
  display: flex;
  align-items: center;
  gap: 7px;
  padding: 12px 16px;
  border-bottom: 1px solid var(--border);
}
.dot {
  width: 10px;
  height: 10px;
  border-radius: 50%;
  display: inline-block;
}
.dot--r {
  background: #ff5f56;
}
.dot--a {
  background: var(--amber);
}
.dot--m {
  background: var(--mint);
}
.console__title {
  margin-left: 10px;
  font-size: 0.78rem;
  color: var(--text-muted);
}
.console__body {
  padding: 18px 18px 22px;
  position: relative;
}
.console__req {
  display: flex;
  align-items: center;
  justify-content: space-between;
  font-size: 0.86rem;
  margin-bottom: 14px;
}
.kv .k {
  color: var(--mint);
}
.kv .v {
  color: var(--amber);
}
.badge {
  background: color-mix(in srgb, var(--amber) 22%, transparent);
  color: var(--amber);
  border: 1px solid color-mix(in srgb, var(--amber) 45%, transparent);
  border-radius: 999px;
  padding: 2px 10px;
  font-size: 0.72rem;
  font-family: var(--font);
  font-weight: 600;
}
.console__svg {
  position: absolute;
  inset: 52px 18px auto;
  width: calc(100% - 36px);
  height: 140px;
  pointer-events: none;
}
.wire {
  stroke: var(--border);
  stroke-width: 1.4;
  transition: stroke 0.4s ease, stroke-width 0.4s ease;
}
.wire--on {
  stroke: var(--amber);
  stroke-width: 2.2;
}
.origin {
  fill: var(--mint);
}
.chips {
  list-style: none;
  margin: 0;
  padding: 0;
  display: flex;
  flex-direction: column;
  gap: 8px;
  position: relative;
  z-index: 1;
  margin-top: 2px;
}
.chip {
  display: flex;
  align-items: center;
  gap: 10px;
  align-self: flex-end;
  width: 78%;
  padding: 8px 12px;
  border: 1px solid var(--border);
  border-radius: 10px;
  background: color-mix(in srgb, var(--bg) 84%, #fff 5%);
  transition: border-color 0.3s ease, background 0.3s ease, transform 0.3s ease;
}
.chip--on {
  border-color: var(--amber);
  background: color-mix(in srgb, var(--amber) 12%, var(--bg));
  transform: translateX(-4px);
}
.chip__dot {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background: var(--border);
}
.chip--on .chip__dot {
  background: var(--amber);
}
.chip__code {
  font-size: 0.8rem;
}
</style>
