<script setup lang="ts">
import { computed } from 'vue'
import type { Section, CtaPayload } from '@/types'

const props = defineProps<{ section: Section }>()
const p = computed(() => (props.section.payload || {}) as CtaPayload)
</script>

<template>
  <section id="cta" class="section cta">
    <div class="container cta__inner">
      <h2 class="cta__title">{{ p.title || section.title }}</h2>
      <p v-if="p.subtitle || section.subtitle" class="cta__sub">{{ p.subtitle || section.subtitle }}</p>
      <a v-if="p.button" :href="p.button.href" class="btn btn--primary cta__btn">{{ p.button.text }}</a>
    </div>
  </section>
</template>

<style scoped>
.cta {
  text-align: center;
}
.cta__inner {
  max-width: 640px;
  background: color-mix(in srgb, var(--mint) 8%, var(--bg));
  border: 1px solid color-mix(in srgb, var(--mint) 30%, var(--border));
  border-radius: calc(var(--radius) + 6px);
  padding: 56px 32px;
}
.cta__title {
  font-size: clamp(1.6rem, 3.5vw, 2.4rem);
}
.cta__sub {
  color: var(--text-muted);
  font-size: 1.05rem;
  margin-bottom: 28px;
}
.cta__btn {
  font-size: 1.05rem;
  padding: 14px 30px;
}
</style>
