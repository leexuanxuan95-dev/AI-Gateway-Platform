<script setup lang="ts">
import { computed } from 'vue'
import type { Section, FeaturesPayload } from '@/types'
import IconGlyph from './IconGlyph.vue'

const props = defineProps<{ section: Section }>()
const cards = computed(() => ((props.section.payload || {}) as FeaturesPayload).cards ?? [])
</script>

<template>
  <section id="features" class="section">
    <div class="container">
      <div class="section__head">
        <h2 class="section__title">{{ section.title }}</h2>
        <p v-if="section.subtitle" class="section__subtitle">{{ section.subtitle }}</p>
      </div>
      <div class="grid grid--3">
        <article v-for="(c, i) in cards" :key="i" class="card feature">
          <span class="feature__icon"><IconGlyph :name="c.icon" /></span>
          <h3 class="feature__title">{{ c.title }}</h3>
          <p class="feature__desc">{{ c.desc }}</p>
        </article>
      </div>
    </div>
  </section>
</template>

<style scoped>
.feature__icon {
  display: inline-flex;
  width: 46px;
  height: 46px;
  align-items: center;
  justify-content: center;
  border-radius: 12px;
  background: color-mix(in srgb, var(--mint) 14%, transparent);
  color: var(--mint);
  margin-bottom: 16px;
}
.feature__title {
  font-size: 1.15rem;
  margin-bottom: 8px;
}
.feature__desc {
  color: var(--text-muted);
  margin: 0;
  font-size: 0.96rem;
}
</style>
