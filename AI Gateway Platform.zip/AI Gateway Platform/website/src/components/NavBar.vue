<script setup lang="ts">
import { ref } from 'vue'
import { useI18n } from 'vue-i18n'
import type { Brand, Lang } from '@/types'

defineProps<{ brand: Brand; primaryCta?: { text: string; href: string } }>()
const emit = defineEmits<{ (e: 'switch-lang', lang: Lang): void }>()

const { t, locale } = useI18n()
const mobileOpen = ref(false)

const links = [
  { key: 'features', href: '#features' },
  { key: 'how', href: '#how' },
  { key: 'models', href: '#models' },
  { key: 'pricing', href: '#pricing' },
  { key: 'faq', href: '#faq' },
]

function close(): void {
  mobileOpen.value = false
}

function setLang(lang: Lang): void {
  if (locale.value === lang) return
  emit('switch-lang', lang)
}
</script>

<template>
  <header class="nav">
    <div class="container nav__inner">
      <a href="#hero" class="nav__brand" @click="close">
        <span class="nav__logo" aria-hidden="true" />
        <span class="nav__name">{{ brand.name }}</span>
      </a>

      <nav class="nav__links" :aria-label="t('nav.menu')">
        <a v-for="l in links" :key="l.key" :href="l.href" class="nav__link">{{ t('nav.' + l.key) }}</a>
      </nav>

      <div class="nav__right">
        <div class="nav__lang" role="group" :aria-label="t('lang.switch')">
          <button :class="{ 'is-on': locale === 'zh' }" @click="setLang('zh')">{{ t('lang.zh') }}</button>
          <span aria-hidden="true">/</span>
          <button :class="{ 'is-on': locale === 'en' }" @click="setLang('en')">{{ t('lang.en') }}</button>
        </div>
        <a :href="primaryCta?.href || '/signup'" class="btn btn--primary nav__cta">
          {{ primaryCta?.text || t('nav.cta') }}
        </a>
        <button
          class="nav__burger"
          :aria-expanded="mobileOpen"
          :aria-label="t('nav.menu')"
          @click="mobileOpen = !mobileOpen"
        >
          <span /><span /><span />
        </button>
      </div>
    </div>

    <div v-show="mobileOpen" class="nav__mobile">
      <a v-for="l in links" :key="l.key" :href="l.href" class="nav__mlink" @click="close">
        {{ t('nav.' + l.key) }}
      </a>
      <a :href="primaryCta?.href || '/signup'" class="btn btn--primary" @click="close">
        {{ primaryCta?.text || t('nav.cta') }}
      </a>
    </div>
  </header>
</template>

<style scoped>
.nav {
  position: sticky;
  top: 0;
  z-index: 100;
  background: color-mix(in srgb, var(--bg) 82%, transparent);
  backdrop-filter: blur(12px);
  border-bottom: 1px solid color-mix(in srgb, var(--border) 70%, transparent);
}
.nav__inner {
  display: flex;
  align-items: center;
  justify-content: space-between;
  height: 64px;
}
.nav__brand {
  display: flex;
  align-items: center;
  gap: 10px;
  font-family: var(--font);
  font-weight: 700;
  font-size: 1.15rem;
}
.nav__logo {
  width: 22px;
  height: 22px;
  border-radius: 6px;
  background: linear-gradient(135deg, var(--mint), var(--amber));
}
.nav__links {
  display: flex;
  gap: 26px;
}
.nav__link {
  color: var(--text-muted);
  font-size: 0.94rem;
  transition: color 0.15s ease;
}
.nav__link:hover {
  color: var(--text);
}
.nav__right {
  display: flex;
  align-items: center;
  gap: 16px;
}
.nav__lang {
  display: flex;
  align-items: center;
  gap: 4px;
  color: var(--text-muted);
  font-size: 0.86rem;
}
.nav__lang button {
  background: none;
  border: none;
  color: inherit;
  cursor: pointer;
  font-size: inherit;
  padding: 2px 4px;
}
.nav__lang button.is-on {
  color: var(--mint);
  font-weight: 600;
}
.nav__burger {
  display: none;
  flex-direction: column;
  gap: 5px;
  background: none;
  border: none;
  cursor: pointer;
  padding: 6px;
}
.nav__burger span {
  width: 22px;
  height: 2px;
  background: var(--text);
  display: block;
}
.nav__mobile {
  display: none;
}
@media (max-width: 860px) {
  .nav__links {
    display: none;
  }
  .nav__cta {
    display: none;
  }
  .nav__burger {
    display: flex;
  }
  .nav__mobile {
    display: flex;
    flex-direction: column;
    gap: 14px;
    padding: 18px 24px 24px;
    border-top: 1px solid var(--border);
  }
  .nav__mlink {
    color: var(--text);
    font-size: 1rem;
  }
}
</style>
