<script setup lang="ts">
import type { Footer, Brand } from '@/types'

defineProps<{ footer: Footer; brand: Brand }>()
</script>

<template>
  <footer class="footer">
    <div class="container footer__inner">
      <div class="footer__brand">
        <span class="footer__name">{{ brand.name }}</span>
        <span v-if="brand.domain" class="footer__domain mono">{{ brand.domain }}</span>
      </div>

      <div class="footer__groups">
        <div v-for="g in footer.groups" :key="g.title" class="footer__group">
          <h4 class="footer__gtitle">{{ g.title }}</h4>
          <ul>
            <li v-for="l in g.links" :key="l.text">
              <a :href="l.href">{{ l.text }}</a>
            </li>
          </ul>
        </div>
      </div>
    </div>

    <div class="container footer__bottom">
      <span>{{ footer.copyright || brand.copyright }}</span>
      <a v-if="footer.icp || brand.icp" href="https://beian.miit.gov.cn" target="_blank" rel="noopener">
        {{ footer.icp || brand.icp }}
      </a>
    </div>
  </footer>
</template>

<style scoped>
.footer {
  border-top: 1px solid var(--border);
  padding: 56px 0 28px;
  margin-top: 24px;
}
.footer__inner {
  display: flex;
  justify-content: space-between;
  gap: 48px;
  flex-wrap: wrap;
}
.footer__brand {
  display: flex;
  flex-direction: column;
  gap: 6px;
}
.footer__name {
  font-family: var(--font);
  font-weight: 700;
  font-size: 1.2rem;
}
.footer__domain {
  color: var(--text-muted);
  font-size: 0.85rem;
}
.footer__groups {
  display: flex;
  gap: 56px;
  flex-wrap: wrap;
}
.footer__gtitle {
  font-size: 0.82rem;
  text-transform: uppercase;
  letter-spacing: 0.08em;
  color: var(--text-muted);
  margin-bottom: 14px;
}
.footer__group ul {
  list-style: none;
  margin: 0;
  padding: 0;
  display: flex;
  flex-direction: column;
  gap: 10px;
}
.footer__group a {
  color: var(--text);
  font-size: 0.92rem;
  opacity: 0.82;
}
.footer__group a:hover {
  opacity: 1;
  color: var(--mint);
}
.footer__bottom {
  display: flex;
  justify-content: space-between;
  gap: 16px;
  flex-wrap: wrap;
  margin-top: 40px;
  padding-top: 22px;
  border-top: 1px solid color-mix(in srgb, var(--border) 60%, transparent);
  color: var(--text-muted);
  font-size: 0.84rem;
}
.footer__bottom a {
  color: var(--text-muted);
}
@media (max-width: 620px) {
  .footer__groups {
    gap: 32px;
  }
}
</style>
