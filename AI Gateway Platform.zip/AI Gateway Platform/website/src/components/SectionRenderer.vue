<script setup lang="ts">
// Maps a section.key -> its component. Unknown keys render nothing.
// (FAQ + Footer are rendered by App.vue from top-level fields, not via a section.)
import type { Section } from '@/types'
import HeroSection from './HeroSection.vue'
import ProvidersSection from './ProvidersSection.vue'
import FeaturesSection from './FeaturesSection.vue'
import HowSection from './HowSection.vue'
import CodeSection from './CodeSection.vue'
import ModelsSection from './ModelsSection.vue'
import PricingSection from './PricingSection.vue'
import SecuritySection from './SecuritySection.vue'
import CtaSection from './CtaSection.vue'
import type { Component } from 'vue'

defineProps<{ section: Section }>()

const registry: Record<string, Component> = {
  hero: HeroSection,
  providers: ProvidersSection,
  features: FeaturesSection,
  how: HowSection,
  code: CodeSection,
  models: ModelsSection,
  pricing: PricingSection,
  security: SecuritySection,
  cta: CtaSection,
}

function resolve(key: string): Component | null {
  return registry[key] ?? null
}
</script>

<template>
  <component :is="resolve(section.key)" v-if="resolve(section.key)" :section="section" />
</template>
