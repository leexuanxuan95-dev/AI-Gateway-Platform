<script setup lang="ts">
import { computed } from 'vue'
import { useI18n } from 'vue-i18n'
import type { Section, PricingPayload, Plan } from '@/types'

const props = defineProps<{ section: Section }>()
const { t } = useI18n()

const p = computed(() => (props.section.payload || {}) as PricingPayload)
const plans = computed(() => p.value.plans ?? [])
const highlightKey = computed(() => (p.value.highlight ?? '').toLowerCase())

// A plan is highlighted via its own `highlight` flag OR by matching the
// section-level `highlight` key against the plan name (e.g. "pro").
function isHighlight(plan: Plan): boolean {
  if (plan.highlight) return true
  if (!highlightKey.value) return false
  return plan.name.toLowerCase().includes(highlightKey.value)
}
</script>

<template>
  <section id="pricing" class="section">
    <div class="container">
      <div class="section__head">
        <h2 class="section__title">{{ section.title }}</h2>
        <p v-if="section.subtitle" class="section__subtitle">{{ section.subtitle }}</p>
      </div>

      <div class="grid grid--4 pricing">
        <article
          v-for="(plan, i) in plans"
          :key="i"
          class="card plan"
          :class="{ 'plan--hl': isHighlight(plan) }"
        >
          <span v-if="isHighlight(plan)" class="plan__ribbon">{{ t('pricing.recommended') }}</span>
          <h3 class="plan__name">{{ plan.name }}</h3>
          <div class="plan__price">
            <span class="plan__amount mono">{{ plan.currency }}{{ plan.price }}</span>
            <span v-if="plan.period" class="plan__period">{{ plan.period }}</span>
          </div>
          <ul class="plan__features">
            <li v-for="f in plan.features ?? []" :key="f">{{ f }}</li>
          </ul>
          <a
            v-if="plan.cta"
            :href="plan.cta.href"
            class="btn plan__cta"
            :class="isHighlight(plan) ? 'btn--primary' : 'btn--ghost'"
          >
            {{ plan.cta.text }}
          </a>
        </article>
      </div>
    </div>
  </section>
</template>

<style scoped>
.plan {
  position: relative;
  display: flex;
  flex-direction: column;
}
.plan--hl {
  border-color: var(--amber);
  box-shadow: 0 0 0 1px var(--amber), 0 20px 50px -30px color-mix(in srgb, var(--amber) 60%, transparent);
}
.plan__ribbon {
  position: absolute;
  top: -11px;
  right: 16px;
  background: var(--amber);
  color: #1a1206;
  font-family: var(--font);
  font-weight: 600;
  font-size: 0.72rem;
  border-radius: 999px;
  padding: 3px 12px;
}
.plan__name {
  font-size: 1.1rem;
  margin-bottom: 10px;
}
.plan__price {
  display: flex;
  align-items: baseline;
  gap: 4px;
  margin-bottom: 18px;
}
.plan__amount {
  font-size: 1.9rem;
  font-weight: 600;
  color: var(--text);
}
.plan__period {
  color: var(--text-muted);
  font-size: 0.9rem;
}
.plan__features {
  list-style: none;
  margin: 0 0 22px;
  padding: 0;
  display: flex;
  flex-direction: column;
  gap: 9px;
  flex: 1;
}
.plan__features li {
  position: relative;
  padding-left: 22px;
  color: var(--text-muted);
  font-size: 0.92rem;
}
.plan__features li::before {
  content: '';
  position: absolute;
  left: 0;
  top: 0.45em;
  width: 12px;
  height: 6px;
  border-left: 2px solid var(--mint);
  border-bottom: 2px solid var(--mint);
  transform: rotate(-45deg);
}
.plan__cta {
  width: 100%;
}
</style>
