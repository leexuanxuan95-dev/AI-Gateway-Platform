<script setup lang="ts">
import { computed } from 'vue'
import type { Section, HowPayload } from '@/types'

const props = defineProps<{ section: Section }>()
const steps = computed(() => ((props.section.payload || {}) as HowPayload).steps ?? [])
</script>

<template>
  <section id="how" class="section">
    <div class="container">
      <div class="section__head">
        <h2 class="section__title">{{ section.title }}</h2>
        <p v-if="section.subtitle" class="section__subtitle">{{ section.subtitle }}</p>
      </div>
      <ol class="grid grid--4 steps">
        <li v-for="(s, i) in steps" :key="i" class="card step">
          <span class="step__no mono">{{ s.no ?? i + 1 }}</span>
          <h3 class="step__title">{{ s.title }}</h3>
          <p class="step__desc">{{ s.desc }}</p>
        </li>
      </ol>
    </div>
  </section>
</template>

<style scoped>
.steps {
  list-style: none;
  padding: 0;
  margin: 0;
  counter-reset: none;
}
.step__no {
  display: inline-block;
  color: var(--amber);
  font-size: 1.6rem;
  font-weight: 600;
  margin-bottom: 12px;
}
.step__title {
  font-size: 1.08rem;
  margin-bottom: 6px;
}
.step__desc {
  color: var(--text-muted);
  margin: 0;
  font-size: 0.94rem;
}
</style>
