<script setup lang="ts">
import { computed } from 'vue'
import type { Section, HeroPayload } from '@/types'
import RoutingConsole from './RoutingConsole.vue'

const props = defineProps<{ section: Section }>()
const p = computed(() => (props.section.payload || {}) as HeroPayload)
const ctas = computed(() => p.value.ctas ?? [])
const badges = computed(() => p.value.badges ?? [])
const showConsole = computed(() => p.value.showConsole !== false)
</script>

<template>
  <section id="hero" class="hero">
    <div class="container hero__grid" :class="{ 'hero__grid--full': !showConsole }">
      <div class="hero__copy">
        <h1 class="hero__title">{{ section.title }}</h1>
        <p class="hero__sub">{{ p.subtitle }}</p>

        <div class="hero__ctas">
          <a
            v-for="(c, i) in ctas"
            :key="i"
            :href="c.href"
            class="btn"
            :class="i === 0 ? 'btn--primary' : 'btn--ghost'"
          >
            {{ c.text }}
          </a>
        </div>

        <ul v-if="badges.length" class="hero__badges">
          <li v-for="b in badges" :key="b">{{ b }}</li>
        </ul>
      </div>

      <div v-if="showConsole" class="hero__visual">
        <RoutingConsole />
      </div>
    </div>
  </section>
</template>

<style scoped>
.hero {
  padding: 96px 0 72px;
  position: relative;
  overflow: hidden;
}
.hero::before {
  content: '';
  position: absolute;
  inset: -20% 30% auto -10%;
  height: 60%;
  background: radial-gradient(
    closest-side,
    color-mix(in srgb, var(--mint) 16%, transparent),
    transparent
  );
  pointer-events: none;
  filter: blur(20px);
}
.hero__grid {
  display: grid;
  grid-template-columns: 1.05fr 0.95fr;
  gap: 48px;
  align-items: center;
  position: relative;
}
.hero__grid--full {
  grid-template-columns: 1fr;
  max-width: 820px;
  text-align: center;
}
.hero__grid--full .hero__ctas,
.hero__grid--full .hero__badges {
  justify-content: center;
}
.hero__title {
  font-size: clamp(2.1rem, 5vw, 3.4rem);
  margin-bottom: 18px;
}
.hero__sub {
  color: var(--text-muted);
  font-size: 1.12rem;
  max-width: 56ch;
}
.hero__ctas {
  display: flex;
  gap: 14px;
  flex-wrap: wrap;
  margin: 28px 0 22px;
}
.hero__badges {
  list-style: none;
  display: flex;
  flex-wrap: wrap;
  gap: 10px 18px;
  padding: 0;
  margin: 0;
  color: var(--text-muted);
  font-size: 0.9rem;
}
.hero__badges li {
  position: relative;
  padding-left: 16px;
}
.hero__badges li::before {
  content: '';
  position: absolute;
  left: 0;
  top: 0.6em;
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background: var(--mint);
}
@media (max-width: 900px) {
  .hero__grid {
    grid-template-columns: 1fr;
  }
  .hero__visual {
    order: -1;
  }
}
</style>
