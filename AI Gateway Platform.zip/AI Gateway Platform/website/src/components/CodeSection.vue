<script setup lang="ts">
import { computed, ref } from 'vue'
import { useI18n } from 'vue-i18n'
import type { Section, CodePayload } from '@/types'

const props = defineProps<{ section: Section }>()
const { t } = useI18n()

const p = computed(() => (props.section.payload || {}) as CodePayload)
const tabs = computed(() => p.value.tabs ?? [])
const activeIdx = ref(0)
const copied = ref(false)

const activeCode = computed(() => tabs.value[activeIdx.value]?.code ?? '')

// Highlight the "改两行 / two lines" comment lines so the drop-in story pops.
const HINT = /(#\s*改这一行.*|#\s*change this line.*|\/\/\s*改这一行.*|\/\/\s*change this line.*)/

function lineClass(line: string): string {
  return HINT.test(line) ? 'code__line code__line--hl' : 'code__line'
}

async function copy(): Promise<void> {
  try {
    await navigator.clipboard.writeText(activeCode.value)
    copied.value = true
    window.setTimeout(() => (copied.value = false), 1600)
  } catch {
    /* clipboard unavailable; no-op */
  }
}
</script>

<template>
  <section id="code" class="section">
    <div class="container">
      <div class="section__head">
        <h2 class="section__title">{{ section.title }}</h2>
        <p v-if="section.subtitle" class="section__subtitle">{{ section.subtitle }}</p>
      </div>

      <div class="code">
        <div class="code__bar">
          <div class="code__tabs" role="tablist" :aria-label="section.title">
            <button
              v-for="(tab, i) in tabs"
              :key="tab.lang"
              role="tab"
              :aria-selected="i === activeIdx"
              :class="['code__tab', { 'code__tab--on': i === activeIdx }]"
              @click="activeIdx = i"
            >
              {{ tab.lang }}
            </button>
          </div>
          <button class="code__copy" type="button" @click="copy">
            {{ copied ? t('code.copied') : t('code.copy') }}
          </button>
        </div>

        <pre class="code__pre"><code><span
          v-for="(line, i) in activeCode.split('\n')"
          :key="i"
          :class="lineClass(line)"
        >{{ line }}
</span></code></pre>
      </div>
    </div>
  </section>
</template>

<style scoped>
.code {
  max-width: 880px;
  margin: 0 auto;
  border: 1px solid var(--border);
  border-radius: var(--radius);
  overflow: hidden;
  background: color-mix(in srgb, var(--bg) 74%, #000 26%);
}
.code__bar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  border-bottom: 1px solid var(--border);
  padding: 6px 10px;
}
.code__tabs {
  display: flex;
  gap: 4px;
}
.code__tab {
  background: transparent;
  border: none;
  color: var(--text-muted);
  font-family: var(--font);
  font-size: 0.86rem;
  font-weight: 600;
  padding: 8px 14px;
  border-radius: 8px;
  cursor: pointer;
}
.code__tab--on {
  color: var(--text);
  background: color-mix(in srgb, var(--mint) 14%, transparent);
}
.code__copy {
  background: transparent;
  border: 1px solid var(--border);
  color: var(--text);
  border-radius: 8px;
  padding: 6px 14px;
  font-size: 0.82rem;
  cursor: pointer;
}
.code__copy:hover {
  border-color: var(--mint);
  color: var(--mint);
}
.code__pre {
  margin: 0;
  padding: 18px 20px;
  overflow-x: auto;
  font-size: 0.86rem;
  line-height: 1.65;
}
.code__line {
  display: block;
}
.code__line--hl {
  background: color-mix(in srgb, var(--amber) 16%, transparent);
  box-shadow: inset 3px 0 0 var(--amber);
  color: var(--amber);
  padding-left: 6px;
  margin-left: -6px;
}
</style>
