<script setup lang="ts">
import { computed } from 'vue'
import { useI18n } from 'vue-i18n'
import type { Section, ModelsPayload } from '@/types'

const props = defineProps<{ section: Section }>()
const { t } = useI18n()
const families = computed(() => ((props.section.payload || {}) as ModelsPayload).families ?? [])
</script>

<template>
  <section id="models" class="section">
    <div class="container">
      <div class="section__head">
        <h2 class="section__title">{{ section.title }}</h2>
        <p v-if="section.subtitle" class="section__subtitle">{{ section.subtitle }}</p>
      </div>

      <div class="grid grid--3">
        <article v-for="fam in families" :key="fam.family" class="card models__fam">
          <h3 class="models__family">{{ fam.family }}</h3>
          <ul class="models__versions">
            <li
              v-for="v in fam.versions ?? []"
              :key="v.code"
              class="models__ver"
              :class="{ 'models__ver--off': v.available === false }"
            >
              <div class="models__head">
                <span class="models__name">{{ v.name || v.code }}</span>
                <span
                  class="models__status"
                  :class="v.available === false ? 'is-soon' : 'is-on'"
                >
                  {{ v.available === false ? t('models.soon') : t('models.available') }}
                </span>
              </div>
              <code class="models__code mono">{{ v.code }}</code>
              <span v-if="v.tagline" class="models__tag">{{ v.tagline }}</span>
            </li>
          </ul>
        </article>
      </div>
    </div>
  </section>
</template>

<style scoped>
.models__family {
  font-size: 1.1rem;
  margin-bottom: 14px;
  color: var(--mint);
}
.models__versions {
  list-style: none;
  margin: 0;
  padding: 0;
  display: flex;
  flex-direction: column;
  gap: 12px;
}
.models__ver {
  border: 1px solid var(--border);
  border-radius: 10px;
  padding: 10px 12px;
}
.models__ver--off {
  opacity: 0.55;
}
.models__head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 4px;
}
.models__name {
  font-family: var(--font);
  font-weight: 600;
}
.models__status {
  font-size: 0.68rem;
  font-weight: 600;
  border-radius: 999px;
  padding: 1px 8px;
}
.is-on {
  color: var(--mint);
  border: 1px solid color-mix(in srgb, var(--mint) 45%, transparent);
}
.is-soon {
  color: var(--text-muted);
  border: 1px solid var(--border);
}
.models__code {
  display: block;
  font-size: 0.78rem;
  color: var(--amber);
}
.models__tag {
  font-size: 0.82rem;
  color: var(--text-muted);
}
</style>
