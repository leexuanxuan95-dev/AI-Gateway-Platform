<script setup lang="ts">
import { computed } from 'vue'
import type { Section, SecurityPayload } from '@/types'
import IconGlyph from './IconGlyph.vue'

const props = defineProps<{ section: Section }>()
const cards = computed(() => ((props.section.payload || {}) as SecurityPayload).cards ?? [])
</script>

<template>
  <section id="security" class="section">
    <div class="container">
      <div class="section__head">
        <h2 class="section__title">{{ section.title }}</h2>
        <p v-if="section.subtitle" class="section__subtitle">{{ section.subtitle }}</p>
      </div>
      <div class="grid grid--4">
        <article v-for="(c, i) in cards" :key="i" class="card sec">
          <span class="sec__icon"><IconGlyph :name="c.icon" /></span>
          <h3 class="sec__title">{{ c.title }}</h3>
          <p class="sec__desc">{{ c.desc }}</p>
        </article>
      </div>
    </div>
  </section>
</template>

<style scoped>
.sec__icon {
  display: inline-flex;
  width: 42px;
  height: 42px;
  align-items: center;
  justify-content: center;
  border-radius: 11px;
  background: color-mix(in srgb, var(--amber) 14%, transparent);
  color: var(--amber);
  margin-bottom: 14px;
}
.sec__title {
  font-size: 1.04rem;
  margin-bottom: 6px;
}
.sec__desc {
  color: var(--text-muted);
  font-size: 0.92rem;
  margin: 0;
}
</style>
