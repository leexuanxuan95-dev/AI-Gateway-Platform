<script setup lang="ts">
// Tiny inline-SVG icon set keyed by name (matches the `icon` strings in payloads).
// Unknown names fall back to a neutral dot so cards never break.
import { computed } from 'vue'

const props = defineProps<{ name?: string; size?: number }>()
const s = computed(() => props.size ?? 26)

const paths: Record<string, string> = {
  hub: 'M12 2v4M12 18v4M2 12h4M18 12h4M5 5l3 3M16 16l3 3M19 5l-3 3M8 16l-3 3',
  swap: 'M7 7h11l-3-3M17 17H6l3 3',
  meter: 'M12 14a2 2 0 1 0 0-4 2 2 0 0 0 0 4zM12 12l4-4M4 20a8 8 0 1 1 16 0',
  'shield-bolt': 'M12 3l7 3v5c0 4-3 7-7 9-4-2-7-5-7-9V6l7-3zM12 8l-2 4h3l-1 4',
  building: 'M4 21V5l8-3 8 3v16M9 9h.01M15 9h.01M9 13h.01M15 13h.01M9 17h6',
  card: 'M3 7h18v10H3zM3 11h18',
  key: 'M14 8a4 4 0 1 0-3.5 6L13 17l2 2 2-2 1-1-1-1 1-1-1-1 1-1z',
  lock: 'M6 11V8a6 6 0 0 1 12 0v3M5 11h14v9H5z',
  partition: 'M12 3v18M4 7h6M4 12h6M4 17h6M14 9h6M14 15h6',
  freeze: 'M12 2v20M2 12h20M5 5l14 14M19 5L5 19',
}

const d = computed(() => paths[props.name ?? ''] ?? 'M12 12h.01')
</script>

<template>
  <svg
    :width="s"
    :height="s"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    stroke-width="1.6"
    stroke-linecap="round"
    stroke-linejoin="round"
    aria-hidden="true"
    focusable="false"
  >
    <path :d="d" />
  </svg>
</template>
