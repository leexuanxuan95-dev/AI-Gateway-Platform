<script setup lang="ts">
import { ref } from 'vue'
import type { FaqItem } from '@/types'

const props = defineProps<{ items: FaqItem[]; title?: string }>()

// Default-open the first item (design doc §3).
const open = ref<number>(props.items.length ? 0 : -1)

function toggle(i: number): void {
  open.value = open.value === i ? -1 : i
}
</script>

<template>
  <section v-if="items.length" id="faq" class="section">
    <div class="container faq">
      <div class="section__head">
        <h2 class="section__title">{{ title || 'FAQ' }}</h2>
      </div>
      <ul class="faq__list">
        <li v-for="(item, i) in items" :key="i" class="faq__item">
          <button
            class="faq__q"
            :aria-expanded="open === i"
            :aria-controls="`faq-a-${i}`"
            @click="toggle(i)"
          >
            <span>{{ item.q }}</span>
            <span class="faq__sign" :class="{ 'faq__sign--open': open === i }" aria-hidden="true">+</span>
          </button>
          <div v-show="open === i" :id="`faq-a-${i}`" class="faq__a" role="region">
            {{ item.a }}
          </div>
        </li>
      </ul>
    </div>
  </section>
</template>

<style scoped>
.faq {
  max-width: 760px;
}
.faq__list {
  list-style: none;
  margin: 0;
  padding: 0;
}
.faq__item {
  border-bottom: 1px solid var(--border);
}
.faq__q {
  width: 100%;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 16px;
  background: transparent;
  border: none;
  color: var(--text);
  font-family: var(--font);
  font-weight: 600;
  font-size: 1.02rem;
  text-align: left;
  padding: 20px 4px;
  cursor: pointer;
}
.faq__sign {
  color: var(--mint);
  font-size: 1.4rem;
  line-height: 1;
  transition: transform 0.2s ease;
}
.faq__sign--open {
  transform: rotate(45deg);
}
.faq__a {
  color: var(--text-muted);
  padding: 0 4px 22px;
  font-size: 0.97rem;
}
</style>
