// Typed model of the Landing CMS payload returned by GET /api/site/landing?lang=zh
// Mirrors the design doc §4.3. Each section's `payload` is loosely typed per `key`;
// components consume only the fields they understand and ignore unknown keys.

export interface Brand {
  name: string
  logo?: string
  domain?: string
  copyright?: string
  icp?: string
}

export interface Seo {
  title: string
  description?: string
  keywords?: string
  ogImage?: string
}

export interface Theme {
  bg?: string
  amber?: string
  mint?: string
  text?: string
  border?: string
  font?: string
  radius?: string
}

export interface Cta {
  text: string
  href: string
}

export interface FaqItem {
  q: string
  a: string
}

export interface FooterLink {
  text: string
  href: string
}

export interface FooterGroup {
  title: string
  links: FooterLink[]
}

export interface Footer {
  groups: FooterGroup[]
  copyright?: string
  icp?: string
}

// ---- Section payloads (discriminated loosely by `key`) ----

export interface HeroPayload {
  subtitle?: string
  ctas?: Cta[]
  badges?: string[]
  showConsole?: boolean
}

export interface ProvidersPayload {
  items?: string[]
}

export interface FeatureCard {
  icon?: string
  title: string
  desc?: string
}
export interface FeaturesPayload {
  cards?: FeatureCard[]
}

export interface HowStep {
  no?: string | number
  title: string
  desc?: string
}
export interface HowPayload {
  steps?: HowStep[]
}

export interface CodeTab {
  lang: string
  code: string
}
export interface CodePayload {
  tabs?: CodeTab[]
  domainVar?: string
}

export interface ModelVersion {
  code: string
  name?: string
  tagline?: string
  available?: boolean
}
export interface ModelFamily {
  family: string
  versions?: ModelVersion[]
}
export interface ModelsPayload {
  families?: ModelFamily[]
}

export interface Plan {
  name: string
  price: string | number
  currency?: string
  period?: string
  features?: string[]
  cta?: Cta
  highlight?: boolean
}
export interface PricingPayload {
  highlight?: string
  plans?: Plan[]
}

export interface SecurityCard {
  icon?: string
  title: string
  desc?: string
}
export interface SecurityPayload {
  cards?: SecurityCard[]
}

export interface CtaPayload {
  title?: string
  subtitle?: string
  button?: Cta
}

export type SectionKey =
  | 'hero'
  | 'providers'
  | 'features'
  | 'how'
  | 'code'
  | 'models'
  | 'pricing'
  | 'security'
  | 'cta'

// Generic payload bag — concrete shape depends on `key`.
export type SectionPayload =
  | HeroPayload
  | ProvidersPayload
  | FeaturesPayload
  | HowPayload
  | CodePayload
  | ModelsPayload
  | PricingPayload
  | SecurityPayload
  | CtaPayload
  | Record<string, unknown>

export interface Section {
  key: string
  enabled?: boolean
  sort?: number
  title?: string
  subtitle?: string
  bind_source?: string
  payload?: SectionPayload
}

export interface Landing {
  brand: Brand
  seo: Seo
  theme: Theme
  sections: Section[]
  faq: FaqItem[]
  footer: Footer
}

export type Lang = 'zh' | 'en'
