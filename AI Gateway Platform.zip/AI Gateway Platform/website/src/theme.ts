import type { Theme } from '@/types'

// Maps theme tokens from the CMS to CSS custom properties on :root.
// styles.css consumes these via var(--bg) etc. Defaults match the OmniRoute brand.
const FALLBACK: Required<Theme> = {
  bg: '#0B1719',
  amber: '#F6B53C',
  mint: '#57E3BE',
  text: '#E8F1EF',
  border: '#21454B',
  font: "'Space Grotesk', 'Noto Sans SC', system-ui, sans-serif",
  radius: '14px',
}

export function applyTheme(theme: Theme | undefined): void {
  const t = { ...FALLBACK, ...(theme || {}) }
  const root = document.documentElement
  root.style.setProperty('--bg', t.bg)
  root.style.setProperty('--amber', t.amber)
  root.style.setProperty('--mint', t.mint)
  root.style.setProperty('--text', t.text)
  root.style.setProperty('--border', t.border)
  root.style.setProperty('--font', t.font)
  root.style.setProperty('--radius', t.radius)
}
